const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('posFiles',{save:args=>ipcRenderer.invoke('pos:save-backup',args)});
