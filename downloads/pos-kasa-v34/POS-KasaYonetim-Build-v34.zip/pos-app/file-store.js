const fs=require('fs/promises');const crypto=require('crypto');
async function writeVerified(filePath,text){
 if(typeof text!=='string'||Buffer.byteLength(text,'utf8')>15000000)throw Error('Yedek boş veya 15 MB sınırını aşıyor.');
 const temp=filePath+'.'+crypto.randomUUID()+'.tmp',buffer=Buffer.from(text,'utf8');let handle;
 try{handle=await fs.open(temp,'wx');await handle.writeFile(buffer);await handle.sync();await handle.close();handle=null;if(!(await fs.readFile(temp)).equals(buffer))throw Error('Geçici dosya doğrulanamadı.');await fs.rename(temp,filePath);if(!(await fs.readFile(filePath)).equals(buffer))throw Error('Kaydedilen dosya doğrulanamadı.');return {saved:true};}
 finally{if(handle)await handle.close().catch(()=>{});await fs.unlink(temp).catch(()=>{});}
}
module.exports={writeVerified};
