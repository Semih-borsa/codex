import assert from 'node:assert/strict';import fs from 'node:fs';import {fileURLToPath} from 'node:url';
const {_electron}=await import(process.env.PLAYWRIGHT_MODULE||'playwright-core');
const root=fileURLToPath(new URL('../pos-app/',import.meta.url));
const profile=fileURLToPath(new URL('../native-v32-profile/',import.meta.url));
const app=await _electron.launch({executablePath:process.env.ELECTRON_PATH||root+'node_modules/electron/dist/electron',args:[root+'main.js','--no-sandbox','--ozone-platform=headless','--user-data-dir='+profile],env:{...process.env,XDG_CACHE_HOME:profile+'cache'}});
try{const page=await app.firstWindow();await page.waitForLoadState();
await page.evaluate(()=>{localStorage.clear();localStorage.setItem('pos:cfg',JSON.stringify({bankalar:[{id:'b',ad:'TEST'}],kasalar:[{id:'k',ad:'Test',kod:'1',bankaId:'b',toplamModu:true}],vadeGunleri:{'KREDİ KARTI':0,'DEBİT KART':0},kasaYapim:{kasaSayisi:1,kupurler:[]}}));localStorage.setItem('pos:txs','[]');});await page.reload();
await page.evaluate(()=>{
const row=(id,tur,tutar,date)=>({id,kasaId:'k',bankaId:'b',islemTarihi:'2026-01-01',yatacakTarih:date,tur,tutar});
localStorage.setItem('pos:txs',JSON.stringify([row('old','KREDİ KARTI',1000,'2026-01-10'),row('now','KREDİ KARTI',1500,'2026-01-17'),{...row('g-kredi','KREDİ KARTI',2500,'2026-03-22'),islemTarihi:'2026-03-01',mutabakatId:'g',posToplam:3000},{...row('g-debit','DEBİT KART',500,'2026-03-17'),islemTarihi:'2026-03-01',mutabakatId:'g',tahsilEdildi:true}]));const cfg=JSON.parse(localStorage.getItem('pos:cfg'));cfg.vadeGunleri={'KREDİ KARTI':21,'DEBİT KART':16};localStorage.setItem('pos:cfg',JSON.stringify(cfg));});await page.reload();
await page.getByLabel('Takip tarihi').fill('2026-01-17');const pct=page.getByLabel('Kredi haftalık değişim',{exact:true});assert.equal(await pct.getAttribute('data-weekly-state'),'artis');assert.match(await pct.innerText(),/%50/);await page.getByLabel('Takip tarihi').fill('2026-01-18');assert.equal(await pct.getAttribute('data-weekly-state'),'eksik');
await page.getByRole('button',{name:/GİRİŞ/}).click();await page.locator('[data-tx-id="g-kredi"]').getByLabel('İşlemi düzenle',{exact:true}).click();await page.getByLabel('Düzenlenen POS günü').fill('2026-03-02');assert.equal(await page.getByLabel('Düzenlenen kredi vadesi').inputValue(),'2026-03-23');assert.equal(await page.getByLabel('Düzenlenen debit tarihi 1').inputValue(),'2026-03-17');await page.getByRole('button',{name:'Toplam değişikliğini kaydet',exact:true}).click();await page.getByRole('button',{name:'Kapat',exact:true}).click();await page.reload();
const rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows.find(t=>t.id==='g-kredi').yatacakTarih,'2026-03-23');assert.equal(rows.find(t=>t.id==='g-debit').yatacakTarih,'2026-03-17');

console.log('PASS v32 native Electron: weekly percentage/missing-base display, grouped sale-date auto credit due, actual debit date preservation and persisted reload. Synthetic isolated profile only.');
}finally{await app.close();fs.rmSync(profile,{recursive:true,force:true});}
