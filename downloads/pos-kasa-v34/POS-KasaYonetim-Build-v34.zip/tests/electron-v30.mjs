import assert from 'node:assert/strict';import fs from 'node:fs';import {fileURLToPath} from 'node:url';
const {_electron}=await import(process.env.PLAYWRIGHT_MODULE||'playwright-core');
const root=fileURLToPath(new URL('../pos-app/',import.meta.url));
const profile=fileURLToPath(new URL('../native-v30-profile/',import.meta.url));
const app=await _electron.launch({executablePath:process.env.ELECTRON_PATH||root+'node_modules/electron/dist/electron',args:[root+'main.js','--no-sandbox','--ozone-platform=headless','--user-data-dir='+profile],env:{...process.env,XDG_CACHE_HOME:profile+'cache'}});
try{const page=await app.firstWindow();await page.waitForLoadState();
await page.evaluate(()=>{localStorage.clear();localStorage.setItem('pos:cfg',JSON.stringify({bankalar:[{id:'b',ad:'TEST'}],kasalar:[{id:'k',ad:'Test',kod:'1',bankaId:'b',toplamModu:true}],vadeGunleri:{'KREDİ KARTI':0,'DEBİT KART':0},kasaYapim:{kasaSayisi:1,kupurler:[]}}));localStorage.setItem('pos:txs','[]');});await page.reload();
await page.getByRole('button',{name:/GİRİŞ/}).click();
const dates=await page.evaluate(()=>{const shift=n=>{const d=new Date();d.setDate(d.getDate()+n);return d.toLocaleDateString('sv-SE');};return {today:shift(0),yesterday:shift(-1)};});
assert.equal(await page.getByLabel('POS işlem günü',{exact:true}).inputValue(),dates.yesterday);await page.getByLabel('Toplam POS kasası').selectOption('k');await page.getByLabel('POS işlem günü',{exact:true}).fill(dates.today);await page.getByLabel('Toplam POS tutarı').fill('3053,50');await page.getByRole('button',{name:'Toplamı kaydet',exact:true}).click();
await page.getByLabel('Yatış kasası').selectOption('k');assert.equal(await page.getByLabel('Yeni debit yatış tarihi').inputValue(),dates.today);await page.getByLabel('Yeni debit tutarı').fill('1000,25');await page.getByRole('button',{name:'Yatan debiti kaydet',exact:true}).click();assert.equal(await page.getByLabel('Yeni debit tutarı').inputValue(),'');
let rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows.find(t=>t.posToplam!=null).tutar,2053.25);assert.equal(rows.find(t=>t.tur==='DEBİT KART').yatacakTarih,dates.today);assert.equal(rows.find(t=>t.tur==='DEBİT KART').islemTarihi,dates.today);
await page.reload();await page.getByRole('button',{name:/GİRİŞ/}).click();assert.equal(await page.getByLabel('POS işlem günü',{exact:true}).inputValue(),dates.yesterday);assert.equal(await page.getByLabel('Yeni debit yatış tarihi').inputValue(),dates.today);rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows.find(t=>t.posToplam!=null).tutar,2053.25);

console.log('PASS v30: native Electron yesterday/today defaults, configured zero-day matching, fresh debit append, amount clear, remaining credit and reload persistence. Synthetic isolated profile only.');
}finally{await app.close();fs.rmSync(profile,{recursive:true,force:true});}
