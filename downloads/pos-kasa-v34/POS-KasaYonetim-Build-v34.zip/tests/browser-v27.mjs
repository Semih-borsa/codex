// Run with PLAYWRIGHT_MODULE pointing to the installed playwright-core ESM entry.
import fs from 'node:fs';import http from 'node:http';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE||'playwright-core');
const root=fileURLToPath(new URL('../pos-app/',import.meta.url));
const server=http.createServer((q,r)=>{const p=path.join(root,q.url==='/'?'index.html':q.url);if(!fs.existsSync(p)){r.statusCode=404;r.end();return;}r.setHeader('Content-Type',p.endsWith('.js')?'text/javascript':p.endsWith('.css')?'text/css':p.endsWith('.png')?'image/png':'text/html');r.end(fs.readFileSync(p));});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
try{
const page=await browser.newPage({viewport:{width:1500,height:1100}}),errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
await page.addInitScript(()=>{if(localStorage.getItem('pos:cfg'))return;localStorage.setItem('pos:cfg',JSON.stringify({bankalar:[{id:'b',ad:'TEST'}],kasalar:[{id:'k',ad:'Test',kod:'1',bankaId:'b',toplamModu:true}],vadeGunleri:{'KREDİ KARTI':0,'DEBİT KART':0},kasaYapim:{kasaSayisi:1,kupurler:[]}}));localStorage.setItem('pos:txs','[]');});
await page.goto(`http://127.0.0.1:${server.address().port}`);await page.getByRole('button',{name:/GİRİŞ/}).click();
const total=page.getByLabel('Toplam POS tutarı'),save=page.getByRole('button',{name:'Toplamı kaydet',exact:true}),debitSave=page.getByRole('button',{name:'Debitleri kaydet',exact:true});
assert.equal(await debitSave.isDisabled(),true);await page.getByLabel('Toplam POS kasası').selectOption('k');
for(const value of ['3053,50','3053.50','3.053,50']){
 await total.fill(value);await total.blur();assert.equal(await total.inputValue(),'3.053,50');await save.click();await page.getByRole('status').waitFor();
 const rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows.length,1);assert.equal(rows[0].posToplam,3053.5);assert.equal(rows[0].tutar,3053.5);
}
await page.getByRole('button',{name:'+ Yatan debit ekle',exact:true}).click();await page.getByLabel('Debit tutarı 1').fill('1000,25');await page.getByLabel('Debit tutarı 1').blur();assert.equal(await page.getByLabel('Debit tutarı 1').inputValue(),'1.000,25');
// Total save must not accidentally save a debit draft.
await save.click();assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')).length),1);
await debitSave.click();let rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows[0].tutar,2053.25);assert.equal(rows[1].tutar,1000.25);
// Debit save uses the saved total, not an unsaved total draft.
await total.fill('9999');await debitSave.click();rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows[0].posToplam,3053.5);assert.equal(rows[0].tutar,2053.25);
await page.reload();await page.getByRole('button',{name:/GİRİŞ/}).click();await page.getByLabel('Toplam POS kaydı').selectOption(rows[0].mutabakatId);assert.equal(await total.inputValue(),'3.053,50');assert.equal(await page.getByLabel('Debit tutarı 1').inputValue(),'1.000,25');
const before=await page.evaluate(()=>localStorage.getItem('pos:txs'));await total.fill('500');await save.click();await page.getByRole('alert').waitFor();assert.equal(await page.evaluate(()=>localStorage.getItem('pos:txs')),before);
await total.fill('4000');await save.click();await page.getByRole('button',{name:'Kaldır',exact:true}).click();await debitSave.click();rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows.length,1);assert.equal(rows[0].tutar,4000);assert.deepEqual(errors,[]);
console.log('PASS: three amount formats, Turkish display, separate total/debit persistence, draft isolation, reload, overpayment rejection, debit removal; no React errors.');
}finally{await browser.close();server.close();}
