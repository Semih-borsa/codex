// Run with PLAYWRIGHT_MODULE pointing to the installed playwright-core ESM entry.
import fs from 'node:fs';import http from 'node:http';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE||'playwright-core');
const root=fileURLToPath(new URL('../pos-app/',import.meta.url));
const server=http.createServer((q,r)=>{const p=path.join(root,q.url==='/'?'index.html':q.url);if(!fs.existsSync(p)){r.statusCode=404;r.end();return;}r.setHeader('Content-Type',p.endsWith('.js')?'text/javascript':p.endsWith('.css')?'text/css':p.endsWith('.png')?'image/png':'text/html');r.end(fs.readFileSync(p));});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
try{
const page=await browser.newPage({viewport:{width:1500,height:1100}}),errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
await page.addInitScript(()=>{
const cfg={bankalar:[{id:'b',ad:'TEST'}],kasalar:['a','b','c'].map(id=>({id,ad:'Kasa '+id,kod:id,bankaId:'b',toplamModu:true})),vadeGunleri:{'KREDİ KARTI':0,'DEBİT KART':0},kasaYapim:{kasaSayisi:1,kupurler:[]}};
const txs=[['a1','a','2026-01-01',4000],['b1','b','2026-01-01',5000],['b2','b','2026-01-02',6000]].map(([id,kasaId,date,total])=>({id:id+'-kredi',kasaId,bankaId:'b',islemTarihi:date,yatacakTarih:date,tur:'KREDİ KARTI',tutar:total,posToplam:total,mutabakatId:id}));
localStorage.setItem('pos:cfg',JSON.stringify(cfg));localStorage.setItem('pos:txs',JSON.stringify(txs));
});
await page.goto(`http://127.0.0.1:${server.address().port}`);await page.getByRole('button',{name:/GİRİŞ/}).click();
const kasa=page.getByLabel('Debit kasası'),record=page.getByLabel('Debit POS kaydı'),save=page.getByRole('button',{name:'Debitleri kaydet',exact:true});
assert.equal(await save.isDisabled(),true);await kasa.selectOption('a');assert.equal(await record.inputValue(),'a1');assert.equal(await save.isEnabled(),true);
await page.getByRole('button',{name:'+ Yatan debit ekle',exact:true}).click();await page.getByLabel('Debit tutarı 1').fill('3053,50');await page.getByLabel('Debit tarihi 1').fill('2026-01-03');await save.click();
let rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows.find(t=>t.mutabakatId==='a1'&&t.posToplam!=null).tutar,946.5);assert.equal(rows.find(t=>t.mutabakatId==='b1').tutar,5000);
await kasa.selectOption('b');assert.equal(await save.isDisabled(),true);assert.equal(await record.inputValue(),'');assert.equal(await record.locator('option').count(),3);await record.selectOption('b2');assert.equal(await save.isEnabled(),true);
await page.getByRole('button',{name:'+ Yatan debit ekle',exact:true}).click();await page.getByLabel('Debit tutarı 1').fill('1000');await page.getByLabel('Debit tarihi 1').fill('2026-01-03');
// Declining a record switch keeps the draft intact.
await page.getByLabel('Debit tutarı 1').blur();const draftBeforeSwitch=await page.getByLabel('Debit tutarı 1').inputValue();assert.equal(draftBeforeSwitch,'1.000,00');page.removeAllListeners('dialog');page.once('dialog',d=>d.dismiss());await kasa.selectOption('a');assert.equal(await kasa.inputValue(),'b');assert.equal(await record.inputValue(),'b2');assert.equal(await page.getByLabel('Debit tutarı 1').inputValue(),draftBeforeSwitch);await save.click();
rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows.find(t=>t.mutabakatId==='b2'&&t.posToplam!=null).tutar,5000);assert.equal(rows.find(t=>t.mutabakatId==='b1').tutar,5000);
await kasa.selectOption('c');assert.equal(await save.isDisabled(),true);assert.equal(await page.getByRole('button',{name:'+ Yatan debit ekle',exact:true}).isDisabled(),true);assert.match(await page.getByRole('status').innerText(),/kayıtlı POS toplamı yok/);assert.deepEqual(errors,[]);
console.log('PASS: lower kasa selection, automatic unique record, explicit multi-date selection, correct group update, draft cancel preservation, missing-total guidance and disabled input; no React errors.');
}finally{await browser.close();server.close();}
