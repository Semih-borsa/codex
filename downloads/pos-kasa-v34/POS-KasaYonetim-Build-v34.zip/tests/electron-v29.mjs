import assert from 'node:assert/strict';import fs from 'node:fs';import {fileURLToPath} from 'node:url';
const {_electron}=await import(process.env.PLAYWRIGHT_MODULE||'playwright-core');
const root=fileURLToPath(new URL('../pos-app/',import.meta.url));
const profile=fileURLToPath(new URL('../native-test-profile/',import.meta.url));
const app=await _electron.launch({executablePath:process.env.ELECTRON_PATH||root+'node_modules/electron/dist/electron',args:[root+'main.js','--no-sandbox','--ozone-platform=headless','--user-data-dir='+profile],env:{...process.env,XDG_CACHE_HOME:profile+'cache'}});
try{const page=await app.firstWindow();await page.waitForLoadState();
await page.evaluate(()=>{localStorage.clear();localStorage.setItem('pos:cfg',JSON.stringify({bankalar:[{id:'b',ad:'TEST'}],kasalar:[{id:'k',ad:'Test',kod:'1',bankaId:'b',toplamModu:true}],vadeGunleri:{'KREDİ KARTI':0,'DEBİT KART':0},kasaYapim:{kasaSayisi:1,kupurler:[]}}));localStorage.setItem('pos:txs','[]');});await page.reload();
await page.getByRole('button',{name:/GİRİŞ/}).click();await page.getByLabel('Debit kasası').selectOption('k');const day=page.getByLabel('Debit POS günü');assert.equal(await day.isEnabled(),true);await day.fill('2026-01-01');assert.equal(await day.inputValue(),'2026-01-01');assert.equal(await page.getByLabel('Debit POS kaydı').isEnabled(),true);
await page.getByLabel('Toplam POS tutarı').fill('3053,50');await page.getByRole('button',{name:'Toplamı kaydet',exact:true}).click();await page.getByRole('button',{name:'+ Yatan debit ekle',exact:true}).click();const receipt=page.getByLabel('Debit tarihi 1');assert.equal(await receipt.isEnabled(),true);await receipt.fill('2026-01-02');await page.getByLabel('Debit tutarı 1').fill('1000,25');await page.getByRole('button',{name:'Debitleri kaydet',exact:true}).click();
let rows=await page.evaluate(()=>JSON.parse(localStorage.getItem('pos:txs')));assert.equal(rows.find(t=>t.posToplam!=null).tutar,2053.25);assert.equal(rows.find(t=>t.tur==='DEBİT KART').yatacakTarih,'2026-01-02');
await page.reload();await page.getByRole('button',{name:/GİRİŞ/}).click();await page.getByLabel('Debit kasası').selectOption('k');assert.equal(await day.inputValue(),'2026-01-01');assert.equal(await receipt.inputValue(),'2026-01-02');
console.log('PASS: native Electron file origin, empty kasa date entry, new POS total, bank receipt date, remaining credit and reload persistence. Synthetic isolated profile only.');
}finally{await app.close();fs.rmSync(profile,{recursive:true,force:true});}
