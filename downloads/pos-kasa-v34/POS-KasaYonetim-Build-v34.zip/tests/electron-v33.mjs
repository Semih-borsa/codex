import assert from 'node:assert/strict';import fs from 'node:fs';import {fileURLToPath} from 'node:url';
const {_electron}=await import(process.env.PLAYWRIGHT_MODULE||'playwright-core');
const root=fileURLToPath(new URL('../pos-app/',import.meta.url));
const profile=fileURLToPath(new URL('../native-v33-profile/',import.meta.url));
const app=await _electron.launch({executablePath:process.env.ELECTRON_PATH||root+'node_modules/electron/dist/electron',args:[root+'main.js','--no-sandbox','--ozone-platform=headless','--user-data-dir='+profile],env:{...process.env,XDG_CACHE_HOME:profile+'cache'}});
try{const page=await app.firstWindow();await page.waitForLoadState();
await page.evaluate(()=>{localStorage.clear();localStorage.setItem('pos:cfg',JSON.stringify({bankalar:[{id:'b',ad:'TEST'}],kasalar:[{id:'k',ad:'Test',kod:'1',bankaId:'b',toplamModu:true}],vadeGunleri:{'KREDİ KARTI':0,'DEBİT KART':0},kasaYapim:{kasaSayisi:1,kupurler:[]}}));localStorage.setItem('pos:txs','[]');});await page.reload();
await page.evaluate(()=>{const shift=n=>{const d=new Date();d.setDate(d.getDate()+n);return d.toLocaleDateString('sv-SE');};const today=shift(0),first=today.slice(0,7)+'-01',lastMonth=new Date(first+'T12:00:00');lastMonth.setDate(0);const prev=lastMonth.toLocaleDateString('sv-SE');
const row=(id,day,tutar)=>({id,kasaId:'k',bankaId:'b',islemTarihi:day,yatacakTarih:day,tur:'KREDİ KARTI',tutar});localStorage.setItem('pos:txs',JSON.stringify([row('now',today,100),row('old',shift(-7),80)]));localStorage.setItem('pos:odemeler',JSON.stringify([{id:'current',ad:'Kira',tutar:200,sonOdeme:today,odendi:true},{id:'old',ad:'Kira',tutar:100,sonOdeme:prev,odendi:true}]));});await page.reload();
const today=await page.evaluate(()=>new Date().toLocaleDateString('sv-SE'));assert.match(await page.getByLabel('POS analiz toplamı').innerText(),/100,00/);assert.equal(await page.locator('[data-pos-bar]').count(),7);const group=page.locator(`[data-payment-month="${today.slice(0,7)}"]`);assert.equal(await group.getByRole('button').first().getAttribute('aria-expanded'),'true');assert.ok(await page.locator('[data-payment-id="current"]').isVisible());assert.equal(await page.locator('[data-payment-id="old"]').count(),0);
await page.getByLabel('POS analiz başlangıç').fill(today);await page.getByLabel('POS analiz bitiş').fill(today);await page.getByRole('button',{name:'Uygula',exact:true}).click();assert.match(await page.getByLabel('POS analiz günlük ortalama').innerText(),/100,00/);assert.match(await page.getByLabel('Ödeme kısa yorumları').innerText(),/%100 arttı/);

const locale=await app.evaluate(({app})=>app.getLocale());assert.ok(locale.startsWith('tr'));console.log('Electron locale: '+locale);
console.log('PASS v33 native Electron: thin weekday graph, custom range, current-month-only payments and short expense comparison; synthetic isolated profile only.');
}finally{await app.close();fs.rmSync(profile,{recursive:true,force:true});}
