# FİRMA ÖDEME SİSTEMİ — Kullanım ve Kurulum

Tek programda: vadesi gelen borç hesaplama + ödenecek tutar düzenleme + C3 ve BANKAYA FORMAT
Excel çıktısı + haftalık geçmiş arşivi. Girdiğin veriler (ödemeler, bankadaki tutar) programı
kapatsan da kalır; sadece HESAPLA'ya basınca yeniden hesaplanır.

## Kurulum

**Hazırlık (bir kez):** Bilgisayarında Python olmalı (python.org, kurarken "Add Python to PATH"
işaretle). Başka hiçbir program gerekmez.

1. Zip'i bir klasöre çıkar (örn. `C:\Users\HP\FirmaOdeme`).
2. **`1-TEST-CALISTIR.bat`** → programı test amaçlı açar (ilk seferde kütüphaneleri kurar).
3. **`2-KURULUM-OLUSTUR.bat`** → programı `.exe` yapar ve **bilgisayara kurar**:
   - Program `%LOCALAPPDATA%\Programs\FirmaOdemeSistemi` klasörüne kopyalanır,
   - **Masaüstü** ve **Başlat menüsü** kısayolları oluşturulur (ek program gerekmez).
   - (İstersen Inno Setup 6 kuruluysa onun Türkçe kurulum sihirbazı .exe'sini üretir; şart değil.)
4. Masaüstündeki **"Firma Odeme Sistemi"** kısayolundan aç.

> Kaldırmak için: `%LOCALAPPDATA%\Programs\FirmaOdemeSistemi` klasörünü ve iki kısayolu sil.
> Verilerin (ayarlar, firma bilgileri, geçmiş arşiv) `%LOCALAPPDATA%\FirmaOdemeSistemi`
> klasöründe ayrı tutulur; program güncellense/yeniden kurulsa da kaybolmaz.

> Not: "Inno Setup bulunamadı" yazısı **hata değildir** — o durumda program yine kısayolla
> düzgün kurulur. Sadece süslü kurulum sihirbazı ekranı yerine doğrudan kurulum yapılır.

## Çalışma akışı
Üstteki **dosya kartlarına** tıklayarak dosya seç (yüklenince kart yeşile döner, dosya adı görünür).
1. **📂 Firma Bilgileri** → `FİRMA BİLGİLERİ.xlsx` (bir kez yükle, kalıcı kalır).
2. **📊 Toplam Borç** → firma toplam borç dosyası.
3. **🔄 Toplu Cari Hareket Raporu** → hareket dosyası.
4. **⚡ HESAPLA** → Vadesi Gelen ve 15 Gün Geçen hesaplanır.
5. **Ödenecek Tutar** sütunu düzenlenebilir (varsayılan = Vadesi Gelen).
6. **BANKADAKİ TUTAR** kutusuna hesaptaki parayı yaz → **FARK** otomatik.
   Tüm tutarlar `1.023.258,45` biçiminde (binlik nokta, ondalık virgül) gösterilir.
7. **💾 Kaydet** (üst bar) ile o anki durumu kaydedebilirsin; kapatınca da otomatik kaydeder.





## Fatura Bazlı Öde (yeni)
Vadesi Gelen tablosunda bir firmanın üzerine **sağ tıkla** → **📄 Fatura Bazlı Öde**.
- O firmanın Toplu Cari Hareket Raporu'ndaki faturalarından **sadece hâlâ ödenmemiş kalanlar** listelenir: **vadesi gelmemiş faturalar hiç gösterilmez**; ayrıca fatura toplamı firmanın hesaplanan Vadesi Gelen tutarından fazlaysa (yani bazı eski faturalar zaten ödenmiş demektir), aradaki fark standart cari hesap mantığıyla **en eski faturalardan düşülür** (önce en eski borç kapanır) — böylece listede kalan faturaların toplamı Vadesi Gelen tutarına eşit olur. Tam ortasına denk gelen bir fatura varsa **kalan tutarıyla, turuncu 'kısmi ödenmiş' notuyla** gösterilir.
- Sıra: **en eski üstte, en yeni altta**, tarih ve tutarıyla.
- Ödemek istediğin faturaları işaretle, **seçilen toplam** anlık görünür.
- **Ödenecek Tutara Uygula**'ya basınca o firmanın Ödenecek Tutar'ı seçtiğin faturaların toplamına eşitlenir.
- Seçilen toplam, firmanın hesaplanan Vadesi Gelen tutarından fazla çıkarsa bilgi notu gösterilir (yine de izin verilir) — çünkü fatura tutarları brüt işlemlerdir, firmanın güncel bakiyesiyle birebir örtüşmeyebilir.
- Hareket dosyasında faturası bulunamayan firmalarda menü seçeneği **pasif** görünür.

## Eşit Dağıt (yeni)
HESAPLA'dan sonra **BANKADAKİ TUTAR**'ı yaz, sağdaki **⚖️ Eşit Dağıt** düğmesine bas:
1. **"Bankada ne kadar bırakmak istiyorsunuz?"** diye sorar (örn. 10.000). Dağıtılacak bütçe = Bankadaki − bırakılacak.
2. **"Ödeme yapmak istemediğiniz firma var mı?"** diye sorar. *Evet* dersen vadesi gelen borcu olan firmalar kutucuklu listede gelir; seçtiklerinin ödenecek tutarı **0** olur, para diğerlerine dağıtılır. (Arama kutusu ve 'Seçimi Temizle' vardır.)
3. **"Tamamı ödenecek firma var mı?"** diye sorar (peşinler zaten tam ödenir). *Evet* dersen listeden seçtiğin firmaların **vadesi gelen borcunun tamamı** ödenir; kalan para diğerlerine orantılı dağıtılır. Bütçe yetmezse uyarır.
4. Dağıtım sırası:
   - **Peşin firmalar** → tamamı (öncelikli)
   - **"Tamamı ödensin" seçtiklerin** → tamamı
   - **Vadesi geleni sınır ve altı** olanlar → tamamı (varsayılan sınır 5.000 ₺; Ayarlar → ⚖️ Eşit Dağıt Ayarı'ndan değiştirilebilir)
   - **Kalan para** → borcu sınırın üstünde olanlara: önce **vadesi 15 gün geçen (gecikmiş) tutarlar öncelikli** ödenir (bir firmanın gecikmiş borcu orantılı payından fazlaysa gecikmişin tamamı ödenir), sonra artan para geri kalan borca **orantılı** dağıtılır
5. Sonunda özet gösterilir (dağıtılan, bankada kalan, kaç firma). Tutarları tablodan elle düzenlemeye devam edebilirsin.
Kara listedeki firmalar dağıtıma girmez (hep 0). Kimse borcundan fazlasını almaz.

> Tüm uyarı/onay pencerelerinin butonları Türkçedir (Evet / Hayır / Tamam / Vazgeç).


### 🟢 Sadece Peşinleri Öde
Eşit Dağıt'ın altındaki bu düğme, **yalnızca peşin firmaların** vadesi gelen borcunun tamamını öder; diğer tüm firmaların ödenecek tutarını **0** yapar. Onay ekranında kaç firma, toplam ne kadar ve bankada ne kadar kalacağı gösterilir; bankadaki tutar yetersizse uyarır. Kara listedekiler yine 0 kalır.

## Kara Liste (yeni)
Ayarlar → **🚫 Kara Liste** alanına eklediğin firmaların **ödenecek tutarı, borç ne olursa olsun 0 gelir** (peşin firmalar gibi cari kodla ekle/çıkar).
- HESAPLA'ya basınca, hesaplanan listede kara listeden firma varsa **uyarı** çıkar.
  - **Hayır** → hepsi kara listede kalır (ödenecek 0).
  - **Evet** → birden fazlaysa hangilerini çıkaracağını **işaretlersin**; seçtiklerin kara listeden **kalıcı** silinip normal işlenir, diğerleri 0 kalır.
- Vadesi Gelen tablosunda: **🟢 peşin firmalar**, **🔴 kara liste** yuvarlağıyla işaretlenir.
- Kara firmalar ödenecek 0 olduğu için BANKAYA/C3 çıktılarına girmez.

## Vade kesim günü seçici (yeni)
HESAPLA'nın solundaki **Vade kesimi** kutusundan hangi güne kadar vadesi gelen borcun hesaplanacağını seçebilirsin:
- **Bu Pazar (varsayılan)** — eskisiyle birebir aynı mantık; bu haftanın pazarı dahil.
- **Sonraki Pazar** — bir sonraki haftanın pazarına kadar (dahil) vadesi geleni gösterir.
- **Belirli tarih** — takvimden seçtiğin gün dahil vadesi gelen borcu hesaplar (örn. çarşamba).
Seçim sadece hesaplamayı etkiler; varsayılan davranış değişmez. HESAPLA sonrası durum çubuğunda hangi kesim gününün kullanıldığı yazar.

## Sekmeler (hepsi program içinde)
- **📊 Vadesi Gelen** — firma tablosu + yarım daire Ödeme Yüzdesi + KPI'lar.
- **📑 C3 (Muhasebe)** — tek dosya/tek sayfa; firma sayısı sınırsız. Excel'e aktar.
- **🏦 BANKAYA FORMAT** — talimat başlığı (14pt) + iki yana yaslı girintili metin (12pt) +
  imzalar (12pt) + liste. Her 50 firmada yeni sayfa (51 → sayfa 2, 101 → sayfa 3).
  Veri satır yüksekliği 27, yatay A4 tek sayfa. Excel'e aktar.
- **📋 Geçmiş Listeler** — "Bu Listeyi Arşivle" ile o anki listeyi (kime ne borç, ne kadar
  ödendi, yüzde kaç) tarih damgasıyla saklar. İstediğinde geçmiş haftalara dönüp bakabilir,
  seçince firma bazında detayını görürsün, gerektiğinde silersin.
- **📈 Yıllık Performans** — arşivlenen tüm haftalardan firma bazında özet çıkarır.
  **Bakiye kümülatif olduğu için** (bu hafta ödenmeyen borç gelecek haftaya taşınır) haftalık
  "Vadesi Gelen" tutarları toplanmaz — bu, yanlışlıkla aynı borcu birden çok kez saymak
  olurdu. Bunun yerine:
  - **Toplam Ödenen** → haftalar arası gerçekten toplanır (gerçek nakit çıkışı).
  - **İlk Bakiye / Son Bakiye** → sadece yılın başındaki ve en son görülen bakiye (anlık durum).
  - **Ort. Ödeme %** → haftalık yüzdelerin ortalaması.
  - **⚠️ Kronik uyarı listesi** → en son haftadan geriye doğru art arda ödenmeyen firmalar
    ayrı, öne çıkan bir tabloda kırmızıyla gösterilir — "geçen hafta ödenmeyen bu hafta da
    duruyor" durumunu gizlemek yerine görünür kılar. Excel'e aktarılabilir.

## Veri dosyaları (kullanıcı klasöründe)
`settings.json` (ayarlar), `ek_firmalar.json` (elle eklenen firmalar),
`firma_bilgileri.json` (firma önbelleği), `oturum.json` (son çalışma), `arsiv.json` (geçmiş).
