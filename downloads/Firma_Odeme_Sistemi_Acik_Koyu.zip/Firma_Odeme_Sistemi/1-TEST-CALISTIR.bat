@echo off
chcp 65001 >nul
cd /d "%~dp0"
call "0-ORTAM-HAZIRLA.bat"
if errorlevel 1 goto HATA
".venv\Scripts\python.exe" firma_odeme_sistemi.py
if errorlevel 1 goto HATA
exit /b 0
:HATA
echo HATA: Yukaridaki mesaji kontrol edin.
pause
exit /b 1
