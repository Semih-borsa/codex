# Firma Odeme Sistemi - basit kurulum (ek program gerektirmez)
$ErrorActionPreference = "Stop"
$src = Join-Path $PSScriptRoot "dist\FirmaOdemeSistemi"
if (-not (Test-Path $src)) {
    Write-Host "HATA: dist\FirmaOdemeSistemi bulunamadi. Once derleme yapilmali."
    exit 1
}
$dst = Join-Path $env:LOCALAPPDATA "Programs\FirmaOdemeSistemi"
Write-Host "Program kuruluyor: $dst"
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Copy-Item -Path (Join-Path $src '*') -Destination $dst -Recurse -Force
$exe = Join-Path $dst "FirmaOdemeSistemi.exe"

$ws = New-Object -ComObject WScript.Shell
$desk = [Environment]::GetFolderPath("Desktop")
$l1 = $ws.CreateShortcut((Join-Path $desk "Firma Odeme Sistemi.lnk"))
$l1.TargetPath = $exe; $l1.WorkingDirectory = $dst; $l1.IconLocation = $exe; $l1.Save()

$sm = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
$l2 = $ws.CreateShortcut((Join-Path $sm "Firma Odeme Sistemi.lnk"))
$l2.TargetPath = $exe; $l2.WorkingDirectory = $dst; $l2.IconLocation = $exe; $l2.Save()

Write-Host ""
Write-Host "KURULDU. Masaustunde ve Baslat menusunde 'Firma Odeme Sistemi' kisayolu olustu."
Write-Host "Kaldirmak icin: $dst klasorunu ve iki kisayolu silmeniz yeterli."
