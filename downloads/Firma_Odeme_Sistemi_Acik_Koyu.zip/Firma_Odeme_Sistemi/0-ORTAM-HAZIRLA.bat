@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto INSTALL
where py >nul 2>nul
if errorlevel 1 goto PYTHON
py -3 -m venv .venv
if errorlevel 1 exit /b 1
goto INSTALL
:PYTHON
python -m venv .venv
if errorlevel 1 (
 echo HATA: Python bulunamadi. Python 3.12 veya 3.13 kurun; Add Python to PATH secin.
 exit /b 1
)
:INSTALL
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
exit /b 0
