# Yıllık Performans incelemesi

Hesaplama mantığı değiştirilmedi. Mevcut kaynak fonksiyon örnek arşivlerle çalıştırıldı.

## Doğrulanan davranış

- Yıl filtresi `tarih` alanının son dört karakteriyle çalışır; uygulamanın
  ürettiği `gg.aa.yyyy` formatında doğru sonuç verir.
- Borç bakiyeleri toplanmaz; firmanın ilk ve son arşivde görülen bakiyesi kullanılır.
- Ödeme yüzdesi, vadesi gelen borcu pozitif olan kayıtların yüzdelerinin
  basit ortalamasıdır. Her kayıt eşit ağırlıktadır; %100 üzeri oranlar %100'e kırpılır.
- Örnek: 100 TL borca 100 TL planlanan ödeme ve 900 TL borca 0 TL ödeme
  için mevcut gösterge %50 çıkar. Toplam tutar üzerinden oran %10 olur.
  %50, basit ortalama tanımı için doğrudur; yılın toplam borcunun %50'si ödendi anlamına gelmez.

## Önemli sınırlamalar / yanlış yorum riski

1. **Toplam Ödenen banka onayı değildir.** Arşivlenen `odenecek` değerlerini toplar.
   Banka dekontu, ödeme gerçekleşme durumu veya ayrı ödeme hareketi kontrol edilmez.
   Bu nedenle gerçekte ödenen yıllık tutar olarak tek başına doğrulanamaz.
2. **Hafta Sayısı aslında kayıt sayısıdır.** Takvim haftaları gruplanmaz.
   5 Ocak ve 6 Ocak 2026 tarihli iki kayıt aynı haftada olmasına rağmen 2 hafta sayılır.
   Aynı gün arşiv ekleme ekranı eski kaydı değiştirmeyi önerir; farklı günlerde
   aynı planın yeniden arşivlenmesi için tekilleştirme yoktur.
   Fonksiyona mükerrer kayıt girerse ödeme tutarı da yeniden toplanır.
3. **Kronik uyarı arka arkaya eksik ödenen kayıtları sayar.** Hiç ödeme yapılmamış
   olmak zorunda değildir: `vadesi_gelen - odenecek > 1 TL` yeterlidir.
   Takvim haftası boşlukları veya firmanın bulunmadığı arşivler dikkate alınmaz.
   Bu nedenle “art arda ödenmeyen hafta” etiketi sonucu tam açıklamaz.
4. İlk/son bakiye, ödeme sonrası bankadan teyit edilmiş bakiye değildir;
   arşivdeki anlık planın bakiye alanıdır. Kayıtlar kimlik alanına göre sıralanır;
   uygulamanın ürettiği YYYYMMDD_HHMMSS kimliklerinde tarih sırası doğrudur.

Bu sınırlamalar UI yenilemesinden önce de vardı. Kullanıcının yalnızca inceleme
isteği ve hesaplamayı koruma talimatı nedeniyle iş kuralları değiştirilmedi.
Düzeltme yapılacaksa önce “planlanan ödeme / gerçekleşen ödeme”, “kayıt / hafta”
ve “basit / tutar ağırlıklı ortalama” tanımları kararlaştırılmalıdır.

## Arayüz ve koruma kontrolleri

- Açık ve koyu temalarda sekmeler ve yüzde göstergeleri çalıştırıldı.
- Ödeme renkleri: %50 altı kırmızı; %50 dahil %80 altı sarı; %80 dahil yeşil.
- Tabloda yuvarlanmış görünen yüzde yerine gerçek oran renk seçimi için kullanılır.
- Tema geçişi ödeme tutarlarını değiştirmedi.
- Kaynak AST karşılaştırmasında 35 arayüz dışı üst seviye fonksiyon/sınıf değişmedi.
- Borç, dağıtım, arşiv ve dışa aktarım iş kuralları korundu; mevcut ödeme düzenleme
  işleyişine yalnızca çizim için yüzde bilgisi eklendi.
- Vadesi Gelen, C3, banka ve performans Excel üretimi örnek verilerle geçti.
- Windows kurulum / EXE derleme Linux ortamında doğrulanamadı.
