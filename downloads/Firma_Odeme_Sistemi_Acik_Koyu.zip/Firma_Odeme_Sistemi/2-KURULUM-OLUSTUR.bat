@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === Firma Odeme Sistemi - Acik ve Koyu Tema ===
call "0-ORTAM-HAZIRLA.bat"
if errorlevel 1 goto HATA
".venv\Scripts\python.exe" -m pip install pyinstaller==6.16.0
if errorlevel 1 goto HATA
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --windowed --clean --name "FirmaOdemeSistemi" --icon=icon.ico --add-data "icon.png;." --add-data "settings.json;." --add-data "ek_firmalar.json;." firma_odeme_sistemi.py
if errorlevel 1 goto HATA
if not exist "dist\FirmaOdemeSistemi\FirmaOdemeSistemi.exe" goto HATA
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if defined ISCC goto SETUP
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kur-kisayol.ps1"
if errorlevel 1 goto HATA
echo TAMAMLANDI. Masaustundeki Firma Odeme Sistemi kisayolundan acin.
goto SON
:SETUP
"%ISCC%" kurulum.iss
if errorlevel 1 goto HATA
echo Kurulum hazir: kurulum-cikti\FirmaOdemeSistemi-Kurulum.exe
echo Bu dosyayi calistirarak kurulumu tamamlayin.
start "" "kurulum-cikti"
goto SON
:HATA
echo HATA: Islem tamamlanamadi. Yukaridaki mesaji kontrol edin.
pause
exit /b 1
:SON
pause
exit /b 0
