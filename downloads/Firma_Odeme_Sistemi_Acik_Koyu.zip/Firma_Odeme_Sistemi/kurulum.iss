; Firma Ödeme Sistemi - Inno Setup kurulum betiği
#define AppName "Firma Ödeme Sistemi"
#define AppVer "1.0.0"
#define AppExe "FirmaOdemeSistemi.exe"

[Setup]
AppName={#AppName}
AppVersion={#AppVer}
AppPublisher=Semih ERDEM
DefaultDirName={autopf}\FirmaOdemeSistemi
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir=kurulum-cikti
OutputBaseFilename=FirmaOdemeSistemi-Kurulum
SetupIconFile=icon.ico
UninstallDisplayIcon={app}\{#AppExe}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog

[Languages]
Name: "tr"; MessagesFile: "compiler:Languages\Turkish.isl"

[Tasks]
Name: "desktopicon"; Description: "Masaüstü kısayolu oluştur"; GroupDescription: "Kısayollar:"

[Files]
Source: "dist\FirmaOdemeSistemi\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{group}\{#AppName} - Kaldır"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "Programı şimdi çalıştır"; Flags: nowait postinstall skipifsilent
