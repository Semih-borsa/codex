"""Presentation only: themes, line icons and payment-ratio painting."""
import re, json, os
from PyQt5.QtCore import Qt, QRectF, QEvent, QObject
from PyQt5.QtGui import QColor, QPainter, QPen, QFont, QPalette
from PyQt5.QtWidgets import QWidget, QStyledItemDelegate, QTableWidget, QApplication

LIGHT = dict(bg='#F3F6FB', surface='#FFFFFF', surface2='#F8FAFD', border='#DCE5EF',
 accent='#0866F5', accent2='#EAF2FF', success='#159447', warning='#B87500', danger='#DF354A',
 text='#132A49', muted='#63758C', header='#F2F6FB', alt='#F8FAFD', gold='#0866F5', coral='#DF354A')
DARK = dict(bg='#111C28', surface='#192938', surface2='#203243', border='#34495E',
 accent='#38A9FF', accent2='#233D55', success='#45D778', warning='#FFD15A', danger='#FF7E89',
 text='#ECF3FC', muted='#ADBED0', header='#213447', alt='#1D2E3E', gold='#38A9FF', coral='#FF7E89')
C = LIGHT.copy()
_ACTIVE = 'light'
def colors(): return DARK if _ACTIVE == 'dark' else LIGHT

def ratio_color(percent):
    if 50 <= percent < 80: return '#FFD15A' if _ACTIVE == 'dark' else '#EAB308'
    return colors()['danger' if percent < 50 else 'success']

STYLE = '''
QWidget { background: #F3F6FB; color: #132A49; font-family: 'Segoe UI', 'DejaVu Sans'; font-size: 12px; }
QLabel { background: transparent; }
QFrame#topBar { background: #FFFFFF; border-bottom: 1px solid #DCE5EF; }
QFrame#sourceRail { background: #F3F6FB; border-right: 1px solid #DCE5EF; }
QPushButton { background: #FFFFFF; color: #132A49; border: 1px solid #DCE5EF; border-radius: 7px; padding: 8px 12px; min-height: 20px; font-weight: 600; }
QPushButton:hover { background: #EAF2FF; border-color: #0866F5; }
QPushButton:pressed { background: #DCE5EF; }
QPushButton:disabled { color: #63758C; background: #F8FAFD; }
QPushButton[cls='primary'] { background: #0866F5; color: white; border-color: #0866F5; }
QPushButton[cls='export'] { background: #FFFFFF; color: #159447; border-color: #159447; }
QPushButton[cls='nav'] { background: transparent; color: #63758C; border: none; border-bottom: 2px solid transparent; border-radius: 0px; padding: 14px 7px; font-size: 11px; }
QPushButton[cls='nav']:checked { color: #0866F5; border-bottom: 2px solid #0866F5; }
QPushButton[cls='nav']:hover { background: #EAF2FF; }
QTableWidget { background: #FFFFFF; alternate-background-color: #F8FAFD; color: #132A49; border: 1px solid #DCE5EF; gridline-color: #DCE5EF; selection-background-color: #EAF2FF; selection-color: #132A49; font-size: 12px; }
QTableWidget::item { padding: 5px 7px; border: none; }
QTableWidget::item:selected { background: #EAF2FF; color: #132A49; }
QHeaderView::section { background: #F2F6FB; color: #132A49; border: none; border-right: 1px solid #DCE5EF; border-bottom: 1px solid #DCE5EF; padding: 9px 7px; font-size: 11px; font-weight: 600; }
QLineEdit,QTextEdit,QComboBox,QDateEdit { background: #FFFFFF; color: #132A49; border: 1px solid #DCE5EF; border-radius: 6px; padding: 6px 8px; selection-background-color: #0866F5; selection-color: white; }
QLineEdit:focus,QTextEdit:focus,QComboBox:focus,QDateEdit:focus { border-color: #0866F5; }
QComboBox QAbstractItemView,QCalendarWidget QWidget,QMenu { background: #FFFFFF; color: #132A49; selection-background-color: #EAF2FF; }
QMenu::item { padding: 8px 18px; }
QMenu::item:selected { background: #EAF2FF; }
QGroupBox { background: #FFFFFF; border: 1px solid #DCE5EF; border-radius: 8px; margin-top: 18px; padding: 14px; font-weight: 600; }
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0px 5px; }
QScrollArea,QTabWidget::pane { border: none; }
QTabBar::tab { background: #FFFFFF; color: #63758C; padding: 10px 15px; }
QTabBar::tab:selected { background: #EAF2FF; color: #0866F5; }
QListWidget { background: #FFFFFF; color: #132A49; border: 1px solid #DCE5EF; }
QListWidget::item { padding: 8px; }
QListWidget::item:selected { background: #EAF2FF; }
QCheckBox { background: transparent; spacing: 8px; }
QStatusBar { background: #FFFFFF; color: #63758C; border-top: 1px solid #DCE5EF; font-size: 11px; }
QToolTip { background: #FFFFFF; color: #132A49; border: 1px solid #DCE5EF; padding: 8px; }
QScrollBar:vertical { background: #F8FAFD; width: 10px; }
QScrollBar:horizontal { background: #F8FAFD; height: 10px; }
QScrollBar::handle { background: #DCE5EF; border-radius: 4px; min-height: 25px; min-width: 25px; }
QScrollBar::add-line,QScrollBar::sub-line { width: 0px; height: 0px; }
'''
# Older inline styles in secondary dialogs are translated too.
EXTRA = {'#E6EFF8':'#233D55','#CDDFEF':'#34495E','#F1F6FB':'#203243',
 '#ADC5DD':'#38A9FF','#F5F8FB':'#203243','#BDD0E2':'#34495E',
 '#DCE8F4':'#34495E','#F8F9FA':'#192938','#E6EEF7':'#233D55',
 '#DAE7F4':'#233D55','#243B53':'#ECF3FC','#EAF1F8':'#203243',
 '#C3D2E0':'#34495E','#EAF0F5':'#192938','#E6EBF0':'#203243',
 '#FFFFFF':'#192938','#000000':'#ECF3FC'}
def dark_style(style):
    mapping = {LIGHT[k].upper(): DARK[k] for k in LIGHT}
    mapping.update(EXTRA)
    return re.sub(r'#[0-9A-Fa-f]{6}', lambda m: mapping.get(m[0].upper(),m[0]), style)

class LineIcon(QWidget):
    def __init__(self, kind='file', parent=None):
        super().__init__(parent); self.kind=kind; self.setFixedSize(30,30)
    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        p.scale(self.width()/30.0,self.height()/30.0)
        p.setPen(QPen(QColor(colors()['accent']),1.7)); p.setBrush(Qt.NoBrush)
        if self.kind=='bank':
            p.drawLine(4,11,15,4); p.drawLine(15,4,26,11); p.drawLine(4,11,26,11)
            for x in (7,15,23): p.drawLine(x,14,x,24)
            p.drawLine(4,26,26,26)
        elif self.kind=='clock':
            p.drawEllipse(QRectF(4,4,22,22));p.drawLine(15,8,15,15);p.drawLine(15,15,20,18)
        elif self.kind=='alert':
            p.drawLine(15,4,3,26);p.drawLine(3,26,27,26);p.drawLine(27,26,15,4)
            p.drawLine(15,11,15,18);p.drawPoint(15,22)
        elif self.kind=='coins':
            p.drawEllipse(QRectF(5,4,20,8));p.drawLine(5,8,5,22);p.drawLine(25,8,25,22)
            p.drawArc(QRectF(5,10,20,8),180*16,180*16);p.drawArc(QRectF(5,18,20,8),180*16,180*16)
        elif self.kind=='scale':
            p.drawLine(15,4,15,25);p.drawLine(6,25,24,25);p.drawLine(4,9,26,9)
            p.drawLine(7,9,3,19);p.drawLine(7,9,11,19);p.drawLine(3,19,11,19)
            p.drawLine(23,9,19,19);p.drawLine(23,9,27,19);p.drawLine(19,19,27,19)
        elif self.kind=='chart':
            p.setPen(Qt.NoPen); p.setBrush(QColor(colors()['accent']))
            for x,y in ((4,18),(12,11),(20,4)): p.drawRoundedRect(QRectF(x,y,6,28-y),1.5,1.5)
        else:
            p.drawRoundedRect(QRectF(7,3,17,24),2,2)
            for y in (11,16,21): p.drawLine(11,y,20,y)
        p.end()

class FinanceDelegate(QStyledItemDelegate):
    def initStyleOption(self,option,index):
        super().initStyleOption(option,index)
        if _ACTIVE=='dark':
            current=option.palette.color(QPalette.Text).name().upper()
            mapping={LIGHT[k].upper():DARK[k] for k in LIGHT}
            option.palette.setColor(QPalette.Text,QColor(mapping.get(current,DARK['text'])))

class PaymentDelegate(FinanceDelegate):
    def paint(self,painter,option,index):
        try: value=float(index.data(Qt.UserRole)) if index.data(Qt.UserRole) is not None else float(str(index.data()).replace('%','').replace(',','.'))
        except (TypeError,ValueError): return super().paint(painter,option,index)
        painter.save(); painter.setRenderHint(QPainter.Antialiasing)
        col=QColor(ratio_color(value)); r=QRectF(option.rect).adjusted(7,6,-7,-6)
        bg=QColor(col); bg.setAlpha(42 if _ACTIVE=='dark' else 28)
        painter.setPen(Qt.NoPen); painter.setBrush(bg)
        badge=QRectF(r.x(),r.y(),54,r.height()); painter.drawRoundedRect(badge,7,7)
        painter.setPen(QColor(colors()['warning']) if 50 <= value < 80 else col); painter.setFont(QFont('Segoe UI',9,QFont.DemiBold))
        painter.drawText(badge,Qt.AlignCenter,str(index.data()))
        if r.width()>90:
            track=QRectF(r.x()+65,r.center().y()-3,r.width()-65,6)
            painter.setPen(Qt.NoPen); painter.setBrush(QColor(colors()['border'])); painter.drawRoundedRect(track,3,3)
            fill=QRectF(track); fill.setWidth(track.width()*max(0,min(100,value))/100)
            painter.setBrush(col); painter.drawRoundedRect(fill,3,3)
        painter.restore()

class ThemeManager(QObject):
    def __init__(self,app):
        super().__init__(app); self.app=app; self.busy=False; app.installEventFilter(self)
    def adapt(self,w):
        if self.busy: return
        style=w.styleSheet()
        if style:
            old=getattr(w,'_theme_applied',None)
            if style!=old: w._theme_original=style
            base=getattr(w,'_theme_original',style)
            target=dark_style(base) if _ACTIVE=='dark' else base
            if style!=target:
                self.busy=True; w.setStyleSheet(target); self.busy=False
            w._theme_applied=target
        if isinstance(w,QTableWidget) and not isinstance(w.itemDelegate(),FinanceDelegate):
            w.setItemDelegate(FinanceDelegate(w))
        if hasattr(w, "_icon_kind"): w.setIcon(button_icon(w._icon_kind))
        w.update()
    def eventFilter(self,obj,event):
        if isinstance(obj,QWidget) and event.type() in (QEvent.Show,QEvent.Polish,QEvent.StyleChange): self.adapt(obj)
        return False
    def set_theme(self,name):
        global _ACTIVE
        _ACTIVE='dark' if name=='dark' else 'light'
        self.app.setStyleSheet(dark_style(STYLE) if _ACTIVE=='dark' else STYLE)
        pal=self.app.palette(); c=colors()
        for role,key in ((QPalette.Window,'bg'),(QPalette.Base,'surface'),(QPalette.AlternateBase,'alt'),
                         (QPalette.Text,'text'),(QPalette.WindowText,'text'),(QPalette.Button,'surface'),
                         (QPalette.ButtonText,'text'),(QPalette.Highlight,'accent2'),(QPalette.HighlightedText,'text')):
            pal.setColor(role,QColor(c[key]))
        self.app.setPalette(pal)
        for w in self.app.allWidgets(): self.adapt(w)

def button_icon(kind):
    from PyQt5.QtGui import QPixmap, QIcon
    pix=QPixmap(20,20); pix.fill(Qt.transparent)
    p=QPainter(pix); p.setRenderHint(QPainter.Antialiasing)
    p.setPen(QPen(QColor('#FFFFFF' if kind=='calculate' else colors()['success'] if kind=='export' else colors()['accent']),1.5))
    if kind=='calculate':
        p.drawRoundedRect(QRectF(4,2,12,16),2,2);p.drawLine(7,6,13,6)
        for x in (7,10,13):
            for y in (10,14):p.drawPoint(x,y)
    elif kind=='save':
        p.drawRoundedRect(QRectF(3,3,14,14),1,1);p.drawRect(6,3,8,5);p.drawRect(6,12,8,5)
    elif kind=='settings':
        p.drawEllipse(QRectF(6,6,8,8));p.drawEllipse(QRectF(2,2,16,16))
    elif kind=='export':
        p.drawRect(4,2,12,16);p.drawLine(7,8,13,14);p.drawLine(13,8,7,14)
    elif kind=='split':
        p.drawLine(3,10,17,10);p.drawLine(10,4,10,16)
        p.drawLine(3,10,6,7);p.drawLine(17,10,14,13)
    else:
        p.drawLine(11,2,5,11);p.drawLine(5,11,10,11);p.drawLine(10,11,8,18);p.drawLine(8,18,15,8);p.drawLine(15,8,10,8)
    p.end();return QIcon(pix)
