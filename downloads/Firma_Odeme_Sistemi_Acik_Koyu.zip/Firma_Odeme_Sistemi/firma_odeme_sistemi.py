# -*- coding: utf-8 -*-
"""
FİRMA ÖDEME SİSTEMİ
- Bakiye + Hareket dosyalarından "Vadesi Gelen Borç" ve "Vadesi 15 Gün Geçen" hesaplar
- Peşin firmalar için güncel bakiyeyi direkt aktarır
- Ödenecek Tutar (varsayılan = vadesi gelen) elle düzenlenebilir
- KPI paneli + yarım daire Ödeme Yüzdesi göstergesi
- C3 (muhasebe) ve BANKAYA FORMAT (tek dosya, 50'lik sayfalara bölünmüş) Excel çıktısı
"""

import sys, os, json
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from datetime import date, timedelta, datetime

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox, QDialog, QLineEdit, QGridLayout, QCheckBox,
    QGroupBox, QListWidget, QStatusBar, QFrame, QAbstractItemView,
    QTextEdit, QScrollArea, QSizePolicy, QTabWidget, QComboBox, QDateEdit, QMenu, QAction
)
from openpyxl.worksheet.page import PageMargins
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QRectF, QDate
from PyQt5.QtGui import QFont, QColor, QIcon, QPainter, QPen, QBrush, QFontMetrics

# ── Yollar ─────────────────────────────────────────────────────────────────
if getattr(sys, "frozen", False):
    BASE = os.path.dirname(sys.executable)
else:
    BASE = os.path.dirname(os.path.abspath(__file__))


def _veri_dizini():
    """Kurulu .exe Program Files'a giderse oraya yazılamaz; verileri kullanıcı
    klasöründe tut. Kaynaktan/taşınabilir çalıştırmada program klasörünü kullan."""
    if getattr(sys, "frozen", False):
        kok = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        d = os.path.join(kok, "FirmaOdemeSistemi")
    else:
        d = BASE
    try:
        os.makedirs(d, exist_ok=True)
        deneme = os.path.join(d, ".yazilabilir")
        with open(deneme, "w") as f:
            f.write("1")
        os.remove(deneme)
    except Exception:
        d = BASE
    return d


DATA_DIR = _veri_dizini()

AYAR_F     = os.path.join(DATA_DIR, "settings.json")
EK_FIRMA_F = os.path.join(DATA_DIR, "ek_firmalar.json")


def _tohumla():
    """İlk çalıştırmada, pakete gömülü varsayılan ayarları veri klasörüne kopyala."""
    if not hasattr(sys, "_MEIPASS"):
        return
    for ad in ("settings.json", "ek_firmalar.json"):
        hedef = os.path.join(DATA_DIR, ad)
        kaynak = os.path.join(sys._MEIPASS, ad)
        if not os.path.exists(hedef) and os.path.exists(kaynak):
            try:
                with open(kaynak, encoding="utf-8") as f:
                    veri = f.read()
                with open(hedef, "w", encoding="utf-8") as f:
                    f.write(veri)
            except Exception:
                pass


_tohumla()

def _ikon_yolu():
    # önce program klasörü, sonra PyInstaller paketi içi
    yerler = [os.path.join(BASE, "icon.png")]
    if hasattr(sys, "_MEIPASS"):
        yerler.append(os.path.join(sys._MEIPASS, "icon.png"))
    for y in yerler:
        if os.path.exists(y):
            return y
    return yerler[0]

ICON_F = _ikon_yolu()

# ── Varsayılan ayarlar ───────────────────────────────────────────────────────
TALIMAT_VARSAYILAN = (
    "            {kurum} ait olan {hesap} nolu hesabımızdan aşağıdaki listede "
    "belirtilen firmaların iban ve hesap numaraları karşısında yazılan ödeme "
    "miktarlarının toplamda {toplam}-TL'nin transfer edilmesinini rica ederiz. {tarih}"
)

DEF = {
    "pesin_firmalar": [],
    "kara_liste": [],
    "tam_odeme_esigi": 5000,
    "bakiye_path": "", "hareket_path": "", "firma_path": "",
    "banka_hesap_no": "00158007298168513",
    "kurum_adi": "Edirne Valiliği İl Emniyet Müdürlüğü Polis Aile Kantini Başkanlığımıza",
    "talimat_metni": TALIMAT_VARSAYILAN,
    "liste_basligi": "EDİRNE POLİS AİLE KANTİNİ {tarih} FİRMA ÖDEME LİSTESİ",
    "imzalar": [
        {"ad": "Halil GÜNDÜZ",     "unvan": "Kantin Yön. Krl. Başkanı"},
        {"ad": "Nurbay ÇARBOĞA",   "unvan": "Kantin Yön. Krl. Üyesi"},
        {"ad": "Semih ERDEM",      "unvan": "Kantin Yön. Krl. Üyesi"},
        {"ad": "Fatih ÖZEN",       "unvan": "Kantin Yön. Krl. Üyesi"},
        {"ad": "Atakan DENİZMEN",  "unvan": "Kantin Yön. Krl. Üyesi"},
    ],
    "c3_islem": "EVRAK",
    "c3_aciklama": "EFT GÖNDERİLEN",
    "bankaya_bolme": 50,
}


def ayar_yukle():
    if os.path.exists(AYAR_F):
        try:
            with open(AYAR_F, encoding="utf-8") as f:
                s = json.load(f)
            for k, v in DEF.items():
                if k not in s:
                    s[k] = v
            return s
        except Exception:
            pass
    return json.loads(json.dumps(DEF))  # derin kopya


def ayar_kaydet(s):
    with open(AYAR_F, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=2)


def ek_yukle():
    if os.path.exists(EK_FIRMA_F):
        try:
            with open(EK_FIRMA_F, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def ek_kaydet(d):
    with open(EK_FIRMA_F, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)


FIRMA_CACHE_F = os.path.join(DATA_DIR, "firma_bilgileri.json")   # firma bilgileri kalıcı önbellek


def firma_cache_yukle():
    if os.path.exists(FIRMA_CACHE_F):
        try:
            with open(FIRMA_CACHE_F, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def firma_cache_kaydet(d):
    try:
        with open(FIRMA_CACHE_F, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


OTURUM_F = os.path.join(DATA_DIR, "oturum.json")   # son çalışma durumu (liste + bankadaki)


def oturum_kaydet(liste, bankadaki_metin):
    try:
        with open(OTURUM_F, "w", encoding="utf-8") as f:
            json.dump({"liste": liste, "bankadaki": bankadaki_metin,
                       "tarih": str(date.today())}, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def oturum_yukle():
    if os.path.exists(OTURUM_F):
        try:
            with open(OTURUM_F, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d.get("liste"), list) and d["liste"]:
                return d
        except Exception:
            pass
    return None


ARSIV_F = os.path.join(DATA_DIR, "arsiv.json")   # haftalık ödeme listesi geçmişi


def arsiv_yukle():
    if os.path.exists(ARSIV_F):
        try:
            with open(ARSIV_F, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, list):
                return d
        except Exception:
            pass
    return []


def arsiv_kaydet(kayitlar):
    try:
        with open(ARSIV_F, "w", encoding="utf-8") as f:
            json.dump(kayitlar, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ── Para formatı (1.234.567,89) ───────────────────────────────────────────────
def para(sayi):
    try:
        v = round(float(sayi), 2)
        s = f"{abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        return ("-" + s) if v < 0 else s
    except Exception:
        return "0,00"


def para_coz(metin):
    """Kullanıcının girdiği tutarı Türkçe öncelikli çözer.
    '1.234,56'→1234.56  '5.000'→5000  '1.234.567'→1234567  '1234.56'→1234.56  '1234,56'→1234.56"""
    if metin is None:
        return 0.0
    t = str(metin).strip().replace("₺", "").replace("TL", "").replace(" ", "").strip()
    if t == "":
        return 0.0
    if "," in t and "." in t:           # 1.234,56 → binlik nokta, ondalık virgül
        t = t.replace(".", "").replace(",", ".")
    elif "," in t:                       # 1234,56
        t = t.replace(",", ".")
    elif "." in t:
        # Sadece nokta var: Türkçe binlik mi, İngilizce ondalık mı?
        # 3'erli gruplu desen (5.000 / 1.234.567) → binlik say, noktaları at.
        import re as _re
        if _re.fullmatch(r"\d{1,3}(\.\d{3})+", t):
            t = t.replace(".", "")
        # aksi halde (12.34, 1.2 gibi) ondalık kabul et
    try:
        return round(float(t), 2)
    except Exception:
        return 0.0


# ── Türkçe sıralama ───────────────────────────────────────────────────────────
# ── Türkçe diyalog yardımcıları (Evet/Hayır/Tamam butonları Türkçe) ───────────
def _kutu(parent, ikon, baslik, metin, butonlar, varsayilan=None, etiketler=None):
    kutu = QMessageBox(parent)
    kutu.setIcon(ikon)
    kutu.setWindowTitle(baslik)
    kutu.setText(metin)
    kutu.setStandardButtons(butonlar)
    if varsayilan is not None:
        kutu.setDefaultButton(varsayilan)
    for std, yazi in (etiketler or {}).items():
        b = kutu.button(std)
        if b: b.setText(yazi)
    if os.path.exists(ICON_F):
        kutu.setWindowIcon(QIcon(ICON_F))
    return kutu.exec_()


def sor(parent, baslik, metin, varsayilan_hayir=True):
    """Evet / Hayır sorusu — butonlar Türkçe. QMessageBox.Yes / .No döner."""
    return _kutu(parent, QMessageBox.Question, baslik, metin,
                 QMessageBox.Yes | QMessageBox.No,
                 QMessageBox.No if varsayilan_hayir else QMessageBox.Yes,
                 {QMessageBox.Yes: "Evet", QMessageBox.No: "Hayır"})


def bilgi(parent, baslik, metin):
    return _kutu(parent, QMessageBox.Information, baslik, metin,
                 QMessageBox.Ok, QMessageBox.Ok, {QMessageBox.Ok: "Tamam"})


def uyari(parent, baslik, metin):
    return _kutu(parent, QMessageBox.Warning, baslik, metin,
                 QMessageBox.Ok, QMessageBox.Ok, {QMessageBox.Ok: "Tamam"})


def hata_kutusu(parent, baslik, metin):
    return _kutu(parent, QMessageBox.Critical, baslik, metin,
                 QMessageBox.Ok, QMessageBox.Ok, {QMessageBox.Ok: "Tamam"})


# ── Bütçe dağıtımı (Eşit Dağıt) ───────────────────────────────────────────────
def butce_dagit(liste, butce, esik=5000.0, haric_kodlar=None, tam_kodlar=None):
    """Bütçeyi şu sırayla dağıtır ve her firmanın 'odenecek' değerini günceller:
       1) Peşin firmalar → tamamı
       2) Kullanıcının 'tam ödensin' dediği firmalar → tamamı
       3) Vadesi geleni <= esik olanlar → tamamı
       4) Kalan bütçe → geri kalanlara vadesi gelen borçlarıyla ORANTILI
       Kara listedekiler ve kullanıcının hariç tuttukları 0 kalır.
       Kimse borcundan fazlasını almaz; artan bütçe bankada kalır.
       Döner: (dagitilan_toplam, kalan_butce, bilgi_dict)"""
    haric = set(haric_kodlar or [])
    tam   = set(tam_kodlar or [])
    for it in liste:
        it["odenecek"] = 0.0

    uygun = [it for it in liste
             if not it.get("kara") and it["cari_kod"] not in haric and it["vadesi_gelen"] > 0]

    kalan = float(butce)
    bilgi_d = {"pesin": 0, "tam": 0, "esik_alti": 0, "orantili": 0,
               "pesin_tutar": 0.0, "tam_tutar": 0.0,
               "esik_tutar": 0.0, "orantili_tutar": 0.0, "gecikmis_tutar": 0.0}

    # 1) Peşin firmalar
    for it in sorted([x for x in uygun if x.get("pesin")], key=lambda x: x["vadesi_gelen"]):
        if kalan <= 0: break
        ver = min(it["vadesi_gelen"], kalan)
        it["odenecek"] = round(ver, 2); kalan -= ver
        bilgi_d["pesin"] += 1; bilgi_d["pesin_tutar"] += ver

    # 2) Tamamı ödensin denilen firmalar (peşin olmayanlar)
    for it in sorted([x for x in uygun if not x.get("pesin") and x["cari_kod"] in tam],
                     key=lambda x: x["vadesi_gelen"]):
        if kalan <= 0: break
        ver = min(it["vadesi_gelen"], kalan)
        it["odenecek"] = round(ver, 2); kalan -= ver
        bilgi_d["tam"] += 1; bilgi_d["tam_tutar"] += ver

    # 3) Eşik altı (küçük borçlar) — küçükten büyüğe, mümkün olduğunca çok firma kapansın
    for it in sorted([x for x in uygun if not x.get("pesin") and x["cari_kod"] not in tam
                      and x["vadesi_gelen"] <= esik],
                     key=lambda x: x["vadesi_gelen"]):
        if kalan <= 0: break
        ver = min(it["vadesi_gelen"], kalan)
        it["odenecek"] = round(ver, 2); kalan -= ver
        bilgi_d["esik_alti"] += 1; bilgi_d["esik_tutar"] += ver

    # 4) Kalanı dağıt: ÖNCE vadesi 15 gün geçen (gecikmiş) tutarlar öncelikli ödenir,
    #    sonra artan para geri kalan borca orantılı dağıtılır.
    kalanlar = [x for x in uygun if not x.get("pesin") and x["cari_kod"] not in tam
                and x["vadesi_gelen"] > esik]
    if kalanlar and kalan > 0:
        # 4a) Gecikmiş taban = min(15 gün geçen, vadesi gelen)
        for it in kalanlar:
            it["_taban"] = min(float(it.get("vadesi_15_gec", 0) or 0), it["vadesi_gelen"])
        toplam_taban = sum(it["_taban"] for it in kalanlar)
        if toplam_taban > 0:
            if kalan >= toplam_taban:
                for it in kalanlar:
                    it["odenecek"] = round(it["_taban"], 2)
                kalan -= toplam_taban
                bilgi_d["gecikmis_tutar"] = round(toplam_taban, 2)
            else:
                # bütçe gecikmişlere bile yetmiyor → gecikmiş tutarlara orantılı
                o = kalan / toplam_taban
                dag = 0.0
                for it in kalanlar:
                    v = round(it["_taban"] * o, 2); it["odenecek"] = v; dag += v
                bilgi_d["gecikmis_tutar"] = round(dag, 2)
                kalan = 0.0

        # 4b) Artan parayı geri kalan borca (vadesi_gelen - ödenen) orantılı dağıt
        if kalan > 0:
            kalan_borc = sum(it["vadesi_gelen"] - it["odenecek"] for it in kalanlar)
            if kalan_borc > 0:
                o = min(1.0, kalan / kalan_borc)
                dag = 0.0
                for it in kalanlar:
                    ek = round((it["vadesi_gelen"] - it["odenecek"]) * o, 2)
                    yeni = round(min(it["vadesi_gelen"], it["odenecek"] + ek), 2)
                    dag += (yeni - it["odenecek"]); it["odenecek"] = yeni
                kalan -= dag

        for it in kalanlar:
            if it["odenecek"] > 0 or it["_taban"] > 0:
                bilgi_d["orantili"] += 1
            it.pop("_taban", None)
        bilgi_d["orantili_tutar"] = round(sum(x["odenecek"] for x in kalanlar), 2)

    dagitilan_toplam = sum(x["odenecek"] for x in liste)
    return round(dagitilan_toplam, 2), round(max(0.0, butce - dagitilan_toplam), 2), bilgi_d


def excel_kaydet(wb, path, parent=None):
    """Workbook'u kaydeder; dosya açıksa/izin yoksa Türkçe açıklamalı mesaj verir.
    Başarılıysa True döner."""
    try:
        wb.save(path)
        return True
    except PermissionError:
        hata_kutusu(parent, "Dosya Kaydedilemedi",
            "Dosya şu anda Excel'de (veya başka bir programda) AÇIK olduğu için\n"
            "üzerine yazılamadı.\n\n"
            "Lütfen dosyayı kapatın ve tekrar deneyin,\n"
            "ya da farklı bir dosya adı seçin.")
    except OSError as e:
        hata_kutusu(parent, "Dosya Kaydedilemedi",
            f"Dosya yazılamadı (disk dolu olabilir veya klasöre yazma izni yok).\n\nAyrıntı: {e}")
    except Exception as e:
        hata_kutusu(parent, "Hata", str(e))
    return False


def tr_kucult(s):
    """Türkçe duyarlı küçültme: 'BAKİYE'→'bakiye', 'CARI KODU'→'cari kodu' (I→ı, İ→i)."""
    return str(s).replace("İ", "i").replace("I", "ı").lower().strip()


_TR  = "aAbBcCçÇdDeEfFgGğĞhHıIiİjJkKlLmMnNoOöÖpPrRsStTuUüÜvVyYzZ"
_IDX = {c: i for i, c in enumerate(_TR)}


def tr_key(metin):
    out = []
    for c in str(metin).lower():
        if c in _IDX:        out.append(_IDX[c])
        elif c in " -.,()":  out.append(-1)
        else:                out.append(999)
    return out


def bu_haftanin_pazari():
    b = date.today()
    return b + timedelta(days=(6 - b.weekday()))


# ── Hesaplama Thread (vadesi gelen borç motoru) ───────────────────────────────
def odenmemis_faturalar(faturalar, vadesi_gelen):
    """Vadesi gelen faturaların toplamı, firmanın hesaplanan Vadesi Gelen tutarından
    fazlaysa (yani bazı eski faturalar zaten ödenmiş demektir), aradaki farkı standart
    cari hesap mantığıyla EN ESKİ faturalardan düşer — ödemeler önce en eski borca
    uygulanır (FIFO) kabul edilir. Sonuçta sadece gerçekten ödenmemiş kalan tutarlar
    (gerekirse kısmi) döner; toplamı ~vadesi_gelen'e eşit olur."""
    toplam = round(sum(f["tutar"] for f in faturalar), 2)
    fazla = round(toplam - vadesi_gelen, 2)
    if fazla <= 0.01:
        return [dict(f, kismi=False) for f in faturalar]   # hepsi ödenmemiş görünüyor
    kalan_fazla = fazla
    sonuc = []
    for f in faturalar:   # en eskiden en yeniye
        tutar = f["tutar"]
        if kalan_fazla >= tutar - 0.01:
            kalan_fazla -= tutar
            continue   # bu fatura tamamen ödenmiş kabul edilir → listeye girmez
        elif kalan_fazla > 0:
            kalan = round(tutar - kalan_fazla, 2)
            sonuc.append({"tarih": f["tarih"], "tutar": kalan, "kismi": True})
            kalan_fazla = 0
        else:
            sonuc.append(dict(f, kismi=False))
    return sonuc


class HesaplaThread(QThread):
    ilerleme = pyqtSignal(str)
    bitti    = pyqtSignal(dict, str)

    def __init__(self, bakiye_path, hareket_path, kesim_gunu=None, parent=None):
        super().__init__(parent)
        self.bakiye_path  = bakiye_path
        self.hareket_path = hareket_path
        self.kesim_gunu   = kesim_gunu      # None → bu haftanın pazarı (varsayılan)

    def run(self):
        try:
            pazar   = self.kesim_gunu or bu_haftanin_pazari()
            bugun   = date.today()
            limit15 = bugun - timedelta(days=15)

            # ── Bakiye dosyası ───────────────────────────────────────────
            self.ilerleme.emit("Bakiye dosyası okunuyor...")
            try:
                df2 = pd.read_excel(self.bakiye_path, header=0)
            except Exception:
                df2 = pd.read_csv(self.bakiye_path, encoding="utf-8-sig",
                                  sep=None, engine="python", header=0)
            df2.columns = [str(c).strip() for c in df2.columns]

            cm2 = {}
            for c in df2.columns:
                cl = tr_kucult(c)
                if ("cari" in cl or "carı" in cl) and "kod" in cl and "bilg" not in cl:
                    cm2.setdefault("cari_kod", c)
                elif ("ticari" in cl or "unvan" in cl) and "bilg" not in cl:
                    cm2.setdefault("unvan", c)
                elif cl == "bakiye":
                    cm2["bakiye"] = c
                elif "b/a/s" in cl or cl == "b/a":
                    cm2["bas"] = c

            if "cari_kod" not in cm2:
                self.bitti.emit({}, "Bakiye dosyasında 'Cari Kodu' kolonu bulunamadı!"); return
            if "bakiye" not in cm2:
                self.bitti.emit({}, "Bakiye dosyasında 'Bakiye' kolonu bulunamadı!"); return

            bakiye_map = {}
            for _, r in df2.iterrows():
                kod = str(r[cm2["cari_kod"]]).strip()
                if not kod or kod.lower() == "nan":
                    continue
                try:
                    b = float(r[cm2["bakiye"]]) if pd.notna(r[cm2["bakiye"]]) else 0.0
                except Exception:
                    b = 0.0
                unvan = ""
                if "unvan" in cm2 and pd.notna(r[cm2["unvan"]]):
                    unvan = str(r[cm2["unvan"]]).strip()
                bakiye_map[kod] = {"bakiye": b, "unvan": unvan}

            self.ilerleme.emit(f"Bakiye: {len(bakiye_map)} firma okundu")

            # ── Hareket dosyası ──────────────────────────────────────────
            self.ilerleme.emit("Hareket dosyası okunuyor...")
            try:
                df1 = pd.read_excel(self.hareket_path, header=0)
            except Exception:
                df1 = pd.read_csv(self.hareket_path, encoding="utf-8-sig",
                                  sep=None, engine="python", header=0)
            df1.columns = [str(c).strip() for c in df1.columns]

            cm1 = {}
            for c in df1.columns:
                cl = tr_kucult(c)
                if ("cari" in cl or "carı" in cl) and "kod" in cl and "bilg" not in cl:
                    cm1.setdefault("cari_kod", c)
                elif "alacak" in cl and "tutar" in cl:
                    cm1["alacak"] = c
                elif cl == "vadesi" and "vade" not in cm1:
                    cm1["vade"] = c

            if "cari_kod" not in cm1:
                self.bitti.emit({}, "Hareket dosyasında 'Cari Kodu' kolonu bulunamadı!"); return
            if "alacak" not in cm1 or "vade" not in cm1:
                self.bitti.emit({}, "Hareket dosyasında 'Alacak Tutar' veya 'Vadesi' kolonu bulunamadı!"); return

            self.ilerleme.emit("Vadeler hesaplanıyor...")
            vade_map = {}
            fatura_map = {}   # kod -> [{"tarih": date, "tutar": float}, ...] (vadesi <= kesim günü)
            for cari_kod, grup in df1.groupby(cm1["cari_kod"]):
                kod = str(cari_kod).strip()
                j_paz = j_l15 = 0.0
                faturalar = []
                for _, row in grup.iterrows():
                    try:
                        alacak = float(row[cm1["alacak"]]) if pd.notna(row.get(cm1["alacak"])) else 0.0
                    except Exception:
                        alacak = 0.0
                    if alacak <= 0:
                        continue
                    try:
                        vd = pd.to_datetime(row[cm1["vade"]]).date()
                    except Exception:
                        continue
                    if vd > pazar:   j_paz += alacak
                    if vd > limit15: j_l15 += alacak
                    if vd <= pazar:  # sadece vadesi gelmiş (kesim günü dahil) faturalar
                        faturalar.append({"tarih": vd.isoformat(), "tutar": round(alacak, 2)})
                vade_map[kod] = {"j_pazar": round(j_paz, 2), "j_limit15": round(j_l15, 2)}
                if faturalar:
                    faturalar.sort(key=lambda f: f["tarih"])   # en eski üstte
                    fatura_map[kod] = faturalar

            # ── Birleştir ────────────────────────────────────────────────
            self.ilerleme.emit("Eşleştiriliyor...")
            sonuc = {}
            for kod, bv in bakiye_map.items():
                b  = bv["bakiye"]
                vm = vade_map.get(kod, {"j_pazar": 0.0, "j_limit15": 0.0})
                vg = round(max(0.0, b - vm["j_pazar"]), 2)
                sonuc[kod] = {
                    "unvan":         bv["unvan"],
                    "bakiye":        round(b, 2),
                    "vadesi_gelen":  vg,
                    "vadesi_15_gec": round(max(0.0, b - vm["j_limit15"]), 2),
                    "faturalar":     odenmemis_faturalar(fatura_map.get(kod, []), vg),
                }

            for k, v in ek_yukle().items():
                sonuc.setdefault(k, {"unvan": v.get("unvan", ""), "bakiye": 0.0,
                                     "vadesi_gelen": 0.0, "vadesi_15_gec": 0.0})

            self.ilerleme.emit(f"Tamamlandı: {len(sonuc)} firma")
            self.bitti.emit(sonuc, "")

        except Exception as e:
            self.bitti.emit({}, f"Hata: {e}")


# ── Veri modeli ───────────────────────────────────────────────────────────────
class Veri:
    def __init__(self):
        self.ayarlar  = ayar_yukle()
        self.firmalar = {}      # kod → {unvan, iban, aciklama}
        self.sonuc    = {}
        self.liste    = []
        # önbellekten kalıcı firma bilgileri (program kapatılsa da kalır)
        for k, v in firma_cache_yukle().items():
            self.firmalar[k] = v
        for k, v in ek_yukle().items():
            self.firmalar[k] = v

    def firma_bilgileri_yukle(self, path):
        try:
            df = pd.read_excel(path, sheet_name="FİRMA BİLGİLERİ", header=0)
        except Exception:
            df = pd.read_excel(path, header=0)
        df = df.iloc[:, :4]
        df.columns = ["cari_kod", "unvan", "iban", "aciklama"]
        df = df.dropna(subset=["cari_kod"])
        for _, row in df.iterrows():
            kod = str(row["cari_kod"]).strip()
            if not kod or kod.lower() == "nan":
                continue
            self.firmalar[kod] = {
                "unvan":    str(row["unvan"]).strip()    if pd.notna(row["unvan"])    else "",
                "iban":     str(row["iban"]).strip()     if pd.notna(row["iban"])     else "",
                "aciklama": str(row["aciklama"]).strip() if pd.notna(row["aciklama"]) else "",
            }
        # ek firmalar üstte kalsın
        for k, v in ek_yukle().items():
            self.firmalar.setdefault(k, v)
        firma_cache_kaydet(self.firmalar)        # kalıcı önbelleğe yaz
        self.ayarlar["firma_path"] = path
        ayar_kaydet(self.ayarlar)
        return len(self.firmalar)

    def firma_ekle(self, kod, unvan, iban, aciklama):
        self.firmalar[kod] = {"unvan": unvan, "iban": iban, "aciklama": aciklama}
        ek = ek_yukle(); ek[kod] = {"unvan": unvan, "iban": iban, "aciklama": aciklama}
        ek_kaydet(ek)
        firma_cache_kaydet(self.firmalar)        # önbelleği güncelle

    def listeyi_hazirla(self):
        pesin_set = set(self.ayarlar.get("pesin_firmalar", []))
        kara_set  = set(self.ayarlar.get("kara_liste", []))
        # bu hesaplamada geçici olarak normal işlenecek firmalar (kara listeden ayrık tutulanlar)
        gecici_haric = set(getattr(self, "kara_gecici_haric", set()))
        self.liste = []
        for kod, v in self.sonuc.items():
            pesin  = kod in pesin_set
            kara   = (kod in kara_set) and (kod not in gecici_haric)
            bakiye = v["bakiye"]
            fd = self.firmalar.get(kod, {})
            vadesi_gelen  = bakiye if pesin else v["vadesi_gelen"]
            vadesi_15_gec = 0.0    if pesin else v["vadesi_15_gec"]
            self.liste.append({
                "cari_kod":      kod,
                "unvan":         v["unvan"] or fd.get("unvan", kod),
                "banka_unvan":   fd.get("unvan", v["unvan"] or kod),
                "iban":          fd.get("iban", ""),
                "aciklama":      fd.get("aciklama", ""),
                "bakiye":        bakiye,
                "vadesi_gelen":  vadesi_gelen,
                "vadesi_15_gec": vadesi_15_gec,
                "odenecek":      0.0 if kara else vadesi_gelen,   # kara liste → 0
                "pesin":         pesin,
                "kara":          kara,
                "faturalar":     v.get("faturalar", []),
            })
        self.liste.sort(key=lambda x: tr_key(x["unvan"]))
        return len(self.liste)


# ── Stil ──────────────────────────────────────────────────────────────────────
from ui_theme import C, STYLE, ThemeManager, LineIcon, PaymentDelegate, ratio_color, colors, button_icon


# ── Yarım daire Ödeme Yüzdesi göstergesi ──────────────────────────────────────
class GaugeWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.deger = 0.0          # 0..1
        self.setMinimumSize(125, 145)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def setDeger(self, v):
        self.deger = max(0.0, min(1.0, float(v)))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        pad = 20
        cap = 13
        d = min(w - 2 * pad, h - 2 * pad)
        if d <= 0:
            return
        x = (w - d) / 2
        y = (h - d) / 2 - 5
        rect = QRectF(x, y, d, d)

        # arka halka
        pen = QPen(QColor(colors()["border"])); pen.setWidth(cap); pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        p.drawArc(rect, 90 * 16, -360 * 16)

        # dolu halka (renk seviyeye göre)
        v = self.deger
        renk = ratio_color(v * 100)
        pen2 = QPen(QColor(renk)); pen2.setWidth(cap); pen2.setCapStyle(Qt.RoundCap)
        p.setPen(pen2)
        p.drawArc(rect, 90 * 16, -int(360 * v) * 16)

        # yüzde metni
        p.setPen(QColor(colors()["text"]))
        f = QFont("Segoe UI", 17, QFont.Bold)
        while QFontMetrics(f).horizontalAdvance(f"%{v*100:.1f}") > d - 8 and f.pointSize() > 10:
            f.setPointSize(f.pointSize() - 1)
        p.setFont(f)
        p.drawText(QRectF(x, y + d * 0.26, d, d * 0.30),
                   Qt.AlignHCenter | Qt.AlignVCenter, f"%{v*100:.1f}")
        p.setPen(QColor(colors()["muted"]))
        f2 = QFont("Segoe UI", 7, QFont.DemiBold); p.setFont(f2)
        p.drawText(QRectF(x, y + d * 0.56, d, 22), Qt.AlignHCenter | Qt.AlignTop, "ÖDEME ORANI")
        p.end()


# ── KPI Kartı ──────────────────────────────────────────────────────────────────
class KpiKart(QFrame):
    def __init__(self, baslik, renk=None, duzenlenebilir=False, parent=None):
        super().__init__(parent)
        self.renk = renk or C["text"]
        self.setMinimumHeight(78)
        self.setStyleSheet(
            f"KpiKart{{background:{C['surface']};border:1px solid {C['border']};border-radius:9px;}}"
            f"KpiKart:hover{{background:#F5F8FB;border-color:#BDD0E2;}}")
        lay = QVBoxLayout(self); lay.setContentsMargins(10, 10, 10, 9); lay.setSpacing(3)
        bl = QLabel(baslik)
        bl.setStyleSheet(
            f"color:{C['muted']};font-size:11px;font-family:'Segoe UI Variable Text','Segoe UI';"
            f"font-weight:500;border:none;")
        bl.setWordWrap(True)
        caption = QHBoxLayout(); caption.setSpacing(5)
        kind = {"Vadesi Gelen Borç":"file", "Ödenecek Tutar":"coins", "Ödenemeyen Tutar":"alert", "15 Gün Geçen":"clock", "Bankadaki Tutar":"bank", "Banka − Ödenecek Farkı":"scale"}.get(baslik,"file")
        icon = LineIcon(kind); icon.setFixedSize(20,20)
        caption.addWidget(icon); caption.addWidget(bl,1); lay.addLayout(caption)
        if duzenlenebilir:
            self.val = QLineEdit("0,00")
            self.val.setStyleSheet(
                f"background:{C['surface2']};border:1px solid {C['border']};border-radius:10px;"
                f"padding:4px 8px;color:{self.renk};font-size:16px;font-family:'Segoe UI Variable Display','Segoe UI';font-weight:700;")
            lay.addWidget(self.val)
            self.duzenlenebilir = True
        else:
            self.val = QLabel("0,00 ₺")
            self.val.setStyleSheet(
                f"color:{self.renk};font-size:18px;font-family:'Segoe UI Variable Display','Segoe UI';font-weight:700;border:none;")
            self.duzenlenebilir = False
            lay.addWidget(self.val)

    def yaz(self, metin):
        if self.duzenlenebilir:
            self.val.setText(metin)
        else:
            self.val.setText(metin)


# ── Ayarlar Diyaloğu ─────────────────────────────────────────────────────────
class AyarlarDialog(QDialog):
    def __init__(self, veri, parent=None):
        super().__init__(parent)
        self.veri = veri
        self.setWindowTitle("Ayarlar")
        self.setMinimumSize(620, 640)
        self.setStyleSheet(STYLE)
        if os.path.exists(ICON_F):
            self.setWindowIcon(QIcon(ICON_F))
        self._build()
        self._yukle()

    def _build(self):
        dis = QVBoxLayout(self); dis.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;}")
        ic = QWidget(); scroll.setWidget(ic)
        dis.addWidget(scroll)
        lay = QVBoxLayout(ic); lay.setContentsMargins(20, 18, 20, 18); lay.setSpacing(14)

        # Peşin firmalar
        g1 = QGroupBox("Peşin Firmalar  (vade hesabı yapılmaz — güncel bakiye aktarılır)")
        gg1 = QVBoxLayout(g1); gg1.setSpacing(8)
        self.pesin_lst = QListWidget(); self.pesin_lst.setMinimumHeight(110)
        gg1.addWidget(self.pesin_lst)
        pb = QHBoxLayout()
        self.pesin_inp = QLineEdit(); self.pesin_inp.setPlaceholderText("Cari kod (örn: KOPUZ TİCARET)")
        bpe = QPushButton("➕ Ekle"); bpe.clicked.connect(self._pesin_ekle)
        bpc = QPushButton("🗑 Çıkar"); bpc.setProperty("cls", "danger"); bpc.clicked.connect(self._pesin_cikar)
        pb.addWidget(self.pesin_inp); pb.addWidget(bpe); pb.addWidget(bpc)
        gg1.addLayout(pb); lay.addWidget(g1)

        # Kara Liste
        gk = QGroupBox("🚫 Kara Liste  (borç ne olursa olsun ödenecek tutar 0 gelir)")
        ggk = QVBoxLayout(gk); ggk.setSpacing(8)
        self.kara_lst = QListWidget(); self.kara_lst.setMinimumHeight(110)
        ggk.addWidget(self.kara_lst)
        kb = QHBoxLayout()
        self.kara_inp = QLineEdit(); self.kara_inp.setPlaceholderText("Cari kod (örn: CR00123)")
        bke = QPushButton("➕ Ekle"); bke.clicked.connect(self._kara_ekle)
        bkc = QPushButton("🗑 Çıkar"); bkc.setProperty("cls", "danger"); bkc.clicked.connect(self._kara_cikar)
        kb.addWidget(self.kara_inp); kb.addWidget(bke); kb.addWidget(bkc)
        ggk.addLayout(kb); lay.addWidget(gk)

        # Yeni firma
        g2 = QGroupBox("➕  Yeni Firma Ekle  (bakiye dosyasında olmayan firmalar)")
        gg2 = QGridLayout(g2); gg2.setSpacing(9)
        gg2.addWidget(QLabel("Cari Kodu:"), 0, 0)
        self.nf_kod = QLineEdit(); gg2.addWidget(self.nf_kod, 0, 1)
        gg2.addWidget(QLabel("Ticari Unvanı:"), 1, 0)
        self.nf_unvan = QLineEdit(); gg2.addWidget(self.nf_unvan, 1, 1)
        gg2.addWidget(QLabel("IBAN No:"), 2, 0)
        self.nf_iban = QLineEdit(); gg2.addWidget(self.nf_iban, 2, 1)
        gg2.addWidget(QLabel("Açıklama:"), 3, 0)
        self.nf_aciklama = QLineEdit(); gg2.addWidget(self.nf_aciklama, 3, 1)
        bfe = QPushButton("✅  Firmayı Kaydet"); bfe.setProperty("cls", "ok"); bfe.clicked.connect(self._firma_ekle)
        gg2.addWidget(bfe, 4, 0, 1, 2); lay.addWidget(g2)

        # Banka talimat başlığı
        g3 = QGroupBox("🏦  BANKAYA FORMAT — Talimat Başlığı")
        gg3 = QGridLayout(g3); gg3.setSpacing(9)
        gg3.addWidget(QLabel("Banka Hesap No:"), 0, 0)
        self.b_hesap = QLineEdit(); gg3.addWidget(self.b_hesap, 0, 1)
        gg3.addWidget(QLabel("Kurum (… ait olan):"), 1, 0)
        self.b_kurum = QLineEdit(); gg3.addWidget(self.b_kurum, 1, 1)
        gg3.addWidget(QLabel("Talimat metni:"), 2, 0)
        self.b_talimat = QTextEdit(); self.b_talimat.setMinimumHeight(90); gg3.addWidget(self.b_talimat, 2, 1)
        ipucu = QLabel("Değişkenler: {kurum}  {hesap}  {toplam}  {tarih}")
        ipucu.setStyleSheet(f"color:{C['muted']};font-size:11px;"); gg3.addWidget(ipucu, 3, 1)
        gg3.addWidget(QLabel("Liste başlığı:"), 4, 0)
        self.b_liste = QLineEdit(); gg3.addWidget(self.b_liste, 4, 1)
        lay.addWidget(g3)

        # İmzalar
        g4 = QGroupBox("✍️  İmza Sahipleri (5 kişi)")
        gg4 = QGridLayout(g4); gg4.setSpacing(8)
        gg4.addWidget(QLabel("Ad Soyad"), 0, 1); gg4.addWidget(QLabel("Unvan"), 0, 2)
        self.imza_ad = []; self.imza_unvan = []
        for i in range(5):
            gg4.addWidget(QLabel(f"{i+1}."), i + 1, 0)
            a = QLineEdit(); u = QLineEdit()
            gg4.addWidget(a, i + 1, 1); gg4.addWidget(u, i + 1, 2)
            self.imza_ad.append(a); self.imza_unvan.append(u)
        lay.addWidget(g4)

        # C3 sabitleri
        # Eşit Dağıt ayarı
        gd = QGroupBox("⚖️  Eşit Dağıt Ayarı")
        ggd = QGridLayout(gd); ggd.setSpacing(9)
        ggd.addWidget(QLabel("Tamamı ödensin sınırı (₺):"), 0, 0)
        self.esik_inp = QLineEdit(); ggd.addWidget(self.esik_inp, 0, 1)
        n2 = QLabel("Vadesi gelen borcu bu tutar ve altında olan firmaların borcu, "
                    "dağıtımda tamamen ödenir. Kalan para, borcu bu sınırın üstünde olan "
                    "firmalara borçlarıyla orantılı dağıtılır. (Peşin firmalar her zaman önceliklidir.)")
        n2.setStyleSheet(f"color:{C['muted']};font-size:11px;"); n2.setWordWrap(True)
        ggd.addWidget(n2, 1, 0, 1, 2)
        lay.addWidget(gd)

        g5 = QGroupBox("📑  C3 (Muhasebe) Sabitleri")
        gg5 = QGridLayout(g5); gg5.setSpacing(9)
        gg5.addWidget(QLabel("İŞLEM:"), 0, 0)
        self.c3_islem = QLineEdit(); gg5.addWidget(self.c3_islem, 0, 1)
        gg5.addWidget(QLabel("AÇIKLAMA:"), 1, 0)
        self.c3_acik = QLineEdit(); gg5.addWidget(self.c3_acik, 1, 1)
        not_l = QLabel("C3 her zaman tek dosya / tek sayfadır (firma sayısı sınırsız).\n"
                       "BANKAYA FORMAT ise her 50 firmada otomatik yeni sayfaya geçer.")
        not_l.setStyleSheet(f"color:{C['muted']};font-size:11px;"); not_l.setWordWrap(True)
        gg5.addWidget(not_l, 2, 0, 1, 2)
        lay.addWidget(g5)

        bb = QHBoxLayout(); bb.addStretch()
        bk = QPushButton("💾  Kaydet ve Kapat"); bk.setProperty("cls", "ok"); bk.clicked.connect(self._kaydet)
        bb.addWidget(bk); lay.addLayout(bb)

    def _yukle(self):
        a = self.veri.ayarlar
        self.pesin_lst.clear()
        for kod in a.get("pesin_firmalar", []):
            unvan = self.veri.sonuc.get(kod, {}).get("unvan", "") or self.veri.firmalar.get(kod, {}).get("unvan", "")
            self.pesin_lst.addItem(f"{kod}  —  {unvan}")
        self.kara_lst.clear()
        for kod in a.get("kara_liste", []):
            unvan = self.veri.sonuc.get(kod, {}).get("unvan", "") or self.veri.firmalar.get(kod, {}).get("unvan", "")
            self.kara_lst.addItem(f"{kod}  —  {unvan}")
        self.b_hesap.setText(a.get("banka_hesap_no", ""))
        self.b_kurum.setText(a.get("kurum_adi", ""))
        self.b_talimat.setPlainText(a.get("talimat_metni", TALIMAT_VARSAYILAN))
        self.b_liste.setText(a.get("liste_basligi", ""))
        for i, im in enumerate(a.get("imzalar", [])[:5]):
            self.imza_ad[i].setText(im.get("ad", "")); self.imza_unvan[i].setText(im.get("unvan", ""))
        self.c3_islem.setText(a.get("c3_islem", "EVRAK"))
        self.c3_acik.setText(a.get("c3_aciklama", "EFT GÖNDERİLEN"))
        self.esik_inp.setText(para(a.get("tam_odeme_esigi", 5000)))

    def _pesin_ekle(self):
        kod = self.pesin_inp.text().strip()
        if not kod: return
        lst = self.veri.ayarlar.setdefault("pesin_firmalar", [])
        if kod not in lst:
            lst.append(kod)
            unvan = self.veri.sonuc.get(kod, {}).get("unvan", "")
            self.pesin_lst.addItem(f"{kod}  —  {unvan}")
            self.pesin_inp.clear(); ayar_kaydet(self.veri.ayarlar)

    def _pesin_cikar(self):
        s = self.pesin_lst.currentRow()
        if s < 0: return
        kod = self.pesin_lst.item(s).text().split("—")[0].strip()
        lst = self.veri.ayarlar.get("pesin_firmalar", [])
        if kod in lst: lst.remove(kod)
        self.pesin_lst.takeItem(s); ayar_kaydet(self.veri.ayarlar)

    def _kara_ekle(self):
        kod = self.kara_inp.text().strip()
        if not kod: return
        lst = self.veri.ayarlar.setdefault("kara_liste", [])
        if kod not in lst:
            lst.append(kod)
            unvan = self.veri.sonuc.get(kod, {}).get("unvan", "") or self.veri.firmalar.get(kod, {}).get("unvan", "")
            self.kara_lst.addItem(f"{kod}  —  {unvan}")
            self.kara_inp.clear(); ayar_kaydet(self.veri.ayarlar)

    def _kara_cikar(self):
        s = self.kara_lst.currentRow()
        if s < 0: return
        kod = self.kara_lst.item(s).text().split("—")[0].strip()
        lst = self.veri.ayarlar.get("kara_liste", [])
        if kod in lst: lst.remove(kod)
        self.kara_lst.takeItem(s); ayar_kaydet(self.veri.ayarlar)

    def _firma_ekle(self):
        kod = self.nf_kod.text().strip(); unvan = self.nf_unvan.text().strip()
        if not kod or not unvan:
            uyari(self, "Eksik", "Cari kodu ve unvan zorunludur!"); return
        self.veri.firma_ekle(kod, unvan, self.nf_iban.text().strip(), self.nf_aciklama.text().strip())
        bilgi(self, "Eklendi", f"'{unvan}' eklendi.")
        for w in (self.nf_kod, self.nf_unvan, self.nf_iban, self.nf_aciklama): w.clear()

    def _kaydet(self):
        a = self.veri.ayarlar
        a["banka_hesap_no"] = self.b_hesap.text().strip()
        a["kurum_adi"]      = self.b_kurum.text().strip()
        a["talimat_metni"]  = self.b_talimat.toPlainText().strip()
        a["liste_basligi"]  = self.b_liste.text().strip()
        a["imzalar"] = [{"ad": self.imza_ad[i].text().strip(),
                         "unvan": self.imza_unvan[i].text().strip()} for i in range(5)]
        a["c3_islem"]    = self.c3_islem.text().strip() or "EVRAK"
        a["c3_aciklama"] = self.c3_acik.text().strip() or "EFT GÖNDERİLEN"
        e = para_coz(self.esik_inp.text())
        a["tam_odeme_esigi"] = e if e > 0 else 5000
        ayar_kaydet(a)
        self.accept()


# ── Excel oluşturucular (Times New Roman 10, dolgu rengi YOK) ─────────────────
FONT_ADI = "Times New Roman"


def odenecek_listesi(veri):
    """Ödenecek > 0 firmalar — Vadesi Gelen sayfasıyla AYNI sıra (liste Türkçe sıralı)."""
    return [x for x in veri.liste if x["odenecek"] > 0]


def vg_workbook(veri):
    wb = Workbook(); ws = wb.active; ws.title = "Vadesi Gelen"
    thin = Side(style="thin", color="000000"); brd = Border(thin, thin, thin, thin)
    for i, w in enumerate([14, 50, 16, 16, 16, 16, 9], 1):
        ws.column_dimensions[chr(64 + i)].width = w
    hdr = ["Cari Kod", "Ticari Unvanı", "Bakiye", "Vadesi Gelen",
           "15 Gün Geçen", "Ödenecek Tutar", "Ödeme %"]
    for c, h in enumerate(hdr, 1):
        cl = ws.cell(1, c, h)
        cl.font = Font(name=FONT_ADI, bold=True, size=10)
        cl.alignment = Alignment("center", "center"); cl.border = brd
    for it in veri.liste:
        r = ws.max_row + 1
        yuzde = (it["odenecek"] / it["vadesi_gelen"]) if it["vadesi_gelen"] > 0 else 0
        vals = [it["cari_kod"], it["unvan"] + ("  (PEŞİN)" if it["pesin"] else ""),
                it["bakiye"], it["vadesi_gelen"], it["vadesi_15_gec"], it["odenecek"], yuzde]
        for c, v in enumerate(vals, 1):
            cl = ws.cell(r, c, v); cl.border = brd; cl.font = Font(name=FONT_ADI, size=10)
            if c in (3, 4, 5, 6): cl.number_format = "#,##0.00"
            if c == 7: cl.number_format = "0%"
            cl.alignment = Alignment(vertical="center",
                horizontal="center" if c in (1, 7) else "left" if c == 2 else "right")
    r = ws.max_row + 1
    for c in range(1, 8):
        cl = ws.cell(r, c); cl.border = brd
        cl.font = Font(name=FONT_ADI, bold=True, size=10)
        cl.alignment = Alignment("center" if c <= 2 else "right", "center")
    ws.cell(r, 1, "TOPLAM")
    ws.cell(r, 4, sum(x["vadesi_gelen"] for x in veri.liste)).number_format = "#,##0.00"
    ws.cell(r, 5, sum(x["vadesi_15_gec"] for x in veri.liste)).number_format = "#,##0.00"
    ws.cell(r, 6, sum(x["odenecek"] for x in veri.liste)).number_format = "#,##0.00"
    ws.freeze_panes = "A2"
    ws.print_area = f"A1:G{r}"
    ws.page_setup.orientation = "landscape"; ws.page_setup.paperSize = 9
    ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_margins = PageMargins(left=0.2, right=0.2, top=0.3, bottom=0.3, header=0.15, footer=0.15)
    return wb


def c3_workbook(veri, odenenler):
    a = veri.ayarlar
    wb = Workbook(); ws = wb.active; ws.title = "C3"
    thin = Side(style="thin", color="000000"); brd = Border(thin, thin, thin, thin)
    for col, w in zip("ABCD", (18, 16, 26, 16)):
        ws.column_dimensions[col].width = w
    for c, h in enumerate(["Cari Kodu", "İŞLEM", "AÇIKLAMA", "BORÇ"], 1):
        cl = ws.cell(1, c, h); cl.font = Font(name=FONT_ADI, bold=True, size=10)
        cl.alignment = Alignment("center", "center"); cl.border = brd
    for it in odenenler:
        r = ws.max_row + 1
        c1 = ws.cell(r, 1, it["cari_kod"]); c1.border = brd; c1.font = Font(name=FONT_ADI, size=10)
        c2 = ws.cell(r, 2, a.get("c3_islem", "EVRAK")); c2.border = brd; c2.font = Font(name=FONT_ADI, size=10)
        c3 = ws.cell(r, 3, a.get("c3_aciklama", "EFT GÖNDERİLEN")); c3.border = brd; c3.font = Font(name=FONT_ADI, size=10)
        bc = ws.cell(r, 4, round(it["odenecek"], 2)); bc.number_format = "#,##0.00"
        bc.border = brd; bc.font = Font(name=FONT_ADI, size=10)
    r = ws.max_row + 2
    tc = ws.cell(r, 4, round(sum(x["odenecek"] for x in odenenler), 2))
    tc.number_format = "#,##0.00"; tc.font = Font(name=FONT_ADI, bold=True, size=10)
    ws.print_area = f"A1:D{r}"
    ws.page_setup.orientation = "portrait"; ws.page_setup.paperSize = 9
    ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_margins = PageMargins(left=0.25, right=0.25, top=0.35, bottom=0.35, header=0.15, footer=0.15)
    return wb


def banka_sayfa_yaz(veri, wb, ad, grup):
    """A-K düzen: başlık 14, talimat 12 (iki yana yaslı + girinti), imzalar 12,
    açıklama G:J birleşik, tutar K, veri satır yüksekliği 27, tek sayfa."""
    a = veri.ayarlar
    ws = wb.create_sheet(ad)
    toplam = round(sum(x["odenecek"] for x in grup), 2)
    bugun = f"{date.today():%d.%m.%Y}"
    thin = Side(style="thin", color="000000"); brd = Border(thin, thin, thin, thin)
    F = FONT_ADI
    KOL = "ABCDEFGHIJK"

    # Sütun genişlikleri (11 sütun, yatay tek sayfaya sığacak şekilde)
    for col, w in zip(KOL, (6, 15, 15, 15, 20, 14, 12, 12, 12, 12, 17)):
        ws.column_dimensions[col].width = w

    # 1) TALİMAT — 14 punto
    ws.merge_cells("A1:K1")
    c = ws["A1"]; c.value = "TALİMAT"
    c.font = Font(name=F, bold=True, size=14); c.alignment = Alignment("center", "center")
    ws.row_dimensions[1].height = 26

    # 3) Talimat metni — 12 punto, iki yana yaslı (justify), ilk satır girintili
    ws.merge_cells("A3:K3")
    metin = a.get("talimat_metni", TALIMAT_VARSAYILAN).format(
        kurum=a.get("kurum_adi", ""), hesap=a.get("banka_hesap_no", ""),
        toplam=para(toplam), tarih=bugun)
    c = ws["A3"]; c.value = metin
    c.font = Font(name=F, size=12)
    c.alignment = Alignment(horizontal="justify", vertical="center", wrap_text=True)
    ws.row_dimensions[3].height = 66

    # 6-7) İmzalar — isimler 12 punto: A:C, D:E, F:G, H:I, J:K
    imzalar = a.get("imzalar", []); kolonlar = ["A", "D", "F", "H", "J"]
    for m in ("A6:C6", "D6:E6", "F6:G6", "H6:I6", "J6:K6",
              "A7:C7", "D7:E7", "F7:G7", "H7:I7", "J7:K7"):
        ws.merge_cells(m)
    for i, col in enumerate(kolonlar):
        ad_t = imzalar[i].get("ad", "") if i < len(imzalar) else ""
        un_t = imzalar[i].get("unvan", "") if i < len(imzalar) else ""
        c6 = ws[f"{col}6"]; c6.value = ad_t
        c6.font = Font(name=F, size=12); c6.alignment = Alignment("center", "center")
        c7 = ws[f"{col}7"]; c7.value = un_t
        c7.font = Font(name=F, size=10); c7.alignment = Alignment("center", "center")
    ws.row_dimensions[6].height = 28

    # 10) Liste başlığı
    ws.merge_cells("A10:K10")
    c = ws["A10"]; c.value = a.get("liste_basligi", "").format(tarih=bugun)
    c.font = Font(name=F, bold=True, size=12); c.alignment = Alignment("center", "center")
    ws.row_dimensions[10].height = 22

    # 11) Başlık satırı: açıklama G:J, tutar K
    ws.merge_cells("B11:D11"); ws.merge_cells("E11:F11"); ws.merge_cells("G11:J11")
    for adr, val in {"A11": "S. N.", "B11": "Ticari Unvanı", "E11": "Hesap No",
                     "G11": "Açıklama", "K11": "Ödenecek Tutar (TL)"}.items():
        c = ws[adr]; c.value = val
        c.font = Font(name=F, bold=True, size=11)
        c.alignment = Alignment("center", "center", wrap_text=True)
    for col in KOL:
        ws[f"{col}11"].border = brd
    ws.row_dimensions[11].height = 30

    # 12+) Veri satırları — metin uzunluğuna göre otomatik yükseklik (min 27)
    # Sütun kapasiteleri (11pt TNR, birleşik hücre genişliklerine göre yaklaşık karakter):
    KAP_UNVAN = 40    # B:D (15+15+15 genişlik)
    KAP_ACIK  = 44    # G:J (12*4 genişlik)
    r = 12
    for sira, it in enumerate(grup, 1):
        ws.merge_cells(f"B{r}:D{r}"); ws.merge_cells(f"E{r}:F{r}"); ws.merge_cells(f"G{r}:J{r}")
        ws[f"A{r}"] = sira
        ws[f"B{r}"] = it["banka_unvan"]
        ws[f"E{r}"] = it["iban"]
        ws[f"G{r}"] = it["aciklama"]
        tc = ws[f"K{r}"]; tc.value = round(it["odenecek"], 2); tc.number_format = "#,##0.00"
        ws[f"A{r}"].alignment = Alignment("center", "center")
        ws[f"B{r}"].alignment = Alignment("left", "center", wrap_text=True)
        ws[f"E{r}"].alignment = Alignment("center", "center", wrap_text=False)  # IBAN tek satır
        ws[f"G{r}"].alignment = Alignment("left", "center", wrap_text=True)
        tc.alignment = Alignment("right", "center")
        for col in KOL:
            cl = ws[f"{col}{r}"]; cl.border = brd; cl.font = Font(name=F, size=11)
        # kaç satıra sarar? en uzun sarma belirler
        import math as _math
        satir_unvan = max(1, _math.ceil(len(str(it["banka_unvan"])) / KAP_UNVAN))
        satir_acik  = max(1, _math.ceil(len(str(it["aciklama"]))   / KAP_ACIK))
        n_satir = min(3, max(satir_unvan, satir_acik))   # en çok 3 satır
        ws.row_dimensions[r].height = 27 if n_satir == 1 else (15 * n_satir + 6)
        r += 1

    # GENEL TOPLAM — son firmanın hemen altında
    ws.merge_cells(f"B{r}:F{r}"); ws.merge_cells(f"G{r}:J{r}")
    ws[f"G{r}"] = "GENEL TOPLAM"
    ws[f"G{r}"].font = Font(name=F, bold=True, size=11)
    ws[f"G{r}"].alignment = Alignment("right", "center")
    tc = ws[f"K{r}"]; tc.value = toplam; tc.number_format = "#,##0.00"
    tc.font = Font(name=F, bold=True, size=11); tc.alignment = Alignment("right", "center")
    for col in KOL:
        ws[f"{col}{r}"].border = brd
    ws.row_dimensions[r].height = 27

    # Baskı: yatay A4, tek sayfaya sığdır, dar kenar boşlukları, ortalı
    ws.print_area = f"A1:K{r}"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = 9
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.print_options.verticalCentered = False
    ws.page_margins = PageMargins(left=0.15, right=0.15, top=0.25, bottom=0.25,
                                  header=0.1, footer=0.1)


def banka_workbook(veri, odenenler):
    bolme = 50                         # banka talimatı: sayfa başına sabit 50 firma
    parcalar = [odenenler[i:i + bolme] for i in range(0, len(odenenler), bolme)]
    if not parcalar:
        parcalar = [[]]
    wb = Workbook(); wb.remove(wb.active)
    for idx, grup in enumerate(parcalar, 1):
        banka_sayfa_yaz(veri, wb, f"BANKAYA FORMAT ({idx})", grup)
    return wb, len(parcalar)


# ── Yıllık Performans (arşiv üzerinden, çift saymadan) ────────────────────────
def performans_hesapla(kayitlar, yil=None):
    """
    Bakiye kümülatif olduğu için haftalık 'Vadesi Gelen' değerleri TOPLANMAZ
    (aynı ödenmemiş borç her hafta tekrar sayılır). Bunun yerine:
      - Toplam Ödenen  → gerçek nakit çıkışı, haftalar arası TOPLANABİLİR.
      - Borç           → sadece İLK ve SON görülen bakiye (anlık durum).
      - Performans %   → haftalık yüzdelerin ORTALAMASI (toplama değil).
      - Kronik uyarı   → en son haftadan geriye doğru art arda ödenmeyen hafta sayısı.
    """
    sirali = sorted(kayitlar, key=lambda k: k.get("id", ""))
    if yil:
        sirali = [k for k in sirali if str(k.get("tarih", ""))[-4:] == str(yil)]
    firmalar = {}
    for k in sirali:
        for it in k.get("liste", []):
            kod = it.get("cari_kod", "")
            if not kod:
                continue
            f = firmalar.get(kod)
            if f is None:
                f = firmalar[kod] = {
                    "unvan": it.get("unvan", kod),
                    "ilk_bakiye": it.get("bakiye", 0), "ilk_tarih": k.get("zaman", k.get("tarih", "")),
                    "son_bakiye": it.get("bakiye", 0), "son_tarih": k.get("zaman", k.get("tarih", "")),
                    "toplam_odenen": 0.0, "hafta_sayisi": 0,
                    "yuzde_toplam": 0.0, "yuzde_sayisi": 0, "gecmis": [],
                }
            f["son_bakiye"] = it.get("bakiye", 0); f["son_tarih"] = k.get("zaman", k.get("tarih", ""))
            f["toplam_odenen"] += it.get("odenecek", 0)
            f["hafta_sayisi"] += 1
            vg = it.get("vadesi_gelen", 0); od = it.get("odenecek", 0)
            if vg > 0:
                f["yuzde_toplam"] += min(100.0, (od / vg) * 100)
                f["yuzde_sayisi"] += 1
            f["gecmis"].append((vg - od) > 1.0)   # bu hafta ödenmedi mi (1 TL tolerans)

    sonuc = []
    for kod, f in firmalar.items():
        ort_yuzde = (f["yuzde_toplam"] / f["yuzde_sayisi"]) if f["yuzde_sayisi"] > 0 else 0.0
        streak = 0
        for odenmedi in reversed(f["gecmis"]):
            if odenmedi: streak += 1
            else: break
        sonuc.append({
            "cari_kod": kod, "unvan": f["unvan"],
            "ilk_bakiye": round(f["ilk_bakiye"], 2), "ilk_tarih": f["ilk_tarih"],
            "son_bakiye": round(f["son_bakiye"], 2), "son_tarih": f["son_tarih"],
            "toplam_odenen": round(f["toplam_odenen"], 2),
            "hafta_sayisi": f["hafta_sayisi"],
            "ortalama_yuzde": round(ort_yuzde, 1),
            "kronik_streak": streak,
        })
    sonuc.sort(key=lambda x: tr_key(x["unvan"]))
    return sonuc


def perf_workbook(perf_liste, kronik_esik=2):
    wb = Workbook(); ws = wb.active; ws.title = "Yıllık Performans"
    thin = Side(style="thin", color="000000"); brd = Border(thin, thin, thin, thin)
    F = FONT_ADI
    for col, w in zip("ABCDEFGHI", (14, 42, 16, 14, 16, 14, 16, 12, 12)):
        ws.column_dimensions[col].width = w
    hdr = ["Cari Kod", "Ticari Unvanı", "İlk Bakiye", "İlk Tarih", "Son Bakiye",
           "Son Tarih", "Toplam Ödenen", "Hafta Sayısı", "Ort. Ödeme %"]
    for c, h in enumerate(hdr, 1):
        cl = ws.cell(1, c, h); cl.font = Font(name=F, bold=True, size=10)
        cl.alignment = Alignment("center", "center"); cl.border = brd
    for it in perf_liste:
        r = ws.max_row + 1
        vals = [it["cari_kod"], it["unvan"], it["ilk_bakiye"], it["ilk_tarih"],
                it["son_bakiye"], it["son_tarih"], it["toplam_odenen"],
                it["hafta_sayisi"], it["ortalama_yuzde"] / 100]
        for c, v in enumerate(vals, 1):
            cl = ws.cell(r, c, v); cl.border = brd; cl.font = Font(name=F, size=10)
            if c in (3, 5, 7): cl.number_format = "#,##0.00"
            if c == 9: cl.number_format = "0.0%"
            cl.alignment = Alignment(vertical="center",
                horizontal="center" if c in (1, 4, 6, 8, 9) else "left" if c == 2 else "right")
        if it["kronik_streak"] >= kronik_esik:
            for c in range(1, 10):
                ws.cell(r, c).font = Font(name=F, size=10, color="C0392B", bold=True)
    ws.freeze_panes = "A2"
    ws.print_area = f"A1:I{ws.max_row}"
    ws.page_setup.orientation = "landscape"; ws.page_setup.paperSize = 9
    ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_margins = PageMargins(left=0.2, right=0.2, top=0.3, bottom=0.3, header=0.15, footer=0.15)
    return wb


# ── Tıklanabilir Dosya Kartı ──────────────────────────────────────────────────
class DosyaKart(QFrame):
    def __init__(self, ikon, etiket, callback, parent=None):
        super().__init__(parent)
        self.callback = callback
        self.etiket = etiket
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(100)
        self._stil(False)
        lay = QHBoxLayout(self); lay.setContentsMargins(16, 11, 15, 11); lay.setSpacing(13)
        ik = LineIcon("bank" if ikon == "B" else "file")
        ik.setStyleSheet(
            f"font-size:19px;border:1px solid #CDDFEF;border-radius:12px;"
            f"background:#E6EFF8;color:{C['accent']};")
        lay.addWidget(ik)
        iy = QVBoxLayout(); iy.setSpacing(3)
        self.l_etiket = QLabel(etiket)
        self.l_etiket.setWordWrap(True)
        self.l_etiket.setStyleSheet(
            f"color:{C['text']};font-family:'Segoe UI Variable Display','Segoe UI';font-size:14px;"
            f"font-weight:700;border:none;background:transparent;")
        self.l_durum = QLabel("Dosya seçilmedi")
        self.l_durum.setWordWrap(True)
        self.l_durum.setStyleSheet(f"color:{C['muted']};font-size:10px;border:none;background:transparent;")
        iy.addWidget(self.l_etiket); iy.addWidget(self.l_durum)
        lay.addLayout(iy, 1)
        ok = QLabel("›"); ok.setStyleSheet(
            f"color:{C['muted']};font-size:25px;font-weight:300;border:none;background:transparent;")
        lay.addWidget(ok)

    def _stil(self, dolu):
        if dolu:
            self.setStyleSheet(
                f"DosyaKart{{background:{C['surface']};border:1px solid {C['border']};border-radius:9px;}}"
                f"DosyaKart:hover{{background:#F1F6FB;border-color:#ADC5DD;}}")
        else:
            self.setStyleSheet(
                f"DosyaKart{{background:{C['surface']};border:1px solid {C['border']};border-radius:9px;}}"
                f"DosyaKart:hover{{background:#F1F6FB;border-color:#ADC5DD;}}")

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.callback()

    def ayarla(self, dosya_adi):
        if dosya_adi:
            self._stil(True)
            self.l_durum.setText("✓  " + dosya_adi)
            self.l_durum.setStyleSheet(f"color:{C['success']};font-size:10px;font-weight:700;border:none;background:transparent;")
            self.setToolTip(dosya_adi)
        else:
            self._stil(False)
            self.l_durum.setText("Dosya seçilmedi")
            self.l_durum.setStyleSheet(f"color:{C['muted']};font-size:10px;border:none;background:transparent;")
            self.setToolTip("")


# ── Ana Pencere ────────────────────────────────────────────────────────────────
class Ana(QMainWindow):
    def __init__(self):
        super().__init__()
        self.veri = Veri()
        self.bakiye_path  = self.veri.ayarlar.get("bakiye_path", "")
        self.hareket_path = self.veri.ayarlar.get("hareket_path", "")
        self._dolduruyor = False
        self.setWindowTitle("Firma Ödeme Sistemi")
        self.setMinimumSize(1360, 740)
        self.resize(1580, 860)
        if os.path.exists(ICON_F):
            self.setWindowIcon(QIcon(ICON_F))
        self._build()
        self._firma_otomatik_yukle()
        self._kart_guncelle()
        if not self._oturum_geri_yukle():
            self.status.showMessage("Hazır — dosyaları seçip HESAPLA'ya basın.")

    def _oturum_geri_yukle(self):
        """Önceki çalışmada girilen veriler (ödenecek tutarlar, bankadaki) geri gelsin."""
        d = oturum_yukle()
        if not d:
            return False
        self.veri.liste = d["liste"]
        self._tabloyu_doldur()
        if d.get("bankadaki"):
            self.k_bank.val.setText(d["bankadaki"])
        self._kpi_guncelle()
        self._c3_doldur(); self._banka_doldur()
        self._kart_guncelle()
        self.status.showMessage("Önceki kayıtlı veriler yüklendi. Değiştirmek için HESAPLA'ya basın.")
        return True

    # ---- arayüz ----
    def _build(self):
        central = QWidget(); self.setCentralWidget(central)
        root = QVBoxLayout(central); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        bar = QFrame(); bar.setObjectName("topBar"); bar.setFixedHeight(76)
        header = QHBoxLayout(bar); header.setContentsMargins(18,0,18,0); header.setSpacing(6)
        header.addWidget(LineIcon("chart"))
        brand = QLabel("Firma Ödeme Sistemi")
        brand.setStyleSheet(f"font-size:17px;font-weight:700;color:{C['text']};")
        header.addWidget(brand); header.addSpacing(12)
        self.nav_buttons = []
        for i,title in enumerate(("Vadesi Gelen","C3 (Muhasebe)","Bankaya Format","Geçmiş Arşiv","Yıllık Performans")):
            button=QPushButton(title); button.setProperty("cls","nav"); button.setCheckable(True)
            button.clicked.connect(lambda checked=False, idx=i: self._navigate(idx))
            self.nav_buttons.append(button); header.addWidget(button)
        header.addStretch(); header.addWidget(QLabel("Vade kesimi"))
        self.vade_mod = QComboBox(); self.vade_mod.addItems(["Bu Pazar (varsayılan)","Sonraki Pazar","Belirli tarih"])
        self.vade_mod.setFixedWidth(150); self.vade_mod.currentIndexChanged.connect(self._vade_mod_degisti)
        header.addWidget(self.vade_mod)
        self.vade_tarih = QDateEdit(); self.vade_tarih.setCalendarPopup(True)
        self.vade_tarih.setDisplayFormat("dd.MM.yyyy"); self.vade_tarih.setDate(QDate.currentDate())
        self.vade_tarih.setFixedWidth(108); self.vade_tarih.setVisible(False)
        self.vade_tarih.dateChanged.connect(lambda *_: self._vade_ipucu()); header.addWidget(self.vade_tarih)
        self.btn_hesapla=self._btn("HESAPLA","primary",self._hesapla)
        self.btn_kaydet=self._btn("Kaydet","sec",self._kaydet_butonu)
        self.btn_ayar=self._btn("Ayarlar","sec",self._ayarlar)
        for button in (self.btn_hesapla,self.btn_kaydet,self.btn_ayar): header.addWidget(button)
        root.addWidget(bar)
        body=QHBoxLayout(); body.setContentsMargins(0,0,0,0); body.setSpacing(0)
        rail=QFrame(); rail.setObjectName("sourceRail"); rail.setFixedWidth(235)
        side=QVBoxLayout(rail); side.setContentsMargins(14,18,14,14); side.setSpacing(12)
        self.kart_firma=DosyaKart("F","Firma Bilgileri",self._sec_firma)
        self.kart_bakiye=DosyaKart("B","Toplam Borç",self._sec_bakiye)
        self.kart_hareket=DosyaKart("H","Toplu Cari Hareket Raporu",self._sec_hareket)
        for card in (self.kart_firma,self.kart_bakiye,self.kart_hareket): side.addWidget(card)
        side.addStretch()
        side.addWidget(QLabel("Görünüm tercihi"))
        self.theme_selector=QComboBox(); self.theme_selector.addItems(["Açık Kurumsal","Koyu Modern"])
        side.addWidget(self.theme_selector)
        note=QLabel("Dosya seçmek veya değiştirmek için ilgili karta tıklayın.")
        note.setWordWrap(True); note.setStyleSheet(f"color:{C['muted']};font-size:11px;")
        side.addWidget(note); body.addWidget(rail)
        self.tabs=QTabWidget(); self.tabs.tabBar().hide()
        self.tabs.addTab(self._sayfa_vg(),"Vadesi Gelen")
        self.c3_kapsa=QWidget(); self.c3_lay=QVBoxLayout(self.c3_kapsa)
        self.banka_kapsa=QWidget(); self.banka_lay=QVBoxLayout(self.banka_kapsa)
        self.arsiv_kapsa=QWidget(); self.arsiv_lay=QVBoxLayout(self.arsiv_kapsa)
        self.perf_kapsa=QWidget(); self.perf_lay=QVBoxLayout(self.perf_kapsa)
        for widget,title in ((self.c3_kapsa,"C3 (Muhasebe)"),(self.banka_kapsa,"Bankaya Format"),
                             (self.arsiv_kapsa,"Geçmiş Arşiv"),(self.perf_kapsa,"Yıllık Performans")):
            self.tabs.addTab(widget,title)
        self.tabs.currentChanged.connect(self._tab_degisti)
        self.tabs.currentChanged.connect(self._nav_sync)
        content=QWidget(); content_layout=QVBoxLayout(content); content_layout.setContentsMargins(14,16,14,12)
        content_layout.addWidget(self.tabs); body.addWidget(content,1); root.addLayout(body,1)
        self.status=QStatusBar(); self.setStatusBar(self.status)
        self._c3_doldur(); self._banka_doldur(); self._arsiv_doldur(); self._nav_sync(0)
        self._ui_preferences_path=os.path.join(DATA_DIR,"arayuz-tercihi.json")
        try:
            with open(self._ui_preferences_path,encoding="utf-8") as f: dark=json.load(f).get("tema")=="dark"
        except (OSError,ValueError,AttributeError): dark=False
        self.theme_selector.setCurrentIndex(1 if dark else 0)
        self.theme_selector.currentIndexChanged.connect(self._theme_changed)
        self._theme_changed(self.theme_selector.currentIndex(),persist=False)

    def _navigate(self,index):
        self.tabs.setCurrentIndex(index)
        self._nav_sync(index)

    def _nav_sync(self,index):
        for i,button in enumerate(self.nav_buttons): button.setChecked(i==index)

    def _theme_changed(self,index,persist=True):
        name="dark" if index==1 else "light"
        QApplication.instance().theme_manager.set_theme(name)
        if persist:
            try:
                with open(self._ui_preferences_path,"w",encoding="utf-8") as f: json.dump({"tema":name},f)
            except OSError:
                self.status.showMessage("Tema uygulandı; görünüm tercihi diske kaydedilemedi.")


    def _btn(self, metin, cls, slot):
        b = QPushButton(metin)
        kinds = {"HESAPLA":"calculate", "Kaydet":"save", "Ayarlar":"settings", "Excel'e Aktar":"export", "Eşit Dağıt":"split", "Sadece Peşinleri Öde":"bolt"}
        if metin in kinds:
            b._icon_kind = kinds[metin]; b.setIcon(button_icon(b._icon_kind))
        if cls: b.setProperty("cls", cls)
        b.clicked.connect(slot)
        return b

    # ---- Vadesi Gelen sayfası ----
    def _sayfa_vg(self):
        w=QWidget(); body=QHBoxLayout(w); body.setContentsMargins(0,0,0,0); body.setSpacing(14)
        gauge_column=QVBoxLayout(); gauge_column.setSpacing(9)
        frame=QFrame(); frame.setFixedWidth(140)
        frame.setStyleSheet(f"QFrame{{background:{C['surface']};border:1px solid {C['border']};border-radius:9px;}}")
        gauge_layout=QVBoxLayout(frame); gauge_layout.setContentsMargins(4,10,4,4)
        label=QLabel("Ödeme Oranı"); label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet(f"border:none;color:{C['text']};font-size:12px;")
        gauge_layout.addWidget(label); self.gauge=GaugeWidget(); self.gauge.setStyleSheet("border:none;background:transparent;")
        gauge_layout.addWidget(self.gauge); gauge_column.addWidget(frame); gauge_column.addStretch()
        body.addLayout(gauge_column)
        main=QVBoxLayout(); main.setSpacing(14)
        self.k_vg=KpiKart("Vadesi Gelen Borç",C["accent"])
        self.k_od=KpiKart("Ödenecek Tutar",C["success"])
        self.k_odm=KpiKart("Ödenemeyen Tutar",C["danger"])
        self.k_v15=KpiKart("15 Gün Geçen",C["warning"])
        self.k_bank=KpiKart("Bankadaki Tutar",C["accent"],duzenlenebilir=True)
        self.k_fark=KpiKart("Banka − Ödenecek Farkı",C["text"])
        cards=QHBoxLayout(); cards.setSpacing(8)
        for card in (self.k_vg,self.k_od,self.k_odm,self.k_v15,self.k_bank,self.k_fark):
            card.setMinimumWidth(0); cards.addWidget(card,1)
        main.addLayout(cards)
        self.k_bank.val.textChanged.connect(self._kpi_guncelle)
        self.k_bank.val.editingFinished.connect(self._bankadaki_bicimle)
        plan=QFrame(); plan.setObjectName("paymentPlan")
        plan.setStyleSheet(f"QFrame#paymentPlan{{background:{C['surface']};border:1px solid {C['border']};border-radius:9px;}}")
        panel=QVBoxLayout(plan); panel.setContentsMargins(10,10,10,10); panel.setSpacing(10)
        title=QLabel("Ödeme Planı"); title.setStyleSheet(f"font-size:15px;font-weight:700;color:{C['text']};")
        panel.addWidget(title)
        self.tbl=QTableWidget(0,7)
        self.tbl.setHorizontalHeaderLabels(["Cari Kod","Ticari Unvanı","Bakiye","Vadesi Gelen","15 Gün Geçen","Ödenecek Tutar","Ödeme %"])
        self.tbl.verticalHeader().hide(); self.tbl.verticalHeader().setDefaultSectionSize(38)
        self.tbl.setAlternatingRowColors(True); self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        h=self.tbl.horizontalHeader(); h.setSectionResizeMode(0,QHeaderView.ResizeToContents)
        h.setSectionResizeMode(1,QHeaderView.Stretch)
        for c in range(2,6): h.setSectionResizeMode(c,QHeaderView.ResizeToContents)
        h.setSectionResizeMode(6,QHeaderView.Fixed); self.tbl.setColumnWidth(6,160)
        self.tbl.setItemDelegateForColumn(6,PaymentDelegate(self.tbl))
        self.tbl.itemChanged.connect(self._odenecek_degisti)
        self.tbl.setContextMenuPolicy(Qt.CustomContextMenu); self.tbl.customContextMenuRequested.connect(self._tbl_sag_tik)
        panel.addWidget(self.tbl,1)
        footer=QHBoxLayout(); footer.setSpacing(7)
        legend=QLabel("%50 altı kırmızı · %50–80 sarı · %80 ve üzeri yeşil")
        legend.setStyleSheet(f"font-size:10px;color:{C['muted']};")
        footer.addWidget(legend); footer.addStretch()
        self.btn_vg=self._btn("Excel'e Aktar","export",self._export_vg)
        self.btn_dagit=self._btn("Eşit Dağıt","sec",self._esit_dagit)
        self.btn_pesin=self._btn("Sadece Peşinleri Öde","sec",self._sadece_pesin)
        for button in (self.btn_vg,self.btn_dagit,self.btn_pesin): footer.addWidget(button)
        panel.addLayout(footer)
        extra=QHBoxLayout(); extra.addWidget(QLabel("● Peşin firma    ● Kara liste (ödenecek 0)")); extra.addStretch()
        self.btn_reset=self._btn("Ödenecek = Vadesi Gelen","sec",self._odenecek_sifirla)
        extra.addWidget(self.btn_reset); panel.addLayout(extra)
        main.addWidget(plan,1); body.addLayout(main,1)
        return w


    # ---- C3 sayfası ----
    def _c3_doldur(self):
        self._temizle(self.c3_lay)
        a = self.veri.ayarlar
        odn = odenecek_listesi(self.veri)
        if not odn:
            self.c3_lay.addWidget(self._bos_mesaj("Önce dosyaları yükleyip HESAPLA'ya basın, "
                                                  "ardından ödenecek tutarları girin."))
            return
        bl = QLabel("📑  C3 (Muhasebe) — bu şablon Excel'e aktarılacak")
        bl.setStyleSheet(f"font-size:14px;font-weight:700;color:{C['gold']};")
        self.c3_lay.addWidget(bl)
        tbl = QTableWidget(len(odn), 4)
        tbl.setHorizontalHeaderLabels(["Cari Kodu", "İŞLEM", "AÇIKLAMA", "BORÇ"])
        tbl.verticalHeader().setVisible(False)
        tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tbl.setAlternatingRowColors(True)
        tbl.setItemDelegateForColumn(6, PaymentDelegate(tbl)); tbl.setColumnWidth(6, 150)
        hh = tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        for i, it in enumerate(odn):
            tbl.setItem(i, 0, QTableWidgetItem(it["cari_kod"]))
            tbl.setItem(i, 1, QTableWidgetItem(a.get("c3_islem", "EVRAK")))
            tbl.setItem(i, 2, QTableWidgetItem(a.get("c3_aciklama", "EFT GÖNDERİLEN")))
            bi = QTableWidgetItem(para(it["odenecek"])); bi.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            tbl.setItem(i, 3, bi); tbl.setRowHeight(i, 24)
        self.c3_lay.addWidget(tbl, 1)
        alt = QHBoxLayout()
        toplam = sum(x["odenecek"] for x in odn)
        tl = QLabel(f"{len(odn)} kayıt   •   TOPLAM: {para(toplam)} ₺")
        tl.setStyleSheet(f"font-size:13px;font-weight:700;")
        alt.addWidget(tl); alt.addStretch()
        be = self._btn("📥  Excel'e Aktar", "gold", self._export_c3)
        alt.addWidget(be); self.c3_lay.addLayout(alt)

    # ---- BANKAYA sayfası ----
    def _banka_doldur(self):
        self._temizle(self.banka_lay)
        a = self.veri.ayarlar
        odn = odenecek_listesi(self.veri)
        if not odn:
            self.banka_lay.addWidget(self._bos_mesaj("Önce dosyaları yükleyip HESAPLA'ya basın, "
                                                     "ardından ödenecek tutarları girin."))
            return
        bolme = 50
        parcalar = [odn[i:i + bolme] for i in range(0, len(odn), bolme)]
        bugun = f"{date.today():%d.%m.%Y}"

        bl = QLabel(f"🏦  BANKAYA FORMAT — {len(odn)} firma, {len(parcalar)} sayfa "
                    f"(her {bolme} firmada yeni sayfa)")
        bl.setStyleSheet(f"font-size:14px;font-weight:700;color:{C['success']};")
        self.banka_lay.addWidget(bl)
        eksik = [x for x in odn if not x["iban"]]
        if eksik:
            u = QLabel(f"⚠️  {len(eksik)} firmanın IBAN'ı eksik (Ayarlar → Firma Ekle). Hesap No boş çıkar.")
            u.setStyleSheet(f"color:{C['warning']};font-size:12px;font-weight:600;"); u.setWordWrap(True)
            self.banka_lay.addWidget(u)

        ic_tabs = QTabWidget()
        ic_tabs.setStyleSheet(f"QTabBar::tab{{padding:5px 14px;}}")
        for idx, grup in enumerate(parcalar, 1):
            ic_tabs.addTab(self._banka_sayfa_widget(grup, bugun), f"Sayfa {idx}")
        self.banka_lay.addWidget(ic_tabs, 1)

        alt = QHBoxLayout(); alt.addStretch()
        be = self._btn("📥  Excel'e Aktar", "ok", self._export_banka)
        alt.addWidget(be); self.banka_lay.addLayout(alt)

    def _banka_sayfa_widget(self, grup, bugun):
        a = self.veri.ayarlar
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setStyleSheet("QScrollArea{border:none;}")
        w = QWidget(); sc.setWidget(w)
        v = QVBoxLayout(w); v.setContentsMargins(10, 10, 10, 10); v.setSpacing(7)
        toplam = sum(x["odenecek"] for x in grup)

        bas = QLabel("TALİMAT"); bas.setAlignment(Qt.AlignCenter)
        bas.setStyleSheet("font-size:15px;font-weight:800;letter-spacing:2px;")
        v.addWidget(bas)
        metin = a.get("talimat_metni", TALIMAT_VARSAYILAN).format(
            kurum=a.get("kurum_adi", ""), hesap=a.get("banka_hesap_no", ""),
            toplam=para(toplam), tarih=bugun)
        tm = QLabel(metin.strip()); tm.setWordWrap(True)
        tm.setStyleSheet(f"font-family:'Times New Roman';font-size:13px;color:{C['text']};"
                         f"background:{C['surface2']};border:1px solid {C['border']};border-radius:6px;padding:8px;")
        v.addWidget(tm)
        imz = QHBoxLayout()
        for im in a.get("imzalar", [])[:5]:
            ku = QVBoxLayout()
            ad = QLabel(im.get("ad", "")); ad.setAlignment(Qt.AlignCenter)
            ad.setStyleSheet("font-weight:400;font-size:11px;")
            un = QLabel(im.get("unvan", "")); un.setAlignment(Qt.AlignCenter)
            un.setStyleSheet(f"color:{C['muted']};font-size:10px;")
            ku.addWidget(ad); ku.addWidget(un); imz.addLayout(ku)
        v.addLayout(imz)
        lbl = QLabel(a.get("liste_basligi", "").format(tarih=bugun)); lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet("font-weight:700;font-size:12px;margin-top:4px;"); v.addWidget(lbl)

        tbl = QTableWidget(len(grup), 5)
        tbl.setHorizontalHeaderLabels(["S.N.", "Ticari Unvanı", "Hesap No", "Açıklama", "Ödenecek Tutar (TL)"])
        tbl.verticalHeader().setVisible(False)
        tbl.setEditTriggers(QAbstractItemView.NoEditTriggers); tbl.setAlternatingRowColors(True)
        tbl.setItemDelegateForColumn(6, PaymentDelegate(tbl)); tbl.setColumnWidth(6, 150)
        hh = tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.Stretch); hh.setSectionResizeMode(3, QHeaderView.Stretch)
        tbl.setMinimumHeight(min(420, 40 + 25 * len(grup)))
        for i, it in enumerate(grup):
            tbl.setItem(i, 0, QTableWidgetItem(str(i + 1)))
            tbl.setItem(i, 1, QTableWidgetItem(it["banka_unvan"]))
            ib = QTableWidgetItem(it["iban"] or "—")
            if not it["iban"]: ib.setForeground(QColor(C["danger"]))
            tbl.setItem(i, 2, ib)
            tbl.setItem(i, 3, QTableWidgetItem(it["aciklama"]))
            tut = QTableWidgetItem(para(it["odenecek"])); tut.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            tbl.setItem(i, 4, tut); tbl.setRowHeight(i, 24)
        v.addWidget(tbl, 1)
        gt = QLabel(f"GENEL TOPLAM:  {para(toplam)} ₺"); gt.setAlignment(Qt.AlignRight)
        gt.setStyleSheet("font-weight:800;font-size:13px;"); v.addWidget(gt)
        return sc

    def _bos_mesaj(self, metin):
        l = QLabel(metin); l.setAlignment(Qt.AlignCenter); l.setWordWrap(True)
        l.setStyleSheet(f"color:{C['muted']};font-size:14px;padding:40px;")
        return l

    # ---- Geçmiş Listeler (arşiv) ----
    def _arsiv_doldur(self):
        self._temizle(self.arsiv_lay)
        kayitlar = arsiv_yukle()
        self._arsiv_kayitlar = kayitlar

        ust = QHBoxLayout()
        bl = QLabel("📋  Geçmiş Ödeme Listeleri — kime ne kadar borç, ne kadar ödendi, yüzde kaç")
        bl.setStyleSheet(f"font-size:14px;font-weight:700;color:{C['accent']};")
        ust.addWidget(bl); ust.addStretch()
        b_ekle = self._btn(f"➕  Bu Listeyi Arşivle ({date.today():%d.%m.%Y})", "ok", self._arsiv_ekle)
        b_sil  = self._btn("🗑  Seçili Kaydı Sil", "danger", self._arsiv_sil)
        ust.addWidget(b_ekle); ust.addWidget(b_sil)
        self.arsiv_lay.addLayout(ust)

        if not kayitlar:
            self.arsiv_lay.addWidget(self._bos_mesaj(
                "Henüz arşivlenmiş liste yok.\nVadesi Gelen sekmesinde ödemeleri ayarlayıp "
                "buradaki “Bu Listeyi Arşivle” düğmesine basarak her haftanın kaydını saklayabilirsiniz."))
            return

        # Kayıt listesi tablosu
        self.arsiv_tbl = QTableWidget(len(kayitlar), 6)
        self.arsiv_tbl.setHorizontalHeaderLabels(
            ["Tarih / Zaman", "Firma", "Vadesi Gelen Borç", "Ödenen", "Ödenmeyen", "Ödeme %"])
        self.arsiv_tbl.verticalHeader().setVisible(False)
        self.arsiv_tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.arsiv_tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.arsiv_tbl.setAlternatingRowColors(True)
        self.arsiv_tbl.setMaximumHeight(230)
        hh = self.arsiv_tbl.horizontalHeader(); hh.setSectionResizeMode(0, QHeaderView.Stretch)
        for c in range(1, 6): hh.setSectionResizeMode(c, QHeaderView.ResizeToContents)
        # en yeni üstte
        sirali = sorted(kayitlar, key=lambda k: k.get("id", ""), reverse=True)
        self._arsiv_sirali = sirali
        for i, k in enumerate(sirali):
            self.arsiv_tbl.setItem(i, 0, QTableWidgetItem(k.get("zaman", k.get("tarih", ""))))
            self.arsiv_tbl.setItem(i, 1, QTableWidgetItem(str(k.get("firma_sayisi", len(k.get("liste", []))))))
            for c, key in ((2, "vg_toplam"), (3, "od_toplam"), (4, "odenmeyen")):
                it = QTableWidgetItem(para(k.get(key, 0)) + " ₺"); it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.arsiv_tbl.setItem(i, c, it)
            yz = QTableWidgetItem(f"%{k.get('yuzde', 0):.1f}"); yz.setTextAlignment(Qt.AlignCenter)
            self.arsiv_tbl.setItem(i, 5, yz); self.arsiv_tbl.setRowHeight(i, 26)
        self.arsiv_tbl.itemSelectionChanged.connect(self._arsiv_detay_goster)
        self.arsiv_lay.addWidget(self.arsiv_tbl)

        self.arsiv_detay_baslik = QLabel("Detayları görmek için yukarıdan bir kayıt seçin.")
        self.arsiv_detay_baslik.setStyleSheet(f"color:{C['muted']};font-size:12px;font-weight:600;margin-top:4px;")
        self.arsiv_lay.addWidget(self.arsiv_detay_baslik)

        self.arsiv_detay_tbl = QTableWidget(0, 6)
        self.arsiv_detay_tbl.setHorizontalHeaderLabels(
            ["Cari Kod", "Ticari Unvanı", "Bakiye", "Vadesi Gelen", "Ödenen", "Ödeme %"])
        self.arsiv_detay_tbl.verticalHeader().setVisible(False)
        self.arsiv_detay_tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.arsiv_detay_tbl.setAlternatingRowColors(True)
        dh = self.arsiv_detay_tbl.horizontalHeader()
        dh.setSectionResizeMode(1, QHeaderView.Stretch)
        for c in (0, 2, 3, 4, 5): dh.setSectionResizeMode(c, QHeaderView.ResizeToContents)
        self.arsiv_lay.addWidget(self.arsiv_detay_tbl, 1)
        self.arsiv_tbl.selectRow(0)

    def _arsiv_detay_goster(self):
        r = self.arsiv_tbl.currentRow()
        if r < 0 or r >= len(getattr(self, "_arsiv_sirali", [])):
            return
        k = self._arsiv_sirali[r]
        liste = k.get("liste", [])
        self.arsiv_detay_baslik.setText(
            f"📄  {k.get('zaman', k.get('tarih',''))}  —  {len(liste)} firma  •  "
            f"Ödenen {para(k.get('od_toplam',0))} ₺ / Vadesi Gelen {para(k.get('vg_toplam',0))} ₺  "
            f"(%{k.get('yuzde',0):.1f})")
        self.arsiv_detay_tbl.setRowCount(0)
        for it in liste:
            rr = self.arsiv_detay_tbl.rowCount(); self.arsiv_detay_tbl.insertRow(rr)
            self.arsiv_detay_tbl.setRowHeight(rr, 24)
            vg = it.get("vadesi_gelen", 0); od = it.get("odenecek", 0)
            yz = (od / vg * 100) if vg > 0 else 0
            c0 = QTableWidgetItem(it.get("cari_kod", "")); c0.setTextAlignment(Qt.AlignCenter)
            self.arsiv_detay_tbl.setItem(rr, 0, c0)
            self.arsiv_detay_tbl.setItem(rr, 1, QTableWidgetItem(it.get("unvan", "")))
            for c, val in ((2, it.get("bakiye", 0)), (3, vg), (4, od)):
                ci = QTableWidgetItem(para(val)); ci.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.arsiv_detay_tbl.setItem(rr, c, ci)
            cy = QTableWidgetItem(f"%{yz:.0f}"); cy.setTextAlignment(Qt.AlignCenter)
            self.arsiv_detay_tbl.setItem(rr, 5, cy)

    def _arsiv_ekle(self):
        if not self.veri.liste:
            uyari(self, "Uyarı", "Arşivlenecek liste yok — önce HESAPLA'ya basın."); return
        simdi = datetime.now()
        bugun_str = simdi.strftime("%d.%m.%Y")
        eski = arsiv_yukle()
        ayni_gun = [k for k in eski if k.get("tarih") == bugun_str]
        if ayni_gun:
            c = sor(
                self, "Bugün Zaten Arşivlenmiş",
                f"{bugun_str} tarihli {len(ayni_gun)} arşiv kaydı zaten var.\n\n"
                "• EVET  → eski kayıt(lar) silinip bugünün güncel listesi yazılır (önerilen)\n"
                "• HAYIR → vazgeç\n\n"
                "Aynı günün iki kez kaydı, Yıllık Performans'ta haftayı çift sayar.",
                varsayilan_hayir=False)
            if c != QMessageBox.Yes:
                return
            eski = [k for k in eski if k.get("tarih") != bugun_str]
        vg = sum(x["vadesi_gelen"] for x in self.veri.liste)
        od = sum(x["odenecek"] for x in self.veri.liste)
        kayit = {
            "id": simdi.strftime("%Y%m%d_%H%M%S"),
            "tarih": simdi.strftime("%d.%m.%Y"),
            "zaman": simdi.strftime("%d.%m.%Y %H:%M"),
            "bankadaki": self.k_bank.val.text(),
            "firma_sayisi": len(self.veri.liste),
            "vg_toplam": round(vg, 2),
            "od_toplam": round(od, 2),
            "odenmeyen": round(max(0.0, vg - od), 2),
            "yuzde": round((od / vg * 100) if vg > 0 else 0, 1),
            "liste": [dict(x) for x in self.veri.liste],
        }
        eski.append(kayit); arsiv_kaydet(eski)
        self._arsiv_doldur()
        self.status.showMessage(f"✓ {kayit['zaman']} tarihli liste arşivlendi ({kayit['firma_sayisi']} firma).")

    def _arsiv_sil(self):
        r = getattr(self, "arsiv_tbl", None) and self.arsiv_tbl.currentRow()
        if r is None or r < 0 or r >= len(getattr(self, "_arsiv_sirali", [])):
            bilgi(self, "Bilgi", "Silmek için bir kayıt seçin."); return
        k = self._arsiv_sirali[r]
        c = sor(self, "Kaydı Sil",
            f"{k.get('zaman','')} tarihli arşiv kaydı silinsin mi?")
        if c != QMessageBox.Yes: return
        kayitlar = [x for x in arsiv_yukle() if x.get("id") != k.get("id")]
        arsiv_kaydet(kayitlar); self._arsiv_doldur()
        self.status.showMessage("Arşiv kaydı silindi.")

    # ---- Yıllık Performans ----
    def _perf_doldur(self):
        self._temizle(self.perf_lay)
        kayitlar = arsiv_yukle()
        if len(kayitlar) < 1:
            self.perf_lay.addWidget(self._bos_mesaj(
                "Henüz arşiv kaydı yok.\n“Geçmiş Listeler” sekmesinden en az bir hafta "
                "arşivlediğinizde burada yıllık performans görünür."))
            return

        # Yıl seçici — arşivdeki yıllar
        yillar = sorted({str(k.get("tarih", ""))[-4:] for k in kayitlar if k.get("tarih")},
                        reverse=True)
        if not hasattr(self, "_perf_yil") or self._perf_yil not in yillar:
            self._perf_yil = yillar[0] if yillar else None

        secili = [k for k in kayitlar if str(k.get("tarih", ""))[-4:] == self._perf_yil] \
                 if self._perf_yil else kayitlar
        perf = performans_hesapla(kayitlar, yil=self._perf_yil)
        self._perf_liste = perf
        kronik = sorted([x for x in perf if x["kronik_streak"] >= 2],
                        key=lambda x: -x["kronik_streak"])

        ust = QHBoxLayout()
        bl = QLabel(f"📈  {self._perf_yil} Performansı — {len(perf)} firma, "
                    f"{len(secili)} haftalık kayıt üzerinden")
        bl.setStyleSheet(f"font-size:14px;font-weight:700;color:{C['accent']};")
        ust.addWidget(bl); ust.addStretch()
        yl = QLabel("Yıl:"); yl.setStyleSheet(f"color:{C['muted']};font-weight:600;")
        ust.addWidget(yl)
        cmb = QComboBox(); cmb.addItems(yillar)
        cmb.setCurrentText(self._perf_yil or "")
        cmb.setStyleSheet(
            f"QComboBox{{background:{C['surface2']};border:1px solid {C['border']};"
            f"border-radius:7px;padding:5px 10px;color:{C['text']};min-width:80px;}}"
            f"QComboBox QAbstractItemView{{background:{C['surface']};color:{C['text']};"
            f"selection-background-color:{C['accent']};}}")
        cmb.currentTextChanged.connect(self._perf_yil_degisti)
        ust.addWidget(cmb)
        be = self._btn("📥  Excel'e Aktar", "gold", self._export_perf)
        ust.addWidget(be)
        self.perf_lay.addLayout(ust)

        not_l = QLabel("Not: “Toplam Ödenen” haftalar arası toplanır (gerçek nakit). "
                       "“Borç” toplanmaz — sadece ilk/son görülen bakiye gösterilir; "
                       "“Ort. Ödeme %” haftalık yüzdelerin ortalamasıdır.")
        not_l.setStyleSheet(f"color:{C['muted']};font-size:11px;"); not_l.setWordWrap(True)
        self.perf_lay.addWidget(not_l)

        if kronik:
            ku = QLabel(f"⚠️  {len(kronik)} firma art arda ödenmiyor — en dikkat gerektirenler üstte:")
            ku.setStyleSheet(f"color:{C['danger']};font-size:12px;font-weight:700;margin-top:6px;")
            self.perf_lay.addWidget(ku)
            ktbl = QTableWidget(len(kronik), 4)
            ktbl.setHorizontalHeaderLabels(["Cari Kod", "Ticari Unvanı", "Art Arda Ödenmeyen Hafta", "Son Bakiye"])
            ktbl.verticalHeader().setVisible(False)
            ktbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
            ktbl.setMaximumHeight(min(160, 30 + 26 * len(kronik)))
            kh = ktbl.horizontalHeader(); kh.setSectionResizeMode(1, QHeaderView.Stretch)
            for i, f in enumerate(kronik):
                ktbl.setItem(i, 0, QTableWidgetItem(f["cari_kod"]))
                ktbl.setItem(i, 1, QTableWidgetItem(f["unvan"]))
                si = QTableWidgetItem(f"{f['kronik_streak']} hafta"); si.setTextAlignment(Qt.AlignCenter)
                si.setForeground(QColor(C["danger"])); si.setFont(QFont("Segoe UI", 10, QFont.Bold))
                ktbl.setItem(i, 2, si)
                bi = QTableWidgetItem(para(f["son_bakiye"]) + " ₺"); bi.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                ktbl.setItem(i, 3, bi); ktbl.setRowHeight(i, 24)
            self.perf_lay.addWidget(ktbl)

        tbl = QTableWidget(len(perf), 7)
        tbl.setHorizontalHeaderLabels(
            ["Cari Kod", "Ticari Unvanı", "İlk Bakiye", "Son Bakiye",
             "Toplam Ödenen", "Hafta Sayısı", "Ort. Ödeme %"])
        tbl.verticalHeader().setVisible(False)
        tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tbl.setAlternatingRowColors(True)
        tbl.setItemDelegateForColumn(6, PaymentDelegate(tbl)); tbl.setColumnWidth(6, 150)
        hh = tbl.horizontalHeader(); hh.setSectionResizeMode(1, QHeaderView.Stretch)
        for i, f in enumerate(perf):
            tbl.setItem(i, 0, QTableWidgetItem(f["cari_kod"]))
            tbl.setItem(i, 1, QTableWidgetItem(f["unvan"]))
            for c, key in ((2, "ilk_bakiye"), (3, "son_bakiye"), (4, "toplam_odenen")):
                ci = QTableWidgetItem(para(f[key]) + " ₺"); ci.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                tbl.setItem(i, c, ci)
            hs = QTableWidgetItem(str(f["hafta_sayisi"])); hs.setTextAlignment(Qt.AlignCenter)
            tbl.setItem(i, 5, hs)
            yz = QTableWidgetItem(f"%{f['ortalama_yuzde']:.1f}"); yz.setTextAlignment(Qt.AlignCenter)
            if f["ortalama_yuzde"] < 50: yz.setForeground(QColor(C["danger"]))
            elif f["ortalama_yuzde"] < 80: yz.setForeground(QColor(C["warning"]))
            else: yz.setForeground(QColor(C["success"]))
            tbl.setItem(i, 6, yz); tbl.setRowHeight(i, 25)
        self.perf_lay.addWidget(tbl, 1)

    def _perf_yil_degisti(self, yil):
        self._perf_yil = yil
        self._perf_doldur()

    def _export_perf(self):
        perf = getattr(self, "_perf_liste", None)
        if not perf:
            uyari(self, "Uyarı", "Aktarılacak veri yok."); return
        p, _ = QFileDialog.getSaveFileName(self, "Yıllık Performans Excel",
            f"Yillik_Performans_{getattr(self, '_perf_yil', None) or date.today().year}.xlsx", "Excel (*.xlsx)")
        if not p: return
        if excel_kaydet(perf_workbook(perf), p, self):
            bilgi(self, "✅ Kaydedildi", "Yıllık Performans Excel oluşturuldu.")

    def _temizle(self, lay):
        while lay.count():
            it = lay.takeAt(0)
            wdg = it.widget()
            if wdg:
                wdg.deleteLater()
            else:
                cl = it.layout()
                if cl: self._temizle(cl)

    def _tab_degisti(self, idx):
        if idx == 1:   self._c3_doldur()
        elif idx == 2: self._banka_doldur()
        elif idx == 3: self._arsiv_doldur()
        elif idx == 4: self._perf_doldur()

    # ---- dosya seçimi ----
    def _firma_otomatik_yukle(self):
        # önbellek zaten yüklendi; kayıtlı yol varsa tazele (yoksa önbellek kalır)
        p = self.veri.ayarlar.get("firma_path", "")
        if p and os.path.exists(p):
            try:
                self.veri.firma_bilgileri_yukle(p)
                self.kart_firma.ayarla(os.path.basename(p))
            except Exception:
                pass
        elif self.veri.firmalar:
            self.kart_firma.ayarla(f"{len(self.veri.firmalar)} firma (kayıtlı)")

    def _sec_firma(self):
        p, _ = QFileDialog.getOpenFileName(self, "Firma Bilgileri Seç", "", "Excel (*.xlsx *.xlsm)")
        if not p: return
        try:
            n = self.veri.firma_bilgileri_yukle(p)
            self.kart_firma.ayarla(os.path.basename(p))
            self.status.showMessage(f"Firma bilgileri yüklendi ve kaydedildi: {n} firma")
            if self.veri.sonuc:
                self.veri.listeyi_hazirla(); self._tabloyu_doldur(); self._kpi_guncelle()
                self._c3_doldur(); self._banka_doldur()
        except Exception as e:
            hata_kutusu(self, "Hata", f"Firma bilgileri okunamadı:\n{e}")

    def _sec_bakiye(self):
        p, _ = QFileDialog.getOpenFileName(self, "Toplam Borç Dosyası Seç", "", "Excel/CSV (*.xlsx *.xls *.csv)")
        if not p: return
        self.bakiye_path = p
        self.veri.ayarlar["bakiye_path"] = p; ayar_kaydet(self.veri.ayarlar)
        self.kart_bakiye.ayarla(os.path.basename(p))
        self.status.showMessage(f"Toplam Borç: {os.path.basename(p)}")

    def _sec_hareket(self):
        p, _ = QFileDialog.getOpenFileName(self, "Toplu Cari Hareket Raporu Seç", "", "Excel/CSV (*.xlsx *.xls *.csv)")
        if not p: return
        self.hareket_path = p
        self.veri.ayarlar["hareket_path"] = p; ayar_kaydet(self.veri.ayarlar)
        self.kart_hareket.ayarla(os.path.basename(p))
        self.status.showMessage(f"Toplu Cari Hareket Raporu: {os.path.basename(p)}")

    def _kart_guncelle(self):
        if self.bakiye_path and os.path.exists(self.bakiye_path):
            self.kart_bakiye.ayarla(os.path.basename(self.bakiye_path))
        if self.hareket_path and os.path.exists(self.hareket_path):
            self.kart_hareket.ayarla(os.path.basename(self.hareket_path))
        var = bool(self.veri.liste)
        if hasattr(self, "btn_vg"):
            self.btn_vg.setEnabled(var); self.btn_reset.setEnabled(var)
            self.btn_dagit.setEnabled(var)
            self.btn_pesin.setEnabled(var)

    # ---- hesaplama ----
    def _vade_mod_degisti(self, idx):
        # 2 = "Belirli tarih" → tarih kutusunu göster
        self.vade_tarih.setVisible(idx == 2)
        if idx == 1:   # Sonraki Pazar → tarih kutusuna yaz (bilgi amaçlı, gizli)
            pass
        self._vade_ipucu()

    def _kesim_gunu(self):
        """Seçili moda göre kesim gününü (date) döndürür. None → varsayılan pazar."""
        idx = self.vade_mod.currentIndex()
        if idx == 0:
            return None                                  # bu haftanın pazarı (motorda)
        if idx == 1:
            return bu_haftanin_pazari() + timedelta(days=7)   # sonraki pazar
        d = self.vade_tarih.date()
        return date(d.year(), d.month(), d.day())        # belirli tarih (dahil)

    def _vade_ipucu(self):
        k = self._kesim_gunu()
        if k is None:
            k = bu_haftanin_pazari()
            self.status.showMessage(f"Vade kesimi: bu haftanın pazarı ({k:%d.%m.%Y}) "
                                    "dahil vadesi gelen borç hesaplanacak.")
        else:
            self.status.showMessage(f"Vade kesimi: {k:%d.%m.%Y} (dahil) — "
                                    "bu tarihe kadar vadesi gelen borç hesaplanacak.")

    def _hesapla(self):
        if not self.bakiye_path or not os.path.exists(self.bakiye_path):
            uyari(self, "Uyarı", "Toplam Borç dosyası seçilmedi!"); return
        if not self.hareket_path or not os.path.exists(self.hareket_path):
            uyari(self, "Uyarı", "Toplu Cari Hareket Raporu seçilmedi!"); return
        # Elle düzenlenmiş ödenecek tutar varsa uyar — HESAPLA hepsini sıfırlar
        duzenli = any(abs(x.get("odenecek", 0) - x.get("vadesi_gelen", 0)) > 0.005
                      for x in self.veri.liste)
        if duzenli:
            c = sor(
                self, "Düzenlemeler Silinecek",
                "Elle girdiğiniz ödenecek tutarlar var.\n\n"
                "HESAPLA'ya devam ederseniz tüm ödenecek tutarlar yeniden\n"
                "'Vadesi Gelen' değerlerine dönecek ve düzenlemeleriniz silinecek.\n\n"
                "Devam edilsin mi?  (İpucu: önce 'Geçmiş Listeler' sekmesinden\n"
                "mevcut listeyi arşivleyebilirsiniz.)")
            if c != QMessageBox.Yes:
                return
        self.btn_hesapla.setEnabled(False)
        self.status.showMessage("Hesaplanıyor...")
        self.thread = HesaplaThread(self.bakiye_path, self.hareket_path,
                                    kesim_gunu=self._kesim_gunu(), parent=self)
        self.thread.ilerleme.connect(lambda m: self.status.showMessage(m))
        self.thread.bitti.connect(self._hesap_bitti)
        self.thread.start()

    def _hesap_bitti(self, sonuc, hata):
        self.btn_hesapla.setEnabled(True)
        if hata:
            hata_kutusu(self, "Hata", hata); return
        self.veri.sonuc = sonuc
        # Kara liste kontrolü: hesaplanan firmalar arasında kara listede olanlar
        self.veri.kara_gecici_haric = set()
        self._kara_liste_uyari(sonuc)
        n = self.veri.listeyi_hazirla()
        self._tabloyu_doldur(); self._kpi_guncelle(); self._kart_guncelle()
        self._c3_doldur(); self._banka_doldur()
        self.tabs.setCurrentIndex(0)
        self._oturum_kaydet()
        k = self._kesim_gunu() or bu_haftanin_pazari()
        self.status.showMessage(
            f"{n} firma hesaplandı (vade kesimi: {k:%d.%m.%Y} dahil). "
            "Ödenecek tutarları düzenleyip dışa aktarabilirsiniz.")

    def _kara_liste_uyari(self, sonuc):
        """HESAPLA'da kara listedeki firmalar hesaba girdiyse uyar; kullanıcı
        isterse bazılarını kalıcı olarak kara listeden çıkarabilir."""
        kara = self.veri.ayarlar.get("kara_liste", [])
        varolan = [k for k in kara if k in sonuc]
        if not varolan:
            return
        def ad(k):
            u = sonuc.get(k, {}).get("unvan", "") or self.veri.firmalar.get(k, {}).get("unvan", "")
            return f"{k} — {u}" if u else k
        liste_str = "\n".join("• " + ad(k) for k in varolan)
        c = sor(
            self, "Kara Liste Uyarısı",
            f"Aşağıdaki firma(lar) KARA LİSTEDE — ödenecek tutarları 0 gelecek:\n\n"
            f"{liste_str}\n\n"
            "Bu firmalardan kara listeden ÇIKARMAK istediğiniz var mı?\n"
            "• HAYIR → hepsi kara listede kalır (ödenecek 0)\n"
            "• EVET  → hangilerini çıkaracağınızı seçersiniz (kalıcı silinir)")
        if c != QMessageBox.Yes:
            return
        if len(varolan) == 1:
            secilen = varolan
        else:
            secilen = self._kara_secim_dialog(varolan, sonuc)
            if secilen is None:
                return
        if not secilen:
            return
        # kalıcı çıkar
        kl = self.veri.ayarlar.setdefault("kara_liste", [])
        for k in secilen:
            if k in kl: kl.remove(k)
        ayar_kaydet(self.veri.ayarlar)
        bilgi(self, "Kara Liste Güncellendi",
            f"{len(secilen)} firma kara listeden çıkarıldı. Bu firmalar normal işlenecek.")

    def _kara_secim_dialog(self, kodlar, sonuc):
        """Çoklu firma için onay kutulu seçim. Dönen: seçilen kod listesi ya da None (iptal)."""
        dlg = QDialog(self); dlg.setWindowTitle("Kara Listeden Çıkar")
        dlg.setMinimumWidth(460); dlg.setStyleSheet(STYLE)
        if os.path.exists(ICON_F): dlg.setWindowIcon(QIcon(ICON_F))
        v = QVBoxLayout(dlg); v.setContentsMargins(18, 16, 18, 16); v.setSpacing(10)
        bl = QLabel("Kara listeden ÇIKARMAK istediklerinizi işaretleyin\n(işaretlenenler kalıcı silinir, normal işlenir):")
        bl.setStyleSheet("font-weight:600;"); bl.setWordWrap(True); v.addWidget(bl)
        kutular = []
        for k in kodlar:
            u = sonuc.get(k, {}).get("unvan", "") or self.veri.firmalar.get(k, {}).get("unvan", "")
            cb = QCheckBox(f"{k}  —  {u}" if u else k)
            cb.setStyleSheet("padding:4px;"); cb._kod = k
            kutular.append(cb); v.addWidget(cb)
        bb = QHBoxLayout(); bb.addStretch()
        vaz = QPushButton("Vazgeç"); vaz.setProperty("cls", "sec"); vaz.clicked.connect(dlg.reject)
        onay = QPushButton("Seçilenleri Çıkar"); onay.setProperty("cls", "ok"); onay.clicked.connect(dlg.accept)
        bb.addWidget(vaz); bb.addWidget(onay); v.addLayout(bb)
        if dlg.exec_() != QDialog.Accepted:
            return None
        return [cb._kod for cb in kutular if cb.isChecked()]

    def _tabloyu_doldur(self):
        self._dolduruyor = True
        self.tbl.setRowCount(0)
        for item in self.veri.liste:
            r = self.tbl.rowCount(); self.tbl.insertRow(r); self.tbl.setRowHeight(r, 38)
            c0 = QTableWidgetItem(item["cari_kod"]); c0.setTextAlignment(Qt.AlignCenter)
            c0.setFlags(c0.flags() ^ Qt.ItemIsEditable); self.tbl.setItem(r, 0, c0)
            isaret = ""
            if item.get("kara"):   isaret = "  🔴"
            elif item["pesin"]:    isaret = "  🟢"
            c1 = QTableWidgetItem(item["unvan"] + isaret)
            c1.setFlags(c1.flags() ^ Qt.ItemIsEditable); self.tbl.setItem(r, 1, c1)
            c2 = QTableWidgetItem(para(item["bakiye"])); c2.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            c2.setFlags(c2.flags() ^ Qt.ItemIsEditable); self.tbl.setItem(r, 2, c2)
            c3 = QTableWidgetItem(para(item["vadesi_gelen"])); c3.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if item["vadesi_gelen"] > 0:
                c3.setForeground(QColor(C["warning"])); c3.setFont(QFont("Segoe UI", 12, QFont.Bold))
            c3.setFlags(c3.flags() ^ Qt.ItemIsEditable); self.tbl.setItem(r, 3, c3)
            c4 = QTableWidgetItem(para(item["vadesi_15_gec"])); c4.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if item["vadesi_15_gec"] > 0:
                c4.setForeground(QColor(C["danger"])); c4.setFont(QFont("Segoe UI", 12, QFont.Bold))
            c4.setFlags(c4.flags() ^ Qt.ItemIsEditable); self.tbl.setItem(r, 4, c4)
            c5 = QTableWidgetItem(para(item["odenecek"])); c5.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            c5.setForeground(QColor(C["accent"])); c5.setFont(QFont("Segoe UI", 12, QFont.Bold))
            c5.setBackground(QColor(C["accent2"])); c5.setToolTip("Ödenecek tutarı düzenlemek için çift tıklayın.")
            self.tbl.setItem(r, 5, c5)
            yuzde = (item["odenecek"] / item["vadesi_gelen"]) if item["vadesi_gelen"] > 0 else 0
            c6 = QTableWidgetItem(f"%{yuzde*100:.0f}"); c6.setTextAlignment(Qt.AlignCenter)
            c6.setData(Qt.UserRole, yuzde * 100)
            c6.setFlags(c6.flags() ^ Qt.ItemIsEditable); self.tbl.setItem(r, 6, c6)
        self._dolduruyor = False

    def _odenecek_degisti(self, item):
        if self._dolduruyor or item.column() != 5:
            return
        r = item.row()
        if r >= len(self.veri.liste): return
        deger = para_coz(item.text())
        self.veri.liste[r]["odenecek"] = deger
        self._dolduruyor = True
        item.setText(para(deger)); item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        vg = self.veri.liste[r]["vadesi_gelen"]
        self.tbl.item(r, 6).setText(f"%{(deger/vg*100) if vg>0 else 0:.0f}")
        self.tbl.item(r, 6).setData(Qt.UserRole, (deger/vg*100) if vg>0 else 0)
        self._dolduruyor = False
        self._kpi_guncelle()
        self._oturum_kaydet()

    def _esit_dagit(self):
        if not self.veri.liste:
            uyari(self, "Uyarı", "Önce HESAPLA'ya basın."); return
        bankadaki = para_coz(self.k_bank.val.text())
        if bankadaki <= 0:
            uyari(self, "Bankadaki Tutar Gerekli",
                  "Önce 'BANKADAKİ TUTAR' kutusuna hesabınızdaki parayı yazın.\n"
                  "Örnek: 1.010.000,00"); return

        # 1) Bankada ne kadar bırakılacak?
        birak_metin = self._tutar_sor(
            "Bankada Kalacak Tutar",
            f"Bankadaki tutar: {para(bankadaki)} ₺\n\n"
            "Bankada ne kadar para bırakmak istiyorsunuz?\n"
            "(Kalan tutar firmalara dağıtılacak)",
            "10.000,00")
        if birak_metin is None:
            return
        birak = para_coz(birak_metin)
        butce = round(bankadaki - birak, 2)
        if butce <= 0:
            uyari(self, "Dağıtılacak Tutar Yok",
                  f"Bırakmak istediğiniz tutar ({para(birak)} ₺), bankadaki tutardan "
                  f"({para(bankadaki)} ₺) küçük olmalı."); return

        # 2) Ödeme yapılmayacak firma var mı?
        haric = set()
        aday = [x for x in self.veri.liste
                if x["vadesi_gelen"] > 0 and not x.get("kara")]
        if aday:
            c = sor(self, "Hariç Tutulacak Firma",
                    f"Dağıtılacak tutar: {para(butce)} ₺\n\n"
                    "Bu dağıtımda ödeme yapmak İSTEMEDİĞİNİZ firma var mı?\n"
                    "• Evet → listeden seçersiniz, o firmalara 0 verilir\n"
                    "• Hayır → tüm firmalar dağıtıma girer")
            if c == QMessageBox.Yes:
                secim = self._firma_secim_dialog(
                    aday, "Ödeme Yapılmayacak Firmalar",
                    "Bu dağıtımda ödeme yapmak İSTEMEDİĞİNİZ firmaları işaretleyin\n"
                    "(işaretlenenlerin ödenecek tutarı 0 olur, para diğerlerine dağıtılır):")
                if secim is None:
                    return
                haric = set(secim)

        # 3) Tamamı ödenecek firma var mı? (peşinler zaten tam ödeniyor)
        tam = set()
        aday_tam = [x for x in self.veri.liste
                    if x["vadesi_gelen"] > 0 and not x.get("kara")
                    and not x.get("pesin") and x["cari_kod"] not in haric]
        if aday_tam:
            c2 = sor(self, "Tamamı Ödenecek Firma",
                     f"Dağıtılacak tutar: {para(butce)} ₺\n\n"
                     "Peşin firmalar dışında, vadesi gelen borcunun TAMAMINI ödemek "
                     "istediğiniz firma var mı?\n"
                     "• Evet → listeden seçersiniz, borçlarının tamamı ödenir\n"
                     "• Hayır → sadece peşinler ve küçük borçlar tam ödenir")
            if c2 == QMessageBox.Yes:
                secim2 = self._firma_secim_dialog(
                    aday_tam, "Tamamı Ödenecek Firmalar",
                    "Vadesi gelen borcunun TAMAMINI ödemek istediğiniz firmaları işaretleyin\n"
                    "(bu firmalara borçlarının tamamı ödenir, kalan para diğerlerine "
                    "orantılı dağıtılır):")
                if secim2 is None:
                    return
                tam = set(secim2)
                istenen = sum(x["vadesi_gelen"] for x in self.veri.liste
                              if x["cari_kod"] in tam)
                pesin_toplam = sum(x["vadesi_gelen"] for x in self.veri.liste
                                   if x.get("pesin") and not x.get("kara")
                                   and x["cari_kod"] not in haric)
                if istenen + pesin_toplam > butce:
                    c3 = sor(self, "Bütçe Yetersiz",
                             f"Seçtiğiniz firmaların toplam borcu: {para(istenen)} ₺\n"
                             f"Peşin firmalar: {para(pesin_toplam)} ₺\n"
                             f"Dağıtılacak tutar: {para(butce)} ₺\n\n"
                             "Bütçe hepsini tam ödemeye yetmiyor. Devam edilirse sırayla "
                             "ödenir, para bitince kalan firmalara pay düşmez.\n\n"
                             "Devam edilsin mi?")
                    if c3 != QMessageBox.Yes:
                        return

        # 4) Dağıt
        esik = float(self.veri.ayarlar.get("tam_odeme_esigi", 5000) or 5000)
        dagitilan, kalan_butce, bilgi_d = butce_dagit(self.veri.liste, butce, esik, haric, tam)

        self._tabloyu_doldur(); self._kpi_guncelle()
        self._c3_doldur(); self._banka_doldur(); self._oturum_kaydet()

        bankada_kalan = round(bankadaki - dagitilan, 2)
        bilgi(self, "Dağıtım Tamamlandı",
              f"Dağıtılan toplam: {para(dagitilan)} ₺\n"
              f"Bankada kalan:    {para(bankada_kalan)} ₺\n\n"
              f"• Peşin firmalar (tamamı): {bilgi_d['pesin']} firma — {para(bilgi_d['pesin_tutar'])} ₺\n"
              + (f"• Tamamı ödenenler: {bilgi_d['tam']} firma — {para(bilgi_d['tam_tutar'])} ₺\n"
                 if bilgi_d['tam'] else "")
              + f"• {para(esik)} ₺ ve altı (tamamı): {bilgi_d['esik_alti']} firma — {para(bilgi_d['esik_tutar'])} ₺\n"
              + (f"• Vadesi 15 gün geçen (öncelikli ödenen): {para(bilgi_d['gecikmis_tutar'])} ₺\n"
                 if bilgi_d.get('gecikmis_tutar') else "")
              + f"• Orantılı dağıtılan: {bilgi_d['orantili']} firma — {para(bilgi_d['orantili_tutar'])} ₺\n"
              + (f"• Hariç tutulan: {len(haric)} firma\n" if haric else "")
              + "\nTutarları tablodan elle düzenlemeye devam edebilirsiniz.")
        self.status.showMessage(
            f"Eşit Dağıt: {para(dagitilan)} ₺ dağıtıldı, bankada {para(bankada_kalan)} ₺ kalıyor.")

    def _tutar_sor(self, baslik, metin, varsayilan=""):
        """Tutar giriş diyaloğu (Türkçe butonlu). İptal → None."""
        dlg = QDialog(self); dlg.setWindowTitle(baslik); dlg.setMinimumWidth(420)
        dlg.setStyleSheet(STYLE)
        if os.path.exists(ICON_F): dlg.setWindowIcon(QIcon(ICON_F))
        v = QVBoxLayout(dlg); v.setContentsMargins(18, 16, 18, 16); v.setSpacing(12)
        l = QLabel(metin); l.setWordWrap(True); v.addWidget(l)
        inp = QLineEdit(varsayilan); inp.selectAll()
        inp.setStyleSheet(f"font-size:16px;font-weight:700;color:{C['success']};")
        v.addWidget(inp)
        bb = QHBoxLayout(); bb.addStretch()
        vaz = QPushButton("Vazgeç"); vaz.setProperty("cls", "sec"); vaz.clicked.connect(dlg.reject)
        tm = QPushButton("Tamam"); tm.setProperty("cls", "ok"); tm.clicked.connect(dlg.accept)
        inp.returnPressed.connect(dlg.accept)
        bb.addWidget(vaz); bb.addWidget(tm); v.addLayout(bb)
        if dlg.exec_() != QDialog.Accepted:
            return None
        return inp.text()

    def _firma_secim_dialog(self, adaylar, baslik, aciklama):
        """Firma listesi + onay kutuları. Dönen: seçilen cari kod listesi ya da None."""
        dlg = QDialog(self); dlg.setWindowTitle(baslik)
        dlg.setMinimumSize(560, 520); dlg.setStyleSheet(STYLE)
        if os.path.exists(ICON_F): dlg.setWindowIcon(QIcon(ICON_F))
        v = QVBoxLayout(dlg); v.setContentsMargins(18, 16, 18, 16); v.setSpacing(10)
        bl = QLabel(aciklama); bl.setWordWrap(True); bl.setStyleSheet("font-weight:600;")
        v.addWidget(bl)
        ara = QLineEdit(); ara.setPlaceholderText("🔍 Firma ara...")
        v.addWidget(ara)
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setStyleSheet("QScrollArea{border:none;}")
        ic = QWidget(); icv = QVBoxLayout(ic); icv.setSpacing(3)
        kutular = []
        for it in sorted(adaylar, key=lambda x: tr_key(x["unvan"])):
            cb = QCheckBox(f"{it['unvan']}   —   {para(it['vadesi_gelen'])} ₺")
            cb.setStyleSheet("padding:3px;"); cb._kod = it["cari_kod"]
            kutular.append(cb); icv.addWidget(cb)
        icv.addStretch(); sc.setWidget(ic); v.addWidget(sc, 1)

        def filtrele(metin):
            m = tr_kucult(metin)
            for cb in kutular:
                cb.setVisible(m in tr_kucult(cb.text()))
        ara.textChanged.connect(filtrele)

        sayac = QLabel("0 firma seçildi"); sayac.setStyleSheet(f"color:{C['muted']};font-size:12px;")
        v.addWidget(sayac)
        def say():
            n = sum(1 for cb in kutular if cb.isChecked())
            sayac.setText(f"{n} firma seçildi")
        for cb in kutular: cb.stateChanged.connect(lambda *_: say())

        bb = QHBoxLayout()
        temizle = QPushButton("Seçimi Temizle"); temizle.setProperty("cls", "sec")
        temizle.clicked.connect(lambda: [cb.setChecked(False) for cb in kutular])
        bb.addWidget(temizle); bb.addStretch()
        vaz = QPushButton("Vazgeç"); vaz.setProperty("cls", "sec"); vaz.clicked.connect(dlg.reject)
        tm = QPushButton("Onayla"); tm.setProperty("cls", "ok"); tm.clicked.connect(dlg.accept)
        bb.addWidget(vaz); bb.addWidget(tm); v.addLayout(bb)
        if dlg.exec_() != QDialog.Accepted:
            return None
        return [cb._kod for cb in kutular if cb.isChecked()]

    def _tbl_sag_tik(self, pos):
        item = self.tbl.itemAt(pos)
        if item is None:
            return
        r = item.row()
        if r < 0 or r >= len(self.veri.liste):
            return
        firma = self.veri.liste[r]
        faturalar = firma.get("faturalar", [])

        menu = QMenu(self)
        menu.setStyleSheet(
            f"QMenu{{background:{C['surface']};color:{C['text']};border:1px solid {C['border']};}}"
            f"QMenu::item:selected{{background:{C['accent']};}}"
            f"QMenu::item:disabled{{color:{C['muted']};}}")
        act = QAction("📄  Fatura Bazlı Öde", self)
        act.setEnabled(bool(faturalar))
        if not faturalar:
            act.setText("📄  Fatura Bazlı Öde  (fatura kaydı yok)")
        act.triggered.connect(lambda: self._fatura_bazli_ode(r))
        menu.addAction(act)
        menu.exec_(self.tbl.viewport().mapToGlobal(pos))

    def _fatura_bazli_ode(self, satir):
        if satir < 0 or satir >= len(self.veri.liste):
            return
        firma = self.veri.liste[satir]
        faturalar = firma.get("faturalar", [])
        if not faturalar:
            uyari(self, "Fatura Bulunamadı",
                  "Bu firma için Toplu Cari Hareket Raporu'nda vadesi gelen fatura kaydı yok.")
            return

        dlg = QDialog(self)
        dlg.setWindowTitle(f"Fatura Bazlı Öde — {firma['unvan']}")
        dlg.setMinimumSize(520, 520); dlg.setStyleSheet(STYLE)
        if os.path.exists(ICON_F): dlg.setWindowIcon(QIcon(ICON_F))
        v = QVBoxLayout(dlg); v.setContentsMargins(18, 16, 18, 16); v.setSpacing(10)

        bl = QLabel(f"📄  {firma['unvan']}")
        bl.setStyleSheet(f"font-size:14px;font-weight:700;color:{C['accent']};")
        v.addWidget(bl)
        bilgi_l = QLabel(f"Firmanın Vadesi Gelen tutarı: {para(firma['vadesi_gelen'])} ₺   "
                         "(sadece ödenmemiş kalan faturalar; en eski üstte, en yeni altta)")
        bilgi_l.setStyleSheet(f"color:{C['muted']};font-size:11px;"); bilgi_l.setWordWrap(True)
        v.addWidget(bilgi_l)

        tbl = QTableWidget(len(faturalar), 3)
        tbl.setHorizontalHeaderLabels(["Seç", "Fatura Tarihi", "Tutar"])
        tbl.verticalHeader().setVisible(False)
        tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tbl.setAlternatingRowColors(True)
        tbl.setItemDelegateForColumn(6, PaymentDelegate(tbl)); tbl.setColumnWidth(6, 150)
        hh = tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        kutular = []
        for i, f in enumerate(faturalar):   # zaten en eski→en yeni sıralı geliyor
            cb = QCheckBox(); cb._tutar = f["tutar"]
            hucre = QWidget(); hl = QHBoxLayout(hucre)
            hl.setContentsMargins(0, 0, 0, 0); hl.setAlignment(Qt.AlignCenter); hl.addWidget(cb)
            tbl.setCellWidget(i, 0, hucre); kutular.append(cb)
            try:
                tarih_g = f"{date.fromisoformat(f['tarih']):%d.%m.%Y}"
            except Exception:
                tarih_g = f["tarih"]
            ti = QTableWidgetItem(tarih_g); ti.setTextAlignment(Qt.AlignCenter)
            tbl.setItem(i, 1, ti)
            etiket = para(f["tutar"]) + " ₺" + ("  (kalan — kısmi ödenmiş)" if f.get("kismi") else "")
            tu = QTableWidgetItem(etiket); tu.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if f.get("kismi"):
                tu.setForeground(QColor(C["warning"]))
            tbl.setItem(i, 2, tu); tbl.setRowHeight(i, 26)
        v.addWidget(tbl, 1)

        alt = QHBoxLayout()
        hep_sec = QPushButton("Tümünü Seç"); hep_sec.setProperty("cls", "sec")
        hep_sec.clicked.connect(lambda: [cb.setChecked(True) for cb in kutular])
        temiz = QPushButton("Temizle"); temiz.setProperty("cls", "sec")
        temiz.clicked.connect(lambda: [cb.setChecked(False) for cb in kutular])
        alt.addWidget(hep_sec); alt.addWidget(temiz); alt.addStretch()
        v.addLayout(alt)

        toplam_l = QLabel("Seçilen toplam: 0,00 ₺")
        toplam_l.setStyleSheet(f"font-size:14px;font-weight:800;color:{C['success']};")
        v.addWidget(toplam_l)
        fark_l = QLabel(""); fark_l.setStyleSheet(f"color:{C['warning']};font-size:11px;")
        fark_l.setWordWrap(True); v.addWidget(fark_l)

        def guncelle():
            top = sum(cb._tutar for cb in kutular if cb.isChecked())
            toplam_l.setText(f"Seçilen toplam: {para(top)} ₺")
            if top > firma["vadesi_gelen"] + 0.01:
                fark_l.setText(f"ℹ️ Seçilen tutar, firmanın Vadesi Gelen tutarından "
                               f"{para(top - firma['vadesi_gelen'])} ₺ fazla.")
            else:
                fark_l.setText("")
        for cb in kutular: cb.stateChanged.connect(lambda *_: guncelle())

        bb = QHBoxLayout(); bb.addStretch()
        vaz = QPushButton("Vazgeç"); vaz.setProperty("cls", "sec"); vaz.clicked.connect(dlg.reject)
        onay = QPushButton("✅  Ödenecek Tutara Uygula"); onay.setProperty("cls", "ok")
        onay.clicked.connect(dlg.accept)
        bb.addWidget(vaz); bb.addWidget(onay); v.addLayout(bb)

        if dlg.exec_() != QDialog.Accepted:
            return
        secilen_toplam = round(sum(cb._tutar for cb in kutular if cb.isChecked()), 2)
        firma["odenecek"] = secilen_toplam
        self._tabloyu_doldur(); self._kpi_guncelle()
        self._c3_doldur(); self._banka_doldur(); self._oturum_kaydet()
        self.status.showMessage(
            f"{firma['unvan']}: {sum(1 for cb in kutular if cb.isChecked())} fatura seçildi, "
            f"ödenecek tutar {para(secilen_toplam)} ₺ olarak ayarlandı.")

    def _sadece_pesin(self):
        if not self.veri.liste:
            uyari(self, "Uyarı", "Önce HESAPLA'ya basın."); return
        pesinler = [x for x in self.veri.liste if x.get("pesin") and not x.get("kara")
                    and x["vadesi_gelen"] > 0]
        if not pesinler:
            uyari(self, "Peşin Firma Yok",
                  "Listede ödenecek peşin firma bulunamadı.\n"
                  "Peşin firmaları Ayarlar → Peşin Firmalar bölümünden ekleyebilirsiniz."); return

        toplam = round(sum(x["vadesi_gelen"] for x in pesinler), 2)
        bankadaki = para_coz(self.k_bank.val.text())
        ek = ""
        if bankadaki > 0:
            if toplam > bankadaki:
                ek = (f"\n\n⚠️  Bankadaki tutar ({para(bankadaki)} ₺) yetersiz — "
                      f"{para(round(toplam - bankadaki, 2))} ₺ eksik kalıyor.")
            else:
                ek = f"\n\nBankada kalacak: {para(round(bankadaki - toplam, 2))} ₺"

        c = sor(self, "Sadece Peşinleri Öde",
                f"{len(pesinler)} peşin firmanın borcunun tamamı ödenecek:\n"
                f"Toplam: {para(toplam)} ₺\n\n"
                "Diğer tüm firmaların ödenecek tutarı 0 olacak."
                f"{ek}\n\nDevam edilsin mi?")
        if c != QMessageBox.Yes:
            return

        for x in self.veri.liste:
            x["odenecek"] = x["vadesi_gelen"] if (x.get("pesin") and not x.get("kara")) else 0.0

        self._tabloyu_doldur(); self._kpi_guncelle()
        self._c3_doldur(); self._banka_doldur(); self._oturum_kaydet()
        bilgi(self, "Tamamlandı",
              f"{len(pesinler)} peşin firmaya toplam {para(toplam)} ₺ ödeme ayarlandı.\n"
              "Diğer firmaların ödenecek tutarı 0 yapıldı.\n\n"
              "Tutarları tablodan elle düzenlemeye devam edebilirsiniz.")
        self.status.showMessage(
            f"Sadece peşinler: {len(pesinler)} firma, toplam {para(toplam)} ₺.")

    def _odenecek_sifirla(self):
        for it in self.veri.liste:
            it["odenecek"] = it["vadesi_gelen"]
        self._tabloyu_doldur(); self._kpi_guncelle(); self._oturum_kaydet()

    def _oturum_kaydet(self):
        if self.veri.liste:
            oturum_kaydet(self.veri.liste, self.k_bank.val.text())

    def _kaydet_butonu(self):
        if not self.veri.liste:
            self.status.showMessage("Kaydedilecek veri yok — önce HESAPLA'ya basın.")
            return
        self._oturum_kaydet()
        self.status.showMessage("✓ Veriler kaydedildi. Program kapansa da düzenlediğiniz haliyle kalır.")

    def closeEvent(self, e):
        self._oturum_kaydet()
        super().closeEvent(e)

    def _bankadaki_bicimle(self):
        t = self.k_bank.val.text().strip()
        if t:
            deger = para_coz(t)
            # Geçersiz giriş kontrolü: sayı çıkmadı ama alan sayısal karakter içermiyor
            temiz = t.replace("₺", "").replace("TL", "").replace(" ", "")
            gecersiz = (deger == 0.0 and temiz not in ("", "0", "0,0", "0,00", "0.0", "0.00")
                        and not any(ch.isdigit() for ch in temiz) or
                        (deger == 0.0 and any(ch.isalpha() for ch in temiz)))
            if gecersiz:
                self.k_bank.val.setStyleSheet(
                    f"background:{C['surface2']};border:1.5px solid {C['danger']};border-radius:6px;"
                    f"padding:4px 8px;color:{C['danger']};font-size:16px;font-weight:700;")
                self.k_bank.val.setToolTip("Geçersiz tutar — sadece sayı girin (örn: 1.023.258,45)")
                self.status.showMessage("⚠️ Bankadaki Tutar geçersiz — sayı olarak girin (örn: 1.023.258,45)")
                return
            # geçerli → normal stile dön ve biçimle
            self.k_bank.val.setStyleSheet(
                f"background:{C['surface2']};border:1px solid {C['border']};border-radius:6px;"
                f"padding:4px 8px;color:{C['success']};font-size:16px;font-weight:700;")
            self.k_bank.val.setToolTip("")
            yeni = para(deger)
            if yeni != self.k_bank.val.text():
                self.k_bank.val.setText(yeni)
        self._oturum_kaydet()

    def _kpi_guncelle(self):
        L = self.veri.liste
        toplam_vg  = sum(x["vadesi_gelen"]  for x in L)
        toplam_od  = sum(x["odenecek"]      for x in L)
        toplam_v15 = sum(x["vadesi_15_gec"] for x in L)
        odenemeyen = max(0.0, toplam_vg - toplam_od)
        bankadaki  = para_coz(self.k_bank.val.text())
        fark       = bankadaki - toplam_od
        self.k_vg.yaz(para(toplam_vg) + " ₺")
        self.k_od.yaz(para(toplam_od) + " ₺")
        self.k_odm.yaz(para(odenemeyen) + " ₺")
        self.k_v15.yaz(para(toplam_v15) + " ₺")
        self.k_fark.yaz(para(fark) + " ₺")
        self.k_fark.val.setStyleSheet(
            f"color:{C['success'] if fark >= 0 else C['danger']};font-size:16px;font-weight:800;border:none;")
        self.gauge.setDeger((toplam_od / toplam_vg) if toplam_vg > 0 else 0)

    # ---- dışa aktarma ----
    def _export_vg(self):
        if not self.veri.liste:
            uyari(self, "Uyarı", "Önce HESAPLA'ya basın!"); return
        p, _ = QFileDialog.getSaveFileName(self, "Vadesi Gelen Excel",
            f"Vadesi_Gelen_{date.today():%d%m%Y}.xlsx", "Excel (*.xlsx)")
        if not p: return
        if excel_kaydet(vg_workbook(self.veri), p, self):
            bilgi(self, "✅ Kaydedildi", "Vadesi Gelen Excel oluşturuldu.")

    def _export_c3(self):
        odn = odenecek_listesi(self.veri)
        if not odn:
            uyari(self, "Uyarı", "Ödenecek tutarı > 0 olan firma yok!"); return
        p, _ = QFileDialog.getSaveFileName(self, "C3 Excel",
            f"C3_{date.today():%d%m%Y}.xlsx", "Excel (*.xlsx)")
        if not p: return
        if excel_kaydet(c3_workbook(self.veri, odn), p, self):
            bilgi(self, "✅ Kaydedildi", f"C3 oluşturuldu — {len(odn)} kayıt.")

    def _export_banka(self):
        odn = odenecek_listesi(self.veri)
        if not odn:
            uyari(self, "Uyarı", "Ödenecek tutarı > 0 olan firma yok!"); return
        p, _ = QFileDialog.getSaveFileName(self, "BANKAYA FORMAT Excel",
            f"BANKAYA_FORMAT_{date.today():%d%m%Y}.xlsx", "Excel (*.xlsx)")
        if not p: return
        wb, n = banka_workbook(self.veri, odn)
        if excel_kaydet(wb, p, self):
            bilgi(self, "✅ Kaydedildi",
                f"BANKAYA FORMAT oluşturuldu.\n{len(odn)} firma, {n} sayfa.")

    # ---- ayarlar ----
    def _ayarlar(self):
        dlg = AyarlarDialog(self.veri, self)
        dlg.exec_()
        # Ayarlar düzenlenen verileri DEĞİŞTİRMEZ; sadece önizlemeleri tazele.
        # (Peşin firma değişiklikleri bir sonraki HESAPLA'da uygulanır.)
        self._c3_doldur(); self._banka_doldur()
        self._kart_guncelle()
        self._oturum_kaydet()


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.theme_manager = ThemeManager(app)
    app.setStyleSheet(STYLE)
    if os.path.exists(ICON_F):
        app.setWindowIcon(QIcon(ICON_F))
    w = Ana(); w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
