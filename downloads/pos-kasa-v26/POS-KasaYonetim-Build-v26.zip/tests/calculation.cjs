const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const html=fs.readFileSync(__dirname+'/../pos-app/app-source.jsx','utf8');let script=html.slice(html.indexOf('function parseTR('),html.indexOf('/*',html.indexOf('function parseTR(')));script=script.slice(0,script.indexOf('\n}')+2);
const helper=html.slice(html.indexOf('function posAmount'),html.indexOf('function PosMutabakat'));const ctx=vm.createContext({Date,Math,Number,String,Error,parseFloat,toS:d=>d.toISOString().slice(0,10)});vm.runInContext(script+'\n'+helper,ctx);
const args={id:'g',kasa:{id:'k',bankaId:'b'},tarih:'2026-01-01',toplam:'10.000,00',vade:'2026-01-22',debitler:[{id:'d1',tarih:'2026-01-02',tutar:'3000'},{id:'d2',tarih:'2026-01-03',tutar:'2000'}]};let checks=0;
const calc=o=>ctx.posMutabakatOlustur({...args,...o});
assert.equal(calc()[0].tutar,5000);checks++;assert.equal(calc()[0].yatacakTarih,'2026-01-22');checks++;assert.equal(calc()[1].yatacakTarih,'2026-01-02');checks++;assert.equal(calc()[1].tahsilEdildi,true);checks++;assert.equal(calc({debitler:[]})[0].tutar,10000);checks++;
assert.equal(calc({toplam:'0,30',debitler:[{id:'d',tarih:'2026-01-02',tutar:'0,10'}]})[0].tutar,0.2);checks++;
assert.equal(calc({toplam:'5000'})[0].tutar,0);checks++;
for(const patch of [{toplam:'4999'},{toplam:'abc'},{toplam:'-1'},{toplam:'1x'},{toplam:'0.001'},{tarih:'2026-02-30'},{vade:'2025-12-01'},{debitler:[{id:'d',tarih:'2025-12-31',tutar:'1'}]},{debitler:[{id:'d',tarih:'2099-01-01',tutar:'1'}]}]){assert.throws(()=>calc(patch));checks++;}
const original=JSON.stringify(args);calc();assert.equal(JSON.stringify(args),original);checks++;console.log(checks+' calculation checks passed');
const babel=require('../pos-app/vendor/babel.min.js');babel.transform(html,{presets:['react']});console.log('JSX compilation passed');
