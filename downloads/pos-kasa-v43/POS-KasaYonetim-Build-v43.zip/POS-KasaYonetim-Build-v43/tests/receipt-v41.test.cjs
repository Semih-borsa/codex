const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path'),{EventEmitter}=require('node:events'),{PassThrough}=require('node:stream');const R=require('../pos-app/receipt'),G=require('../pos-app/safety'),N=require('../pos-app/native-ocr');
const cfg={bankalar:[{id:'b',ad:'Banka'}],kasalar:[{id:'k',ad:'KASA 1',kod:'123',bankaId:'b',toplamModu:true}],vadeGunleri:{'KREDİ KARTI':21,'DEBİT KART':1}};
const empty=()=>Object.fromEntries(R.FIELDS.map(([k])=>[k,'0']));
const text=`TARIH:27/10/2026 POS NO:123
KREDI KARTI ISLEMLERI
YURTICI SATIS
ISLEM ADEDI:9
TOPLAM ISLEM TUTARI: 800,00 TL
YURTDISI SATIS
TOPLAM ISLEM TUTARI:100,00 TL
VAKIFBANK SATIS
TOPLAM ISLEM TUTARI:50,00 TL
WORLDPUAN SATIS
TOPLAM ISLEM TUTARI:10,00 TL
DEBIT KART ISLEMLERI
YURTICI SATIS
TOPLAM ISLEM TUTARI:200,00 TL
YURTDISI SATIS
TOPLAM ISLEM TUTARI:40,00 TL
VAKIFBANK SATIS
TOPLAM ISLEM TUTARI:30,00 TL
GENEL TOPLAM
1.230,00 TL
GUNSONU TAMAMLANDI`;
const parsed=()=>R.parse(text),input=o=>({txs:[],cfg,kasaId:'k',date:'2026-10-27',values:parsed().values,total:parsed().total,id:'r',confirmed:true,today:'2026-10-28',...o});
test('Yedi kalem parse edilir, tarih/POS yardımcı bilgi',()=>{const p=parsed();assert.equal(p.found.length,7);assert.equal(p.date,'2026-10-27');assert.equal(p.pos,'123');assert.deepEqual(p.issues,[]);});
test('Debit yurtdışı kredi vadesindedir:1000 kredi230debit',()=>{const c=R.check(parsed().values,parsed().total);assert.equal(c.credit,1000);assert.equal(c.debit,230);assert.equal(c.total,1230);assert.equal(c.matches,true);});
test('Türkçe başlık ve çok satırlı değerler okunur',()=>{const p=R.parse('KREDİ KARTI İŞLEMLERİ\nYURTİÇİ SATIŞ\nİŞLEM ADEDİ:8\nTOPLAM İŞLEM TUTARI:\n1.000,25 TL\nGENEL TOPLAM\n1.000,25 TL');assert.equal(p.values.creditDomestic,'1.000,25');assert.equal(p.total,'1.000,25');});
test('Etiket OCR varyantı düzeltilir, tutar tahmin edilmez',()=>{const p=R.parse('KRED! KARTI\nYURTICL\nTOPLAN ISLEN TUTRRI: 1.000,25 TL\nGENEL TOPLAM\n1.000,25 TL');assert.equal(p.values.creditDomestic,'1.000,25');assert.equal(p.issues.length,0);});
test('Kayıt kredi ve debit vadelerine ayrılır; gerçek yatış sayılmaz',()=>{const r=R.prepare(input());assert.equal(r.rows.length,2);assert.equal(r.rows[0].yatacakTarih,'2026-11-17');assert.equal(r.rows[1].yatacakTarih,'2026-10-28');assert.equal(r.rows[0].tutar,1000);assert.equal(r.rows[1].tutar,230);assert.equal(r.rows.some(t=>t.tahsilEdildi===true),false);G.validatePackage({cfg,txs:r.txs});});
for(const delta of ['1229,99','1230,01','1000'])test('Toplam uyuşmazlığı kayıt engeli '+delta,()=>assert.throws(()=>R.prepare(input({total:delta})),/uyuşmuyor/));
test('Manuel kalem düzeltmesi hâlâ uyumsuzsa kayıt yok',()=>assert.throws(()=>R.prepare(input({values:{...parsed().values,debitForeign:'41'}})),/uyuşmuyor/));
test('Onaysız kayıt olmaz',()=>assert.throws(()=>R.prepare(input({confirmed:false})),/onaylayın/));
for(const change of [{date:'2026-02-30'},{date:'2099-01-01'},{kasaId:'unknown'},{cfg:{...cfg,kasalar:[{...cfg.kasalar[0],aktif:false}]}},{values:{...empty(),creditDomestic:'-1'}},{values:{...empty(),creditDomestic:'0.001'}},{total:''}])test('Geçersiz fiş girişi '+JSON.stringify(change),()=>assert.throws(()=>R.prepare(input(change))));
test('Kuruş hesabı 0,10+0,20=0,30',()=>{const c=R.check({...empty(),creditDomestic:'0,10',debitDomestic:'0,20'},'0,30');assert.equal(c.matches,true);});
test('Yalnız kredi veya yalnız debit sıfır kayıt üretmez',()=>{assert.equal(R.prepare(input({values:{...empty(),debitDomestic:'50'},total:'50'})).rows.length,1);assert.equal(R.prepare(input({values:{...empty(),creditDomestic:'50'},total:'50'})).rows.length,1);});
test('0 günlük vade ve yıl sonu',()=>{assert.equal(R.due('2026-12-31',0),'2026-12-31');assert.equal(R.due('2026-12-31',1),'2027-01-01');});
test('İade/iptal ve okunmayan genel toplam uyarısı',()=>{const p=R.parse('KREDI KARTI\nIADE\nTOPLAM ISLEM TUTARI:10,00 TL');assert.ok(p.issues.some(s=>s.includes('İade')));assert.ok(p.issues.some(s=>s.includes('genel toplam')));});
test('Çift satış veya çift genel toplam belirsizliği işaretlenir',()=>{const p=R.parse(text.replace('GENEL TOPLAM','YURTICI SATIS\nTOPLAM ISLEM TUTARI:2,00 TL\nGENEL TOPLAM'));assert.ok(p.issues.some(s=>s.includes('birden fazla')));});
test('Fiş düzenleme eski çiftin yerine geçer',()=>{const a=R.prepare(input()),b=R.prepare(input({txs:a.txs,replaceId:'r',values:{...parsed().values,debitForeign:'50'},total:'1240'}));assert.equal(b.txs.length,2);assert.equal(b.rows[0].tutar,1010);G.validatePackage({cfg,txs:b.txs});});
test('Eksik veya çelişkili düzenleme kimliği reddedilir',()=>assert.throws(()=>R.prepare(input({replaceId:'other'}))));
test('Fiş ayrıntısına uymayan tutar ve yarım silme reddedilir',()=>{const a=R.prepare(input());assert.throws(()=>G.validatePackage({cfg,txs:[{...a.rows[0],tutar:10},a.rows[1]]}));assert.throws(()=>G.validatePackage({cfg,txs:[a.rows[0]]}));});
test('Eski yedek ve yeni fiş yedek uyumluluğu',()=>{G.validatePackage({cfg,txs:[]});const a=R.prepare(input());assert.equal(G.validatePackage(JSON.parse(JSON.stringify({surum:'ParaTakip-1.0',cfg,txs:a.txs}))).txs[0].fisDetay.total,1230);});
test('Kaynak ve önceki manuel kayıt değişmez',()=>{const old={id:'old',kasaId:'k',bankaId:'b',islemTarihi:'2026-01-01',yatacakTarih:'2026-01-01',tur:'KREDİ KARTI',tutar:5},a=input({txs:[old]}),before=JSON.stringify(a);R.prepare(a);assert.equal(JSON.stringify(a),before);});
const png=()=>{const b=Buffer.alloc(32);Buffer.from([137,80,78,71,13,10,26,10]).copy(b);b.write('IHDR',12);b.writeUInt32BE(100,16);b.writeUInt32BE(200,20);return 'data:image/png;base64,'+b.toString('base64');};
test('OCR yalnız sınırlı PNG kabul eder',()=>{assert.equal(N.imageBuffer({image:png()}).length,32);for(const image of ['x','data:image/png;base64,AAAA','data:text/plain;base64,AAAA'])assert.throws(()=>N.imageBuffer({image}));});
test('OCR negatif tutarı pozitif satışa çeviremez',()=>{const p=R.parse('KREDI KARTI\nYURTICI SATIS\nTOPLAM ISLEM TUTARI:-10,00 TL\nGENEL TOPLAM\n10,00 TL');assert.ok(p.issues.length>0);assert.equal(R.check(p.values,p.total).matches,false);});
test('Fiş alanları eksik veya bozuksa eski veriye dokunulmaz',()=>{const a=R.prepare(input());const before=JSON.stringify(a.txs);assert.throws(()=>G.validatePackage({cfg,txs:[{...a.rows[0],fisDetay:{...a.rows[0].fisDetay,total:1}},a.rows[1]]}));assert.equal(JSON.stringify(a.txs),before);});

function fakeUtility(result,{hang=false,exit=false,onKill=()=>{}}={}){return ()=>{const child=new EventEmitter();child.stdout=new PassThrough();child.stderr=new PassThrough();child.kill=()=>{onKill();child.emit('exit',0);};child.postMessage=args=>{assert.ok(args.image.startsWith('data:image/png;base64,'));queueMicrotask(()=>{if(exit)child.emit('exit',1);else if(!hang)child.emit('message',result);});};queueMicrotask(()=>child.emit('spawn'));return child;};}
test('Gömülü motor sonucu mevcut köprüye döner, süreç kapatılır',async()=>{let killed=0;const r=await N.recognize({image:png()},{forkUtility:fakeUtility({ok:true,text:'örnek fiş',confidence:95},{onKill:()=>killed++})});assert.equal(r.text,'örnek fiş');assert.equal(r.language,'tur+eng');assert.equal(killed,1);});
for(const [name,result,match] of [['eksik motor',{ok:false,code:'assets'},/eksik veya bozuk/],['okuma hatası',{ok:false,code:'failed'},/okunamadı/],['bozuk yanıt',null,/yanıtı geçersiz/],['bozuk metin',{ok:true,text:null},/metni geçersiz/]])test('Gömülü OCR hata '+name,async()=>assert.rejects(N.recognize({image:png()},{forkUtility:fakeUtility(result)}),match));
test('OCR zaman aşımında alt süreç kapatılır',async()=>{let killed=0;await assert.rejects(N.recognize({image:png()},{timeoutMs:10,forkUtility:fakeUtility(null,{hang:true,onKill:()=>killed++})}),/zaman aşımı/);assert.equal(killed,1);});
test('OCR alt süreç beklenmedik çıkışı açık hatadır',async()=>assert.rejects(N.recognize({image:png()},{forkUtility:fakeUtility(null,{exit:true})}),/tamamlanmadan/));
test('OCR eksik paket internet indirmeden hata verir',async()=>{const dir=await fs.mkdtemp(path.join(os.tmpdir(),'pos-embedded-missing-'));try{await assert.rejects(N.recognize({image:png()},{runtimeDir:dir,forkUtility:()=>{throw Error('must not start')}}),/dosyaları bulunamadı/);}finally{await fs.rm(dir,{recursive:true,force:true});}});
test('OCR çalıştırıcı başlatılamazsa mevcut veri değişmez',async()=>assert.rejects(N.recognize({image:png()},{forkUtility:()=>{throw Error('fail')}}),/başlatılamadı/));
test('OCR toplu kapatma bekleyen işi reddeder',async()=>{const p=N.recognize({image:png()},{forkUtility:fakeUtility(null,{hang:true})});N.terminateAll();await assert.rejects(p,/tamamlanmadan/);});
test('Motor ve iki dil dosyasının tamamı yerel ve doğrulanmış',()=>assert.ok(require('../pos-app/ocr-runtime/verify.cjs').verifyRuntime()>20));
test('Dil dosyası bozulunca doğrulama reddeder',async()=>{const dir=await fs.mkdtemp(path.join(os.tmpdir(),'pos-assets-'));try{const files=Array.from({length:20},(_,i)=>({file:'tessdata/tur.traineddata',bytes:1,sha256:'0'.repeat(64)}));await fs.writeFile(path.join(dir,'assets-sha256.json'),JSON.stringify({version:1,files}));assert.throws(()=>require('../pos-app/ocr-runtime/verify.cjs').verifyRuntime(dir),/eksik veya bozuk/);}finally{await fs.rm(dir,{recursive:true,force:true});}});
test('Gömülü işçi ağ erişimini kapatır',async()=>{const execFile=require('node:util').promisify(require('node:child_process').execFile);const script=`require(${JSON.stringify(path.resolve(__dirname,'../pos-app/ocr-runtime/offline.cjs'))});const assert=require('node:assert/strict');assert.throws(()=>require('node:https').get('https://example.invalid'));assert.throws(()=>require('node:net').connect(80,'example.invalid'));global.fetch('https://example.invalid').then(()=>process.exit(1),()=>require('node:fs').writeSync(1,'offline blocked'));`;const r=await execFile(process.execPath,['-e',script]);assert.match(r.stdout,/offline blocked/);});
test('OCR para içindeki boşluğu kaldırır, basamak tahmin etmez',()=>{const p=R.parse('KREDI KARTI\nYURTICI SATIS\nTOPLAM ISLEM TUTARI:82. 189,52 TL\nGENEL TOPLAM\n82.189,52 TL');assert.equal(p.values.creditDomestic,'82.189,52');assert.equal(R.check(p.values,p.total).matches,true);});
test('Bozuk OCR para tokeninin parçası tutar sayılmaz',()=>{const p=R.parse('KREDI KARTI\nYURTICI SATIS\nTOPLAM ISLEM TUTARI:15.44,15 TL\nGENEL TOPLAM\n15.344,15 TL');assert.equal(p.values.creditDomestic,'0');assert.equal(R.check(p.values,p.total).matches,false);});
test('Windows paketleme hooku OCR modülleri ve dilleri eksiksiz kopyalar',async()=>{const dir=await fs.mkdtemp(path.join(os.tmpdir(),'pos-ocr-pack-'));try{await require('../pos-app/bundle-ocr.cjs')({packager:{projectDir:path.resolve(__dirname,'../pos-app')},appOutDir:dir});assert.ok(require('../pos-app/ocr-runtime/verify.cjs').verifyRuntime(path.join(dir,'resources/ocr-runtime'))>20);await fs.access(path.join(dir,'resources/ocr-runtime/node_modules/tesseract.js/src/index.js'));}finally{await fs.rm(dir,{recursive:true,force:true});}});
test('JPEG hazırlama yüksek kaliteli ve2400 sınırında, dosya yolu almaz',()=>{const source='data:image/jpeg;base64,'+Buffer.from([255,216,255,0]).toString('base64');let options;const out=N.prepareJpeg(source,{createFromBuffer:()=>({isEmpty:()=>false,getSize:()=>({width:500,height:1500}),resize:v=>{options=v;return {toDataURL:()=>png()};}})});assert.equal(out,png());assert.equal(options.height,2400);assert.equal(options.width,800);assert.equal(options.quality,'best');});
test('JPEG hazırlamada bozuk, dosya yolu ve aşırı çözünürlük reddedilir',()=>{assert.throws(()=>N.prepareJpeg('C:/receipt.jpg',{}));assert.throws(()=>N.prepareJpeg('data:image/jpeg;base64,AAAA',{}));const source='data:image/jpeg;base64,'+Buffer.from([255,216,255,0]).toString('base64');assert.throws(()=>N.prepareJpeg(source,{createFromBuffer:()=>({isEmpty:()=>false,getSize:()=>({width:10000,height:10000})})}),/fazla büyük/);});
