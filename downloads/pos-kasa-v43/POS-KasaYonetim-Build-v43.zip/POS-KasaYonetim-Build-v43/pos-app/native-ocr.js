'use strict';
const path=require('node:path'),fs=require('node:fs');
const PNG=Buffer.from([137,80,78,71,13,10,26,10]),active=new Set();
function imageBuffer(args){if(!args||typeof args.image!=='string'||args.image.length>20000000||!/^data:image\/png;base64,[A-Za-z0-9+/]+=*$/.test(args.image))throw Error('Fotoğraf isteği geçersiz.');const b=Buffer.from(args.image.slice(22),'base64');if(b.length<24||b.length>15000000||!b.subarray(0,8).equals(PNG)||b.subarray(12,16).toString()!=='IHDR')throw Error('Geçerli bir PNG fotoğrafı gerekli.');const w=b.readUInt32BE(16),h=b.readUInt32BE(20);if(w<1||h<1||w>2400||h>2400)throw Error('Fotoğraf boyutu en fazla 2400 piksel olmalı.');return b;}
function prepareJpeg(original,nativeImage){
 if(typeof original!=='string'||original.length>20000000||!/^data:image\/jpeg;base64,[A-Za-z0-9+/]+=*$/.test(original))throw Error('Kaynak JPEG fotoğrafı geçersiz.');
 const bytes=Buffer.from(original.slice(original.indexOf(',')+1),'base64');if(bytes.length<3||bytes.length>15000000||bytes[0]!==255||bytes[1]!==216||bytes[2]!==255)throw Error('Kaynak JPEG fotoğrafı geçersiz.');
 const api=nativeImage||require('electron').nativeImage;if(!api)throw Error('Fotoğraf hazırlama için masaüstü uygulamasını açın.');
 const photo=api.createFromBuffer(bytes);if(photo.isEmpty())throw Error('JPEG fotoğrafı açılamadı.');const {width,height}=photo.getSize();if(width<1||height<1||width*height>40000000)throw Error('Fotoğraf çözünürlüğü fazla büyük.');
 const scale=Math.min(2400/Math.max(width,height),2);return photo.resize({width:Math.max(1,Math.round(width*scale)),height:Math.max(1,Math.round(height*scale)),quality:'best'}).toDataURL();
}
async function recognize(args,{runtimeDir=path.join(__dirname,'ocr-runtime'),forkUtility,nativeImage,timeoutMs=90000}={}){
 imageBuffer(args);const image=args.original?prepareJpeg(args.original,nativeImage):args.image;imageBuffer({image});
 const script=path.join(runtimeDir,'read.cjs');
 if(!fs.existsSync(script)||!fs.existsSync(path.join(runtimeDir,'assets-sha256.json')))throw Error('Gömülü OCR dosyaları bulunamadı. Tam program klasörünü kullanın.');
 if(!forkUtility){const {utilityProcess}=require('electron');if(!utilityProcess?.fork)throw Error('Fotoğraf okuma için masaüstü uygulamasını açın.');forkUtility=p=>utilityProcess.fork(p,[],{stdio:'pipe',serviceName:'POS Gömülü OCR'});}
 return new Promise((resolve,reject)=>{
  let child,settled=false,stderrSize=0;
  const finish=(error,result)=>{if(settled)return;settled=true;clearTimeout(timer);if(child){active.delete(child);try{child.kill();}catch{}}if(error)reject(error);else resolve(result);};
  const timer=setTimeout(()=>finish(Error('Fotoğraf okuma zaman aşımına uğradı. Daha net bir fotoğraf deneyin.')),timeoutMs);
  try{
   child=forkUtility(script);active.add(child);
   child.once('spawn',()=>{try{child.postMessage({image});}catch{finish(Error('Fotoğraf okuyucuya gönderilemedi.'));}});
   child.on('message',result=>{if(!result||typeof result!=='object'){finish(Error('Gömülü OCR yanıtı geçersiz.'));return;}if(!result.ok){finish(Error(result.code==='assets'?'Gömülü OCR dosyaları eksik veya bozuk. Tam program paketini yeniden çıkarın.':'Fotoğraf okunamadı. Daha net fotoğraf deneyin veya fiş tutarlarını kontrol ederek düzeltin.'));return;}if(typeof result.text!=='string'||result.text.length>200000){finish(Error('Okunan fiş metni geçersiz.'));return;}finish(null,{text:result.text,language:'tur+eng',engine:'Tesseract',confidence:Number(result.confidence)||0});});
   child.on('error',()=>finish(Error('Gömülü fotoğraf okuyucu başlatılamadı.')));
   child.on('exit',()=>{if(!settled)finish(Error('Gömülü fotoğraf okuyucu tamamlanmadan kapandı.'));});
   child.stdout?.resume();child.stderr?.on('data',d=>{stderrSize+=Buffer.byteLength(d);if(stderrSize>1000000)finish(Error('Fotoğraf okuyucu hata verdi.'));});
  }catch{finish(Error('Gömülü fotoğraf okuyucu başlatılamadı.'));}
 });
}
function terminateAll(){for(const child of active)try{child.kill();}catch{}active.clear();}
module.exports={imageBuffer,prepareJpeg,recognize,terminateAll};
