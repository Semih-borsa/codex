'use strict';
const fs=require('node:fs/promises'),path=require('node:path');
module.exports=async context=>{
 const source=path.join(context.packager.projectDir,'ocr-runtime');
 const destination=path.join(context.appOutDir,'resources','ocr-runtime');
 const {verifyRuntime}=require('./ocr-runtime/verify.cjs');
 verifyRuntime(source);
 await fs.rm(destination,{recursive:true,force:true});
 await fs.cp(source,destination,{recursive:true,dereference:true});
 const count=verifyRuntime(destination);
 console.log(`Gömülü OCR paketlendi ve doğrulandı: ${count} dosya`);
};
