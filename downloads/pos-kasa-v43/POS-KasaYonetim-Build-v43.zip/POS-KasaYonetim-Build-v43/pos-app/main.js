const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
// Tarih alanları mevcut Türkçe gün-ay-yıl düzenini kullanır.
app.commandLine.appendSwitch('lang', 'tr-TR');
const {pathToFileURL}=require('url');
const {writeVerified}=require('./file-store');
const pageURL=pathToFileURL(path.join(__dirname,'index.html')).href;
ipcMain.handle('pos:save-backup',async(event,args)=>{
 if(event.senderFrame!==event.sender.mainFrame||event.senderFrame?.url!==pageURL||!args||typeof args.text!=='string'||Buffer.byteLength(args.text,'utf8')>15000000)throw Error('Dosya isteği geçersiz.');
 const result=await dialog.showSaveDialog(BrowserWindow.fromWebContents(event.sender),{title:'JSON yedeğini kaydet',defaultPath:String(args.name||'POS-yedek.json').replace(/[\\/:*?"<>|]/g,'_'),filters:[{name:'JSON yedeği',extensions:['json']}]});
 if(result.canceled||!result.filePath)return {canceled:true};
 return writeVerified(result.filePath,args.text);
});

// Yalnız güvenilir ana pencere; dosya yolu veya komut kullanıcıdan alınmaz.
const {recognize,terminateAll}=require('./native-ocr');
app.on('before-quit',terminateAll);
const ocrBusy=new Set();
ipcMain.handle('pos:read-receipt',async(event,args)=>{
 if(event.senderFrame!==event.sender.mainFrame||event.senderFrame?.url!==pageURL)throw Error('Fotoğraf isteği yetkisiz.');
 const id=event.sender.id;if(ocrBusy.has(id))throw Error('Fotoğraf okuma zaten sürüyor.');ocrBusy.add(id);
 try{return await recognize(args,{runtimeDir:app.isPackaged?path.join(process.resourcesPath,'ocr-runtime'):path.join(__dirname,'ocr-runtime')});}finally{ocrBusy.delete(id);}
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    icon: path.join(__dirname, 'icon.ico'),
    height: 860,
    minWidth: 960,
    minHeight: 640,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: true,
      sandbox: true,
      preload: path.join(__dirname, 'preload.js')
    },
    title: 'POS - Kasa Yönetim',
    backgroundColor: '#0f1117',
    show: false
  });

  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  win.webContents.on('will-navigate',(event,url)=>{if(url!==pageURL)event.preventDefault();});
  win.webContents.on('will-attach-webview',event=>event.preventDefault());
  win.webContents.session.setPermissionRequestHandler((contents,permission,callback)=>callback(permission==='notifications'&&contents.getURL()===pageURL));
  win.webContents.session.setPermissionCheckHandler((contents,permission)=>permission==='notifications'&&contents?.getURL()===pageURL);
  win.loadFile(path.join(__dirname, 'index.html'));

  win.once('ready-to-show', () => {
    win.show();
  });

  win.setMenuBarVisibility(false);
}

if(!app.requestSingleInstanceLock()){app.quit();}else{
app.on('second-instance',()=>{const w=BrowserWindow.getAllWindows()[0];if(w){if(w.isMinimized())w.restore();w.focus();}});
app.whenReady().then(() => {
  // Windows bildirimlerinde uygulama adının doğru görünmesi için
  if (process.platform === 'win32') {
    app.setAppUserModelId('POS - Kasa Yönetim');
  }
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

}
