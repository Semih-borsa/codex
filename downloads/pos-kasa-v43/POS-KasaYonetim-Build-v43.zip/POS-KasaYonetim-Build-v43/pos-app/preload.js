const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('posFiles',{save:args=>ipcRenderer.invoke('pos:save-backup',args)});

contextBridge.exposeInMainWorld('posReceiptOCR',{read:args=>ipcRenderer.invoke('pos:read-receipt',args)});
