'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
function verifyRuntime(dir=__dirname){
 try{
  const manifest=JSON.parse(fs.readFileSync(path.join(dir,'assets-sha256.json'),'utf8'));
  if(manifest.version!==1||!Array.isArray(manifest.files)||manifest.files.length<20)throw Error('manifest');
  for(const entry of manifest.files){if(typeof entry.file!=='string'||entry.file.startsWith('/')||entry.file.includes('..')||!/^\w[\w./@-]*$/.test(entry.file))throw Error('path');const content=fs.readFileSync(path.join(dir,entry.file));if(content.length!==entry.bytes||crypto.createHash('sha256').update(content).digest('hex')!==entry.sha256)throw Error('hash');}
  return manifest.files.length;
 }catch{const error=Error('Gömülü OCR dosyaları eksik veya bozuk. Tam program paketini yeniden çıkarın.');error.code='POS_OCR_ASSETS';throw error;}
}
if(require.main===module)console.log('Gömülü OCR dosyaları doğrulandı: '+verifyRuntime());
module.exports={verifyRuntime};
