# Gömülü OCR bileşenleri

Tesseract.js6.0.1 ve package-lock.json ile sabitlenmiş bağımlılıkları npm paketlerinden alınmıştır. Kaynak: https://github.com/naptha/tesseract.js . Tesseract.js ve tesseract.js-core Apache-2.0 lisanslıdır; paketlerin LICENSE/NOTICE dosyaları node_modules altında korunur. Alt bağımlılık lisansları kendi paketlerindedir.

Türkçe ve İngilizce dil verileri: https://github.com/tesseract-ocr/tessdata_best , tur.traineddata ve eng.traineddata. Apache-2.0 lisansının kopyası tessdata/LICENSE dosyasındadır. Dosyalar dağıtım paketinde sabitlenir; kesin SHA-256 değerleri assets-sha256.json içinde bulunur. Uygulama dil verisini internetten indirmez.

read.cjs, worker-local.cjs, offline.cjs ve verify.cjs uygulama entegrasyonudur. Üçüncü taraf paket kaynakları değiştirilmemiştir. Üçüncü taraf projelere ait telif bildirimleri kendi dosyalarında korunur. Dil verileri ve motorun düşük seviyeli bileşenlerinin bildirimleri ilgili proje lisanslarıyla birlikte dağıtılır.
