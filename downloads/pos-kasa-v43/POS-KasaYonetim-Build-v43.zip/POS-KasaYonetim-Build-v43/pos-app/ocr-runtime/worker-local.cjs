'use strict';
require('./offline.cjs');
require('./node_modules/tesseract.js/src/worker-script/node/index.js');
