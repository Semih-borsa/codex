'use strict';
require('./offline.cjs');
const path=require('node:path'),fs=require('node:fs');
const {verifyRuntime}=require('./verify.cjs');
const port=process.parentPort;
const send=value=>port?port.postMessage(value):process.send?.(value);
let started=false;
async function read(args){
 if(started)return;started=true;
 let worker;
 try{
  verifyRuntime(__dirname);
  if(!args||typeof args.image!=='string'||!args.image.startsWith('data:image/png;base64,')||args.image.length>20000000)throw Error('image');
  const image=Buffer.from(args.image.slice(22),'base64');
  const {createWorker,OEM,PSM}=require('./node_modules/tesseract.js');
  worker=await createWorker('tur+eng',OEM.LSTM_ONLY,{workerPath:path.join(__dirname,'worker-local.cjs'),langPath:path.join(__dirname,'tessdata'),gzip:false,cacheMethod:'none',legacyCore:false,legacyLang:false,logging:false,errorHandler:()=>{}});
  await worker.setParameters({tessedit_pageseg_mode:PSM.SINGLE_BLOCK,preserve_interword_spaces:'1',user_defined_dpi:'300',thresholding_method:'2'});
  const {data}=await worker.recognize(image,{}, {text:true});
  if(typeof data.text!=='string'||data.text.length>200000)throw Error('output');
  await worker.terminate();worker=null;
  send({ok:true,text:data.text,language:'tur+eng',engine:'tesseract.js 6.0.1',confidence:Number(data.confidence)||0});
 }catch(error){
  if(worker)try{await worker.terminate();}catch{}
  send({ok:false,code:error.code==='POS_OCR_ASSETS'?'assets':'failed'});
 }finally{setTimeout(()=>process.exit(0),30);}
}
if(port)port.once('message',event=>read(event.data));else process.once('message',read);
