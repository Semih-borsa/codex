'use strict';
// OCR dosyaları yereldir. Eksik veri için internetten indirme yapılmaz.
const deny=()=>{throw Error('POS OCR çevrimdışı çalışır; ağ isteği engellendi.');};
global.fetch=async()=>deny();
for(const name of ['http','https']){const m=require('node:'+name);m.request=deny;m.get=deny;}
const net=require('node:net');net.connect=deny;net.createConnection=deny;net.Socket.prototype.connect=deny;
require('node:tls').connect=deny;
try{require('node:http2').connect=deny;}catch{}
module.exports=deny;
