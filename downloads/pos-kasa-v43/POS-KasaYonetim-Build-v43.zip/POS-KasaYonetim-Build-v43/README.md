# POS Kasa Yönetim — Build v43 / 1.5.3

Güncel belgeler **KULLANIM-v43.md** ve **SONUC-RAPORU-v43.md**. Eski sürüm belgeleri arşivdir.

POS/nakit/veresiye renkleri halka ve çubuk grafiklerde eşleşir. Veresiye için ortak tarihli, yan yana üç tutar alanı tek Kaydet ile kaydedilir; boş tutarlar0 sayılır.

Tam kaynak paketidir. Windows'ta `pos-app/BUILD.bat` ile derleyin. Gömülü OCR için ayrı dil kurulumu gerekmez. Üretilen `win-unpacked` klasörünün tamamını kullanın. Güncellemeden önce JSON yedeği alın; veri klasörünü temizlemeyin.
