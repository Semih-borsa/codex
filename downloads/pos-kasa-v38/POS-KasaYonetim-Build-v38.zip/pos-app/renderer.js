const {
  useState,
  useEffect,
  useMemo,
  useRef,
  useCallback
} = React;
const SEED_RAW = [["KASA 1", "2025-11-04", "KREDİ KARTI", 37859.57, "2025-11-25"], ["KASA 1", "2025-11-04", "DEBİT KART", 23095.69, "2025-11-20"], ["KASA 2", "2025-11-04", "KREDİ KARTI", 29914.08, "2025-11-25"], ["KASA 2", "2025-11-04", "DEBİT KART", 19043.93, "2025-11-20"], ["EMNİYET", "2025-11-04", "KREDİ KARTI", 4139.75, "2025-11-25"], ["EMNİYET", "2025-11-04", "DEBİT KART", 4521.85, "2025-11-20"], ["EMNİYET", "2025-11-05", "KREDİ KARTI", 7470, "2025-11-26"], ["EMNİYET", "2025-11-05", "DEBİT KART", 3795.05, "2025-11-21"], ["KASA 2", "2025-11-05", "KREDİ KARTI", 47403.55, "2025-11-26"], ["KASA 2", "2025-11-05", "DEBİT KART", 11845.2, "2025-11-21"], ["KASA 1", "2025-11-05", "KREDİ KARTI", 56083.65, "2025-11-26"], ["KASA 1", "2025-11-05", "DEBİT KART", 15724.95, "2025-11-21"], ["EMNİYET", "2025-11-06", "KREDİ KARTI", 7158.75, "2025-11-27"], ["EMNİYET", "2025-11-06", "DEBİT KART", 2772.2, "2025-11-22"], ["KASA 2", "2025-11-06", "KREDİ KARTI", 37048.42, "2025-11-27"], ["KASA 2", "2025-11-06", "DEBİT KART", 13457.86, "2025-11-22"], ["KASA 1", "2025-11-06", "KREDİ KARTI", 38191.22, "2025-11-27"], ["KASA 1", "2025-11-06", "DEBİT KART", 12535.93, "2025-11-22"], ["EMNİYET", "2025-11-07", "KREDİ KARTI", 4012.25, "2025-11-28"], ["EMNİYET", "2025-11-07", "DEBİT KART", 3630.95, "2025-11-23"], ["KASA 2", "2025-11-07", "KREDİ KARTI", 28274.3, "2025-11-28"], ["KASA 2", "2025-11-07", "DEBİT KART", 17861.74, "2025-11-23"], ["KASA 1", "2025-11-07", "KREDİ KARTI", 37277.68, "2025-11-28"], ["KASA 1", "2025-11-07", "DEBİT KART", 17984.72, "2025-11-23"], ["KASA 2", "2025-11-08", "KREDİ KARTI", 61473.34, "2025-11-29"], ["KASA 2", "2025-11-08", "DEBİT KART", 26056.12, "2025-11-24"], ["KASA 1", "2025-11-08", "KREDİ KARTI", 47715.47, "2025-11-29"], ["KASA 1", "2025-11-08", "DEBİT KART", 11738.26, "2025-11-24"], ["KASA 1", "2025-11-09", "KREDİ KARTI", 38306.41, "2025-11-30"], ["KASA 1", "2025-11-09", "DEBİT KART", 6792.82, "2025-11-25"], ["KASA 2", "2025-11-09", "KREDİ KARTI", 37087.69, "2025-11-30"], ["KASA 2", "2025-11-09", "DEBİT KART", 20874.75, "2025-11-25"], ["EMNİYET", "2025-11-10", "KREDİ KARTI", 6407.4, "2025-12-01"], ["EMNİYET", "2025-11-10", "DEBİT KART", 3574.25, "2025-11-26"], ["KASA 2", "2025-11-10", "KREDİ KARTI", 35257.82, "2025-12-01"], ["KASA 2", "2025-11-10", "DEBİT KART", 10198.51, "2025-11-26"], ["KASA 1", "2025-11-10", "KREDİ KARTI", 34056.71, "2025-12-01"], ["KASA 1", "2025-11-10", "DEBİT KART", 15898.82, "2025-11-26"], ["EMNİYET", "2025-11-11", "KREDİ KARTI", 4120.95, "2025-12-02"], ["EMNİYET", "2025-11-11", "DEBİT KART", 3087.7, "2025-11-27"], ["KASA 2", "2025-11-11", "KREDİ KARTI", 28067.37, "2025-12-02"], ["KASA 2", "2025-11-11", "DEBİT KART", 12144.7, "2025-11-27"], ["KASA 1", "2025-11-11", "KREDİ KARTI", 45187.55, "2025-12-02"], ["KASA 1", "2025-11-11", "DEBİT KART", 17434.59, "2025-11-27"], ["EMNİYET", "2025-11-12", "KREDİ KARTI", 2859.75, "2025-12-03"], ["EMNİYET", "2025-11-12", "DEBİT KART", 3957.25, "2025-11-28"], ["KASA 2", "2025-11-12", "KREDİ KARTI", 38629.58, "2025-12-03"], ["KASA 2", "2025-11-12", "DEBİT KART", 23826.57, "2025-11-28"], ["KASA 1", "2025-11-12", "KREDİ KARTI", 29444.3, "2025-12-03"], ["KASA 1", "2025-11-12", "DEBİT KART", 2476.92, "2025-11-28"], ["EMNİYET", "2025-11-13", "KREDİ KARTI", 5231.25, "2025-12-04"], ["EMNİYET", "2025-11-13", "DEBİT KART", 2901.5, "2025-11-29"], ["KASA 2", "2025-11-13", "KREDİ KARTI", 30088.04, "2025-12-04"], ["KASA 2", "2025-11-13", "DEBİT KART", 10096.82, "2025-11-29"], ["KASA 1", "2025-11-13", "KREDİ KARTI", 27895.75, "2025-12-04"], ["KASA 1", "2025-11-13", "DEBİT KART", 11853.46, "2025-11-29"], ["EMNİYET", "2025-11-14", "KREDİ KARTI", 6634.4, "2025-12-05"], ["EMNİYET", "2025-11-14", "DEBİT KART", 3233.25, "2025-11-30"], ["KASA 2", "2025-11-14", "KREDİ KARTI", 25933.8, "2025-12-05"], ["KASA 2", "2025-11-14", "DEBİT KART", 8632.5, "2025-11-30"], ["KASA 1", "2025-11-14", "KREDİ KARTI", 39848.28, "2025-12-05"], ["KASA 1", "2025-11-14", "DEBİT KART", 14496.42, "2025-11-30"], ["KASA 2", "2025-11-15", "KREDİ KARTI", 55610.36, "2025-12-06"], ["KASA 2", "2025-11-15", "DEBİT KART", 30088.86, "2025-12-01"], ["KASA 1", "2025-11-15", "KREDİ KARTI", 40982.86, "2025-12-06"], ["KASA 1", "2025-11-15", "DEBİT KART", 26059.12, "2025-12-01"], ["KASA 2", "2025-11-16", "KREDİ KARTI", 42070.64, "2025-12-07"], ["KASA 2", "2025-11-16", "DEBİT KART", 19179, "2025-12-02"], ["KASA 1", "2025-11-16", "KREDİ KARTI", 42203.98, "2025-12-07"], ["KASA 1", "2025-11-16", "DEBİT KART", 30524.94, "2025-12-02"], ["EMNİYET", "2025-11-17", "KREDİ KARTI", 9666.55, "2025-12-08"], ["EMNİYET", "2025-11-17", "DEBİT KART", 4229.75, "2025-12-03"], ["KASA 3", "2025-11-17", "KREDİ KARTI", 516.6, "2025-12-08"], ["KASA 2", "2025-11-17", "KREDİ KARTI", 41782.03, "2025-12-08"], ["KASA 2", "2025-11-17", "DEBİT KART", 14661.76, "2025-12-03"], ["KASA 1", "2025-11-17", "KREDİ KARTI", 49702.82, "2025-12-08"], ["KASA 1", "2025-11-17", "DEBİT KART", 15663.45, "2025-12-03"], ["EMNİYET", "2025-11-18", "KREDİ KARTI", 14429.75, "2025-12-09"], ["EMNİYET", "2025-11-18", "DEBİT KART", 7630.1, "2025-12-04"], ["KASA 2", "2025-11-18", "KREDİ KARTI", 33839.52, "2025-12-09"], ["KASA 2", "2025-11-18", "DEBİT KART", 22556.45, "2025-12-04"], ["KASA 1", "2025-11-18", "KREDİ KARTI", 36999.72, "2025-12-09"], ["KASA 1", "2025-11-18", "DEBİT KART", 12579.76, "2025-12-04"], ["EMNİYET", "2025-11-19", "KREDİ KARTI", 7922.55, "2025-12-10"], ["EMNİYET", "2025-11-19", "DEBİT KART", 4617, "2025-12-05"], ["KASA 2", "2025-11-19", "KREDİ KARTI", 26243.52, "2025-12-10"], ["KASA 2", "2025-11-19", "DEBİT KART", 19051.76, "2025-12-05"], ["KASA 1", "2025-11-19", "KREDİ KARTI", 48802.54, "2025-12-10"], ["KASA 1", "2025-11-19", "DEBİT KART", 17427.25, "2025-12-05"], ["EMNİYET", "2025-11-20", "KREDİ KARTI", 7235.25, "2025-12-11"], ["EMNİYET", "2025-11-20", "DEBİT KART", 5252.75, "2025-12-06"], ["KASA 2", "2025-11-20", "KREDİ KARTI", 49890.83, "2025-12-11"], ["KASA 2", "2025-11-20", "DEBİT KART", 11714.06, "2025-12-06"], ["KASA 1", "2025-11-20", "KREDİ KARTI", 25331.93, "2025-12-11"], ["KASA 1", "2025-11-20", "DEBİT KART", 10113.56, "2025-12-06"], ["EMNİYET", "2025-11-21", "KREDİ KARTI", 10230.6, "2025-12-12"], ["EMNİYET", "2025-11-21", "DEBİT KART", 6340.05, "2025-12-07"], ["KASA 2", "2025-11-21", "KREDİ KARTI", 33940.03, "2025-12-12"], ["KASA 2", "2025-11-21", "DEBİT KART", 18634.66, "2025-12-07"], ["KASA 1", "2025-11-21", "KREDİ KARTI", 36911.02, "2025-12-12"], ["KASA 1", "2025-11-21", "DEBİT KART", 11744.3, "2025-12-07"], ["KASA 2", "2025-11-22", "KREDİ KARTI", 54774.98, "2025-12-13"], ["KASA 2", "2025-11-22", "DEBİT KART", 18164.84, "2025-12-08"], ["KASA 1", "2025-11-22", "KREDİ KARTI", 42154.39, "2025-12-13"], ["KASA 1", "2025-11-22", "DEBİT KART", 13043.32, "2025-12-08"], ["KASA 2", "2025-11-23", "KREDİ KARTI", 45771.92, "2025-12-14"], ["KASA 2", "2025-11-23", "DEBİT KART", 12501.81, "2025-12-09"], ["KASA 1", "2025-11-23", "KREDİ KARTI", 31508.87, "2025-12-14"], ["KASA 1", "2025-11-23", "DEBİT KART", 9143.47, "2025-12-09"], ["EMNİYET", "2025-11-24", "KREDİ KARTI", 7051.85, "2025-12-15"], ["EMNİYET", "2025-11-24", "DEBİT KART", 3122.25, "2025-12-10"], ["KASA 2", "2025-11-24", "KREDİ KARTI", 33453.6, "2025-12-15"], ["KASA 2", "2025-11-24", "DEBİT KART", 10046.72, "2025-12-10"], ["KASA 1", "2025-11-24", "KREDİ KARTI", 27290.41, "2025-12-15"], ["KASA 1", "2025-11-24", "DEBİT KART", 17354.86, "2025-12-10"], ["KASA 3", "2025-11-25", "DEBİT KART", 866.95, "2025-12-11"], ["KASA 2", "2025-11-25", "KREDİ KARTI", 37733.47, "2025-12-16"], ["KASA 2", "2025-11-25", "DEBİT KART", 14404.67, "2025-12-11"], ["KASA 1", "2025-11-25", "KREDİ KARTI", 29914.75, "2025-12-16"], ["KASA 1", "2025-11-25", "DEBİT KART", 19679.12, "2025-12-11"], ["EMNİYET", "2025-11-25", "KREDİ KARTI", 4176.5, "2025-12-16"], ["EMNİYET", "2025-11-25", "DEBİT KART", 3534.45, "2025-12-11"], ["EMNİYET", "2025-11-26", "KREDİ KARTI", 8639.9, "2025-12-17"], ["EMNİYET", "2025-11-26", "DEBİT KART", 9413, "2025-12-12"], ["KASA 3", "2025-11-26", "KREDİ KARTI", 2015.12, "2025-12-17"], ["KASA 2", "2025-11-26", "KREDİ KARTI", 39076.5, "2025-12-17"], ["KASA 2", "2025-11-26", "DEBİT KART", 16945.95, "2025-12-12"], ["KASA 1", "2025-11-26", "KREDİ KARTI", 45675.52, "2025-12-17"], ["KASA 1", "2025-11-26", "DEBİT KART", 19701.35, "2025-12-12"], ["EMNİYET", "2025-11-27", "KREDİ KARTI", 9471.75, "2025-12-18"], ["EMNİYET", "2025-11-27", "DEBİT KART", 6397, "2025-12-13"], ["KASA 1", "2025-11-27", "KREDİ KARTI", 29798.77, "2025-12-18"], ["KASA 1", "2025-11-27", "DEBİT KART", 13633.65, "2025-12-13"], ["KASA 2", "2025-11-27", "KREDİ KARTI", 37974.08, "2025-12-18"], ["KASA 2", "2025-11-27", "DEBİT KART", 17257.35, "2025-12-13"]];
const DEF_CFG = {
  vadeGunleri: {
    "KREDİ KARTI": 21,
    "DEBİT KART": 16
  },
  bankalar: [{
    id: "b1",
    ad: "VAKIFBANK"
  }],
  kasalar: [{
    id: "k1",
    ad: "KASA 1",
    kod: "1065626",
    bankaId: "b1"
  }, {
    id: "k2",
    ad: "KASA 2",
    kod: "1065624",
    bankaId: "b1"
  }, {
    id: "k3",
    ad: "KASA 3",
    kod: "1573325",
    bankaId: "b1"
  }, {
    id: "k4",
    ad: "EMNİYET",
    kod: "PS957956",
    bankaId: "b1"
  }],
  kasaYapim: {
    kasaSayisi: 14,
    kupurler: [{
      tutar: 50,
      adet: 4
    }, {
      tutar: 20,
      adet: 16
    }, {
      tutar: 10,
      adet: 19
    }, {
      tutar: 5,
      adet: 23
    }]
  },
  bankaYedek: {
    aktif: false,
    adet: null
  }
};
const DEF_PARA = {
  c200: 0,
  c100: 0,
  c50: 0,
  c20: 0,
  c10: 0,
  c5k: 0,
  c5m: 0
};
const DEF_KASA_DURUM = {
  fazla: 0,
  eksik: 0,
  tarih: ""
};
const SAYIM_KEYS = ["tarih", "alacak", "kasalarAdet", "kasaYedekSabit", "yk1", "yk05", "yk025", "yk01", "yk005", "bp1", "bp05", "bp025", "bp01", "bp005", "bozukKarisik", "avansAdet", "b200", "b100", "b50", "b20", "b10", "b5", "b5m", "merkezKasa"];
const SAYIM_SEED_RAW = [["2025-06-15", 465, 7, 1750, 300, 300, 300, 300, 300, 1900, 600, 2200, 4900, 3800, 109.45, 1, 0, 0, 74, 347, 569, 445, 0, 37735.15], ["2025-07-15", 0, 3, 1750, 300, 300, 300, 300, 300, 4300, 1800, 3100, 4400, 3300, 104.25, 1, 263, 59, 75, 367, 571, 779, 12, 93334.64], ["2025-08-10", 0, 3, 1750, 300, 300, 300, 300, 300, 5400, 1900, 3000, 1500, 1500, 90.55, 1, 246, 44, 102, 458, 689, 779, 5, 93235.75], ["2025-08-20", 1719, 7, 1750, 300, 300, 300, 300, 300, 3600, 1100, 2100, 1500, 1500, 77.4, 1, 2, 0, 44, 366, 513, 495, 9, 39412.38], ["2025-09-18", 722.95, 6, 1750, 300, 300, 300, 300, 300, 2600, 900, 1700, 1600, 1500, 96.65, 1, 163, 19, 72, 357, 400, 296, 8, 68159.09], ["2025-10-10", 0, 5, 1750, 300, 300, 300, 300, 300, 3300, 1000, 1600, 1900, 1700, 42.3, 1, 0, 0, 61, 239, 234, 343, 25, 27360.49], ["2025-11-07", 0, 5, 1750, 300, 300, 300, 300, 300, 4200, 900, 1500, 2400, 2000, 105.95, 1, 0, 0, 72, 263, 194, 305, 18, 28950.44], ["2025-11-12", 0, 6, 1750, 300, 300, 300, 300, 300, 4100, 600, 1200, 2400, 2000, 126.3, 1, 146, 59, 71, 299, 393, 243, 31, 68248.43], ["2025-12-13", 339.9, 4, 1750, 300, 300, 300, 300, 300, 2600, 1700, 1600, 2500, 2000, 98.75, 1, 462, 75, 44, 100, 316, 281, 73, 122689.38], ["2026-01-11", 0, 3, 1750, 300, 300, 300, 300, 300, 2500, 1700, 1300, 2500, 2000, 113, 1, 521, 127, 112, 202, 215, 225, 39, 141100.86], ["2026-02-08", 0, 3, 1750, 300, 300, 300, 300, 300, 3200, 1600, 1600, 2800, 2100, 116.5, 1, 760, 197, 119, 347, 453, 305, 77, 202620.7], ["2026-03-08", 0, 3, 1750, 300, 300, 300, 300, 300, 2900, 1400, 1400, 2900, 2300, 103.95, 1, 761, 136, 71, 136, 448, 539, 22, 190542.25], ["2026-05-02", 0, 4, 1750, 300, 300, 300, 300, 300, 5100, 2100, 2000, 1200, 1100, 32, 1, 470, 96, 104, 419, 508, 362, 243, 140700.33], ["2026-05-20", 0, 10, 1750, 300, 300, 300, 300, 300, 2700, 400, 700, 1200, 1100, 135.85, 1, 3, 0, 30, 108, 120, 280, 6, 30780.71], ["2026-06-07", 0, 3, 1750, 300, 300, 300, 300, 300, 3100, 1500, 2100, 1300, 1300, 106.15, 1, 670, 193, 114, 337, 289, 526, 56, 182644.79]];
const DEF_SAYIM = {
  alacak: 0,
  kasalarAdet: 0,
  kasaBirim: 2000,
  avansAdet: 0,
  avansBirim: 2000,
  kasaYedekSabit: 1750,
  yk1: 300,
  yk05: 300,
  yk025: 300,
  yk01: 300,
  yk005: 300,
  bp1: 0,
  bp05: 0,
  bp025: 0,
  bp01: 0,
  bp005: 0,
  bozukKarisik: 0,
  b200: 0,
  b100: 0,
  b50: 0,
  b20: 0,
  b10: 0,
  b5: 0,
  b5m: 0,
  merkezKasa: 0
};
function hesaplaSayim(f) {
  const g = k => parseTR(f[k]);
  const yedekBozuk = g("yk1") * 1 + g("yk05") * 0.5 + g("yk025") * 0.25 + g("yk01") * 0.1 + g("yk005") * 0.05;
  const bozuk = g("bp1") * 1 + g("bp05") * 0.5 + g("bp025") * 0.25 + g("bp01") * 0.1 + g("bp005") * 0.05;
  const banknot = g("b200") * 200 + g("b100") * 100 + g("b50") * 50 + g("b20") * 20 + g("b10") * 10 + g("b5") * 5 + g("b5m") * 5;
  const kasalar = g("kasalarAdet") * (g("kasaBirim") || 2000);
  const avans = g("avansAdet") * (g("avansBirim") || 2000);
  const toplam = g("alacak") + kasalar + g("kasaYedekSabit") + yedekBozuk + bozuk + g("bozukKarisik") + avans + banknot;
  const fazlaEksik = toplam - g("merkezKasa");
  return {
    toplam,
    fazlaEksik,
    yedekBozuk,
    bozuk,
    banknot,
    kasalar,
    avans
  };
}
const fmt = n => new Intl.NumberFormat("tr-TR", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
}).format(n);
const fmtN = n => new Intl.NumberFormat("tr-TR").format(n);
const toS = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const addD = (s, n) => {
  const d = new Date(s + "T00:00:00");
  d.setDate(d.getDate() + n);
  return toS(d);
};
const fDSh = s => {
  if (!s) return "—";
  const d = new Date(s + "T00:00:00");
  return `${String(d.getDate()).padStart(2, "0")}.${String(d.getMonth() + 1).padStart(2, "0")}.${d.getFullYear()}`;
};
const uid = () => `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
const BCOLS = ["#3b82f6", "#ec4899", "#f97316", "#a855f7", "#14b8a6", "#f59e0b"];
const BACCS = ["#60a5fa", "#f472b6", "#fb923c", "#c084fc", "#2dd4bf", "#fbbf24"];
const LS = {
  get: (k, d) => {
    try {
      const v = localStorage.getItem(k);
      return v ? JSON.parse(v) : d;
    } catch {
      return d;
    }
  },
  set: (k, v) => {
    try {
      if (localStorage.getItem("pos:restoreJournal")) throw Error("Yarım geri yükleme var; uygulamayı yeniden açın.");
      localStorage.setItem(k, JSON.stringify(v));
    } catch {
      throw Error("Kayıt yazılamadı. Depolama alanını kontrol edin.");
    }
  }
};
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
const bugünTS = () => {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}_${String(d.getHours()).padStart(2, "0")}${String(d.getMinutes()).padStart(2, "0")}`;
};
const simdiZaman = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}`;
};
function currentBackup() {
  const data = {
    surum: "ParaTakip-1.0",
    tarih: new Date().toISOString()
  };
  for (const k of POSGuard.KEYS) {
    const text = localStorage.getItem("pos:" + k);
    if (text !== null) data[k] = JSON.parse(text);
  }
  POSGuard.validatePackage(data, {}, DEF_CFG);
  return data;
}
async function saveBackupDocument(name, text) {
  if (!window.posFiles?.save) throw Error("Doğrulanmış dosya kaydı için masaüstü uygulamasını açın.");
  const r = await window.posFiles.save({
    name,
    text
  });
  if (r.canceled) return false;
  if (!r.saved) throw Error("Dosya kaydedilemedi.");
  return true;
}
async function jsonYedekAl() {
  try {
    const data = currentBackup();
    if (await saveBackupDocument(`ParaTakip_Yedek_${bugünTS()}.json`, JSON.stringify(data, null, 2))) alert("Yedek dosyası kaydedildi ve doğrulandı.");
  } catch (e) {
    alert("Yedek alınamadı: " + e.message);
  }
}
function jsonGeriYukle(file, onDone) {
  if (file.size > 15000000) {
    onDone(false, "Yedek en fazla 15 MB olabilir.");
    return;
  }
  const reader = new FileReader();
  reader.onerror = () => onDone(false, "Yedek dosyası okunamadı.");
  reader.onload = async e => {
    try {
      const before = POSGuard.snapshot(localStorage),
        current = {};
      let corrupt = false;
      for (const [k, text] of Object.entries(before)) if (text !== null) {
        try {
          current[k] = JSON.parse(text);
        } catch {
          corrupt = true;
        }
      }
      const raw = JSON.parse(e.target.result.replace(/^\uFEFF/, "")),
        next = POSGuard.validatePackage(raw, current, DEF_CFG);
      const complete = !!next.cfg && Object.hasOwn(next, "txs");
      if (corrupt && !complete) throw Error("Bozuk mevcut kaydı kurtarmak için ayar ve işlemleri içeren tam yedek gerekli.");
      const oldCount = (current.txs || []).length,
        newCount = next.txs?.length ?? oldCount;
      if (!confirm(`${complete ? "Tam yedek" : "Kısmi paket"}: ${Object.keys(next).join(", ")} alanları değişecek. İşlemler: ${oldCount} → ${newCount}. Nakit: ${(current.nakit || []).length} → ${(next.nakit ?? current.nakit ?? []).length}. Eksik alanlar korunacak. Devam edilsin mi?`)) {
        onDone(false, "Geri yükleme iptal edildi; kayıtlar değişmedi.");
        return;
      }
      const protection = corrupt ? {
        hamKurtarma: true,
        rawRecords: before
      } : {
        surum: "ParaTakip-1.0",
        tarih: new Date().toISOString(),
        ...current
      };
      if (!(await saveBackupDocument(`GeriYuklemeOncesi_${bugünTS()}.json`, JSON.stringify(protection, null, 2)))) {
        onDone(false, "Güvenlik yedeği iptal edildi; kayıtlar değişmedi.");
        return;
      }
      POSGuard.restore(localStorage, next, before);
      onDone(true, `${newCount} işlem; geri yükleme doğrulandı.`);
    } catch (err) {
      onDone(false, "Geri yüklenemedi: " + err.message);
    }
  };
  reader.readAsText(file);
}
function excelIslemGecmisi(txs, cfg) {
  if (!window.XLSX) {
    alert("Excel kütüphanesi yüklenemedi");
    return;
  }
  const rows = txs.map(t => {
    const kasa = cfg.kasalar.find(k => k.id === t.kasaId);
    const banka = cfg.bankalar.find(b => b.id === t.bankaId);
    return {
      "Banka": banka?.ad || "",
      "Kasa": kasa?.ad || t.kasaId,
      "Kasa Kodu": kasa?.kod || "",
      "İşlem Tarihi": fDSh(t.islemTarihi),
      "Kart Türü": t.tur,
      "Tutar": t.tutar,
      "Yatacağı Tarih": fDSh(t.yatacakTarih)
    };
  });
  const ws = XLSX.utils.json_to_sheet(rows);
  ws["!cols"] = [{
    wch: 14
  }, {
    wch: 12
  }, {
    wch: 12
  }, {
    wch: 13
  }, {
    wch: 14
  }, {
    wch: 14
  }, {
    wch: 14
  }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "İşlem Geçmişi");
  XLSX.writeFile(wb, `ParaTakip_IslemGecmisi_${bugünTS()}.xlsx`);
}
function excelParaLog(paraLog) {
  if (!window.XLSX) {
    alert("Excel kütüphanesi yüklenemedi");
    return;
  }
  if (!paraLog || !paraLog.length) {
    alert("Henüz para giriş/çıkış kaydı yok");
    return;
  }
  const rows = paraLog.slice().sort((a, b) => (a.zaman || a.tarih || "") < (b.zaman || b.tarih || "") ? 1 : -1).map(l => ({
    "Tarih / Saat": l.zaman ? fDSh(l.zaman.slice(0, 10)) + " " + l.zaman.slice(11) : l.tarih ? fDSh(l.tarih) : "",
    "İşlem": l.islem === "giris" ? "GİRİŞ" : "ÇIKIŞ",
    "200 TL": l.c200 || 0,
    "100 TL": l.c100 || 0,
    "50 TL": l.c50 || 0,
    "20 TL": l.c20 || 0,
    "10 TL": l.c10 || 0,
    "5 TL Kağıt": l.c5k || 0,
    "5 TL Madeni": l.c5m || 0,
    "Toplam Tutar": l.toplam || 0
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  ws["!cols"] = [{
    wch: 19
  }, {
    wch: 8
  }, {
    wch: 8
  }, {
    wch: 8
  }, {
    wch: 8
  }, {
    wch: 8
  }, {
    wch: 8
  }, {
    wch: 11
  }, {
    wch: 12
  }, {
    wch: 13
  }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Para Giriş-Çıkış");
  XLSX.writeFile(wb, `ParaTakip_ParaDokumu_${bugünTS()}.xlsx`);
}
function excelKasaLog(kasaLog) {
  if (!window.XLSX) {
    alert("Excel kütüphanesi yüklenemedi");
    return;
  }
  if (!kasaLog || !kasaLog.length) {
    alert("Henüz kasa fazlası/eksiği kaydı yok");
    return;
  }
  let kümülatif = 0;
  const sirali = kasaLog.slice().sort((a, b) => a.tarih < b.tarih ? -1 : 1);
  const rows = sirali.map(l => {
    if (l.tur === "sifirla") {
      kümülatif = 0;
      return {
        "Tarih": fDSh(l.tarih),
        "Tür": "— SIFIRLAMA —",
        "Fazla": "",
        "Eksik": "",
        "Kümülatif Net": 0
      };
    }
    const fazla = l.tur === "fazla" ? l.tutar : 0;
    const eksik = l.tur === "eksik" ? l.tutar : 0;
    kümülatif += fazla - eksik;
    return {
      "Tarih": fDSh(l.tarih),
      "Tür": l.tur === "fazla" ? "FAZLA" : "EKSİK",
      "Fazla": fazla || "",
      "Eksik": eksik || "",
      "Kümülatif Net": kümülatif
    };
  }).reverse();
  const ws = XLSX.utils.json_to_sheet(rows);
  ws["!cols"] = [{
    wch: 12
  }, {
    wch: 8
  }, {
    wch: 12
  }, {
    wch: 12
  }, {
    wch: 14
  }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Kasa Fazla-Eksik");
  XLSX.writeFile(wb, `ParaTakip_KasaDokumu_${bugünTS()}.xlsx`);
}
function excelKasaSayimi(sayimlar) {
  if (!window.XLSX) {
    alert("Excel kütüphanesi yüklenemedi");
    return;
  }
  if (!sayimlar || !sayimlar.length) {
    alert("Henüz kasa sayımı kaydı yok");
    return;
  }
  const sirali = [...sayimlar].sort((a, b) => a.tarih < b.tarih ? -1 : 1);
  let oncekiFE = null;
  const rows = sirali.map(s => {
    const c = hesaplaSayim(s);
    const fark = oncekiFE !== null ? c.fazlaEksik - oncekiFE : "";
    oncekiFE = c.fazlaEksik;
    return {
      "Tarih": fDSh(s.tarih),
      "Alacak": s.alacak || 0,
      "Kasalar Adet": s.kasalarAdet || 0,
      "Kasalar ₺": c.kasalar,
      "Avans Adet": s.avansAdet || 0,
      "Avans ₺": c.avans,
      "Kasa Yedek Sabit": s.kasaYedekSabit || 0,
      "Yedek Bozuk ₺": c.yedekBozuk,
      "Bozuk Para ₺": c.bozuk,
      "Bozuk Karışık": s.bozukKarisik || 0,
      "200 TL": s.b200 || 0,
      "100 TL": s.b100 || 0,
      "50 TL": s.b50 || 0,
      "20 TL": s.b20 || 0,
      "10 TL": s.b10 || 0,
      "5 TL": s.b5 || 0,
      "5 TL Madeni": s.b5m || 0,
      "Banknot ₺": c.banknot,
      "TOPLAM": c.toplam,
      "Merkez Kasa": s.merkezKasa || 0,
      "Fazla/Eksik": c.fazlaEksik,
      "Önceki Farkı": fark
    };
  }).reverse();
  const ws = XLSX.utils.json_to_sheet(rows);
  ws["!cols"] = Object.keys(rows[0] || {}).map(() => ({
    wch: 13
  }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Kasa Sayımı");
  XLSX.writeFile(wb, `ParaTakip_KasaSayimi_${bugünTS()}.xlsx`);
}
function excelGunlukRapor(txs, cfg) {
  if (!window.XLSX) {
    alert("Excel kütüphanesi yüklenemedi");
    return;
  }
  const byDate = {};
  txs.forEach(t => {
    const d = t.yatacakTarih;
    if (!byDate[d]) byDate[d] = {};
    const kasa = cfg.kasalar.find(k => k.id === t.kasaId);
    const ad = kasa?.ad || t.kasaId;
    if (!byDate[d][ad]) byDate[d][ad] = {
      kredi: 0,
      debit: 0
    };
    if (t.tur === "DEBİT KART") byDate[d][ad].debit += t.tutar;else byDate[d][ad].kredi += t.tutar;
  });
  const kasaSirala = (a, b) => {
    const s = ad => {
      const m = ad.match(/^KASA\s+(\d+)$/i);
      if (m) return parseInt(m[1]);
      if (ad.toUpperCase() === "EMNİYET") return 9000;
      return 9999;
    };
    return s(a) - s(b);
  };
  const rows = [];
  Object.keys(byDate).sort().forEach(d => {
    const kasalar = Object.keys(byDate[d]).sort(kasaSirala);
    let gunToplam = 0;
    kasalar.forEach(ad => {
      const {
        kredi,
        debit
      } = byDate[d][ad];
      const tplm = kredi + debit;
      gunToplam += tplm;
      rows.push({
        "Yatacağı Tarih": fDSh(d),
        "Kasa": ad,
        "Kredi Kartı": kredi,
        "Debit Kart": debit,
        "Toplam": tplm
      });
    });
    rows.push({
      "Yatacağı Tarih": fDSh(d),
      "Kasa": "► GÜN TOPLAMI",
      "Kredi Kartı": "",
      "Debit Kart": "",
      "Toplam": gunToplam
    });
  });
  const ws = XLSX.utils.json_to_sheet(rows);
  ws["!cols"] = [{
    wch: 14
  }, {
    wch: 16
  }, {
    wch: 14
  }, {
    wch: 14
  }, {
    wch: 14
  }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Günlük Yatış Raporu");
  XLSX.writeFile(wb, `ParaTakip_GunlukRapor_${bugünTS()}.xlsx`);
}
function parseTR(s) {
  if (s === null || s === undefined) return 0;
  s = String(s).trim();
  if (!s) return 0;
  if (s.includes(",")) return parseFloat(s.replace(/\./g, "").replace(",", ".")) || 0;
  const p = s.split(".");
  if (p.length === 2 && p[1].length !== 3) return parseFloat(s) || 0;
  if (p.length >= 2) return parseFloat(s.replace(/\./g, "")) || 0;
  return parseFloat(s) || 0;
}
function ParaInput({
  value,
  onChange,
  placeholder,
  style,
  onEnter,
  inputRef
}) {
  const [odakta, setOdakta] = useState(false);
  const bos = value === "" || value === null || value === undefined;
  let invalid = false;
  try {
    if (!bos) POSGuard.money(value, true);
  } catch {
    invalid = true;
  }
  const goster = odakta || invalid ? value ?? "" : bos ? "" : fmt(parseTR(value));
  return React.createElement("input", {
    type: "text",
    inputMode: "decimal",
    ref: inputRef,
    value: goster,
    placeholder: placeholder || "0,00",
    onFocus: () => setOdakta(true),
    onBlur: () => setOdakta(false),
    onChange: e => onChange(e.target.value),
    onKeyDown: e => {
      if (e.key === "Enter" && onEnter) onEnter();
    },
    style: style
  });
}
function bildirimGonder(list) {
  try {
    if (typeof Notification === "undefined") return;
    const bugun = toS(new Date());
    const goster = () => {
      list.slice(0, 4).forEach((o, i) => {
        setTimeout(() => {
          const gecikti = o.sonOdeme < bugun;
          try {
            new Notification(gecikti ? "⚠ Ödeme Gecikti" : "🔔 Bugün Son Ödeme Günü", {
              body: `${o.ad} — ₺${fmt(o.tutar)}${gecikti ? "  (son gün: " + fDSh(o.sonOdeme) + ")" : ""}`,
              silent: false
            });
          } catch (e) {}
        }, i * 700);
      });
    };
    if (Notification.permission === "granted") goster();else if (Notification.permission !== "denied") Notification.requestPermission().then(p => {
      if (p === "granted") goster();
    }).catch(() => {});
  } catch (e) {}
}
function App() {
  const today = toS(new Date());
  const [cfg, setCfg] = useState(DEF_CFG);
  const [txs, setTxs] = useState([]);
  const [nakit, setNakit] = useState([]);
  const [tab, setTab] = useState("ozet");
  const [odemeOdak, setOdemeOdak] = useState(false);
  const [loading, setL] = useState(true);
  const [tDate, setTDate] = useState(today);
  const [rangeBas, setRangeBas] = useState("");
  const [rangeBit, setRangeBit] = useState("");
  const [sorgu, setSorgu] = useState(null);
  const [odemeler, setOdemeler] = useState([]);
  const [plan, setPlan] = useState(null);
  const [hatirlatma, setHatirlatma] = useState(null);
  const [para, setPara] = useState(DEF_PARA);
  const [kasaDurum, setKD] = useState(DEF_KASA_DURUM);
  const [paraLog, setParaLog] = useState([]);
  const [kasaLog, setKasaLog] = useState([]);
  const [sayimlar, setSayimlar] = useState([]);
  useEffect(() => {
    const c = LS.get("pos:cfg", DEF_CFG);
    if (!c.kasaYapim) c.kasaYapim = DEF_CFG.kasaYapim;else if (!c.kasaYapim.kupurler) {
      const eski = c.kasaYapim;
      c.kasaYapim = {
        kasaSayisi: eski.kasaSayisi || 14,
        kupurler: [{
          tutar: 50,
          adet: eski.s50 || 0
        }, {
          tutar: 20,
          adet: eski.s20 || 0
        }, {
          tutar: 10,
          adet: eski.s10 || 0
        }, {
          tutar: 5,
          adet: eski.s5 || 0
        }]
      };
    }
    if (!c.bankaYedek) c.bankaYedek = {
      aktif: false,
      adet: null
    };
    setCfg(c);
    const t = LS.get("pos:txs", null);
    if (t) {
      setTxs(t);
      const dates = [...new Set(t.map(x => x.yatacakTarih))].sort();
      setTDate(dates.includes(today) ? today : dates[0] || today);
    } else {
      const s = buildSeed(c);
      setTxs(s);
      LS.set("pos:txs", s);
      const dates = [...new Set(s.map(x => x.yatacakTarih))].sort();
      setTDate(dates.includes(today) ? today : dates[0] || today);
    }
    setNakit(LS.get("pos:nakit", []));
    setPara(LS.get("pos:para", DEF_PARA));
    setKD(LS.get("pos:kasadurum", {
      ...DEF_KASA_DURUM,
      tarih: addD(today, -1)
    }));
    setParaLog(LS.get("pos:paralog", []));
    setKasaLog(LS.get("pos:kasalog", []));
    const savedSayim = LS.get("pos:sayimlar", null);
    if (savedSayim) {
      setSayimlar(savedSayim);
    } else {
      const seeded = SAYIM_SEED_RAW.map((row, i) => {
        const o = {
          id: `sseed_${i}`
        };
        SAYIM_KEYS.forEach((k, j) => o[k] = row[j]);
        return o;
      });
      setSayimlar(seeded);
      LS.set("pos:sayimlar", seeded);
    }
    setOdemeler(LS.get("pos:odemeler", []));
    const d1 = new Date();
    d1.setMonth(d1.getMonth() + 1);
    d1.setDate(1);
    const sp = LS.get("pos:plan", null);
    const varsayilan = {
      bakiyeTarihi: today,
      odemeGunu: today,
      maasTarihi: toS(d1),
      maasTutari: "",
      bankaBakiye: "",
      nakitTahmini: "",
      bugunPosHaric: true,
      maasGunuPosHaric: true
    };
    if (sp && sp.planTarihi && !sp.odemeGunu) {
      sp.odemeGunu = sp.planTarihi;
      sp.bakiyeTarihi = today;
      sp.bugunPosHaric = true;
      delete sp.planTarihi;
      delete sp.planGunuPos;
    }
    setPlan(sp ? {
      ...varsayilan,
      ...sp,
      bakiyeTarihi: sp.bakiyeTarihi && sp.bakiyeTarihi >= today ? sp.bakiyeTarihi : today
    } : varsayilan);
    setL(false);
  }, []);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [tab]);
  useEffect(() => {
    if (tab === "ozet" && odemeOdak) {
      document.getElementById("ozet-odemeler")?.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
      setOdemeOdak(false);
    }
  }, [tab, odemeOdak]);
  useEffect(() => {
    if (loading) return;
    const bugun = toS(new Date());
    const due = odemeler.filter(o => !o.odendi && o.sonOdeme <= bugun).sort((a, b) => a.sonOdeme < b.sonOdeme ? -1 : 1);
    if (due.length) {
      setHatirlatma(due);
      bildirimGonder(due);
    }
  }, [loading]);
  const buildSeed = c => SEED_RAW.map(([ka, iT, tur, tutar, yT], i) => {
    const k = c.kasalar.find(x => x.ad === ka) || c.kasalar[0];
    return {
      id: `seed_${i}`,
      kasaId: k.id,
      bankaId: k.bankaId,
      islemTarihi: iT,
      tur,
      tutar,
      yatacakTarih: yT
    };
  });
  const saveNakit = d => {
    POSGuard.cashList(d, cfg);
    try {
      if (localStorage.getItem("pos:restoreJournal")) throw Error("Geri yükleme bekliyor.");
      const text = JSON.stringify(d);
      localStorage.setItem("pos:nakit", text);
      if (localStorage.getItem("pos:nakit") !== text) throw Error("Yazma doğrulanamadı.");
    } catch {
      throw Error("Nakit kaydı kaydedilemedi. Mevcut kayıtlar korundu; tekrar deneyin.");
    }
    setNakit(d);
  };
  const saveTxs = d => {
    POSGuard.validatePackage({
      txs: d
    }, {
      cfg
    }, DEF_CFG);
    try {
      if (localStorage.getItem("pos:restoreJournal")) throw Error("Geri yükleme bekliyor.");
      localStorage.setItem("pos:txs", JSON.stringify(d));
    } catch {
      throw Error("Kayıt kaydedilemedi. Depolama alanını kontrol edin; mevcut kayıtlar korundu.");
    }
    setTxs(d);
  };
  const saveCfg = c => {
    try {
      POSGuard.validatePackage({
        cfg: c
      }, {
        txs,
        nakit
      }, DEF_CFG);
    } catch (e) {
      alert(e.message);
      return false;
    }
    try {
      if (localStorage.getItem("pos:restoreJournal")) throw Error("Geri yükleme bekliyor.");
      localStorage.setItem("pos:cfg", JSON.stringify(c));
    } catch {
      alert("Ayarlar kaydedilemedi. Depolama alanını kontrol edin.");
      return false;
    }
    setCfg(c);
    return true;
  };
  const savePara = d => {
    LS.set("pos:para", d);
    setPara(d);
  };
  const saveKD = d => {
    LS.set("pos:kasadurum", d);
    setKD(d);
  };
  const saveParaLog = d => {
    LS.set("pos:paralog", d);
    setParaLog(d);
  };
  const saveKasaLog = d => {
    LS.set("pos:kasalog", d);
    setKasaLog(d);
  };
  const saveSayimlar = d => {
    LS.set("pos:sayimlar", d);
    setSayimlar(d);
  };
  const saveOdemeler = d => {
    LS.set("pos:odemeler", d);
    setOdemeler(d);
  };
  const savePlan = d => {
    LS.set("pos:plan", d);
    setPlan(d);
  };
  const DA = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
  const MO = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
  const shiftDate = n => {
    const d = new Date(tDate + "T00:00:00");
    d.setDate(d.getDate() + n);
    setTDate(toS(d));
  };
  const dateLabel = () => {
    if (tDate === today) return "Bugün";
    const d = new Date(tDate + "T00:00:00");
    return `${DA[d.getDay()]}, ${d.getDate()} ${MO[d.getMonth()]} ${d.getFullYear()}`;
  };
  const filtered = useMemo(() => txs.filter(t => t.yatacakTarih === tDate), [txs, tDate]);
  const takipData = useMemo(() => {
    const byB = {};
    cfg.bankalar.forEach((b, bi) => {
      byB[b.id] = {
        banka: b,
        color: BCOLS[bi % BCOLS.length],
        accent: BACCS[bi % BACCS.length],
        kasalar: {},
        total: 0,
        kredi: 0,
        debit: 0
      };
    });
    filtered.forEach(t => {
      if (!byB[t.bankaId]) return;
      const ki = cfg.kasalar.find(k => k.id === t.kasaId);
      if (!ki) return;
      const bs = byB[t.bankaId];
      if (!bs.kasalar[t.kasaId]) bs.kasalar[t.kasaId] = {
        kasa: ki,
        debit: 0,
        kredi: 0
      };
      if (t.tur === "DEBİT KART") {
        bs.kasalar[t.kasaId].debit += t.tutar;
        bs.debit += t.tutar;
      } else {
        bs.kasalar[t.kasaId].kredi += t.tutar;
        bs.kredi += t.tutar;
      }
      bs.total += t.tutar;
    });
    const kasaSirala = (a, b) => {
      const s = ad => {
        const m = ad.match(/^KASA\s+(\d+)$/i);
        if (m) return parseInt(m[1]);
        if (ad.toUpperCase() === "EMNİYET") return 9000;
        return 9999;
      };
      return s(a.kasa.ad) - s(b.kasa.ad);
    };
    const result = Object.values(byB).filter(b => b.total > 0);
    result.forEach(b => {
      b.kasalarSorted = Object.values(b.kasalar).sort(kasaSirala);
    });
    return result;
  }, [filtered, cfg]);
  const gTotal = takipData.reduce((s, b) => s + b.total, 0);
  const gKredi = takipData.reduce((s, b) => s + b.kredi, 0);
  const gDebit = takipData.reduce((s, b) => s + b.debit, 0);
  const haftalik = useMemo(() => ({
    simdi: takipGunOzeti(txs, cfg, tDate),
    once: takipGunOzeti(txs, cfg, POSGuard.day(tDate) ? addD(tDate, -7) : ""),
    tarih: POSGuard.day(tDate) ? addD(tDate, -7) : ""
  }), [txs, cfg, tDate]);
  const aralikHesap = useMemo(() => {
    if (!sorgu) return null;
    const bas = sorgu.bas <= sorgu.bit ? sorgu.bas : sorgu.bit;
    const bit = sorgu.bas <= sorgu.bit ? sorgu.bit : sorgu.bas;
    let toplam = 0,
      kredi = 0,
      debit = 0,
      adet = 0;
    const gunler = {};
    txs.forEach(t => {
      if (t.yatacakTarih >= bas && t.yatacakTarih <= bit) {
        toplam += t.tutar;
        adet++;
        if (t.tur === "DEBİT KART") debit += t.tutar;else kredi += t.tutar;
        gunler[t.yatacakTarih] = (gunler[t.yatacakTarih] || 0) + t.tutar;
      }
    });
    return {
      toplam,
      kredi,
      debit,
      adet,
      gunSayisi: Object.keys(gunler).length,
      bas,
      bit
    };
  }, [txs, sorgu]);
  const sorgula = () => {
    if (rangeBas && rangeBit) setSorgu({
      bas: rangeBas,
      bit: rangeBit
    });
  };
  const I = {
    background: "#0f1117",
    border: "1px solid #2d3748",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "9px 12px",
    fontSize: 13,
    fontFamily: "'IBM Plex Mono',monospace",
    width: "100%"
  };
  if (loading) return React.createElement("div", {
    style: {
      height: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#94a3b8",
      fontSize: 13
    }
  }, React.createElement("span", {
    className: "pulse"
  }, "\u27F3 Y\xFCkleniyor..."));
  const TABS = [["ozet", "ÖZET", "chart"], ["takip", "TAKİP", "chart"], ["giris", "GİRİŞ", "edit"], ["para", "PARA", "money"], ["plan", "NAKİT PLAN", "calendar"], ["sayim", "KASA SAYIMI", "money"], ["ayarlar", "AYARLAR", "settings"]];
  return React.createElement("div", {
    style: {
      minHeight: "100vh",
      background: "#0f1117"
    }
  }, React.createElement("div", {
    style: {
      background: "#0d1020",
      borderBottom: "1px solid #1e293b",
      padding: "14px 20px",
      position: "sticky",
      top: 0,
      zIndex: 200
    }
  }, React.createElement("div", {
    style: {
      maxWidth: 1140,
      margin: "0 auto",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16,
      flexWrap: "wrap"
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      letterSpacing: 3,
      textTransform: "uppercase",
      marginBottom: 2
    }
  }, React.createElement("img", {
    src: "icon.png",
    alt: "",
    style: {
      width: 22,
      height: 22,
      verticalAlign: "middle",
      borderRadius: 5,
      marginRight: 7
    }
  }), " POS - KASA Y\xD6NET\u0130M"), React.createElement("div", {
    style: {
      fontSize: 17,
      fontWeight: 700,
      color: "#f1f5f9",
      letterSpacing: -.5
    }
  }, "POS - Kasa Y\xF6netim")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 5,
      flexWrap: "wrap"
    }
  }, TABS.map(([t, l, kind]) => React.createElement("button", {
    key: t,
    "aria-current": tab === t ? "page" : undefined,
    onClick: () => setTab(t),
    style: {
      background: tab === t ? "#1e293b" : "transparent",
      border: `1px solid ${tab === t ? "#3b82f6" : "#1e293b"}`,
      borderRadius: 8,
      color: tab === t ? "#f1f5f9" : "#a2b1c6",
      cursor: "pointer",
      padding: "7px 13px",
      fontSize: 11,
      letterSpacing: .5,
      fontFamily: "inherit",
      transition: "all .15s"
    }
  }, React.createElement(UiIcon, {
    kind: kind
  }), " ", l))))), React.createElement("div", {
    style: {
      maxWidth: 1140,
      margin: "0 auto",
      padding: "20px 16px"
    }
  }, tab === "ozet" && React.createElement(IsletmeOzeti, {
    cfg: cfg,
    nakit: nakit,
    txs: txs,
    odemeler: odemeler,
    saveOdemeler: saveOdemeler,
    onTakip: day => {
      setTDate(day);
      setTab("takip");
    }
  }), tab === "takip" && React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #1e293b",
      borderRadius: 12,
      padding: "12px 16px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 10,
      marginBottom: 16
    }
  }, React.createElement("button", {
    onClick: () => shiftDate(-1),
    style: {
      ...I,
      width: 40,
      padding: "7px",
      textAlign: "center",
      cursor: "pointer",
      border: "1px solid #2d3748"
    }
  }, "\u25C0"), React.createElement("div", {
    style: {
      flex: 1,
      textAlign: "center"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: "#f1f5f9",
      marginBottom: 2
    }
  }, dateLabel()), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, fDSh(tDate))), React.createElement("button", {
    onClick: () => shiftDate(1),
    style: {
      ...I,
      width: 40,
      padding: "7px",
      textAlign: "center",
      cursor: "pointer",
      border: "1px solid #2d3748"
    }
  }, "\u25B6"), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 5
    }
  }, React.createElement("input", {
    "aria-label": "Takip tarihi",
    type: "date",
    value: tDate,
    onChange: e => setTDate(e.target.value),
    style: {
      ...I,
      width: 160,
      padding: "7px 10px",
      fontSize: 12
    }
  }), tDate !== today && React.createElement("button", {
    onClick: () => setTDate(today),
    style: {
      background: "#1e3a5f",
      border: "1px solid #3b82f6",
      borderRadius: 7,
      color: "#60a5fa",
      cursor: "pointer",
      padding: "4px",
      fontSize: 11,
      fontFamily: "inherit"
    }
  }, "BUG\xDCN"))), React.createElement("div", {
    "data-takip-total-card": true,
    className: "fi",
    style: {
      background: "linear-gradient(135deg,#141825,#1a2035)",
      border: "1px solid #2d3a5c",
      borderRadius: 12,
      padding: "16px 20px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "wrap",
      gap: 12,
      marginBottom: 14
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase",
      marginBottom: 5
    }
  }, "BUG\xDCN TOPLAM YATACAK TUTAR"), React.createElement("div", {
    style: {
      fontSize: 28,
      fontWeight: 700,
      color: "#f1f5f9",
      letterSpacing: -1
    }
  }, "\u20BA ", fmt(gTotal)), React.createElement(HaftalikDegisim, {
    simdi: haftalik.simdi.total,
    once: haftalik.once.total,
    etiket: "Toplam yat\u0131\u015F haftal\u0131k de\u011Fi\u015Fim",
    tarih: haftalik.tarih
  }), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginTop: 3
    }
  }, takipData.length, " banka \xB7 ", filtered.length, " i\u015Flem")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 18
    }
  }, React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      textTransform: "uppercase",
      marginBottom: 3
    }
  }, "KRED\u0130 KARTI"), React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: "#93c5fd"
    }
  }, "\u20BA ", fmt(gKredi)), React.createElement(HaftalikDegisim, {
    simdi: haftalik.simdi.kredi,
    once: haftalik.once.kredi,
    etiket: "Kredi haftal\u0131k de\u011Fi\u015Fim",
    tarih: haftalik.tarih
  })), React.createElement("div", {
    style: {
      width: 1,
      background: "#1e293b"
    }
  }), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      textTransform: "uppercase",
      marginBottom: 3
    }
  }, "DEB\u0130T KART"), React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: "#86efac"
    }
  }, "\u20BA ", fmt(gDebit)), React.createElement(HaftalikDegisim, {
    simdi: haftalik.simdi.debit,
    once: haftalik.once.debit,
    etiket: "Debit haftal\u0131k de\u011Fi\u015Fim",
    tarih: haftalik.tarih
  })))), takipData.length === 0 && React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "50px",
      color: "#94a3b8",
      background: "#141825",
      borderRadius: 12,
      border: "1px dashed #1e293b",
      fontSize: 13
    }
  }, "Bu tarihte yat\u0131\u015F kayd\u0131 yok"), takipData.map((bD, bi) => {
    const kList = bD.kasalarSorted || Object.values(bD.kasalar);
    return React.createElement("div", {
      key: bD.banka.id,
      className: "fi",
      style: {
        marginBottom: 14,
        animationDelay: `${bi * .06}s`
      }
    }, React.createElement("div", {
      "data-bank-header": bD.banka.id,
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "10px 14px",
        background: `${bD.color}11`,
        border: `1px solid ${bD.color}33`,
        borderRadius: "10px 10px 0 0"
      }
    }, React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, React.createElement("div", {
      style: {
        width: 10,
        height: 10,
        borderRadius: 2,
        background: bD.color,
        boxShadow: `0 0 6px ${bD.color}`
      }
    }), React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: bD.accent,
        letterSpacing: 1
      }
    }, bD.banka.ad))), React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(210px,1fr))",
        gap: 8,
        background: `${bD.color}08`,
        border: `1px solid ${bD.color}22`,
        borderTop: "none",
        borderRadius: "0 0 10px 10px",
        padding: 8
      }
    }, kList.map(({
      kasa,
      debit,
      kredi
    }) => {
      const tot = debit + kredi;
      return React.createElement("div", {
        key: kasa.id,
        style: {
          background: "#141825",
          border: `1px solid ${bD.color}33`,
          borderRadius: 10,
          padding: "13px 15px"
        }
      }, React.createElement("div", {
        style: {
          display: "flex",
          alignItems: "center",
          gap: 6,
          marginBottom: 8
        }
      }, React.createElement("div", {
        style: {
          width: 7,
          height: 7,
          borderRadius: 1,
          background: bD.color
        }
      }), React.createElement("span", {
        style: {
          fontSize: 12,
          fontWeight: 700,
          color: bD.accent,
          letterSpacing: .5
        }
      }, kasa.ad), React.createElement("span", {
        style: {
          fontSize: 11,
          color: "#94a3b8",
          marginLeft: "auto"
        }
      }, kasa.kod)), React.createElement("div", {
        style: {
          fontSize: 18,
          fontWeight: 700,
          color: "#f1f5f9",
          marginBottom: 8
        }
      }, "\u20BA ", fmt(tot), React.createElement(HaftalikDegisim, {
        simdi: haftalik.simdi.kasalar[kasa.id]?.total,
        once: haftalik.once.kasalar[kasa.id]?.total,
        etiket: kasa.ad + " toplam haftalık değişim",
        tarih: haftalik.tarih
      })), React.createElement("div", {
        style: {
          height: 2,
          background: "#1e293b",
          borderRadius: 2,
          marginBottom: 8,
          overflow: "hidden"
        }
      }, React.createElement("div", {
        style: {
          height: "100%",
          borderRadius: 2,
          width: `${bD.total > 0 ? tot / bD.total * 100 : 0}%`,
          background: `linear-gradient(90deg,${bD.color},${bD.accent})`,
          transition: "width .5s"
        }
      })), React.createElement("div", {
        style: {
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 5
        }
      }, kredi > 0 && React.createElement("div", {
        style: {
          background: "#00000022",
          borderRadius: 6,
          padding: "6px 9px",
          borderLeft: "2px solid #3b82f6"
        }
      }, React.createElement("div", {
        style: {
          fontSize: 9,
          color: "#a2b1c6",
          letterSpacing: 1,
          marginBottom: 2
        }
      }, "KRED\u0130"), React.createElement("div", {
        style: {
          fontSize: 11,
          fontWeight: 600,
          color: "#93c5fd"
        }
      }, "\u20BA", fmt(kredi)), React.createElement(HaftalikDegisim, {
        simdi: haftalik.simdi.kasalar[kasa.id]?.kredi,
        once: haftalik.once.kasalar[kasa.id]?.kredi,
        etiket: kasa.ad + " kredi haftalık değişim",
        tarih: haftalik.tarih,
        compact: true
      })), debit > 0 && React.createElement("div", {
        style: {
          background: "#00000022",
          borderRadius: 6,
          padding: "6px 9px",
          borderLeft: "2px solid #22c55e"
        }
      }, React.createElement("div", {
        style: {
          fontSize: 9,
          color: "#a2b1c6",
          letterSpacing: 1,
          marginBottom: 2
        }
      }, "DEB\u0130T"), React.createElement("div", {
        style: {
          fontSize: 11,
          fontWeight: 600,
          color: "#86efac"
        }
      }, "\u20BA", fmt(debit)), React.createElement(HaftalikDegisim, {
        simdi: haftalik.simdi.kasalar[kasa.id]?.debit,
        once: haftalik.once.kasalar[kasa.id]?.debit,
        etiket: kasa.ad + " debit haftalık değişim",
        tarih: haftalik.tarih,
        compact: true
      }))));
    })));
  }), React.createElement("div", {
    style: {
      marginTop: 20,
      background: "#141825",
      border: "1px solid #8b5cf633",
      borderRadius: 12,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "12px 16px",
      borderBottom: "1px solid #1e293b",
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("div", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 1,
      background: "#8b5cf6"
    }
  }), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase"
    }
  }, "TAR\u0130H ARALI\u011EI TOPLAMI")), React.createElement("div", {
    style: {
      padding: "16px 18px"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: 12,
      flexWrap: "wrap",
      marginBottom: 16
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "BA\u015ELANGI\xC7 TAR\u0130H\u0130"), React.createElement("input", {
    type: "date",
    value: rangeBas,
    onChange: e => setRangeBas(e.target.value),
    style: {
      ...I,
      width: 160,
      fontSize: 13
    }
  })), React.createElement("div", {
    style: {
      color: "#94a3b8",
      fontSize: 18,
      paddingBottom: 6
    }
  }, "\u2192"), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "B\u0130T\u0130\u015E TAR\u0130H\u0130"), React.createElement("input", {
    type: "date",
    value: rangeBit,
    onChange: e => setRangeBit(e.target.value),
    style: {
      ...I,
      width: 160,
      fontSize: 13
    }
  })), React.createElement("button", {
    onClick: sorgula,
    disabled: !rangeBas || !rangeBit,
    style: {
      background: rangeBas && rangeBit ? "#5b21b6" : "#1e293b",
      border: `1px solid ${rangeBas && rangeBit ? "#8b5cf6" : "#2d3748"}`,
      borderRadius: 8,
      color: rangeBas && rangeBit ? "#c4b5fd" : "#94a3b8",
      cursor: rangeBas && rangeBit ? "pointer" : "not-allowed",
      padding: "9px 22px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600,
      letterSpacing: 1
    }
  }, "\uD83D\uDD0D SORGULA"), sorgu && React.createElement("button", {
    onClick: () => {
      setSorgu(null);
      setRangeBas("");
      setRangeBit("");
    },
    style: {
      background: "#0f1117",
      border: "1px solid #2d3748",
      borderRadius: 8,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "9px 14px",
      fontSize: 11,
      fontFamily: "inherit"
    }
  }, "Temizle")), !aralikHesap ? React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "24px",
      color: "#94a3b8",
      fontSize: 12,
      background: "#0f1117",
      borderRadius: 10,
      border: "1px dashed #2d3748"
    }
  }, "\u0130ki tarih se\xE7ip ", React.createElement("span", {
    style: {
      color: "#8b5cf6"
    }
  }, "Sorgula"), "'ya bas\u0131n") : React.createElement("div", {
    style: {
      background: "linear-gradient(135deg,#1a1530,#221a3d)",
      border: "1px solid #8b5cf644",
      borderRadius: 10,
      padding: "16px 20px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "wrap",
      gap: 14
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase",
      marginBottom: 5
    }
  }, fDSh(aralikHesap.bas), " \u2014 ", fDSh(aralikHesap.bit), " ARASI TOPLAM"), React.createElement("div", {
    style: {
      fontSize: 28,
      fontWeight: 700,
      color: "#c4b5fd",
      letterSpacing: -1
    }
  }, "\u20BA ", fmt(aralikHesap.toplam)), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginTop: 3
    }
  }, aralikHesap.gunSayisi, " g\xFCn \xB7 ", aralikHesap.adet, " i\u015Flem")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 18
    }
  }, React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      textTransform: "uppercase",
      marginBottom: 3
    }
  }, "KRED\u0130 KARTI"), React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: "#93c5fd"
    }
  }, "\u20BA ", fmt(aralikHesap.kredi))), React.createElement("div", {
    style: {
      width: 1,
      background: "#2d2447"
    }
  }), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      textTransform: "uppercase",
      marginBottom: 3
    }
  }, "DEB\u0130T KART"), React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: "#86efac"
    }
  }, "\u20BA ", fmt(aralikHesap.debit)))))))), tab === "giris" && React.createElement(GirisTab, {
    cfg: cfg,
    nakit: nakit,
    saveNakit: saveNakit,
    txs: txs,
    saveTxs: saveTxs
  }), tab === "para" && React.createElement(ParaTab, {
    cfg: cfg,
    saveCfg: saveCfg,
    para: para,
    savePara: savePara,
    kasaDurum: kasaDurum,
    saveKD: saveKD,
    paraLog: paraLog,
    saveParaLog: saveParaLog,
    kasaLog: kasaLog,
    saveKasaLog: saveKasaLog
  }), tab === "plan" && plan && React.createElement(NakitPlanTab, {
    txs: txs,
    odemeler: odemeler,
    plan: plan,
    savePlan: savePlan
  }), tab === "sayim" && React.createElement(KasaSayimiTab, {
    sayimlar: sayimlar,
    saveSayimlar: saveSayimlar
  }), tab === "ayarlar" && React.createElement(AyarlarTab, {
    cfg: cfg,
    saveCfg: saveCfg,
    txs: txs,
    paraLog: paraLog,
    kasaLog: kasaLog,
    sayimlar: sayimlar,
    onReload: () => window.location.reload()
  }), React.createElement("div", {
    style: {
      marginTop: 24,
      textAlign: "center",
      color: "#1e293b",
      fontSize: 11,
      letterSpacing: 1
    }
  }, "POS-Kasa Y\xF6netim \xB7 ", txs.length, " i\u015Flem \xB7 ", sayimlar.length, " say\u0131m \xB7 ", odemeler.length, " \xF6deme \xB7 ", cfg.bankalar.length, " banka \xB7 ", cfg.kasalar.length, " kasa")), hatirlatma && React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "#000000aa",
      zIndex: 900,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 20
    }
  }, React.createElement("div", {
    className: "fi",
    style: {
      background: "#141825",
      border: "1px solid #f97316",
      borderRadius: 16,
      padding: "26px 28px",
      width: 520,
      maxWidth: "94vw",
      maxHeight: "85vh",
      overflowY: "auto",
      boxShadow: "0 20px 60px #000000cc"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      marginBottom: 6
    }
  }, React.createElement("span", {
    style: {
      fontSize: 26
    }
  }, "\uD83D\uDD14"), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 700,
      color: "#fb923c"
    }
  }, "\xD6deme Hat\u0131rlatmas\u0131"), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, hatirlatma.length, " \xF6demenin vadesi geldi veya ge\xE7ti"))), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7,
      margin: "16px 0"
    }
  }, hatirlatma.map(o => {
    const bugun = toS(new Date());
    const gecikti = o.sonOdeme < bugun;
    const gun = Math.round((new Date(bugun + "T00:00:00") - new Date(o.sonOdeme + "T00:00:00")) / 86400000);
    return React.createElement("div", {
      key: o.id,
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        background: gecikti ? "#2d1414" : "#2a2410",
        border: `1px solid ${gecikti ? "#ef444455" : "#eab30855"}`,
        borderRadius: 9,
        padding: "12px 15px"
      }
    }, React.createElement("div", null, React.createElement("div", {
      style: {
        fontSize: 14,
        fontWeight: 600,
        color: "#f1f5f9"
      }
    }, o.ad), React.createElement("div", {
      style: {
        fontSize: 11,
        color: gecikti ? "#f87171" : "#fbbf24",
        marginTop: 2
      }
    }, gecikti ? `${gun} gün gecikti · son gün ${fDSh(o.sonOdeme)}` : `BUGÜN son ödeme günü`)), React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 700,
        color: gecikti ? "#f87171" : "#fbbf24"
      }
    }, "\u20BA ", fmt(o.tutar)));
  })), React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 10,
      flexWrap: "wrap"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "#a2b1c6"
    }
  }, "Toplam: ", React.createElement("b", {
    style: {
      color: "#fb923c"
    }
  }, "\u20BA", fmt(hatirlatma.reduce((s, o) => s + o.tutar, 0)))), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, React.createElement("button", {
    className: "btn-hover",
    onClick: () => {
      setTab("ozet");
      setHatirlatma(null);
      setOdemeOdak(true);
    },
    style: {
      background: "#7c2d12",
      border: "1px solid #f97316",
      borderRadius: 8,
      color: "#fb923c",
      cursor: "pointer",
      padding: "10px 18px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\xD6demelere Git"), React.createElement("button", {
    onClick: () => setHatirlatma(null),
    style: {
      background: "#1e293b",
      border: "1px solid #2d3748",
      borderRadius: 8,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "10px 20px",
      fontSize: 12,
      fontFamily: "inherit"
    }
  }, "Tamam"))))));
}
const POS_KAYDET_STILI = {
  background: "#166534",
  border: "1px solid #22c55e",
  borderRadius: 9,
  color: "#4ade80",
  cursor: "pointer",
  padding: "10px 26px",
  fontSize: 13,
  fontFamily: "inherit",
  fontWeight: 600,
  letterSpacing: 1
};
function posAmount(value) {
  return POSGuard.money(value);
}
function posTutarGoster(value) {
  try {
    return fmt(POSGuard.money(value, true));
  } catch {
    return value;
  }
}
function posMutabakatKaydet({
  mode,
  gid,
  txs,
  kasa,
  tarih,
  toplam,
  vade,
  debitler,
  newId
}) {
  const saved = txs.find(t => t.mutabakatId === gid && t.posToplam != null);
  if (mode !== "total" && mode !== "debit") throw Error("Kaydetme türü geçersiz.");
  if (mode === "debit" && !saved) throw Error("Önce kasa, işlem günü ve toplam POS tutarını girip Toplamı kaydet düğmesine basın.");
  const isTotal = mode === "total",
    id = saved?.mutabakatId || newId;
  if (!id) throw Error("Kayıt kimliği eksik.");
  if (isTotal && !String(toplam ?? "").trim()) throw Error("Toplam POS tutarını girin.");
  const existingDebits = saved ? txs.filter(t => t.mutabakatId === gid && t.tur === "DEBİT KART").map(t => ({
    id: t.id,
    tarih: t.yatacakTarih,
    tutar: String(t.tutar)
  })) : [];
  const list = posMutabakatOlustur({
    id,
    kasa: saved ? {
      ...kasa,
      id: saved.kasaId,
      bankaId: saved.bankaId
    } : kasa,
    tarih: isTotal ? tarih : saved.islemTarihi,
    toplam: isTotal ? toplam : String(saved.posToplam),
    vade: isTotal ? vade : saved.yatacakTarih,
    debitler: isTotal ? existingDebits : debitler
  });
  return {
    id,
    list,
    txs: [...list, ...txs.filter(t => t.mutabakatId !== id)]
  };
}
function posMutabakatOlustur({
  id,
  kasa,
  tarih,
  toplam,
  vade,
  debitler
}) {
  const valid = d => typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d) && !isNaN(Date.parse(d)) && new Date(d).toISOString().slice(0, 10) === d;
  const kurus = n => Math.round(n * 100);
  if (!kasa || !valid(tarih) || tarih > toS(new Date()) || !valid(vade) || vade < tarih) throw Error("İşlem ve kredi vade tarihlerini kontrol edin.");
  const total = posAmount(toplam);
  if (!Number.isFinite(total) || total <= 0 || total > 1e10) throw Error("Geçerli bir toplam POS tutarı girin.");
  const rows = debitler.filter(r => String(r.tutar).trim()).map(r => {
    const n = posAmount(r.tutar);
    if (!valid(r.tarih) || r.tarih < tarih || r.tarih > toS(new Date()) || !Number.isFinite(n) || n <= 0 || n > 1e10) throw Error("Debit tarihi işlem tarihinden önce veya bugünden sonra olamaz; tutar pozitif olmalı.");
    return {
      ...r,
      tutar: kurus(n) / 100
    };
  });
  const paid = rows.reduce((n, r) => n + kurus(r.tutar), 0),
    remaining = kurus(total) - paid;
  if (remaining < 0) throw Error("Yatan debit toplamı POS toplamını aşamaz.");
  const base = {
    kasaId: kasa.id,
    bankaId: kasa.bankaId,
    islemTarihi: tarih,
    mutabakatId: id
  };
  return [{
    ...base,
    id: id + "-kredi",
    tur: "KREDİ KARTI",
    tutar: remaining / 100,
    yatacakTarih: vade,
    posToplam: kurus(total) / 100
  }, ...rows.map(r => ({
    ...base,
    id: r.id,
    tur: "DEBİT KART",
    tutar: r.tutar,
    yatacakTarih: r.tarih,
    tahsilEdildi: true
  }))];
}
function posDebitAdaylari({
  txs,
  kasaId,
  yatisTarihi,
  vadeGun
}) {
  if (!POSGuard.day(yatisTarihi) || !Number.isInteger(vadeGun) || vadeGun < 0 || vadeGun > 365) return [];
  return txs.filter(t => {
    if (t.kasaId !== kasaId || !t.mutabakatId || t.posToplam == null || !POSGuard.day(t.islemTarihi)) return false;
    const day = new Date(t.islemTarihi + "T12:00:00Z");
    day.setUTCDate(day.getUTCDate() + vadeGun);
    return day.toISOString().slice(0, 10) === yatisTarihi;
  });
}
function posYeniDebitEkle({
  txs,
  kasaId,
  yatisTarihi,
  tutar,
  vadeGun,
  kayitId,
  id
}) {
  if (!kasaId) throw Error("Debit için kasa seçin.");
  if (!POSGuard.day(yatisTarihi) || yatisTarihi > toS(new Date())) throw Error("Geçerli bir yatış tarihi seçin; gelecekte olamaz.");
  const amount = posAmount(tutar),
    adaylar = posDebitAdaylari({
      txs,
      kasaId,
      yatisTarihi,
      vadeGun
    });
  const group = kayitId ? txs.find(t => t.kasaId === kasaId && t.mutabakatId === kayitId && t.posToplam != null) : adaylar.length === 1 ? adaylar[0] : null;
  if (!group) throw Error(adaylar.length > 1 ? "Birden fazla POS kaydı eşleşti. İlgili satış kaydını seçin." : "Debit vadesine göre POS toplamı bulunamadı. İlgili satış kaydını seçin veya önce toplamı kaydedin.");
  if (!POSGuard.day(group.islemTarihi) || group.islemTarihi > yatisTarihi) throw Error("Debit yatış tarihi satış gününden önce olamaz.");
  const kalan = Math.round(group.tutar * 100) - Math.round(amount * 100);
  if (kalan < 0) throw Error("Yatan debit tutarı kalan POS tutarını aşamaz.");
  if (!id || txs.some(t => t.id === id)) throw Error("Debit kayıt kimliği geçersiz veya tekrarlı.");
  const debit = {
    id,
    kasaId: group.kasaId,
    bankaId: group.bankaId,
    islemTarihi: group.islemTarihi,
    mutabakatId: group.mutabakatId,
    tur: "DEBİT KART",
    tutar: amount,
    yatacakTarih: yatisTarihi,
    tahsilEdildi: true
  };
  return {
    group: {
      ...group,
      tutar: kalan / 100
    },
    debit,
    txs: [debit, ...txs.map(t => t.id === group.id ? {
      ...t,
      tutar: kalan / 100
    } : t)]
  };
}
function posYeniToplamEkle({
  txs,
  kasa,
  tarih,
  toplam,
  vade,
  id
}) {
  if (!id || txs.some(t => t.mutabakatId === id || t.id === id + "-kredi")) throw Error("Yeni toplam kimliği geçersiz veya tekrarlı.");
  if (!kasa || kasa.aktif === false || !kasa.toplamModu) throw Error("Toplam POS takibi açık, aktif bir kasa seçin.");
  return posMutabakatKaydet({
    mode: "total",
    gid: "",
    txs,
    kasa,
    tarih,
    toplam,
    vade,
    debitler: [],
    newId: id
  });
}
function posGecmistenSil(txs, id) {
  const row = txs.find(t => t.id === id);
  if (!row) throw Error("Silinecek işlem bulunamadı.");
  if (!row.mutabakatId) return txs.filter(t => t.id !== id);
  const group = txs.filter(t => t.mutabakatId === row.mutabakatId),
    credit = group.filter(t => t.posToplam != null);
  if (credit.length !== 1) throw Error("Bağlı POS toplamı doğrulanamadı; kayıtlar değiştirilmedi.");
  if (row.id === credit[0].id) return txs.filter(t => t.mutabakatId !== row.mutabakatId);
  if (row.tur !== "DEBİT KART") throw Error("Silinecek bağlı işlem türü geçersiz.");
  const restored = (Math.round(credit[0].tutar * 100) + Math.round(row.tutar * 100)) / 100;
  return txs.filter(t => t.id !== id).map(t => t.id === credit[0].id ? {
    ...t,
    tutar: restored
  } : t);
}
function posVadeTarihi(tarih, gun) {
  if (!POSGuard.day(tarih) || !Number.isInteger(gun) || gun < 0 || gun > 365) return "";
  const d = new Date(tarih + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + gun);
  return d.toISOString().slice(0, 10);
}
function takipGunOzeti(txs, cfg, tarih) {
  const empty = () => ({
    total: {
      tutar: 0,
      adet: 0
    },
    kredi: {
      tutar: 0,
      adet: 0
    },
    debit: {
      tutar: 0,
      adet: 0
    }
  });
  const out = {
    ...empty(),
    bankalar: Object.create(null),
    kasalar: Object.create(null)
  };
  const banks = new Set(cfg.bankalar.map(b => b.id)),
    kasalar = new Set(cfg.kasalar.map(k => k.id));
  for (const t of txs) {
    if (t.yatacakTarih !== tarih || !banks.has(t.bankaId) || !kasalar.has(t.kasaId)) continue;
    const tur = t.tur === "DEBİT KART" ? "debit" : "kredi";
    for (const target of [out, out.bankalar[t.bankaId] || (out.bankalar[t.bankaId] = empty()), out.kasalar[t.kasaId] || (out.kasalar[t.kasaId] = empty())]) for (const key of ["total", tur]) {
      target[key].tutar += Math.round(t.tutar * 100);
      target[key].adet++;
    }
  }
  for (const target of [out, ...Object.values(out.bankalar), ...Object.values(out.kasalar)]) for (const key of ["total", "kredi", "debit"]) target[key].tutar /= 100;
  return out;
}
function haftalikFark(simdi, once) {
  if (!once?.adet) return {
    durum: "eksik",
    oran: null,
    aciklama: "Önceki haftanın aynı gününde bu türde kayıt yok."
  };
  if (!simdi?.adet) return {
    durum: "eksik",
    oran: null,
    aciklama: "Seçili günde bu türde kayıt yok."
  };
  if (once.tutar === 0) return {
    durum: "sifir",
    oran: null,
    aciklama: "Önceki tutar 0 TL; yüzdesel değişim hesaplanamaz."
  };
  const oran = (Math.round(simdi.tutar * 100) - Math.round(once.tutar * 100)) / Math.round(once.tutar * 100) * 100;
  return {
    durum: oran > 0 ? "artis" : oran < 0 ? "azalis" : "ayni",
    oran,
    aciklama: "Önceki haftanın aynı günüyle karşılaştırma."
  };
}
function analizGunKaydir(day, n) {
  if (!POSGuard.day(day) || !Number.isInteger(n)) return "";
  const d = new Date(day + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
function analizDonemleri(today) {
  if (!POSGuard.day(today)) throw Error("Geçerli analiz tarihi gerekli.");
  const y = Number(today.slice(0, 4)),
    m = Number(today.slice(5, 7)),
    d = Number(today.slice(8, 10));
  const previousEnd = analizGunKaydir(today.slice(0, 7) + "-01", -1),
    previousStart = previousEnd.slice(0, 7) + "-01";
  const previousDay = Math.min(d, Number(previousEnd.slice(8, 10)));
  return {
    hafta: {
      bas: analizGunKaydir(today, -6),
      bit: today
    },
    gecenHafta: {
      bas: analizGunKaydir(today, -13),
      bit: analizGunKaydir(today, -7)
    },
    ay: {
      bas: today.slice(0, 7) + "-01",
      bit: today
    },
    gecenAy: {
      bas: previousStart,
      bit: previousEnd
    },
    ayKiyas: {
      bas: previousStart,
      bit: previousEnd.slice(0, 7) + "-" + String(previousDay).padStart(2, "0")
    },
    yil: {
      bas: y + "-01-01",
      bit: today
    }
  };
}
function posAralikOzeti(txs, cfg, bas, bit) {
  if (!POSGuard.day(bas) || !POSGuard.day(bit) || bas > bit) throw Error("Başlangıç ve bitiş tarihlerini kontrol edin.");
  const start = new Date(bas + "T12:00:00Z"),
    count = Math.round((new Date(bit + "T12:00:00Z") - start) / 86400000) + 1;
  const days = Array.from({
    length: 7
  }, (_, i) => {
    const weekday = (i + 1) % 7,
      offset = (weekday - start.getUTCDay() + 7) % 7;
    return {
      gun: i,
      adet: 0,
      toplam: 0,
      gunSayisi: Math.floor(count / 7) + (offset < count % 7 ? 1 : 0),
      ortalama: null
    };
  });
  const banks = new Set(cfg.bankalar.map(b => b.id)),
    kasalar = new Set(cfg.kasalar.map(k => k.id));
  let cents = 0,
    adet = 0;
  for (const t of txs) {
    if (!POSGuard.day(t.yatacakTarih) || t.yatacakTarih < bas || t.yatacakTarih > bit || !banks.has(t.bankaId) || !kasalar.has(t.kasaId)) continue;
    const index = (new Date(t.yatacakTarih + "T12:00:00Z").getUTCDay() + 6) % 7,
      n = Math.round(t.tutar * 100);
    days[index].toplam += n;
    days[index].adet++;
    cents += n;
    adet++;
  }
  for (const row of days) {
    row.ortalama = row.gunSayisi ? row.toplam / row.gunSayisi / 100 : null;
    row.toplam /= 100;
  }
  return {
    bas,
    bit,
    gunSayisi: count,
    adet,
    toplam: cents / 100,
    ortalama: cents / count / 100,
    gunler: days
  };
}
function posAnalizKiyas(txs, cfg, today) {
  const p = analizDonemleri(today);
  return {
    hafta: {
      simdi: posAralikOzeti(txs, cfg, p.hafta.bas, p.hafta.bit),
      once: posAralikOzeti(txs, cfg, p.gecenHafta.bas, p.gecenHafta.bit)
    },
    ay: {
      simdi: posAralikOzeti(txs, cfg, p.ay.bas, p.ay.bit),
      once: posAralikOzeti(txs, cfg, p.ayKiyas.bas, p.ayKiyas.bit)
    }
  };
}
function odemeAyOzeti(odemeler, today) {
  const groups = Object.create(null),
    current = today.slice(0, 7),
    prev = analizGunKaydir(current + "-01", -1).slice(0, 7),
    year = today.slice(0, 4);
  groups[current] = {
    ay: current,
    items: [],
    toplam: 0,
    bekleyen: 0
  };
  for (const o of odemeler) {
    if (!POSGuard.day(o.sonOdeme) || !Number.isFinite(o.tutar) || o.tutar <= 0) continue;
    const key = o.sonOdeme.slice(0, 7),
      g = groups[key] || (groups[key] = {
        ay: key,
        items: [],
        toplam: 0,
        bekleyen: 0
      });
    g.items.push(o);
    g.toplam += Math.round(o.tutar * 100);
    if (!o.odendi) g.bekleyen += Math.round(o.tutar * 100);
  }
  for (const g of Object.values(groups)) {
    g.toplam /= 100;
    g.bekleyen /= 100;
    g.items = [...g.items].sort((a, b) => Number(!!a.odendi) - Number(!!b.odendi) || a.sonOdeme.localeCompare(b.sonOdeme) || a.ad.localeCompare(b.ad, 'tr'));
  }
  const simdi = groups[current],
    once = groups[prev],
    kiyas = haftalikFark({
      tutar: simdi.toplam,
      adet: simdi.items.length
    }, once ? {
      tutar: once.toplam,
      adet: once.items.length
    } : null);
  const yearly = Object.values(groups).filter(g => g.ay.startsWith(year) && g.ay <= current && g.items.length).sort((a, b) => a.toplam - b.toplam || a.ay.localeCompare(b.ay));
  const aggregate = items => {
    const map = new Map();
    for (const o of items || []) {
      const key = o.ad.trim().replace(/\s+/g, ' ').toLocaleLowerCase('tr-TR');
      const old = map.get(key) || {
        ad: o.ad.trim(),
        tutar: 0
      };
      old.tutar += Math.round(o.tutar * 100);
      map.set(key, old);
    }
    return map;
  };
  const nowNames = aggregate(simdi.items),
    oldNames = aggregate(once?.items),
    changes = [];
  for (const [key, n] of nowNames) {
    const old = oldNames.get(key);
    if (old?.tutar > 0) changes.push({
      ad: n.ad,
      oran: (n.tutar - old.tutar) / old.tutar * 100
    });
  }
  const artis = changes.filter(x => x.oran > 0).sort((a, b) => b.oran - a.oran || a.ad.localeCompare(b.ad, 'tr'))[0],
    azalis = changes.filter(x => x.oran < 0).sort((a, b) => a.oran - b.oran || a.ad.localeCompare(b.ad, 'tr'))[0];
  return {
    current,
    groups: Object.values(groups).sort((a, b) => b.ay.localeCompare(a.ay)),
    kiyas,
    enAz: yearly.length > 1 ? yearly[0] : null,
    enCok: yearly.length > 1 ? yearly[yearly.length - 1] : null,
    artis,
    azalis
  };
}
function ozetVerileri(txs, cfg, odemeler, today) {
  const simdi = takipGunOzeti(txs, cfg, today),
    once = takipGunOzeti(txs, cfg, analizGunKaydir(today, -7));
  const gelecek = Array.from({
    length: 7
  }, (_, i) => {
    const tarih = analizGunKaydir(today, i + 1);
    return {
      tarih,
      ...takipGunOzeti(txs.filter(t => !t.tahsilEdildi), cfg, tarih)
    };
  });
  const payments = odemeler.filter(o => !o.odendi && POSGuard.day(o.sonOdeme) && o.sonOdeme >= gelecek[0].tarih && o.sonOdeme <= gelecek[6].tarih);
  return {
    simdi,
    once,
    gelecek,
    gelecekToplam: gelecek.reduce((n, g) => n + Math.round(g.total.tutar * 100), 0) / 100,
    odemeler: payments,
    odemeToplam: payments.reduce((n, o) => n + Math.round(o.tutar * 100), 0) / 100
  };
}
function ozetKasaPerformansi(txs, cfg, today, filter) {
  const p = analizDonemleri(today);
  let current, previous;
  if (filter === "hafta") {
    current = p.hafta;
    previous = p.gecenHafta;
  } else if (filter === "yil") {
    current = p.yil;
    const y = Number(today.slice(0, 4)) - 1,
      m = Number(today.slice(5, 7)),
      d = Number(today.slice(8, 10)),
      lastDay = new Date(Date.UTC(y, m, 0)).getUTCDate();
    previous = {
      bas: y + "-01-01",
      bit: y + "-" + String(m).padStart(2, "0") + "-" + String(Math.min(d, lastDay)).padStart(2, "0")
    };
  } else {
    current = p.ay;
    previous = p.ayKiyas;
  }
  const rows = cfg.kasalar.map(k => {
    const own = txs.filter(t => t.kasaId === k.id),
      now = posAralikOzeti(own, cfg, current.bas, current.bit),
      old = posAralikOzeti(own, cfg, previous.bas, previous.bit);
    return {
      kasa: k,
      simdi: now,
      once: old
    };
  }).filter(r => r.simdi.adet);
  const total = rows.reduce((n, r) => n + Math.round(r.simdi.toplam * 100), 0) / 100;
  return rows.sort((a, b) => b.simdi.toplam - a.simdi.toplam || a.kasa.ad.localeCompare(b.kasa.ad, 'tr')).map(r => ({
    ...r,
    pay: total ? r.simdi.toplam / total * 100 : 0
  }));
}
function nakitAnalizKayitlari(records, cfg) {
  return records.map(n => ({
    ...n,
    kasaId: n.kasaId,
    bankaId: cfg.kasalar.find(k => k.id === n.kasaId)?.bankaId,
    yatacakTarih: n.tarih
  }));
}
function nakitKaydet({
  records,
  cfg,
  id,
  kasaId,
  tarih,
  tutar,
  editing = false,
  allowZero = false
}) {
  const kasa = cfg.kasalar.find(k => k.id === kasaId),
    old = records.find(n => n.id === id);
  if (!kasa || kasa.aktif === false && !(editing && old?.kasaId === kasaId)) throw Error("Aktif bir kasa seçin.");
  if (!POSGuard.day(tarih) || tarih > toS(new Date())) throw Error("İşlem tarihi bugün veya geçmiş bir gün olmalı.");
  if (editing && !old || !editing && old) throw Error("Nakit kayıt kimliği eksik veya tekrarlı.");
  const row = {
    id,
    kasaId,
    tarih,
    tutar: POSGuard.money(tutar, allowZero)
  };
  const next = editing ? records.map(n => n.id === id ? row : n) : [row, ...records];
  POSGuard.cashList(next, cfg);
  return next;
}
function nakitVarsayilanKasalar(cfg) {
  const active = cfg.kasalar.filter(k => k.aktif !== false),
    used = new Set();
  return [1, 2].map(n => {
    const exact = active.find(k => !used.has(k.id) && k.ad.trim().replace(/\s+/g, " ").toLocaleUpperCase("tr-TR") === "KASA " + n),
      k = exact || active.find(k => !used.has(k.id));
    if (k) used.add(k.id);
    return k?.id || "";
  });
}
function nakitTopluKaydet({
  records,
  cfg,
  rows
}) {
  if (!Array.isArray(rows)) throw Error("Nakit giriş satırları geçersiz.");
  let next = records,
    count = 0;
  rows.forEach((row, i) => {
    try {
      if (!row || typeof row !== "object") throw Error("Nakit satırı geçersiz.");
      next = nakitKaydet({
        records: next,
        cfg,
        id: row.id,
        kasaId: row.kasaId,
        tarih: row.tarih,
        tutar: String(row.tutar ?? "").trim() || "0",
        allowZero: true
      });
      count++;
    } catch (e) {
      throw Error(`${i + 1}. satır: ${e.message}`);
    }
  });
  if (!count) throw Error("En az bir kasa satırı ekleyin.");
  return {
    records: next,
    count
  };
}
function satisDagilimi(txs, nakit, cfg, bas, bit) {
  const sales = txs.filter(t => !t.mutabakatId || t.posToplam != null).map(t => ({
    ...t,
    tutar: t.posToplam ?? t.tutar,
    yatacakTarih: t.islemTarihi
  }));
  const pos = posAralikOzeti(sales, cfg, bas, bit),
    cash = posAralikOzeti(nakitAnalizKayitlari(nakit, cfg), cfg, bas, bit);
  const posCents = Math.round(pos.toplam * 100),
    cashCents = Math.round(cash.toplam * 100),
    total = posCents + cashCents;
  return {
    pos: pos.toplam,
    nakit: cash.toplam,
    toplam: total / 100,
    posOran: total ? posCents / total * 100 : null,
    nakitOran: total ? 100 - posCents / total * 100 : null,
    adet: pos.adet + cash.adet
  };
}
function PosMutabakat({
  cfg,
  txs,
  saveTxs,
  initialId,
  onClose
}) {
  const [date, setDate] = useState(""),
    [total, setTotal] = useState(""),
    [due, setDue] = useState(""),
    [debits, setDebits] = useState([]),
    [error, setError] = useState(""),
    [msg, setMsg] = useState("");
  const group = txs.find(t => t.mutabakatId === initialId && t.posToplam != null);
  useEffect(() => {
    const t = txs.find(x => x.mutabakatId === initialId && x.posToplam != null);
    if (!t) return;
    setDate(t.islemTarihi);
    setTotal(posTutarGoster(t.posToplam));
    setDue(t.yatacakTarih);
    setDebits(txs.filter(x => x.mutabakatId === initialId && x.tur === "DEBİT KART").map(x => ({
      id: x.id,
      tarih: x.yatacakTarih,
      tutar: posTutarGoster(x.tutar)
    })));
  }, [initialId]);
  const I = {
    background: "#0f1117",
    border: "1px solid #334155",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "8px 10px",
    fontSize: 12,
    width: "100%",
    fontFamily: "inherit"
  };
  const close = () => {
    const same = (a, b) => {
      try {
        return POSGuard.money(a, true) === POSGuard.money(b, true);
      } catch {
        return a === b;
      }
    };
    const saved = txs.filter(t => t.mutabakatId === initialId && t.tur === "DEBİT KART");
    const dirty = group && (date !== group.islemTarihi || due !== group.yatacakTarih || !same(total, group.posToplam) || debits.length !== saved.length || debits.some(r => !saved.some(t => t.id === r.id && t.yatacakTarih === r.tarih && same(r.tutar, t.tutar))));
    if (!dirty || confirm("Kaydedilmemiş değişiklikler var. Kaydetmeden kapatılsın mı?")) onClose();
  };
  const save = mode => {
    try {
      if (!group) throw Error("POS kaydı bulunamadı.");
      const result = posMutabakatKaydet({
        mode,
        gid: initialId,
        txs,
        kasa: cfg.kasalar.find(k => k.id === group.kasaId),
        tarih: date,
        toplam: total,
        vade: due,
        debitler: debits
      });
      saveTxs(result.txs);
      setError("");
      setMsg("Değişiklikler kaydedildi.");
    } catch (e) {
      setMsg("");
      setError(e.message);
    }
  };
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "#00000099",
      zIndex: 500,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #36577c",
      borderRadius: 14,
      padding: 22,
      width: 650,
      maxWidth: "94vw",
      maxHeight: "90vh",
      overflowY: "auto"
    }
  }, React.createElement("h3", {
    style: {
      fontSize: 14,
      marginBottom: 12
    }
  }, "POS kayd\u0131n\u0131 d\xFCzenle \u2014 ", cfg.kasalar.find(k => k.id === group?.kasaId)?.ad), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,minmax(0,1fr))",
      gap: 10,
      fontSize: 12
    }
  }, React.createElement("label", null, "POS g\xFCn\xFC", React.createElement("input", {
    "aria-label": "D\xFCzenlenen POS g\xFCn\xFC",
    type: "date",
    style: I,
    value: date,
    onChange: e => {
      setDate(e.target.value);
      setDue(posVadeTarihi(e.target.value, cfg.vadeGunleri["KREDİ KARTI"] ?? 21));
      setMsg("");
      setError("");
    }
  })), React.createElement("label", null, "Toplam POS", React.createElement("input", {
    "aria-label": "D\xFCzenlenen POS toplam\u0131",
    inputMode: "decimal",
    style: I,
    value: total,
    onChange: e => setTotal(e.target.value),
    onBlur: () => setTotal(v => posTutarGoster(v))
  })), React.createElement("label", null, "Kredi vadesi", React.createElement("input", {
    "aria-label": "D\xFCzenlenen kredi vadesi",
    type: "date",
    style: I,
    value: due,
    onChange: e => setDue(e.target.value)
  }))), React.createElement("button", {
    className: "btn-hover",
    style: {
      ...POS_KAYDET_STILI,
      marginTop: 12
    },
    onClick: () => save("total")
  }, React.createElement(UiIcon, {
    kind: "save"
  }), " Toplam de\u011Fi\u015Fikli\u011Fini kaydet"), React.createElement("h4", {
    style: {
      fontSize: 12,
      margin: "18px 0 8px"
    }
  }, "Kay\u0131tl\u0131 debitler"), debits.map((r, i) => React.createElement("div", {
    key: r.id,
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 10,
      marginBottom: 10
    }
  }, React.createElement("label", {
    style: {
      fontSize: 11
    }
  }, "Yat\u0131\u015F tarihi", React.createElement("input", {
    "aria-label": "Düzenlenen debit tarihi " + (i + 1),
    type: "date",
    style: I,
    value: r.tarih,
    onChange: e => setDebits(v => v.map(x => x.id === r.id ? {
      ...x,
      tarih: e.target.value
    } : x))
  })), React.createElement("label", {
    style: {
      fontSize: 11
    }
  }, "Debit tutar\u0131", React.createElement("input", {
    "aria-label": "Düzenlenen debit tutarı " + (i + 1),
    style: I,
    value: r.tutar,
    onChange: e => setDebits(v => v.map(x => x.id === r.id ? {
      ...x,
      tutar: e.target.value
    } : x))
  })))), debits.length > 0 && React.createElement("button", {
    className: "btn-hover",
    style: POS_KAYDET_STILI,
    onClick: () => save("debit")
  }, React.createElement(UiIcon, {
    kind: "save"
  }), " Debit de\u011Fi\u015Fikliklerini kaydet"), error && React.createElement("p", {
    role: "alert",
    style: {
      color: "#f87171",
      marginTop: 12
    }
  }, error), msg && React.createElement("p", {
    role: "status",
    style: {
      color: "#86efac",
      marginTop: 12
    }
  }, msg), React.createElement("button", {
    style: {
      ...I,
      width: "auto",
      marginTop: 16,
      cursor: "pointer"
    },
    onClick: close
  }, "Kapat")));
}
function HaftalikDegisim({
  simdi,
  once,
  etiket,
  tarih,
  compact = false,
  titleOverride
}) {
  const fark = haftalikFark(simdi, once),
    color = fark.durum === "artis" ? "#4ade80" : fark.durum === "azalis" ? "#f87171" : "#94a3b8";
  return React.createElement("div", {
    "aria-label": etiket,
    "data-weekly-state": fark.durum,
    title: titleOverride || `${fDSh(tarih)}: ${once?.adet ? "₺ " + fmt(once.tutar) : "Kayıt yok"}. ${fark.aciklama}`,
    style: {
      fontSize: 11,
      fontWeight: 500,
      color,
      marginTop: 4,
      lineHeight: 1.4,
      whiteSpace: compact ? "nowrap" : undefined
    }
  }, fark.oran == null ? "–" : `${fark.oran > 0 ? "↑ " : fark.oran < 0 ? "↓ " : ""}%${Math.abs(fark.oran).toLocaleString("tr-TR", {
    maximumFractionDigits: 1
  })}`, !compact && React.createElement("span", {
    style: {
      fontSize: 11,
      marginLeft: 5,
      color: "#94a3b8"
    }
  }, "\xF6nceki hafta"));
}
function PosGelirAnalizi({
  txs,
  cfg,
  nakitModu = false
}) {
  const prefix = nakitModu ? "NAKİT" : "POS",
    spoken = nakitModu ? "Nakit" : "POS",
    tag = nakitModu ? "cash" : "pos";
  const today = toS(new Date()),
    presets = analizDonemleri(today),
    days = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"],
    short = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];
  const [filter, setFilter] = useState("hafta"),
    [range, setRange] = useState(presets.hafta),
    [draft, setDraft] = useState(presets.hafta),
    [error, setError] = useState("");
  const data = useMemo(() => posAralikOzeti(txs, cfg, range.bas, range.bit), [txs, cfg, range]),
    kiyas = useMemo(() => posAnalizKiyas(txs, cfg, today), [txs, cfg, today]);
  const max = Math.max(1, ...data.gunler.map(d => d.ortalama || 0)),
    unit = Math.pow(10, Math.floor(Math.log10(max))),
    top = Math.ceil(max / unit) * unit;
  const I = {
    background: "#0f1117",
    border: "1px solid #334155",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "7px 10px",
    fontSize: 12,
    fontFamily: "inherit"
  };
  const choose = key => {
    setFilter(key);
    setError("");
    if (key !== "ozel") {
      setRange(presets[key]);
      setDraft(presets[key]);
    }
  };
  const apply = () => {
    try {
      posAralikOzeti([], cfg, draft.bas, draft.bit);
      setRange({
        ...draft
      });
      setFilter("ozel");
      setError("");
    } catch (e) {
      setError(e.message);
    }
  };
  const comparison = (key, label) => {
    const c = kiyas[key],
      f = haftalikFark({
        tutar: c.simdi.toplam,
        adet: c.simdi.adet
      }, {
        tutar: c.once.toplam,
        adet: c.once.adet
      }),
      color = f.durum === "artis" ? "#4ade80" : f.durum === "azalis" ? "#f87171" : "#94a3b8";
    return React.createElement("div", {
      "data-pos-comparison": nakitModu ? undefined : key,
      "data-cash-comparison": nakitModu ? key : undefined,
      style: {
        background: "#0f1117",
        border: "1px solid #253047",
        borderRadius: 9,
        padding: "11px 13px",
        fontSize: 11
      }
    }, React.createElement("div", {
      style: {
        color: "#a2b1c6",
        letterSpacing: 1,
        marginBottom: 7
      }
    }, label), React.createElement("div", {
      style: {
        color: "#94a3b8",
        marginBottom: 5
      }
    }, fDSh(c.simdi.bas), " \u2013 ", fDSh(c.simdi.bit), " / ", fDSh(c.once.bas), " \u2013 ", fDSh(c.once.bit)), React.createElement("div", {
      style: {
        display: "flex",
        gap: 14,
        alignItems: "center",
        flexWrap: "wrap"
      }
    }, React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#f1f5f9",
        fontWeight: 600
      }
    }, "\u20BA ", fmt(c.simdi.toplam)), React.createElement("span", {
      style: {
        color: "#94a3b8"
      }
    }, "\u20BA ", fmt(c.once.toplam)), React.createElement("span", {
      style: {
        color
      }
    }, f.oran == null ? "–" : f.oran === 0 ? `${spoken} gelirleri değişmedi.` : `${spoken} gelirleri %${Math.abs(f.oran).toLocaleString('tr-TR', {
      maximumFractionDigits: 1
    })} ${f.oran > 0 ? "arttı" : "azaldı"}.`)));
  };
  return React.createElement("section", {
    "aria-label": spoken + " gelir analizi",
    style: {
      marginTop: 20,
      background: "#141825",
      border: "1px solid #3b82f633",
      borderRadius: 12,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "12px 16px",
      borderBottom: "1px solid #1e293b",
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2
    }
  }, prefix, " GEL\u0130R ANAL\u0130Z\u0130"), React.createElement("div", {
    style: {
      padding: "14px 18px"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      gap: 7,
      flexWrap: "wrap",
      marginBottom: 12
    }
  }, [["hafta", "Bu hafta"], ["gecenHafta", "Geçen hafta"], ["ay", "Bu ay"], ["gecenAy", "Geçen ay"], ["yil", "Bu yıl"], ["ozel", "Özel aralık"]].map(([key, label]) => React.createElement("button", {
    key: key,
    "aria-pressed": filter === key,
    onClick: () => choose(key),
    style: {
      ...I,
      cursor: "pointer",
      background: filter === key ? "#1e3a5f" : "#0f1117",
      borderColor: filter === key ? "#3b82f6" : "#253047",
      color: filter === key ? "#93c5fd" : "#cbd5e1"
    }
  }, label))), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "end",
      flexWrap: "wrap",
      justifyContent: "space-between",
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      gap: 9,
      alignItems: "end",
      flexWrap: "wrap"
    }
  }, React.createElement("label", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, "BA\u015ELANGI\xC7", React.createElement("input", {
    "aria-label": spoken + " analiz başlangıç",
    lang: "tr-TR",
    type: "date",
    style: {
      ...I,
      display: "block",
      marginTop: 4
    },
    value: draft.bas,
    onChange: e => {
      setFilter("ozel");
      setDraft(v => ({
        ...v,
        bas: e.target.value
      }));
      setError("");
    }
  })), React.createElement("label", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, "B\u0130T\u0130\u015E", React.createElement("input", {
    "aria-label": spoken + " analiz bitiş",
    lang: "tr-TR",
    type: "date",
    style: {
      ...I,
      display: "block",
      marginTop: 4
    },
    value: draft.bit,
    onChange: e => {
      setFilter("ozel");
      setDraft(v => ({
        ...v,
        bit: e.target.value
      }));
      setError("");
    }
  })), React.createElement("button", {
    onClick: apply,
    style: {
      ...I,
      background: "#1e3a5f",
      borderColor: "#3b82f6",
      color: "#93c5fd",
      cursor: "pointer"
    }
  }, "Uygula")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 24
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 4
    }
  }, "TOPLAM ", prefix), React.createElement("div", {
    "aria-label": spoken + " analiz toplamı",
    style: {
      fontSize: 16,
      fontWeight: 600
    }
  }, "\u20BA ", fmt(data.toplam))), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 4
    }
  }, "G\xDCNL\xDCK ORTALAMA"), React.createElement("div", {
    "aria-label": spoken + " analiz günlük ortalama",
    style: {
      fontSize: 16,
      fontWeight: 600
    }
  }, "\u20BA ", fmt(data.ortalama))))), error && React.createElement("p", {
    role: "alert",
    style: {
      color: "#f87171",
      fontSize: 12,
      marginBottom: 10
    }
  }, error), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0,2fr) minmax(220px,1fr)",
      gap: 12
    }
  }, React.createElement("div", {
    style: {
      background: "#0f1117",
      border: "1px solid #253047",
      borderRadius: 9,
      padding: "12px 10px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      marginBottom: 8
    }
  }, "G\xDCNLERE G\xD6RE ORTALAMA"), data.adet === 0 ? React.createElement("div", {
    style: {
      height: 230,
      display: "grid",
      placeItems: "center",
      color: "#94a3b8",
      fontSize: 12
    }
  }, "Kay\u0131t yok") : React.createElement("svg", {
    role: "img",
    "aria-label": spoken + " günlük ortalama grafiği",
    viewBox: "0 0 660 240",
    style: {
      width: "100%",
      maxHeight: 260,
      display: "block",
      fontFamily: "inherit",
      overflow: "visible"
    }
  }, React.createElement("defs", null, React.createElement("linearGradient", {
    id: tag + "-average-gradient",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, React.createElement("stop", {
    stopColor: "#38bdf8"
  }), React.createElement("stop", {
    offset: "1",
    stopColor: "#2563eb"
  }))), [0, 1, 2, 3, 4].map(i => {
    const value = top * i / 4,
      y = 202 - i * 44;
    return React.createElement("g", {
      key: i
    }, React.createElement("line", {
      x1: "54",
      y1: y,
      x2: "648",
      y2: y,
      stroke: "#263349",
      strokeDasharray: "3 4"
    }), React.createElement("text", {
      x: "46",
      y: y + 4,
      fill: "#94a3b8",
      textAnchor: "end",
      fontSize: "11"
    }, value >= 1000 ? (value / 1000).toLocaleString('tr-TR', {
      maximumFractionDigits: 1
    }) + " bin" : value.toLocaleString('tr-TR', {
      maximumFractionDigits: 1
    })));
  }), data.gunler.map((row, i) => {
    const value = row.ortalama || 0,
      height = value / top * 176,
      x = 92 + i * 84;
    return React.createElement("g", {
      key: i
    }, React.createElement("rect", {
      "data-pos-bar": nakitModu ? undefined : i,
      "data-cash-bar": nakitModu ? i : undefined,
      x: x - 16,
      y: 202 - height,
      width: "32",
      height: height,
      rx: "3",
      fill: "url(#" + tag + "-average-gradient)"
    }, React.createElement("title", null, days[i], ": \u20BA ", fmt(value))), React.createElement("text", {
      x: x,
      y: Math.max(16, 194 - height),
      fill: "#93c5fd",
      textAnchor: "middle",
      fontSize: "11"
    }, row.gunSayisi ? fmt(value) : "–"), React.createElement("text", {
      x: x,
      y: "226",
      fill: "#94a3b8",
      textAnchor: "middle",
      fontSize: "11"
    }, short[i]));
  }))), React.createElement("div", {
    style: {
      background: "#0f1117",
      border: "1px solid #253047",
      borderRadius: 9,
      padding: "12px 14px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      marginBottom: 6
    }
  }, "G\xDCNL\xDCK ORTALAMALAR"), data.gunler.map((row, i) => React.createElement("div", {
    key: i,
    "data-pos-weekday": nakitModu ? undefined : i,
    "data-cash-weekday": nakitModu ? i : undefined,
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: 10,
      padding: "10px 0",
      borderBottom: i < 6 ? "1px solid #1e293b" : undefined,
      fontSize: 12
    }
  }, React.createElement("span", {
    style: {
      color: "#cbd5e1"
    }
  }, days[i]), React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, !data.adet || row.ortalama === null ? "–" : "₺ " + fmt(row.ortalama)))))), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(2,minmax(0,1fr))",
      gap: 12,
      marginTop: 12
    }
  }, comparison("hafta", "HAFTALIK"), comparison("ay", "AYLIK"))));
}
function SatisDagilimi({
  txs,
  nakit,
  cfg
}) {
  const presets = analizDonemleri(toS(new Date()));
  const [filter, setFilter] = useState("hafta"),
    [range, setRange] = useState(presets.hafta),
    [draft, setDraft] = useState(presets.hafta),
    [error, setError] = useState("");
  const data = useMemo(() => satisDagilimi(txs, nakit, cfg, range.bas, range.bit), [txs, nakit, cfg, range]);
  const I = {
    background: "#0f1117",
    border: "1px solid #334155",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "7px 10px",
    fontSize: 12,
    fontFamily: "inherit"
  };
  const choose = key => {
    setFilter(key);
    setError("");
    if (key !== "ozel") {
      setRange(presets[key]);
      setDraft(presets[key]);
    }
  };
  const apply = () => {
    try {
      satisDagilimi([], [], cfg, draft.bas, draft.bit);
      setRange({
        ...draft
      });
      setFilter("ozel");
      setError("");
    } catch (e) {
      setError(e.message);
    }
  };
  const posRounded = data.posOran === null ? null : Math.round(data.posOran * 10) / 10,
    cashRounded = posRounded === null ? null : Math.round((100 - posRounded) * 10) / 10;
  return React.createElement("section", {
    "aria-label": "POS ve nakit sat\u0131\u015F da\u011F\u0131l\u0131m\u0131",
    style: {
      marginTop: 20,
      background: "#141825",
      border: "1px solid #3b82f633",
      borderRadius: 12,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "12px 16px",
      borderBottom: "1px solid #1e293b",
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2
    }
  }, "POS / NAK\u0130T DA\u011EILIMI"), React.createElement("div", {
    style: {
      padding: "14px 18px"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      gap: 7,
      flexWrap: "wrap",
      marginBottom: 12
    }
  }, [["hafta", "Bu hafta"], ["gecenHafta", "Geçen hafta"], ["ay", "Bu ay"], ["gecenAy", "Geçen ay"], ["yil", "Bu yıl"], ["ozel", "Özel aralık"]].map(([key, label]) => React.createElement("button", {
    key: key,
    "aria-pressed": filter === key,
    onClick: () => choose(key),
    style: {
      ...I,
      cursor: "pointer",
      background: filter === key ? "#1e3a5f" : "#0f1117",
      borderColor: filter === key ? "#3b82f6" : "#253047",
      color: filter === key ? "#93c5fd" : "#cbd5e1"
    }
  }, label))), React.createElement("div", {
    style: {
      display: "flex",
      gap: 9,
      alignItems: "end",
      flexWrap: "wrap",
      marginBottom: 14
    }
  }, React.createElement("label", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, "BA\u015ELANGI\xC7", React.createElement("input", {
    "aria-label": "Da\u011F\u0131l\u0131m ba\u015Flang\u0131\xE7",
    lang: "tr-TR",
    type: "date",
    style: {
      ...I,
      display: "block",
      marginTop: 4
    },
    value: draft.bas,
    onChange: e => {
      setFilter("ozel");
      setDraft(v => ({
        ...v,
        bas: e.target.value
      }));
      setError("");
    }
  })), React.createElement("label", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, "B\u0130T\u0130\u015E", React.createElement("input", {
    "aria-label": "Da\u011F\u0131l\u0131m biti\u015F",
    lang: "tr-TR",
    type: "date",
    style: {
      ...I,
      display: "block",
      marginTop: 4
    },
    value: draft.bit,
    onChange: e => {
      setFilter("ozel");
      setDraft(v => ({
        ...v,
        bit: e.target.value
      }));
      setError("");
    }
  })), React.createElement("button", {
    style: {
      ...I,
      background: "#1e3a5f",
      borderColor: "#3b82f6",
      color: "#93c5fd",
      cursor: "pointer"
    },
    onClick: apply
  }, "Uygula")), error && React.createElement("p", {
    role: "alert",
    style: {
      fontSize: 12,
      color: "#f87171"
    }
  }, error), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 36,
      flexWrap: "wrap",
      padding: "8px 0"
    }
  }, React.createElement("svg", {
    "aria-label": "POS ve nakit da\u011F\u0131l\u0131m halkas\u0131",
    role: "img",
    viewBox: "0 0 300 240",
    style: {
      width: 300,
      maxWidth: "100%",
      height: "auto",
      fontFamily: "inherit"
    }
  }, React.createElement("circle", {
    cx: "150",
    cy: "120",
    r: "86",
    fill: "none",
    stroke: "#253047",
    strokeWidth: "20"
  }), data.toplam > 0 && React.createElement("g", {
    transform: "rotate(-90 150 120)"
  }, React.createElement("circle", {
    "data-share-ring": "pos",
    cx: "150",
    cy: "120",
    r: "86",
    fill: "none",
    stroke: "#3b82f6",
    strokeWidth: "20",
    pathLength: "100",
    strokeDasharray: `${data.posOran} ${100 - data.posOran}`
  }), React.createElement("circle", {
    "data-share-ring": "nakit",
    cx: "150",
    cy: "120",
    r: "86",
    fill: "none",
    stroke: "#34d399",
    strokeWidth: "20",
    pathLength: "100",
    strokeDasharray: `${data.nakitOran} ${100 - data.nakitOran}`,
    strokeDashoffset: -data.posOran
  })), React.createElement("text", {
    x: "150",
    y: "109",
    textAnchor: "middle",
    fill: "#a2b1c6",
    fontSize: "11",
    letterSpacing: "1"
  }, "TOPLAM SATI\u015E"), React.createElement("text", {
    "aria-label": "Da\u011F\u0131l\u0131m toplam\u0131",
    x: "150",
    y: "140",
    textAnchor: "middle",
    fill: "#f1f5f9",
    fontWeight: "600",
    fontSize: fmt(data.toplam).length > 13 ? 18 : 23
  }, "\u20BA ", fmt(data.toplam))), React.createElement("div", {
    style: {
      minWidth: 220,
      maxWidth: "100%",
      flex: "0 1 360px"
    }
  }, [["pos", "POS", data.pos, posRounded, "#3b82f6"], ["nakit", "NAKİT", data.nakit, cashRounded, "#34d399"]].map(([key, label, tutar, oran, color]) => React.createElement("div", {
    key: key,
    "data-sale-share": key,
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 20,
      padding: "17px 0",
      borderBottom: "1px solid #253047"
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      color: "#cbd5e1",
      fontSize: 12
    }
  }, React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: "50%",
      background: color
    }
  }), label), React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: "#f1f5f9",
      marginTop: 8
    }
  }, "\u20BA ", fmt(tutar))), React.createElement("span", {
    style: {
      fontSize: 23,
      fontWeight: 600,
      color
    }
  }, oran === null ? "–" : "%" + oran.toLocaleString('tr-TR', {
    maximumFractionDigits: 1
  })))), !data.adet && React.createElement("div", {
    style: {
      marginTop: 12,
      fontSize: 12,
      color: "#94a3b8"
    }
  }, "Kay\u0131t yok")))));
}
function IsletmeOzeti({
  cfg,
  nakit,
  txs,
  odemeler,
  saveOdemeler,
  onTakip
}) {
  const today = toS(new Date()),
    [period, setPeriod] = useState("ay");
  const data = useMemo(() => ozetVerileri(txs, cfg, odemeler, today), [txs, cfg, odemeler, today]),
    performance = useMemo(() => ozetKasaPerformansi(txs, cfg, today, period), [txs, cfg, today, period]);
  const max = Math.max(1, ...data.gelecek.map(r => r.total.tutar)),
    unit = Math.pow(10, Math.floor(Math.log10(max))),
    top = Math.ceil(max / unit) * unit;
  const card = {
      background: "#141825",
      border: "1px solid #253047",
      borderRadius: 12
    },
    I = {
      background: "#0f1117",
      border: "1px solid #334155",
      borderRadius: 8,
      color: "#e2e8f0",
      padding: "7px 10px",
      fontSize: 12,
      fontFamily: "inherit"
    };
  const dateName = new Date(today + "T12:00:00").toLocaleDateString('tr-TR', {
    weekday: 'long'
  });
  return React.createElement("section", {
    "aria-label": "\u0130\u015Fletme \xF6zeti"
  }, React.createElement("div", {
    style: {
      ...card,
      padding: "16px 18px",
      display: "flex",
      justifyContent: "space-between",
      gap: 12,
      alignItems: "center",
      flexWrap: "wrap",
      marginBottom: 16
    }
  }, React.createElement("h2", {
    style: {
      fontSize: 18,
      fontWeight: 600
    }
  }, "\u0130\u015Fletme \xD6zeti"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "#a2b1c6"
    }
  }, dateName.charAt(0).toLocaleUpperCase('tr-TR') + dateName.slice(1), ", ", fDSh(today))), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,minmax(0,1fr))",
      gap: 12,
      marginBottom: 16
    }
  }, [["total", "BUGÜN TOPLAM YATACAK TUTAR"], ["kredi", "KREDİ KARTI"], ["debit", "DEBİT KART"]].map(([key, label]) => React.createElement("button", {
    key: key,
    "data-summary-card": key,
    "aria-label": label + " ayrıntıları",
    onClick: () => onTakip(today),
    style: {
      ...card,
      padding: "17px 18px",
      textAlign: "left",
      color: "#f1f5f9",
      fontFamily: "inherit",
      cursor: "pointer"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      letterSpacing: 1,
      color: "#a2b1c6",
      marginBottom: 10
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: 26,
      fontWeight: 700,
      letterSpacing: -1,
      marginBottom: 9
    }
  }, "\u20BA ", fmt(data.simdi[key].tutar)), React.createElement(HaftalikDegisim, {
    simdi: data.simdi[key],
    once: data.once[key],
    etiket: label + " haftalık değişim",
    tarih: analizGunKaydir(today, -7)
  }), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginTop: 7,
      display: "flex",
      justifyContent: "space-between",
      gap: 10
    }
  }, React.createElement("span", null, data.once[key].adet ? "₺ " + fmt(data.once[key].tutar) : "–"), React.createElement("span", {
    "aria-hidden": "true"
  }, "\u2192"))))), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0,1.7fr) minmax(260px,1fr)",
      gap: 12,
      marginBottom: 16
    }
  }, React.createElement("div", {
    style: card
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: 12,
      padding: "12px 16px",
      borderBottom: "1px solid #253047"
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1
    }
  }, "\xD6N\xDCM\xDCZDEK\u0130 7 G\xDCN"), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginTop: 5
    }
  }, fDSh(data.gelecek[0].tarih), " \u2013 ", fDSh(data.gelecek[6].tarih))), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, "BEKLENEN POS"), React.createElement("div", {
    "aria-label": "\xD6zet beklenen POS toplam\u0131",
    style: {
      fontSize: 15,
      fontWeight: 600,
      marginTop: 5
    }
  }, "\u20BA ", fmt(data.gelecekToplam)))), React.createElement("div", {
    style: {
      padding: "14px 12px"
    }
  }, React.createElement("svg", {
    role: "img",
    "aria-label": "\xD6n\xFCm\xFCzdeki 7 g\xFCn beklenen yat\u0131\u015F grafi\u011Fi",
    viewBox: "0 0 660 240",
    style: {
      width: "100%",
      maxHeight: 260,
      display: "block",
      fontFamily: "inherit"
    }
  }, React.createElement("defs", null, React.createElement("linearGradient", {
    id: "summary-pos-gradient",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, React.createElement("stop", {
    stopColor: "#38bdf8"
  }), React.createElement("stop", {
    offset: "1",
    stopColor: "#2563eb"
  }))), [0, 1, 2, 3, 4].map(i => {
    const value = top * i / 4,
      y = 198 - i * 43;
    return React.createElement("g", {
      key: i
    }, React.createElement("line", {
      x1: "54",
      x2: "648",
      y1: y,
      y2: y,
      stroke: "#263349",
      strokeDasharray: "3 4"
    }), React.createElement("text", {
      x: "46",
      y: y + 4,
      textAnchor: "end",
      fill: "#94a3b8",
      fontSize: "11"
    }, value >= 1000 ? (value / 1000).toLocaleString('tr-TR', {
      maximumFractionDigits: 1
    }) + " bin" : value.toLocaleString('tr-TR', {
      maximumFractionDigits: 1
    })));
  }), data.gelecek.map((r, i) => {
    const height = r.total.tutar / top * 172,
      x = 92 + i * 84;
    return React.createElement("g", {
      key: r.tarih
    }, React.createElement("rect", {
      "data-future-pos-bar": r.tarih,
      role: "button",
      tabIndex: 0,
      "aria-label": fDSh(r.tarih) + " yatış ayrıntıları",
      onKeyDown: e => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onTakip(r.tarih);
        }
      },
      onClick: () => onTakip(r.tarih),
      style: {
        cursor: "pointer"
      },
      x: x - 16,
      y: 198 - height,
      width: "32",
      height: height,
      rx: "3",
      fill: "url(#summary-pos-gradient)"
    }, React.createElement("title", null, fDSh(r.tarih), ": \u20BA ", fmt(r.total.tutar))), React.createElement("text", {
      x: x,
      y: Math.max(15, 190 - height),
      textAnchor: "middle",
      fill: "#93c5fd",
      fontSize: "11"
    }, fmt(r.total.tutar)), React.createElement("text", {
      x: x,
      y: "219",
      textAnchor: "middle",
      fill: "#94a3b8",
      fontSize: "11"
    }, new Date(r.tarih + "T12:00:00").toLocaleDateString('tr-TR', {
      weekday: 'short'
    })), React.createElement("text", {
      x: x,
      y: "235",
      textAnchor: "middle",
      fill: "#94a3b8",
      fontSize: "10"
    }, fDSh(r.tarih)));
  })))), React.createElement("div", {
    style: card
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 8,
      padding: "12px 14px",
      borderBottom: "1px solid #253047"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1
    }
  }, "KASA PERFORMANSI"), React.createElement("select", {
    "aria-label": "\xD6zet kasa performans\u0131 d\xF6nemi",
    style: I,
    value: period,
    onChange: e => setPeriod(e.target.value)
  }, React.createElement("option", {
    value: "hafta"
  }, "Bu hafta"), React.createElement("option", {
    value: "ay"
  }, "Bu ay"), React.createElement("option", {
    value: "yil"
  }, "Bu y\u0131l"))), React.createElement("div", {
    style: {
      padding: "4px 14px",
      maxHeight: 286,
      overflowY: "auto"
    }
  }, !performance.length ? React.createElement("div", {
    style: {
      padding: "36px 0",
      textAlign: "center",
      color: "#94a3b8",
      fontSize: 12
    }
  }, "Kay\u0131t yok") : performance.map((r, i) => React.createElement("div", {
    key: r.kasa.id,
    "data-summary-kasa": r.kasa.id,
    style: {
      padding: "12px 0",
      borderBottom: i < performance.length - 1 ? "1px solid #253047" : undefined
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: 10,
      alignItems: "start"
    }
  }, React.createElement("div", null, React.createElement("div", {
    "data-summary-kasa-name": true,
    style: {
      fontSize: 12,
      color: "#e2e8f0",
      fontWeight: 600
    }
  }, r.kasa.ad), React.createElement("div", {
    "data-summary-kasa-amount": true,
    style: {
      fontSize: 15,
      color: "#f1f5f9",
      fontWeight: 600,
      marginTop: 6
    }
  }, "\u20BA ", fmt(r.simdi.toplam))), React.createElement(HaftalikDegisim, {
    simdi: {
      tutar: r.simdi.toplam,
      adet: r.simdi.adet
    },
    once: {
      tutar: r.once.toplam,
      adet: r.once.adet
    },
    etiket: r.kasa.ad + " özet dönem değişimi",
    tarih: r.once.bit,
    titleOverride: `${fDSh(r.once.bas)} – ${fDSh(r.once.bit)}: ${r.once.adet ? "₺ " + fmt(r.once.toplam) : "Kayıt yok"}`,
    compact: true
  })), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      marginTop: 8
    }
  }, React.createElement("div", {
    style: {
      height: 6,
      background: "#253047",
      borderRadius: 3,
      flex: 1,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      height: "100%",
      width: r.pay + "%",
      background: ["#3b82f6", "#38bdf8", "#93c5fd"][i % 3],
      borderRadius: 3
    }
  })), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#94a3b8"
    }
  }, "%", r.pay.toLocaleString('tr-TR', {
    maximumFractionDigits: 1
  })))))))), React.createElement("div", {
    style: {
      ...card,
      padding: "12px 16px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 12,
      fontSize: 12,
      marginBottom: 16
    }
  }, React.createElement("span", {
    style: {
      color: "#cbd5e1"
    }
  }, data.odemeler.length ? `Önümüzdeki 7 günde ${data.odemeler.length} ödeme, toplam ₺ ${fmt(data.odemeToplam)}.` : "Önümüzdeki 7 günde kayıtlı bekleyen ödeme yok."), React.createElement("button", {
    style: {
      ...I,
      cursor: "pointer"
    },
    onClick: () => document.getElementById("ozet-odemeler")?.scrollIntoView({
      behavior: "smooth",
      block: "start"
    })
  }, "\xD6demelere git")), React.createElement(SatisDagilimi, {
    txs: txs,
    nakit: nakit,
    cfg: cfg
  }), React.createElement(PosGelirAnalizi, {
    txs: txs,
    cfg: cfg
  }), React.createElement(PosGelirAnalizi, {
    txs: nakitAnalizKayitlari(nakit, cfg),
    cfg: cfg,
    nakitModu: true
  }), React.createElement("div", {
    id: "ozet-odemeler",
    style: {
      scrollMarginTop: 110
    }
  }, React.createElement(AylikOdemeler, {
    odemeler: odemeler,
    saveOdemeler: saveOdemeler
  })));
}
function PosYeniDebit({
  cfg,
  txs,
  saveTxs
}) {
  const [kasaId, setKasaId] = useState(""),
    [yatis, setYatis] = useState(toS(new Date())),
    [tutar, setTutar] = useState(""),
    [secim, setSecim] = useState(""),
    [error, setError] = useState(""),
    [msg, setMsg] = useState("");
  const busy = useRef(false),
    vade = cfg.vadeGunleri["DEBİT KART"] ?? 16;
  const records = txs.filter(t => t.kasaId === kasaId && t.mutabakatId && t.posToplam != null && t.islemTarihi <= yatis);
  const adaylar = posDebitAdaylari({
    txs,
    kasaId,
    yatisTarihi: yatis,
    vadeGun: vade
  });
  const selected = secim ? records.find(t => t.mutabakatId === secim) : adaylar.length === 1 ? adaylar[0] : null;
  const kasalar = cfg.kasalar.filter(k => k.aktif !== false && k.toplamModu || txs.some(t => t.kasaId === k.id && t.mutabakatId && t.posToplam != null));
  const I = {
    background: "#0f1117",
    border: "1px solid #334155",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "7px 9px",
    fontSize: 12,
    width: "100%",
    fontFamily: "inherit"
  };
  const changed = () => {
    setSecim("");
    setError("");
    setMsg("");
  };
  const save = () => {
    if (busy.current) return;
    busy.current = true;
    try {
      const result = posYeniDebitEkle({
        txs,
        kasaId,
        yatisTarihi: yatis,
        tutar,
        vadeGun: vade,
        kayitId: secim,
        id: uid()
      });
      saveTxs(result.txs);
      setTutar("");
      setYatis(toS(new Date()));
      setSecim("");
      setError("");
      setMsg(`${fDSh(result.group.islemTarihi)} POS kaydına debit eklendi. Kalan kredi: ₺ ${fmt(result.group.tutar)} · Kredi vadesi: ${fDSh(result.group.yatacakTarih)}`);
    } catch (e) {
      setMsg("");
      setError(e.message);
    } finally {
      busy.current = false;
    }
  };
  return React.createElement("div", {
    "aria-label": "Yeni yatan debit giri\u015Fi",
    style: {
      marginBottom: 14,
      paddingBottom: 14,
      borderBottom: "1px solid #334155"
    }
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,minmax(0,1fr))",
      gap: 10,
      fontSize: 11
    }
  }, React.createElement("label", null, "Kasa", React.createElement("select", {
    "aria-label": "Yat\u0131\u015F kasas\u0131",
    style: I,
    value: kasaId,
    onChange: e => {
      setKasaId(e.target.value);
      changed();
    }
  }, React.createElement("option", {
    value: ""
  }, "Kasa se\xE7in"), kasalar.map(k => React.createElement("option", {
    key: k.id,
    value: k.id
  }, k.ad, " / ", k.kod, k.aktif === false ? " (Pasif)" : "")))), React.createElement("label", null, "Bankaya yat\u0131\u015F tarihi", React.createElement("input", {
    "aria-label": "Yeni debit yat\u0131\u015F tarihi",
    type: "date",
    max: toS(new Date()),
    style: I,
    value: yatis,
    onChange: e => {
      setYatis(e.target.value);
      changed();
    }
  })), React.createElement("label", null, "Yatan debit (TL)", React.createElement("input", {
    "aria-label": "Yeni debit tutar\u0131",
    inputMode: "decimal",
    style: I,
    value: tutar,
    onChange: e => {
      setTutar(e.target.value);
      setMsg("");
      setError("");
    },
    onBlur: () => setTutar(v => posTutarGoster(v))
  }))), React.createElement("p", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      margin: "9px 0"
    }
  }, "Debit vadesi: ", vade, " g\xFCn. ", selected ? `Eşleşen POS günü: ${fDSh(selected.islemTarihi)} · Kalan kredi: ₺ ${fmt(selected.tutar)} · Vade: ${fDSh(selected.yatacakTarih)}` : kasaId ? adaylar.length > 1 ? "Birden fazla kayıt eşleşti; satış kaydını seçin." : "Bu yatış tarihi için POS toplamı bulunamadı. Satış kaydını seçin veya toplamı kaydedin." : "Kasa ve yatış gününü seçin; POS kaydı vade ayarından bulunur."), kasaId && React.createElement("label", {
    style: {
      fontSize: 11
    }
  }, "Sat\u0131\u015F kayd\u0131 (gerekirse d\xFCzeltin)", React.createElement("select", {
    "aria-label": "Yeni debit sat\u0131\u015F kayd\u0131",
    style: I,
    value: secim,
    onChange: e => {
      setSecim(e.target.value);
      setError("");
      setMsg("");
    }
  }, React.createElement("option", {
    value: ""
  }, "Vade ayar\u0131na g\xF6re otomatik bul"), records.map(t => React.createElement("option", {
    key: t.id,
    value: t.mutabakatId
  }, t.islemTarihi, " \u2014 Toplam \u20BA ", fmt(t.posToplam), " \u2014 Kalan \u20BA ", fmt(t.tutar))))), error && React.createElement("p", {
    role: "alert",
    style: {
      color: "#f87171",
      fontSize: 12
    }
  }, error), msg && React.createElement("p", {
    role: "status",
    style: {
      color: "#86efac",
      fontSize: 12
    }
  }, msg), React.createElement("button", {
    className: "btn-hover",
    style: {
      ...POS_KAYDET_STILI,
      marginTop: 10
    },
    onClick: save
  }, React.createElement(UiIcon, {
    kind: "save"
  }), " Yatan debiti kaydet"));
}
const GIRIS_BASLIK = {
  fontSize: 11,
  color: "#a2b1c6",
  letterSpacing: 2,
  textTransform: "uppercase",
  marginBottom: 14
};
function NakitGiris({
  cfg,
  nakit,
  saveNakit,
  editing,
  onDone
}) {
  const yesterday = () => addD(toS(new Date()), -1);
  const [rows, setRows] = useState(() => nakitVarsayilanKasalar(cfg).map(kasaId => ({
      key: uid(),
      kasaId,
      tarih: yesterday(),
      tutar: ""
    }))),
    [editRow, setEditRow] = useState({
      kasaId: "",
      tarih: yesterday(),
      tutar: ""
    }),
    [error, setError] = useState(""),
    [msg, setMsg] = useState("");
  const lock = useRef(false);
  useEffect(() => {
    if (editing) {
      setEditRow({
        kasaId: editing.kasaId,
        tarih: editing.tarih,
        tutar: posTutarGoster(editing.tutar)
      });
      setError("");
      setMsg("");
      document.getElementById("nakit-giris")?.scrollIntoView({
        block: "center"
      });
    } else setError("");
  }, [editing]);
  const I = {
    background: "#0f1117",
    border: "1px solid #2d3748",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "8px 11px",
    fontSize: 13,
    fontFamily: "inherit",
    width: "100%"
  };
  const change = (index, patch) => {
    if (editing) setEditRow(v => ({
      ...v,
      ...patch
    }));else setRows(v => v.map((r, i) => i === index ? {
      ...r,
      ...patch
    } : r));
    setError("");
    setMsg("");
  };
  const save = () => {
    if (lock.current) return;
    lock.current = true;
    try {
      if (editing) {
        const next = nakitKaydet({
          records: nakit,
          cfg,
          id: editing.id,
          ...editRow,
          tutar: String(editRow.tutar ?? "").trim() || "0",
          editing: true,
          allowZero: true
        });
        saveNakit(next);
        onDone();
        setMsg("Nakit kaydı güncellendi.");
      } else {
        const result = nakitTopluKaydet({
          records: nakit,
          cfg,
          rows: rows.map(r => ({
            ...r,
            id: uid()
          }))
        });
        saveNakit(result.records);
        setRows(v => v.map(r => ({
          ...r,
          tutar: "",
          tarih: yesterday()
        })));
        setMsg(`${result.count} nakit kaydı birlikte kaydedildi.`);
      }
      setError("");
    } catch (e) {
      setError(e.message);
      setMsg("");
    } finally {
      lock.current = false;
    }
  };
  const addRow = () => {
    const used = new Set(rows.map(r => r.kasaId)),
      k = cfg.kasalar.find(k => k.aktif !== false && !used.has(k.id));
    setRows(v => [...v, {
      key: uid(),
      kasaId: k?.id || "",
      tarih: yesterday(),
      tutar: ""
    }]);
    setError("");
    setMsg("");
  };
  return React.createElement("section", {
    id: "nakit-giris",
    "aria-label": "Kasadan gelen nakit giri\u015Fi",
    style: {
      background: "#141825",
      border: "1px solid #1e293b",
      borderRadius: 12,
      padding: "18px 20px",
      marginBottom: 18
    }
  }, React.createElement("div", {
    style: GIRIS_BASLIK
  }, "KASADAN GELEN NAK\u0130T", editing ? " · DÜZENLE" : ""), (editing ? [editRow] : rows).map((row, i) => React.createElement("div", {
    key: editing ? editing.id : row.key,
    "data-cash-entry-row": i,
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,minmax(0,1fr)) auto",
      gap: 10,
      fontSize: 11,
      marginBottom: 12,
      alignItems: "end"
    }
  }, React.createElement("label", {
    style: {
      color: "#a2b1c6"
    }
  }, "KASA", React.createElement("select", {
    "aria-label": editing ? "Nakit kasası" : `Nakit kasası ${i + 1}`,
    style: I,
    value: row.kasaId,
    onChange: e => change(i, {
      kasaId: e.target.value
    })
  }, React.createElement("option", {
    value: ""
  }, "Kasa se\xE7in"), cfg.kasalar.filter(k => k.aktif !== false || k.id === editing?.kasaId).map(k => React.createElement("option", {
    key: k.id,
    value: k.id
  }, k.ad, " (", k.kod, ")", k.aktif === false ? " (Pasif)" : "")))), React.createElement("label", {
    style: {
      color: "#a2b1c6"
    }
  }, "\u0130\u015ELEM TAR\u0130H\u0130", React.createElement("input", {
    "aria-label": editing ? "Nakit işlem tarihi" : `Nakit işlem tarihi ${i + 1}`,
    lang: "tr-TR",
    type: "date",
    max: toS(new Date()),
    style: I,
    value: row.tarih,
    onChange: e => change(i, {
      tarih: e.target.value
    })
  })), React.createElement("label", {
    style: {
      color: "#a2b1c6"
    }
  }, "TUTAR (\u20BA)", React.createElement("input", {
    "aria-label": editing ? "Nakit tutarı" : `Nakit tutarı ${i + 1}`,
    inputMode: "decimal",
    style: I,
    value: row.tutar,
    onChange: e => change(i, {
      tutar: e.target.value
    }),
    onBlur: () => change(i, {
      tutar: posTutarGoster(row.tutar)
    })
  })), !editing && i >= 2 ? React.createElement("button", {
    "aria-label": `${i + 1}. nakit satırını kaldır`,
    title: "Sat\u0131r\u0131 kald\u0131r",
    style: {
      ...I,
      width: 36,
      cursor: "pointer",
      color: "#f87171"
    },
    onClick: () => {
      setRows(v => v.filter((_, j) => j !== i));
      setError("");
      setMsg("");
    }
  }, React.createElement(UiIcon, {
    kind: "close"
  })) : React.createElement("span", {
    style: {
      width: 36
    }
  }))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      flexWrap: "wrap",
      marginTop: 16
    }
  }, React.createElement("button", {
    className: "btn-hover",
    style: POS_KAYDET_STILI,
    onClick: e => {
      if (e.detail > 1) return;
      save();
    }
  }, React.createElement(UiIcon, {
    kind: "save"
  }), " ", editing ? "Nakdi güncelle" : "Nakdi kaydet"), editing ? React.createElement("button", {
    style: {
      ...I,
      width: "auto",
      cursor: "pointer"
    },
    onClick: () => {
      onDone();
      setError("");
      setMsg("");
    }
  }, "Vazge\xE7") : React.createElement("button", {
    style: {
      ...I,
      width: "auto",
      background: "#1e3a5f",
      borderColor: "#3b82f633",
      color: "#93c5fd",
      cursor: "pointer",
      display: "inline-flex",
      alignItems: "center",
      gap: 7
    },
    onClick: addRow
  }, React.createElement("span", {
    "aria-hidden": "true",
    style: {
      fontSize: 18,
      lineHeight: 1
    }
  }, "+"), " Kasa ekle")), error && React.createElement("p", {
    role: "alert",
    style: {
      fontSize: 12,
      color: "#f87171"
    }
  }, error), msg && React.createElement("p", {
    role: "status",
    style: {
      fontSize: 12,
      color: "#4ade80"
    }
  }, msg));
}
function GirisTab({
  cfg,
  txs,
  saveTxs,
  nakit,
  saveNakit
}) {
  const today = toS(new Date());
  const yesterday = addD(today, -1);
  const [fBanka, setFBanka] = useState(cfg.bankalar[0]?.id || "");
  const [fKasa, setFKasa] = useState(cfg.kasalar[0]?.id || "");
  const [fDate, setFDate] = useState(yesterday);
  const blank = () => ["", "", ""];
  const [krediRows, setKrediRows] = useState(blank());
  const [debitRows, setDebitRows] = useState(blank());
  const [editTx, setEditTx] = useState(null);
  const saveLock = useRef(false);
  const [total, setTotal] = useState(""),
    [entryError, setEntryError] = useState(""),
    [editCash, setEditCash] = useState(null);
  const totalMode = !!cfg.kasalar.find(k => k.id === fKasa)?.toplamModu;
  const allHistory = [...txs, ...nakit.map(n => ({
    ...n,
    cash: true,
    tur: "NAKİT",
    islemTarihi: n.tarih,
    yatacakTarih: n.tarih
  }))].sort((a, b) => b.islemTarihi.localeCompare(a.islemTarihi));
  const [histQuery, setHistQuery] = useState(""),
    [histStart, setHistStart] = useState(""),
    [histEnd, setHistEnd] = useState(""),
    [histPage, setHistPage] = useState({
      nakit: 1,
      pos: 1
    });
  const historyRows = useMemo(() => allHistory.filter(t => {
    const k = cfg.kasalar.find(k => k.id === t.kasaId),
      b = cfg.bankalar.find(b => b.id === t.bankaId);
    return (!histStart || t.islemTarihi >= histStart) && (!histEnd || t.islemTarihi <= histEnd) && (!histQuery || `${k?.ad} ${k?.kod} ${b?.ad} ${t.tur} ${t.tutar}`.toLocaleLowerCase('tr-TR').includes(histQuery.toLocaleLowerCase('tr-TR')));
  }), [txs, nakit, cfg, histQuery, histStart, histEnd]);
  const [delConfirm, setDelConfirm] = useState(null);
  const [editGroup, setEditGroup] = useState(null),
    [deleteError, setDeleteError] = useState("");
  const [saved, setSaved] = useState(false);
  useEffect(() => {
    const bankaIds = cfg.bankalar.map(b => b.id);
    const gb = bankaIds.includes(fBanka) ? fBanka : cfg.bankalar[0]?.id || "";
    setFBanka(gb);
    const ki = cfg.kasalar.filter(k => k.aktif !== false && k.bankaId === gb).map(k => k.id);
    if (!ki.includes(fKasa)) setFKasa(ki[0] || "");
  }, [cfg.bankalar, cfg.kasalar]);
  const kasalarForBanka = cfg.kasalar.filter(k => k.aktif !== false && k.bankaId === fBanka);
  const vadeK = cfg.vadeGunleri["KREDİ KARTI"] ?? 21;
  const vadeD = cfg.vadeGunleri["DEBİT KART"] ?? 16;
  const yatK = fDate ? addD(fDate, vadeK) : "";
  const yatD = fDate ? addD(fDate, vadeD) : "";
  const I = {
    background: "#0f1117",
    border: "1px solid #2d3748",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "8px 11px",
    fontSize: 13,
    fontFamily: "'IBM Plex Mono',monospace",
    width: "100%"
  };
  const handleKasaForBanka = bid => {
    setTotal("");
    setKrediRows(blank());
    setDebitRows(blank());
    setEntryError("");
    setSaved(false);
    setFBanka(bid);
    const ks = cfg.kasalar.filter(k => k.aktif !== false && k.bankaId === bid);
    setFKasa(ks[0]?.id || "");
  };
  const handleSave = () => {
    const selected = cfg.kasalar.find(k => k.id === fKasa);
    if (!selected || selected.aktif === false) {
      alert("Aktif bir kasa seçin.");
      return;
    }
    if (selected.toplamModu) {
      if (saveLock.current) return;
      saveLock.current = true;
      try {
        const result = posYeniToplamEkle({
          txs,
          kasa: selected,
          tarih: fDate,
          toplam: total,
          vade: yatK,
          id: uid()
        });
        if (txs.some(t => t.posToplam != null && t.kasaId === fKasa && t.islemTarihi === fDate) && !confirm("Bu kasa ve gün için POS toplamı zaten var. Önceki kaydı değiştirmeden ayrı bir toplam kaydı daha eklensin mi?")) return;
        saveTxs(result.txs);
        setTotal("");
        setFDate(yesterday);
        setEntryError("");
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      } catch (e) {
        setEntryError(e.message);
      } finally {
        saveLock.current = false;
      }
      return;
    }
    if (!POSGuard.day(fDate) || fDate > today) {
      alert("İşlem tarihi bugün veya geçmiş bir gün olmalı.");
      return;
    }
    const newTxs = [];
    try {
      krediRows.forEach(v => {
        if (!String(v).trim()) return;
        const n = POSGuard.money(v);
        newTxs.push({
          id: uid(),
          kasaId: fKasa,
          bankaId: fBanka,
          islemTarihi: fDate,
          tur: "KREDİ KARTI",
          tutar: n,
          yatacakTarih: yatK
        });
      });
      debitRows.forEach(v => {
        if (!String(v).trim()) return;
        const n = POSGuard.money(v);
        newTxs.push({
          id: uid(),
          kasaId: fKasa,
          bankaId: fBanka,
          islemTarihi: fDate,
          tur: "DEBİT KART",
          tutar: n,
          yatacakTarih: yatD
        });
      });
    } catch (e) {
      alert(e.message);
      return;
    }
    if (!newTxs.length) return;
    try {
      saveTxs([...newTxs, ...txs]);
    } catch (e) {
      setEntryError(e.message);
      return;
    }
    setEntryError("");
    setKrediRows(blank());
    setDebitRows(blank());
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const delTx = id => {
    try {
      if (delConfirm?.cash) {
        saveNakit(nakit.filter(n => n.id !== id));
        if (editCash?.id === id) setEditCash(null);
      } else {
        const next = posGecmistenSil(txs, id);
        saveTxs(next);
      }
      setDelConfirm(null);
      setDeleteError("");
    } catch (e) {
      setDeleteError(e.message);
    }
  };
  const updateTx = upd => {
    if (upd.mutabakatId) {
      alert("Bağlı kayıtları İşlem Geçmişi içindeki düzenleme düğmesinden açın.");
      return;
    }
    saveTxs(txs.map(t => t.id === upd.id ? upd : t));
  };
  return React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #1e293b",
      borderRadius: 12,
      padding: "18px 20px",
      marginBottom: 18
    }
  }, React.createElement("div", {
    style: GIRIS_BASLIK
  }, "YEN\u0130 \u0130\u015ELEM G\u0130R\u0130\u015E\u0130"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap",
      marginBottom: 16,
      alignItems: "flex-end"
    }
  }, React.createElement("div", {
    style: {
      flex: "1 1 160px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "BANKA"), React.createElement("select", {
    value: fBanka,
    onChange: e => handleKasaForBanka(e.target.value),
    style: {
      ...I
    }
  }, cfg.bankalar.map(b => React.createElement("option", {
    key: b.id,
    value: b.id
  }, b.ad)))), React.createElement("div", {
    style: {
      flex: "1 1 160px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "KASA"), React.createElement("select", {
    value: fKasa,
    onChange: e => {
      setFKasa(e.target.value);
      setTotal("");
      setKrediRows(blank());
      setDebitRows(blank());
      setEntryError("");
      setSaved(false);
    },
    style: {
      ...I
    }
  }, kasalarForBanka.map(k => React.createElement("option", {
    key: k.id,
    value: k.id
  }, k.ad, " (", k.kod, ")")))), React.createElement("div", {
    style: {
      flex: "1 1 160px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "\u0130\u015ELEM TAR\u0130H\u0130"), React.createElement("input", {
    type: "date",
    value: fDate,
    onChange: e => setFDate(e.target.value),
    style: {
      ...I
    }
  }))), totalMode ? React.createElement("label", {
    style: {
      display: "block",
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 16
    }
  }, "TOPLAM POS (\u20BA)", React.createElement("input", {
    "aria-label": "Toplam POS tutar\u0131",
    inputMode: "decimal",
    style: {
      ...I,
      marginTop: 5
    },
    value: total,
    onChange: e => {
      setTotal(e.target.value);
      setEntryError("");
      setSaved(false);
    },
    onBlur: () => setTotal(v => posTutarGoster(v))
  })) : React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12,
      marginBottom: 16
    }
  }, React.createElement("div", {
    style: {
      background: "#0f1117",
      border: "1px solid #3b82f633",
      borderRadius: 10,
      padding: "14px 16px"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 7,
      marginBottom: 10
    }
  }, React.createElement("div", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 1,
      background: "#3b82f6"
    }
  }), React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: "#60a5fa",
      letterSpacing: .5
    }
  }, "\uD83D\uDCB3 KRED\u0130 KARTI")), krediRows.map((v, i) => React.createElement("div", {
    key: i,
    style: {
      marginBottom: 8
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginBottom: 4,
      letterSpacing: 1
    }
  }, "TUTAR ", i + 1, " (\u20BA)"), React.createElement(ParaInput, {
    value: v,
    onChange: val => {
      const r = [...krediRows];
      r[i] = val;
      setKrediRows(r);
    },
    onEnter: handleSave,
    style: {
      ...I,
      textAlign: "right"
    }
  })))), React.createElement("div", {
    style: {
      background: "#0f1117",
      border: "1px solid #22c55e33",
      borderRadius: 10,
      padding: "14px 16px"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 7,
      marginBottom: 10
    }
  }, React.createElement("div", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 1,
      background: "#22c55e"
    }
  }), React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: "#4ade80",
      letterSpacing: .5
    }
  }, "\uD83C\uDFE7 DEB\u0130T KART")), debitRows.map((v, i) => React.createElement("div", {
    key: i,
    style: {
      marginBottom: 8
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginBottom: 4,
      letterSpacing: 1
    }
  }, "TUTAR ", i + 1, " (\u20BA)"), React.createElement(ParaInput, {
    value: v,
    onChange: val => {
      const r = [...debitRows];
      r[i] = val;
      setDebitRows(r);
    },
    onEnter: handleSave,
    style: {
      ...I,
      textAlign: "right"
    }
  }))))), entryError && React.createElement("p", {
    role: "alert",
    style: {
      fontSize: 12,
      color: "#f87171"
    }
  }, entryError), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn-hover",
    onClick: handleSave,
    style: POS_KAYDET_STILI
  }, React.createElement(UiIcon, {
    kind: "save"
  }), " KAYDET"), saved && React.createElement("span", {
    className: "fi",
    style: {
      fontSize: 12,
      color: "#4ade80"
    }
  }, "\u2713 Kaydedildi"), React.createElement("span", {
    style: {
      marginLeft: "auto",
      fontSize: 11,
      color: "#94a3b8"
    }
  }, "Kredi vade: ", vadeK, "g \xA0|\xA0 Debit vade: ", vadeD, "g"))), React.createElement(NakitGiris, {
    cfg: cfg,
    nakit: nakit,
    saveNakit: saveNakit,
    editing: editCash,
    onDone: () => setEditCash(null)
  }), React.createElement("section", {
    style: {
      background: "#141825",
      border: "1px solid #1e293b",
      borderRadius: 12,
      padding: "18px 20px",
      marginBottom: 18
    }
  }, React.createElement("div", {
    style: GIRIS_BASLIK
  }, "YATAN DEB\u0130T TAK\u0130B\u0130"), React.createElement(PosYeniDebit, {
    cfg: cfg,
    txs: txs,
    saveTxs: saveTxs
  })), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginBottom: 12,
      flexWrap: "wrap"
    }
  }, React.createElement("input", {
    "aria-label": "Ge\xE7mi\u015Fte ara",
    placeholder: "Kasa, banka, t\xFCr veya tutar ara",
    style: {
      ...I,
      flex: 2,
      minWidth: 180
    },
    value: histQuery,
    onChange: e => {
      setHistQuery(e.target.value);
      setHistPage({
        nakit: 1,
        pos: 1
      });
    }
  }), React.createElement("input", {
    "aria-label": "Ge\xE7mi\u015F ba\u015Flang\u0131\xE7",
    type: "date",
    style: {
      ...I,
      flex: 1
    },
    value: histStart,
    onChange: e => {
      setHistStart(e.target.value);
      setHistPage({
        nakit: 1,
        pos: 1
      });
    }
  }), React.createElement("input", {
    "aria-label": "Ge\xE7mi\u015F biti\u015F",
    type: "date",
    style: {
      ...I,
      flex: 1
    },
    value: histEnd,
    onChange: e => {
      setHistEnd(e.target.value);
      setHistPage({
        nakit: 1,
        pos: 1
      });
    }
  })), histStart && histEnd && histStart > histEnd && React.createElement("p", {
    role: "alert"
  }, "Ba\u015Flang\u0131\xE7 tarihi biti\u015Ften sonra olamaz."), React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #1e293b",
      borderRadius: 12,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "11px 16px",
      borderBottom: "1px solid #1e293b",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase"
    }
  }, "\u0130\u015ELEM GE\xC7M\u0130\u015E\u0130"), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, historyRows.length, " e\u015Fle\u015Fme / ", allHistory.length, " kay\u0131t")), [["nakit", "NAKİT", true], ["pos", "POS", false]].map(([key, label, cash]) => {
    const rows = historyRows.filter(t => !!t.cash === cash),
      pages = Math.max(1, Math.ceil(rows.length / 50)),
      page = Math.min(histPage[key], pages);
    return React.createElement("details", {
      key: key,
      "data-history-group": key,
      style: {
        borderTop: "1px solid #253047"
      }
    }, React.createElement("summary", {
      style: {
        cursor: "pointer",
        padding: "14px 16px",
        fontSize: 12,
        fontWeight: 600,
        color: cash ? "#34d399" : "#60a5fa",
        letterSpacing: 1
      }
    }, label, " ", React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 400,
        color: "#a2b1c6",
        marginLeft: 10
      }
    }, rows.length, " kay\u0131t")), React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr 90px 80px 110px 100px 60px 36px",
        gap: 4,
        padding: "7px 14px",
        borderBottom: "1px solid #1e293b",
        fontSize: 11,
        color: "#a2b1c6",
        letterSpacing: 1
      }
    }, React.createElement("div", null, "BANKA"), React.createElement("div", null, "KASA"), React.createElement("div", null, "\u0130\u015ELEM TAR."), React.createElement("div", null, "T\xDCR"), React.createElement("div", {
      style: {
        textAlign: "right"
      }
    }, "TUTAR"), React.createElement("div", {
      style: {
        textAlign: "center"
      }
    }, "YATACAK"), React.createElement("div", {
      style: {
        textAlign: "center"
      }
    }, "G\xDCNCELLE"), React.createElement("div", null)), React.createElement("div", {
      style: {
        maxHeight: 440,
        overflowY: "auto"
      }
    }, rows.length === 0 && React.createElement("div", {
      style: {
        textAlign: "center",
        padding: "40px",
        color: "#94a3b8",
        fontSize: 12
      }
    }, "Hen\xFCz kay\u0131t yok"), rows.slice((page - 1) * 50, page * 50).map((t, i) => {
      const kasa = cfg.kasalar.find(k => k.id === t.kasaId);
      const banka = cfg.bankalar.find(b => b.id === t.bankaId);
      const bi = cfg.bankalar.findIndex(b => b.id === t.bankaId);
      const col = BCOLS[bi % BCOLS.length] || "#94a3b8";
      const isK = t.tur === "KREDİ KARTI";
      return React.createElement("div", {
        key: t.id,
        "data-tx-id": t.id,
        className: "row-hover",
        style: {
          display: "grid",
          gridTemplateColumns: "1fr 1fr 90px 80px 110px 100px 60px 36px",
          gap: 4,
          padding: "8px 14px",
          background: i % 2 === 0 ? "transparent" : "#0d1020",
          borderBottom: "1px solid #1e293b1a",
          alignItems: "center",
          fontSize: 12,
          transition: "background .1s"
        }
      }, React.createElement("div", {
        style: {
          color: col,
          fontSize: 11
        }
      }, banka?.ad || "-"), React.createElement("div", {
        style: {
          color: "#e2e8f0"
        }
      }, kasa?.ad || t.kasaId), React.createElement("div", {
        style: {
          color: "#94a3b8",
          fontSize: 11
        }
      }, fDSh(t.islemTarihi)), React.createElement("div", null, React.createElement("span", {
        style: {
          fontSize: 11,
          padding: "2px 7px",
          borderRadius: 4,
          fontWeight: 600,
          background: isK ? "#1e3a5f22" : "#14301f22",
          color: isK ? "#60a5fa" : "#4ade80",
          border: `1px solid ${isK ? "#3b82f633" : "#22c55e33"}`
        }
      }, t.cash ? "NAKİT" : isK ? "KREDİ" : "DEBİT")), React.createElement("div", {
        style: {
          textAlign: "right",
          fontWeight: 600,
          color: "#f1f5f9"
        }
      }, "\u20BA ", fmt(t.tutar)), React.createElement("div", {
        style: {
          textAlign: "center",
          fontSize: 11,
          color: "#4ade80"
        }
      }, t.cash ? "–" : fDSh(t.yatacakTarih)), React.createElement("div", {
        style: {
          textAlign: "center"
        }
      }, React.createElement("button", {
        "aria-label": "\u0130\u015Flemi d\xFCzenle",
        onClick: () => {
          if (t.cash) {
            setEditCash(nakit.find(n => n.id === t.id));
            return;
          }
          if (t.mutabakatId) {
            setEditGroup(t.mutabakatId);
            return;
          }
          setEditTx(t);
        },
        style: {
          background: "#1e3a5f",
          border: "1px solid #3b82f633",
          borderRadius: 6,
          color: "#60a5fa",
          cursor: "pointer",
          padding: "3px 8px",
          fontSize: 11,
          fontFamily: "inherit"
        }
      }, React.createElement(UiIcon, {
        kind: "edit"
      }))), React.createElement("div", {
        style: {
          textAlign: "center"
        }
      }, React.createElement("button", {
        "aria-label": "\u0130\u015Flemi sil",
        onClick: () => {
          setDeleteError("");
          setDelConfirm(t);
        },
        style: {
          background: "none",
          border: "none",
          color: "#94a3b8",
          cursor: "pointer",
          fontSize: 13,
          fontFamily: "inherit",
          transition: "color .15s"
        },
        onMouseEnter: e => e.target.style.color = "#ef4444",
        onMouseLeave: e => e.target.style.color = "#94a3b8"
      }, React.createElement(UiIcon, {
        kind: "close"
      }))));
    }), React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        alignItems: "center",
        justifyContent: "center",
        padding: 12,
        fontSize: 12
      }
    }, React.createElement("button", {
      disabled: page <= 1,
      onClick: () => setHistPage(v => ({
        ...v,
        [key]: page - 1
      }))
    }, "\xD6nceki"), React.createElement("span", null, "Sayfa ", page, " / ", pages, " \xB7 ", rows.length, " e\u015Fle\u015Fme"), React.createElement("button", {
      disabled: page >= pages,
      onClick: () => setHistPage(v => ({
        ...v,
        [key]: page + 1
      }))
    }, "Sonraki"))));
  })), editGroup && React.createElement(PosMutabakat, {
    cfg: cfg,
    txs: txs,
    saveTxs: saveTxs,
    initialId: editGroup,
    onClose: () => setEditGroup(null)
  }), editTx && React.createElement(EditModal, {
    tx: editTx,
    cfg: cfg,
    onSave: upd => {
      updateTx(upd);
      setEditTx(null);
    },
    onClose: () => setEditTx(null)
  }), delConfirm && (() => {
    const kasa = cfg.kasalar.find(k => k.id === delConfirm.kasaId);
    return React.createElement("div", {
      style: {
        position: "fixed",
        inset: 0,
        background: "#00000099",
        zIndex: 500,
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, React.createElement("div", {
      style: {
        background: "#141825",
        border: "1px solid #ef4444",
        borderRadius: 14,
        padding: "26px",
        width: 400,
        maxWidth: "90vw",
        textAlign: "center"
      }
    }, React.createElement("div", {
      style: {
        fontSize: 26,
        marginBottom: 10
      }
    }, "\u26A0\uFE0F"), React.createElement("div", {
      style: {
        fontSize: 14,
        color: "#f1f5f9",
        fontWeight: 600,
        marginBottom: 10
      }
    }, "\u0130\u015Flemi Sil"), React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 6
      }
    }, kasa?.ad || "", " \xB7 ", delConfirm.cash ? "NAKİT" : delConfirm.tur === "KREDİ KARTI" ? "KREDİ" : "DEBİT", " \xB7 ", React.createElement("span", {
      style: {
        color: "#f1f5f9",
        fontWeight: 600
      }
    }, "\u20BA", fmt(delConfirm.tutar))), React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#f87171",
        marginBottom: 18
      }
    }, delConfirm.mutabakatId ? delConfirm.posToplam != null ? "Bu POS toplamı ve ona bağlı tüm debitler silinecek. Emin misiniz?" : "Yalnız bu debit silinecek; tutarı kalan krediye geri eklenecek. Emin misiniz?" : "Bu işlem kalıcı olarak silinecek. Emin misiniz?"), deleteError && React.createElement("p", {
      role: "alert",
      style: {
        color: "#f87171",
        fontSize: 12,
        marginBottom: 12
      }
    }, deleteError), React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        justifyContent: "center"
      }
    }, React.createElement("button", {
      onClick: () => setDelConfirm(null),
      style: {
        background: "#1e293b",
        border: "1px solid #2d3748",
        borderRadius: 8,
        color: "#94a3b8",
        cursor: "pointer",
        padding: "9px 22px",
        fontSize: 12,
        fontFamily: "inherit"
      }
    }, "\u0130ptal"), React.createElement("button", {
      className: "btn-hover",
      onClick: () => delTx(delConfirm.id),
      style: {
        background: "#7f1d1d",
        border: "1px solid #ef4444",
        borderRadius: 8,
        color: "#f87171",
        cursor: "pointer",
        padding: "9px 22px",
        fontSize: 12,
        fontFamily: "inherit",
        fontWeight: 600
      }
    }, "Evet, Sil"))));
  })());
}
function EditModal({
  tx,
  cfg,
  onSave,
  onClose
}) {
  const [fKasa, setFKasa] = useState(tx.kasaId);
  const [fBanka, setFBanka] = useState(tx.bankaId);
  const [fDate, setFDate] = useState(tx.islemTarihi);
  const [fTur, setFTur] = useState(tx.tur);
  const [fTutar, setFTutar] = useState(String(tx.tutar));
  const [fYat, setFYat] = useState(tx.yatacakTarih);
  const I = {
    background: "#0f1117",
    border: "1px solid #2d3748",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "9px 12px",
    fontSize: 13,
    fontFamily: "'IBM Plex Mono',monospace",
    width: "100%"
  };
  const calc = (d, tur) => posVadeTarihi(d, cfg.vadeGunleri[tur || fTur] ?? 0);
  const handleSave = () => {
    try {
      const n = POSGuard.money(fTutar);
      const next = {
        ...tx,
        kasaId: fKasa,
        bankaId: fBanka,
        islemTarihi: fDate,
        tur: fTur,
        tutar: n,
        yatacakTarih: fYat
      };
      POSGuard.transaction(next, cfg);
      if (fDate > toS(new Date())) throw Error("İşlem tarihi gelecekte olamaz.");
      if (cfg.kasalar.find(k => k.id === fKasa)?.bankaId !== fBanka && fKasa !== tx.kasaId) throw Error("Kasa seçilen bankaya ait değil.");
      onSave(next);
    } catch (e) {
      alert(e.message);
    }
  };
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "#00000088",
      zIndex: 500,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    onClick: e => e.target === e.currentTarget && onClose()
  }, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #3b82f6",
      borderRadius: 14,
      padding: "24px",
      width: 480,
      maxWidth: "95vw"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 18
    }
  }, React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: "#f1f5f9"
    }
  }, "\u270F\uFE0F \u0130\u015Flemi G\xFCncelle"), React.createElement("button", {
    "aria-label": "Kapat",
    onClick: onClose,
    style: {
      background: "none",
      border: "none",
      color: "#a2b1c6",
      cursor: "pointer",
      fontSize: 18
    }
  }, React.createElement(UiIcon, {
    kind: "close"
  }))), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 10,
      marginBottom: 10
    }
  }, cfg.bankalar.length > 1 && React.createElement("div", {
    style: {
      gridColumn: "1/-1"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "BANKA"), React.createElement("select", {
    value: fBanka,
    onChange: e => {
      setFBanka(e.target.value);
      setFKasa(cfg.kasalar.find(k => k.bankaId === e.target.value && k.aktif !== false)?.id || "");
    },
    style: {
      ...I
    }
  }, cfg.bankalar.map(b => React.createElement("option", {
    key: b.id,
    value: b.id
  }, b.ad)))), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "KASA"), React.createElement("select", {
    value: fKasa,
    onChange: e => setFKasa(e.target.value),
    style: {
      ...I
    }
  }, cfg.kasalar.filter(k => k.bankaId === fBanka && k.aktif !== false || k.id === tx.kasaId && fBanka === tx.bankaId).map(k => React.createElement("option", {
    key: k.id,
    value: k.id
  }, k.ad)))), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "\u0130\u015ELEM TAR\u0130H\u0130"), React.createElement("input", {
    "aria-label": "D\xFCzenlenen i\u015Flem g\xFCn\xFC",
    type: "date",
    value: fDate,
    onChange: e => {
      setFDate(e.target.value);
      setFYat(calc(e.target.value));
    },
    style: {
      ...I
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "KART T\xDCR\xDC"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 6
    }
  }, ["KREDİ KARTI", "DEBİT KART"].map(t => React.createElement("button", {
    key: t,
    onClick: () => {
      setFTur(t);
      setFYat(calc(fDate, t));
    },
    style: {
      flex: 1,
      background: fTur === t ? t === "KREDİ KARTI" ? "#1e3a5f" : "#14301f" : "#0f1117",
      border: `1px solid ${fTur === t ? t === "KREDİ KARTI" ? "#3b82f6" : "#22c55e" : "#2d3748"}`,
      borderRadius: 7,
      color: fTur === t ? t === "KREDİ KARTI" ? "#60a5fa" : "#4ade80" : "#a2b1c6",
      cursor: "pointer",
      padding: "9px 4px",
      fontSize: 11,
      fontFamily: "inherit"
    }
  }, t === "KREDİ KARTI" ? "KREDİ" : "DEBİT")))), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "TUTAR (\u20BA)"), React.createElement(ParaInput, {
    value: fTutar,
    onChange: setFTutar,
    style: {
      ...I,
      textAlign: "right"
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "YATACAK TAR\u0130H"), React.createElement("input", {
    "aria-label": "D\xFCzenlenen yat\u0131\u015F g\xFCn\xFC",
    type: "date",
    value: fYat,
    onChange: e => setFYat(e.target.value),
    style: {
      ...I
    }
  }))), React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 8,
      marginTop: 6
    }
  }, React.createElement("button", {
    onClick: onClose,
    style: {
      background: "#1e293b",
      border: "1px solid #2d3748",
      borderRadius: 8,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "9px 20px",
      fontSize: 12,
      fontFamily: "inherit"
    }
  }, "\u0130ptal"), React.createElement("button", {
    className: "btn-hover",
    onClick: handleSave,
    style: {
      background: "#166534",
      border: "1px solid #22c55e",
      borderRadius: 8,
      color: "#4ade80",
      cursor: "pointer",
      padding: "9px 20px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\u2713 G\xFCncelle"))));
}
const KUPUR_RENK = {
  200: "#f59e0b",
  100: "#3b82f6",
  50: "#8b5cf6",
  20: "#22c55e",
  10: "#06b6d4",
  5: "#f97316"
};
const DENOMINATIONS = [{
  key: "c200",
  label: "200 TL",
  val: 200,
  color: "#f59e0b"
}, {
  key: "c100",
  label: "100 TL",
  val: 100,
  color: "#3b82f6"
}, {
  key: "c50",
  label: "50 TL",
  val: 50,
  color: "#8b5cf6"
}, {
  key: "c20",
  label: "20 TL",
  val: 20,
  color: "#22c55e"
}, {
  key: "c10",
  label: "10 TL",
  val: 10,
  color: "#06b6d4"
}, {
  key: "c5k",
  label: "5 TL (Kağıt)",
  val: 5,
  color: "#f97316"
}, {
  key: "c5m",
  label: "5 TL (Madeni)",
  val: 5,
  color: "#94a3b8"
}];
function NakitPlanTab({
  txs,
  odemeler,
  plan,
  savePlan
}) {
  const set = (k, v) => savePlan({
    ...plan,
    [k]: v
  });
  const num = v => parseTR(v);
  const temizle = () => savePlan({
    bakiyeTarihi: "",
    odemeGunu: "",
    maasTarihi: "",
    maasTutari: "",
    bankaBakiye: "",
    nakitTahmini: "",
    bugunPosHaric: true,
    maasGunuPosHaric: true
  });
  const I = {
    background: "#0f1117",
    border: "1px solid #2d3748",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "9px 12px",
    fontSize: 13,
    fontFamily: "'IBM Plex Mono',monospace",
    width: "100%"
  };
  const hesap = useMemo(() => {
    const bt = plan.bakiyeTarihi,
      og = plan.odemeGunu,
      mt = plan.maasTarihi;
    if (!bt || !og || !mt || og < bt || mt < og) return null;
    const aBas = plan.bugunPosHaric ? addD(bt, 1) : bt;
    const aBit = og;
    const bBas = addD(og, 1);
    const bBit = plan.maasGunuPosHaric ? addD(mt, -1) : mt;
    let posA = 0,
      posB = 0;
    const posGun = {};
    txs.forEach(t => {
      if (t.tahsilEdildi) return;
      const y = t.yatacakTarih;
      posGun[y] = (posGun[y] || 0) + t.tutar;
      if (y >= aBas && y <= aBit) posA += t.tutar;
      if (y >= bBas && y <= bBit) posB += t.tutar;
    });
    let giderA = 0,
      giderB = 0;
    const giderGun = {};
    const listA = [],
      listB = [];
    odemeler.forEach(o => {
      if (o.odendi) return;
      const s = o.sonOdeme;
      if (s >= bt && s <= og) {
        giderA += o.tutar;
        listA.push(o);
        giderGun[s] = (giderGun[s] || 0) + o.tutar;
      } else if (s >= bBas && s <= mt) {
        giderB += o.tutar;
        listB.push(o);
        giderGun[s] = (giderGun[s] || 0) + o.tutar;
      }
    });
    const maas = num(plan.maasTutari),
      banka = num(plan.bankaBakiye),
      nakit = num(plan.nakitTahmini);
    const odemeGunuBakiye = banka + nakit + posA - giderA;
    const maasRezerv = Math.max(0, maas + giderB - posB);
    const odenebilir = odemeGunuBakiye - maasRezerv;
    const maasGunuBakiye = odemeGunuBakiye + posB - giderB;
    const gunler = [];
    let bakiye = banka;
    let d = bt;
    let guard = 0;
    while (d <= mt && guard < 400) {
      let pIn = posGun[d] || 0;
      if (d === bt && plan.bugunPosHaric) pIn = 0;
      if (d === mt && plan.maasGunuPosHaric) pIn = 0;
      const gOut = giderGun[d] || 0;
      if (d === bt) bakiye += nakit;
      bakiye += pIn - gOut;
      gunler.push({
        tarih: d,
        pos: pIn,
        gider: gOut,
        bakiye,
        odemeGunu: d === og,
        maasGunu: d === mt
      });
      d = addD(d, 1);
      guard++;
    }
    return {
      posA,
      posB,
      giderA,
      giderB,
      listA,
      listB,
      maas,
      banka,
      nakit,
      odemeGunuBakiye,
      maasRezerv,
      odenebilir,
      maasGunuBakiye,
      gunler,
      aBas,
      aBit,
      bBas,
      bBit
    };
  }, [txs, odemeler, plan]);
  const yeterli = hesap && hesap.odenebilir >= 0;
  return React.createElement(React.Fragment, null, React.createElement(Card, {
    title: "PLANLAMA B\u0130LG\u0130LER\u0130",
    accent: "#eab308"
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill,minmax(168px,1fr))",
      gap: 11,
      marginBottom: 12
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "BUG\xDCN (BAK\u0130YE TAR\u0130H\u0130)"), React.createElement("input", {
    type: "date",
    value: plan.bakiyeTarihi,
    onChange: e => set("bakiyeTarihi", e.target.value),
    style: {
      ...I
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "F\u0130RMA \xD6DEME G\xDCN\xDC"), React.createElement("input", {
    type: "date",
    value: plan.odemeGunu,
    onChange: e => set("odemeGunu", e.target.value),
    style: {
      ...I,
      border: "1px solid #22c55e55"
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "MAA\u015E \xD6DEME TAR\u0130H\u0130"), React.createElement("input", {
    type: "date",
    value: plan.maasTarihi,
    onChange: e => set("maasTarihi", e.target.value),
    style: {
      ...I,
      border: "1px solid #eab30855"
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "MAA\u015E TUTARI (\u20BA)"), React.createElement(ParaInput, {
    value: plan.maasTutari,
    onChange: v => set("maasTutari", v),
    style: {
      ...I,
      border: "1px solid #eab30855",
      textAlign: "right"
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "BANKADAK\u0130 PARA (\u20BA)"), React.createElement(ParaInput, {
    value: plan.bankaBakiye,
    onChange: v => set("bankaBakiye", v),
    style: {
      ...I,
      textAlign: "right"
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "TAHM\u0130N\u0130 NAK\u0130T G\u0130R\u0130\u015E\u0130 (\u20BA)"), React.createElement(ParaInput, {
    value: plan.nakitTahmini,
    onChange: v => set("nakitTahmini", v),
    style: {
      ...I,
      textAlign: "right"
    }
  }))), React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      flexWrap: "wrap",
      alignItems: "center"
    }
  }, React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 7,
      cursor: "pointer",
      fontSize: 11,
      color: plan.bugunPosHaric ? "#fbbf24" : "#a2b1c6"
    }
  }, React.createElement("input", {
    type: "checkbox",
    checked: plan.bugunPosHaric,
    onChange: e => set("bugunPosHaric", e.target.checked)
  }), "Bug\xFCn yatan POS'u sayma ", React.createElement("span", {
    style: {
      color: "#94a3b8"
    }
  }, "(bakiyeye zaten girdiyse)")), React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 7,
      cursor: "pointer",
      fontSize: 11,
      color: plan.maasGunuPosHaric ? "#fbbf24" : "#a2b1c6"
    }
  }, React.createElement("input", {
    type: "checkbox",
    checked: plan.maasGunuPosHaric,
    onChange: e => set("maasGunuPosHaric", e.target.checked)
  }), "Maa\u015F g\xFCn\xFC yatacak POS'lar\u0131 sayma ", React.createElement("span", {
    style: {
      color: "#94a3b8"
    }
  }, "(maa\u015F gece \xF6dendi\u011Fi i\xE7in)")), React.createElement("button", {
    className: "btn-hover",
    onClick: temizle,
    style: {
      marginLeft: "auto",
      background: "#1e293b",
      border: "1px solid #475569",
      borderRadius: 8,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "8px 18px",
      fontSize: 11,
      fontFamily: "inherit",
      fontWeight: 600,
      letterSpacing: 1
    }
  }, "\uD83D\uDD04 TEM\u0130ZLE"))), !hesap ? React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "30px",
      color: "#94a3b8",
      fontSize: 12,
      background: "#141825",
      borderRadius: 12,
      border: "1px dashed #2d3748"
    }
  }, "Tarih s\u0131ras\u0131: Bug\xFCn \u2264 Firma \xF6deme g\xFCn\xFC \u2264 Maa\u015F tarihi olmal\u0131") : React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12,
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      background: yeterli ? "linear-gradient(135deg,#0f2418,#14301f)" : "linear-gradient(135deg,#2d1414,#3d1a1a)",
      border: `1px solid ${yeterli ? "#22c55e" : "#ef4444"}`,
      borderRadius: 12,
      padding: "18px 22px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: yeterli ? "#15803d" : "#991b1b",
      letterSpacing: 2,
      textTransform: "uppercase",
      marginBottom: 6
    }
  }, yeterli ? `${fDSh(plan.odemeGunu)} FİRMALARA ÖDEYEBİLECEĞİM` : "⚠ AÇIK VAR"), React.createElement("div", {
    style: {
      fontSize: 30,
      fontWeight: 700,
      color: yeterli ? "#4ade80" : "#f87171",
      letterSpacing: -1
    }
  }, "\u20BA ", fmt(Math.abs(hesap.odenebilir))), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#78716c",
      marginTop: 5
    }
  }, yeterli ? "Bu tutara kadar ödeme yapabilirsin" : "Maaş için bu kadar eksik kalıyor")), React.createElement("div", {
    style: {
      background: "linear-gradient(135deg,#2a2410,#3d3418)",
      border: "1px solid #eab308",
      borderRadius: 12,
      padding: "18px 22px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a16207",
      letterSpacing: 2,
      textTransform: "uppercase",
      marginBottom: 6
    }
  }, "MAA\u015E \u0130\xC7\u0130N AYIRMAM GEREKEN"), React.createElement("div", {
    style: {
      fontSize: 30,
      fontWeight: 700,
      color: "#fbbf24",
      letterSpacing: -1
    }
  }, "\u20BA ", fmt(hesap.maasRezerv)), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#78716c",
      marginTop: 5
    }
  }, hesap.maasRezerv === 0 ? "Sonraki POS girişleri maaşı karşılıyor" : `${fDSh(plan.maasTarihi)} maaşı için`))), React.createElement(Card, {
    title: "HESAP D\xD6K\xDCM\xDC",
    accent: "#3b82f6"
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#22c55e",
      letterSpacing: 1,
      marginBottom: 6,
      fontWeight: 600
    }
  }, "\u2460 \xD6DEME G\xDCN\xDC ELDEK\u0130 PARA"), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1,
      fontSize: 12,
      marginBottom: 12
    }
  }, [["Bankadaki para", hesap.banka, "#e2e8f0", ""], [`Yatacak POS (${fDSh(hesap.aBas)} → ${fDSh(hesap.aBit)})`, hesap.posA, "#93c5fd", "+"], ["Tahmini nakit girişi", hesap.nakit, "#93c5fd", "+"], ["Ödeme gününe kadarki ödemeler", hesap.giderA, "#f87171", "−"]].map(([lbl, val, renk, isaret], i) => React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "8px 12px",
      background: i % 2 === 0 ? "#0f1117" : "transparent",
      borderRadius: 6
    }
  }, React.createElement("span", {
    style: {
      color: "#94a3b8"
    }
  }, isaret, " ", lbl), React.createElement("span", {
    style: {
      color: renk,
      fontWeight: 600
    }
  }, "\u20BA ", fmt(val)))), React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "9px 12px",
      borderTop: "1px solid #2d3748",
      marginTop: 3
    }
  }, React.createElement("span", {
    style: {
      color: "#cbd5e1",
      fontWeight: 600
    }
  }, "= \xD6deme g\xFCn\xFC eldeki para"), React.createElement("span", {
    style: {
      color: "#f1f5f9",
      fontWeight: 700,
      fontSize: 14
    }
  }, "\u20BA ", fmt(hesap.odemeGunuBakiye)))), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#eab308",
      letterSpacing: 1,
      marginBottom: 6,
      fontWeight: 600
    }
  }, "\u2461 MAA\u015E \u0130\xC7\u0130N AYRILACAK"), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1,
      fontSize: 12,
      marginBottom: 12
    }
  }, [["Maaş tutarı", hesap.maas, "#fbbf24", "+"], ["Maaşa kadarki diğer ödemeler", hesap.giderB, "#f87171", "+"], [`Maaşa kadar yatacak POS (${fDSh(hesap.bBas)} → ${fDSh(hesap.bBit)})`, hesap.posB, "#93c5fd", "−"]].map(([lbl, val, renk, isaret], i) => React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "8px 12px",
      background: i % 2 === 0 ? "#0f1117" : "transparent",
      borderRadius: 6
    }
  }, React.createElement("span", {
    style: {
      color: "#94a3b8"
    }
  }, isaret, " ", lbl), React.createElement("span", {
    style: {
      color: renk,
      fontWeight: 600
    }
  }, "\u20BA ", fmt(val)))), React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "9px 12px",
      background: "#1a1508",
      borderRadius: 6,
      marginTop: 3
    }
  }, React.createElement("span", {
    style: {
      color: "#a16207",
      fontWeight: 600
    }
  }, "= Maa\u015F i\xE7in ayr\u0131lacak"), React.createElement("span", {
    style: {
      color: "#fbbf24",
      fontWeight: 700,
      fontSize: 14
    }
  }, "\u20BA ", fmt(hesap.maasRezerv)))), React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "12px 14px",
      background: yeterli ? "#0f2418" : "#2d1414",
      borderRadius: 8,
      border: `1px solid ${yeterli ? "#22c55e44" : "#ef444444"}`
    }
  }, React.createElement("span", {
    style: {
      color: yeterli ? "#4ade80" : "#f87171",
      fontWeight: 700,
      fontSize: 13
    }
  }, "\u2460 \u2212 \u2461 = F\u0130RMALARA \xD6DENEB\u0130L\u0130R"), React.createElement("span", {
    style: {
      color: yeterli ? "#4ade80" : "#f87171",
      fontWeight: 700,
      fontSize: 16
    }
  }, "\u20BA ", fmt(hesap.odenebilir))), (hesap.listA.length > 0 || hesap.listB.length > 0) && React.createElement("div", {
    style: {
      marginTop: 12,
      paddingTop: 12,
      borderTop: "1px solid #1e293b"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      marginBottom: 7
    }
  }, "D\xDC\u015E\xDCLEN \xD6DEMELER"), React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 6
    }
  }, [...hesap.listA, ...hesap.listB].map(o => React.createElement("span", {
    key: o.id,
    style: {
      fontSize: 11,
      background: "#2d1414",
      border: "1px solid #ef444433",
      borderRadius: 6,
      padding: "4px 9px",
      color: "#fca5a5"
    }
  }, o.ad, " \xB7 \u20BA", fmt(o.tutar), " \xB7 ", fDSh(o.sonOdeme)))))), React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #1e293b",
      borderRadius: 12,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "11px 16px",
      borderBottom: "1px solid #1e293b",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase"
    }
  }, "G\xDCN G\xDCN BAK\u0130YE (hi\xE7 \xF6deme yap\u0131lmazsa)"), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, hesap.gunler.length, " g\xFCn")), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "140px 1fr 1fr 1fr",
      gap: 6,
      padding: "7px 16px",
      borderBottom: "1px solid #1e293b",
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1
    }
  }, React.createElement("div", null, "TAR\u0130H"), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, "POS G\u0130R\u0130\u015E\u0130"), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, "\xD6DEME"), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, "BAK\u0130YE")), React.createElement("div", {
    style: {
      maxHeight: 340,
      overflowY: "auto"
    }
  }, hesap.gunler.map((g, i) => {
    const vurgu = g.maasGunu ? "#eab308" : g.odemeGunu ? "#22c55e" : null;
    return React.createElement("div", {
      key: g.tarih,
      className: "row-hover",
      style: {
        display: "grid",
        gridTemplateColumns: "140px 1fr 1fr 1fr",
        gap: 6,
        padding: "8px 16px",
        background: g.maasGunu ? "#2a241055" : g.odemeGunu ? "#0f241855" : i % 2 === 0 ? "transparent" : "#0d1020",
        borderBottom: "1px solid #1e293b1a",
        borderLeft: `3px solid ${vurgu || "transparent"}`,
        alignItems: "center",
        fontSize: 12
      }
    }, React.createElement("div", {
      style: {
        color: vurgu || "#e2e8f0",
        fontWeight: vurgu ? 700 : 400
      }
    }, fDSh(g.tarih), g.odemeGunu && React.createElement("span", {
      style: {
        fontSize: 9,
        marginLeft: 5
      }
    }, "\xD6DEME"), g.maasGunu && React.createElement("span", {
      style: {
        fontSize: 9,
        marginLeft: 5
      }
    }, "MAA\u015E")), React.createElement("div", {
      style: {
        textAlign: "right",
        color: g.pos > 0 ? "#93c5fd" : "#334155"
      }
    }, g.pos > 0 ? "+ ₺" + fmt(g.pos) : "—"), React.createElement("div", {
      style: {
        textAlign: "right",
        color: g.gider > 0 ? "#f87171" : "#334155"
      }
    }, g.gider > 0 ? "− ₺" + fmt(g.gider) : "—"), React.createElement("div", {
      style: {
        textAlign: "right",
        fontWeight: 600,
        color: g.bakiye >= 0 ? "#f1f5f9" : "#f87171"
      }
    }, "\u20BA ", fmt(g.bakiye)));
  })))));
}
function AylikOdemeler({
  odemeler,
  saveOdemeler
}) {
  const today = toS(new Date());
  const [ad, setAd] = useState("");
  const [tutar, setTutar] = useState("");
  const [tarih, setTarih] = useState("");
  const [silId, setSilId] = useState(null);
  const [openMonths, setOpenMonths] = useState({}),
    [error, setError] = useState("");
  const report = useMemo(() => odemeAyOzeti(odemeler, today), [odemeler, today]);
  const monthName = ym => new Date(ym + "-01T12:00:00Z").toLocaleDateString("tr-TR", {
    month: "long",
    year: "numeric",
    timeZone: "UTC"
  });
  const pct = n => Math.abs(n).toLocaleString("tr-TR", {
    maximumFractionDigits: 1
  });
  const [editOdeme, setEditOdeme] = useState(null);
  const [editAd, setEditAd] = useState("");
  const [editTutar, setEditTutar] = useState("");
  const I = {
    background: "#0f1117",
    border: "1px solid #2d3748",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "9px 12px",
    fontSize: 13,
    fontFamily: "'IBM Plex Mono',monospace",
    width: "100%"
  };
  const ekle = () => {
    try {
      const t = POSGuard.money(tutar);
      if (!ad.trim()) throw Error("Ödeme adını girin.");
      if (!POSGuard.day(tarih)) throw Error("Geçerli bir son ödeme tarihi seçin.");
      saveOdemeler([{
        id: uid(),
        ad: ad.trim(),
        tutar: t,
        sonOdeme: tarih,
        odendi: false
      }, ...odemeler]);
      setAd("");
      setTutar("");
      setTarih("");
      setError("");
    } catch (e) {
      setError(e.message);
    }
  };
  const toggle = id => {
    try {
      saveOdemeler(odemeler.map(o => o.id === id ? {
        ...o,
        odendi: !o.odendi
      } : o));
      setError("");
    } catch (e) {
      setError(e.message);
    }
  };
  const sil = id => {
    try {
      saveOdemeler(odemeler.filter(o => o.id !== id));
      setSilId(null);
      setError("");
    } catch (e) {
      setError(e.message);
    }
  };
  const updateTarih = (id, yeni) => {
    if (!POSGuard.day(yeni)) return;
    try {
      saveOdemeler(odemeler.map(o => o.id === id ? {
        ...o,
        sonOdeme: yeni
      } : o));
      setError("");
    } catch (e) {
      setError(e.message);
    }
  };
  const openEdit = o => {
    setError("");
    setEditOdeme(o);
    setEditAd(o.ad);
    setEditTutar(String(o.tutar));
  };
  const saveEdit = () => {
    try {
      const t = POSGuard.money(editTutar);
      if (!editAd.trim()) throw Error("Ödeme adını girin.");
      saveOdemeler(odemeler.map(o => o.id === editOdeme.id ? {
        ...o,
        ad: editAd.trim(),
        tutar: t
      } : o));
      setEditOdeme(null);
      setError("");
    } catch (e) {
      setError(e.message);
    }
  };
  const bekleyenToplam = odemeler.filter(o => !o.odendi).reduce((s, o) => s + o.tutar, 0);
  const bekleyenAdet = odemeler.filter(o => !o.odendi).length;
  const gunFark = t => {
    const d = new Date(t + "T00:00:00");
    const b = new Date(today + "T00:00:00");
    return Math.round((d - b) / 86400000);
  };
  return React.createElement("div", {
    style: {
      marginTop: 20,
      background: "#141825",
      border: "1px solid #f9731633",
      borderRadius: 12,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "12px 16px",
      borderBottom: "1px solid #1e293b",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("div", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 1,
      background: "#f97316"
    }
  }), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase"
    }
  }, "AYLIK \xD6DEME TAK\u0130B\u0130")), bekleyenAdet > 0 && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "#fb923c"
    }
  }, "Bekleyen: ", React.createElement("b", null, "\u20BA", fmt(bekleyenToplam)), " (", bekleyenAdet, ")")), React.createElement("div", {
    style: {
      padding: "16px 18px"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap",
      alignItems: "flex-end",
      marginBottom: 16
    }
  }, React.createElement("div", {
    style: {
      flex: "2 1 200px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "\xD6DEME ADI"), React.createElement("input", {
    "aria-label": "Yeni \xF6deme ad\u0131",
    value: ad,
    placeholder: "Kira, elektrik, internet...",
    onChange: e => setAd(e.target.value),
    onKeyDown: e => e.key === "Enter" && ekle(),
    style: {
      ...I
    }
  })), React.createElement("div", {
    style: {
      flex: "1 1 120px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "TUTAR (\u20BA)"), React.createElement(ParaInput, {
    value: tutar,
    onChange: setTutar,
    onEnter: ekle,
    style: {
      ...I,
      textAlign: "right"
    }
  })), React.createElement("div", {
    style: {
      flex: "1 1 150px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "SON \xD6DEME TAR\u0130H\u0130"), React.createElement("input", {
    "aria-label": "Yeni \xF6deme son tarihi",
    type: "date",
    value: tarih,
    onChange: e => setTarih(e.target.value),
    style: {
      ...I
    }
  })), React.createElement("button", {
    onClick: ekle,
    style: {
      background: "#7c2d12",
      border: "1px solid #f97316",
      borderRadius: 8,
      color: "#fb923c",
      cursor: "pointer",
      padding: "9px 20px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600,
      letterSpacing: 1
    }
  }, "+ EKLE")), error && !silId && !editOdeme && React.createElement("p", {
    role: "alert",
    style: {
      fontSize: 12,
      color: "#f87171",
      marginBottom: 12
    }
  }, error), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, report.groups.map(g => {
    const open = Object.hasOwn(openMonths, g.ay) ? openMonths[g.ay] : g.ay === report.current;
    return React.createElement("section", {
      key: g.ay,
      "data-payment-month": g.ay,
      style: {
        border: "1px solid #253047",
        borderRadius: 9,
        overflow: "hidden"
      }
    }, React.createElement("button", {
      "aria-expanded": open,
      "aria-controls": "payments-" + g.ay,
      "aria-label": monthName(g.ay) + " ödemeleri",
      onClick: () => setOpenMonths(v => ({
        ...v,
        [g.ay]: !open
      })),
      style: {
        width: "100%",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: 12,
        padding: "12px 14px",
        background: "#0f1117",
        border: 0,
        color: "#e2e8f0",
        cursor: "pointer",
        fontFamily: "inherit",
        fontSize: 12,
        textAlign: "left"
      }
    }, React.createElement("span", null, open ? "▾" : "▸", " ", monthName(g.ay), " ", React.createElement("span", {
      style: {
        color: "#94a3b8",
        fontSize: 11
      }
    }, "(", g.items.length, ")")), React.createElement("span", {
      style: {
        fontWeight: 600
      }
    }, "\u20BA ", fmt(g.toplam))), open && React.createElement("div", {
      id: "payments-" + g.ay,
      style: {
        padding: 8,
        display: "flex",
        flexDirection: "column",
        gap: 7
      }
    }, g.items.length ? g.items.map(o => {
      const gun = gunFark(o.sonOdeme);
      let durum, renk;
      if (o.odendi) {
        durum = "✓ Ödendi";
        renk = "#4ade80";
      } else if (gun < 0) {
        durum = `${-gun} gün gecikti`;
        renk = "#f87171";
      } else if (gun === 0) {
        durum = "Bugün son gün!";
        renk = "#fbbf24";
      } else if (gun <= 3) {
        durum = `${gun} gün kaldı`;
        renk = "#fbbf24";
      } else {
        durum = `${gun} gün kaldı`;
        renk = "#a2b1c6";
      }
      return React.createElement("div", {
        key: o.id,
        "data-payment-id": o.id,
        className: "row-hover",
        style: {
          display: "grid",
          gridTemplateColumns: "1fr 130px 110px 130px 130px 36px",
          gap: 10,
          alignItems: "center",
          background: o.odendi ? "#0d1610" : "#0f1117",
          border: `1px solid ${o.odendi ? "#22c55e22" : gun < 0 ? "#ef444433" : "#1e293b"}`,
          borderRadius: 9,
          padding: "11px 14px"
        }
      }, React.createElement("div", {
        style: {
          fontSize: 13,
          color: o.odendi ? "#86efac" : "#e2e8f0",
          fontWeight: 500,
          textDecoration: o.odendi ? "line-through" : "none",
          opacity: o.odendi ? 0.7 : 1
        }
      }, o.ad), React.createElement("div", {
        style: {
          fontSize: 14,
          fontWeight: 700,
          color: o.odendi ? "#4ade80" : "#f1f5f9",
          textAlign: "right"
        }
      }, "\u20BA ", fmt(o.tutar)), React.createElement("input", {
        "aria-label": o.ad + " son ödeme tarihi",
        type: "date",
        value: o.sonOdeme,
        onChange: e => updateTarih(o.id, e.target.value),
        title: "Son \xF6deme tarihini de\u011Fi\u015Ftir",
        style: {
          background: "#0f1117",
          border: "1px solid #2d3748",
          borderRadius: 6,
          color: "#cbd5e1",
          padding: "5px 7px",
          fontSize: 11,
          fontFamily: "'IBM Plex Mono',monospace",
          cursor: "pointer",
          textAlign: "center"
        }
      }), React.createElement("div", {
        style: {
          fontSize: 11,
          color: renk,
          textAlign: "center",
          fontWeight: 600
        }
      }, durum), React.createElement("div", {
        style: {
          display: "flex",
          gap: 5,
          justifyContent: "center"
        }
      }, React.createElement("button", {
        "aria-label": "\u0130\u015Flemi d\xFCzenle",
        onClick: () => openEdit(o),
        title: "Ad ve tutar\u0131 d\xFCzenle",
        style: {
          background: "#1e3a5f",
          border: "1px solid #3b82f644",
          borderRadius: 6,
          color: "#60a5fa",
          cursor: "pointer",
          padding: "4px 8px",
          fontSize: 11,
          fontFamily: "inherit"
        }
      }, React.createElement(UiIcon, {
        kind: "edit"
      })), !o.odendi ? React.createElement("button", {
        onClick: () => toggle(o.id),
        title: "\xD6dendi olarak i\u015Faretle",
        style: {
          background: "#14301f",
          border: "1px solid #22c55e44",
          borderRadius: 6,
          color: "#4ade80",
          cursor: "pointer",
          padding: "4px 8px",
          fontSize: 11,
          fontFamily: "inherit"
        }
      }, "\u2713 \xD6de") : React.createElement("button", {
        onClick: () => toggle(o.id),
        title: "\xD6denmedi olarak i\u015Faretle",
        style: {
          background: "#1e293b",
          border: "1px solid #47556944",
          borderRadius: 6,
          color: "#94a3b8",
          cursor: "pointer",
          padding: "4px 8px",
          fontSize: 11,
          fontFamily: "inherit"
        }
      }, "\u21A9 Geri")), React.createElement("div", {
        style: {
          textAlign: "center"
        }
      }, React.createElement("button", {
        "aria-label": "\xD6demeyi sil",
        onClick: () => {
          setError("");
          setSilId(o.id);
        },
        style: {
          background: "none",
          border: "none",
          color: "#94a3b8",
          cursor: "pointer",
          fontSize: 13,
          fontFamily: "inherit"
        },
        onMouseEnter: e => e.target.style.color = "#ef4444",
        onMouseLeave: e => e.target.style.color = "#94a3b8"
      }, React.createElement(UiIcon, {
        kind: "close"
      }))));
    }) : React.createElement("div", {
      style: {
        padding: 18,
        textAlign: "center",
        fontSize: 12,
        color: "#94a3b8"
      }
    }, "Hen\xFCz \xF6deme eklenmedi")));
  })), React.createElement("div", {
    "aria-label": "\xD6deme k\u0131sa yorumlar\u0131",
    style: {
      marginTop: 14,
      display: "flex",
      flexDirection: "column",
      gap: 6,
      fontSize: 12,
      lineHeight: 1.6
    }
  }, report.kiyas.oran !== null && React.createElement("div", {
    style: {
      color: report.kiyas.oran > 0 ? "#f87171" : report.kiyas.oran < 0 ? "#4ade80" : "#94a3b8"
    }
  }, report.kiyas.oran === 0 ? "Bu ay giderler geçen ayla aynı." : `Bu ay giderler geçen aya göre %${pct(report.kiyas.oran)} ${report.kiyas.oran > 0 ? "arttı" : "azaldı"}.`), report.enCok && report.enAz && React.createElement("div", {
    style: {
      color: "#cbd5e1"
    }
  }, "Bu y\u0131l en \xE7ok gider: ", monthName(report.enCok.ay).split(" ")[0], "; en az: ", monthName(report.enAz.ay).split(" ")[0], "."), report.artis && React.createElement("div", {
    style: {
      color: "#f87171"
    }
  }, "En fazla artan: ", report.artis.ad, " (%", pct(report.artis.oran), ")."), report.azalis && React.createElement("div", {
    style: {
      color: "#4ade80"
    }
  }, "En fazla azalan: ", report.azalis.ad, " (%", pct(report.azalis.oran), ")."))), silId && React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "#00000099",
      zIndex: 500,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #ef4444",
      borderRadius: 14,
      padding: "26px",
      width: 360,
      maxWidth: "90vw",
      textAlign: "center"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 26,
      marginBottom: 10
    }
  }, "\u26A0\uFE0F"), React.createElement("div", {
    style: {
      fontSize: 14,
      color: "#f1f5f9",
      fontWeight: 600,
      marginBottom: 18
    }
  }, "Bu \xF6deme silinsin mi?"), error && React.createElement("p", {
    role: "alert",
    style: {
      color: "#f87171",
      fontSize: 12,
      marginBottom: 12
    }
  }, error), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      justifyContent: "center"
    }
  }, React.createElement("button", {
    onClick: () => setSilId(null),
    style: {
      background: "#1e293b",
      border: "1px solid #2d3748",
      borderRadius: 8,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "9px 22px",
      fontSize: 12,
      fontFamily: "inherit"
    }
  }, "\u0130ptal"), React.createElement("button", {
    onClick: () => sil(silId),
    style: {
      background: "#7f1d1d",
      border: "1px solid #ef4444",
      borderRadius: 8,
      color: "#f87171",
      cursor: "pointer",
      padding: "9px 22px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "Evet, Sil")))), editOdeme && React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "#00000099",
      zIndex: 500,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    onClick: e => e.target === e.currentTarget && setEditOdeme(null)
  }, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #3b82f6",
      borderRadius: 14,
      padding: "24px",
      width: 400,
      maxWidth: "92vw"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 16
    }
  }, React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: "#f1f5f9"
    }
  }, "\u270F\uFE0F \xD6demeyi D\xFCzenle"), React.createElement("button", {
    "aria-label": "Kapat",
    onClick: () => setEditOdeme(null),
    style: {
      background: "none",
      border: "none",
      color: "#a2b1c6",
      cursor: "pointer",
      fontSize: 18
    }
  }, React.createElement(UiIcon, {
    kind: "close"
  }))), React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "\xD6DEME ADI"), React.createElement("input", {
    value: editAd,
    onChange: e => setEditAd(e.target.value),
    onKeyDown: e => e.key === "Enter" && saveEdit(),
    style: {
      ...I
    }
  })), React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "TUTAR (\u20BA)"), React.createElement(ParaInput, {
    value: editTutar,
    onChange: setEditTutar,
    onEnter: saveEdit,
    style: {
      ...I,
      textAlign: "right"
    }
  })), error && React.createElement("p", {
    role: "alert",
    style: {
      color: "#f87171",
      fontSize: 12,
      marginBottom: 12
    }
  }, error), React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 8
    }
  }, React.createElement("button", {
    onClick: () => setEditOdeme(null),
    style: {
      background: "#1e293b",
      border: "1px solid #2d3748",
      borderRadius: 8,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "9px 20px",
      fontSize: 12,
      fontFamily: "inherit"
    }
  }, "\u0130ptal"), React.createElement("button", {
    className: "btn-hover",
    onClick: saveEdit,
    style: {
      background: "#166534",
      border: "1px solid #22c55e",
      borderRadius: 8,
      color: "#4ade80",
      cursor: "pointer",
      padding: "9px 20px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\u2713 Kaydet")))));
}
function UiIcon({
  kind = "edit"
}) {
  const paths = {
    edit: "M4 16 16 4l4 4L8 20H4Z",
    close: "M6 6l12 12M18 6 6 18",
    chart: "M4 20V10m6 10V4m6 16v-8m6 8V7",
    money: "M3 6h18v14H3zM8 6V4h10v2M16 11h5v5h-5z",
    settings: "M4 6h16M4 12h16M4 18h16M8 3v6m8 0v6m-6 0v6",
    calendar: "M4 5h16v16H4zM8 3v4m8-4v4M4 10h16",
    download: "M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4",
    upload: "M12 16V4m-5 5 5-5 5 5M4 17v4h16v-4",
    save: "M4 3h14l3 3v15H3V3h1M7 3v6h10V3M7 21v-8h10v8"
  };
  return React.createElement("svg", {
    "aria-hidden": "true",
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      verticalAlign: "middle",
      flexShrink: 0
    }
  }, React.createElement("path", {
    d: paths[kind] || paths.edit
  }));
}
function SB({
  label,
  accent = "#a2b1c6",
  children
}) {
  return React.createElement("div", {
    style: {
      background: "#141825",
      border: `1px solid ${accent}22`,
      borderRadius: 12,
      padding: "18px 20px",
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase",
      marginBottom: 14,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("div", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 1,
      background: accent
    }
  }), label), children);
}
function Card({
  title,
  children,
  accent = "#3b82f6"
}) {
  return React.createElement("div", {
    style: {
      background: "#141825",
      border: `1px solid ${accent}22`,
      borderRadius: 12,
      padding: "16px 18px",
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase",
      marginBottom: 14,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("div", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 1,
      background: accent
    }
  }), title), children);
}
function ParaTab({
  cfg,
  saveCfg,
  para,
  savePara,
  kasaDurum,
  saveKD,
  paraLog,
  saveParaLog,
  kasaLog,
  saveKasaLog
}) {
  const today = toS(new Date());
  const inputRefs = useRef({});
  const [islem, setIslem] = useState("giris");
  const [dahil50, setDahil50] = useState(false);
  const [fazlaInput, setFazlaInput] = useState("");
  const [eksikInput, setEksikInput] = useState("");
  const [kdTarih, setKdTarih] = useState(addD(toS(new Date()), -1));
  const [resetConfirm, setResetConfirm] = useState(false);
  const [savedMsg, setSavedMsg] = useState("");
  const showMsg = m => {
    setSavedMsg(m);
    setTimeout(() => setSavedMsg(""), 2200);
  };
  const ky = cfg.kasaYapim || DEF_CFG.kasaYapim;
  const kasaSayisi = ky.kasaSayisi || 14;
  const kupurler = (ky.kupurler || DEF_CFG.kasaYapim.kupurler).slice().sort((a, b) => b.tutar - a.tutar);
  const paraMevcut = tutar => {
    if (tutar === 200) return para.c200 || 0;
    if (tutar === 100) return para.c100 || 0;
    if (tutar === 50) return para.c50 || 0;
    if (tutar === 20) return para.c20 || 0;
    if (tutar === 10) return para.c10 || 0;
    if (tutar === 5) return (para.c5k || 0) + (para.c5m || 0);
    return 0;
  };
  const bankaYedek = cfg.bankaYedek || {
    aktif: false,
    adet: null
  };
  const kupur100 = kupurler.find(k => k.tutar === 100);
  const gereken100 = (kupur100?.adet || 0) * kasaSayisi;
  const istenen100 = bankaYedek.adet ?? gereken100;
  const mevcut100 = para.c100 || 0;
  const fazla100 = Math.max(0, mevcut100 - istenen100);
  const setBankaYedek = patch => saveCfg({
    ...cfg,
    bankaYedek: {
      ...bankaYedek,
      ...patch
    }
  });
  const bankaTutar = useMemo(() => {
    let t = (para.c200 || 0) * 200;
    t += bankaYedek.aktif ? fazla100 * 100 : mevcut100 * 100;
    if (dahil50 && (para.c50 || 0) > 100) t += (para.c50 - 100) * 50;
    return t;
  }, [para, dahil50, bankaYedek.aktif, fazla100, mevcut100]);
  const applyAmounts = () => {
    const newPara = {
      ...para
    };
    const logKayit = {
      id: uid(),
      zaman: simdiZaman(),
      islem: islem,
      c200: 0,
      c100: 0,
      c50: 0,
      c20: 0,
      c10: 0,
      c5k: 0,
      c5m: 0,
      toplam: 0
    };
    let herhangiVar = false;
    DENOMINATIONS.forEach(({
      key,
      val
    }) => {
      const el = inputRefs.current[key];
      const v = el ? parseInt(el.value) || 0 : 0;
      if (v === 0) return;
      herhangiVar = true;
      logKayit[key] = v;
      logKayit.toplam += v * val;
      if (islem === "giris") newPara[key] = (newPara[key] || 0) + v;else newPara[key] = Math.max(0, (newPara[key] || 0) - v);
      if (el) el.value = "";
    });
    if (!herhangiVar) return;
    savePara(newPara);
    saveParaLog([logKayit, ...paraLog]);
    showMsg(islem === "giris" ? "✓ Giriş kaydedildi" : "✓ Çıkış kaydedildi");
  };
  const applyFazla = () => {
    const v = parseTR(fazlaInput);
    if (!v || isNaN(v)) return;
    const nd = {
      ...kasaDurum,
      fazla: (kasaDurum.fazla || 0) + v,
      tarih: kdTarih
    };
    saveKD(nd);
    saveKasaLog([{
      id: uid(),
      tarih: kdTarih,
      tur: "fazla",
      tutar: v
    }, ...kasaLog]);
    setFazlaInput("");
    showMsg("✓ Kasa fazlası eklendi");
  };
  const applyEksik = () => {
    const v = parseTR(eksikInput);
    if (!v || isNaN(v)) return;
    const nd = {
      ...kasaDurum,
      eksik: (kasaDurum.eksik || 0) + v,
      tarih: kdTarih
    };
    saveKD(nd);
    saveKasaLog([{
      id: uid(),
      tarih: kdTarih,
      tur: "eksik",
      tutar: v
    }, ...kasaLog]);
    setEksikInput("");
    showMsg("✓ Kasa eksiği eklendi");
  };
  const doReset = () => {
    saveKD({
      fazla: 0,
      eksik: 0,
      tarih: kdTarih
    });
    saveKasaLog([{
      id: uid(),
      tarih: kdTarih,
      tur: "sifirla",
      tutar: 0
    }, ...kasaLog]);
    setResetConfirm(false);
    showMsg("✓ Tutarlar sıfırlandı");
  };
  const net = kasaDurum.fazla - kasaDurum.eksik;
  return React.createElement(React.Fragment, null, savedMsg && React.createElement("div", {
    className: "fi",
    style: {
      background: "#14301f",
      border: "1px solid #22c55e",
      borderRadius: 9,
      padding: "10px 16px",
      marginBottom: 12,
      fontSize: 12,
      color: "#4ade80"
    }
  }, savedMsg), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14
    }
  }, React.createElement("div", null, React.createElement(Card, {
    title: "PARA SAYIMI",
    accent: "#f59e0b"
  }, React.createElement("div", {
    style: {
      display: "flex",
      gap: 6,
      marginBottom: 14
    }
  }, ["giris", "cikis"].map(t => React.createElement("button", {
    key: t,
    onClick: () => setIslem(t),
    style: {
      flex: 1,
      background: islem === t ? t === "giris" ? "#14301f" : "#2d1a1a" : "#0f1117",
      border: `1px solid ${islem === t ? t === "giris" ? "#22c55e" : "#ef4444" : "#2d3748"}`,
      borderRadius: 8,
      color: islem === t ? t === "giris" ? "#4ade80" : "#f87171" : "#a2b1c6",
      cursor: "pointer",
      padding: "9px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600,
      letterSpacing: 1
    }
  }, t === "giris" ? "⬆ GİRİŞ" : "⬇ ÇIKIŞ"))), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "120px 80px 1fr",
      gap: "6px 8px",
      alignItems: "center",
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1
    }
  }, "KUP\xDCR"), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      textAlign: "right"
    }
  }, "MEVCUT"), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1
    }
  }, "ADET G\u0130R"), DENOMINATIONS.map(({
    key,
    label,
    color
  }) => React.createElement(React.Fragment, {
    key: key
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, React.createElement("div", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 1,
      background: color
    }
  }), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "#e2e8f0"
    }
  }, label)), React.createElement("div", {
    style: {
      textAlign: "right",
      fontSize: 13,
      fontWeight: 700,
      color: color
    }
  }, fmtN(para[key] || 0)), React.createElement("input", {
    type: "number",
    min: "0",
    defaultValue: "",
    placeholder: "0",
    ref: el => inputRefs.current[key] = el,
    onKeyDown: e => e.key === "Enter" && applyAmounts(),
    style: {
      background: "#0f1117",
      border: "1px solid #2d3748",
      borderRadius: 8,
      color: "#e2e8f0",
      padding: "6px 10px",
      fontSize: 12,
      fontFamily: "'IBM Plex Mono',monospace",
      width: "100%"
    }
  })))), React.createElement("button", {
    className: "btn-hover",
    onClick: applyAmounts,
    style: {
      width: "100%",
      background: islem === "giris" ? "#166534" : "#7f1d1d",
      border: `1px solid ${islem === "giris" ? "#22c55e" : "#ef4444"}`,
      borderRadius: 9,
      color: islem === "giris" ? "#4ade80" : "#f87171",
      cursor: "pointer",
      padding: "10px",
      fontSize: 13,
      fontFamily: "inherit",
      fontWeight: 600,
      letterSpacing: 1
    }
  }, islem === "giris" ? "⬆ GİRİŞ UYGULA" : "⬇ ÇIKIŞ UYGULA")), React.createElement(Card, {
    title: "BANKAYA YATACAK PARA",
    accent: "#3b82f6"
  }, React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 8,
      marginBottom: 10
    }
  }, React.createElement("div", {
    style: {
      background: "#0f1117",
      border: "1px solid #f59e0b33",
      borderRadius: 8,
      padding: "10px 12px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 4
    }
  }, "200 TL \xD7 ", fmtN(para.c200 || 0)), React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 700,
      color: "#f59e0b"
    }
  }, "\u20BA ", fmt((para.c200 || 0) * 200))), React.createElement("div", {
    style: {
      background: "#0f1117",
      border: "1px solid #3b82f633",
      borderRadius: 8,
      padding: "10px 12px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 4
    }
  }, bankaYedek.aktif ? `100 TL × ${fmtN(fazla100)} (fazla)` : `100 TL × ${fmtN(mevcut100)}`), React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 700,
      color: "#3b82f6"
    }
  }, "\u20BA ", fmt(bankaYedek.aktif ? fazla100 * 100 : mevcut100 * 100)))), React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      cursor: "pointer",
      background: "#0f1117",
      border: `1px solid ${dahil50 ? "#8b5cf6" : "#1e293b"}`,
      borderRadius: 8,
      padding: "10px 12px",
      marginBottom: 10
    }
  }, React.createElement("input", {
    type: "checkbox",
    checked: dahil50,
    onChange: e => setDahil50(e.target.checked)
  }), React.createElement("span", {
    style: {
      fontSize: 11,
      color: dahil50 ? "#c4b5fd" : "#a2b1c6"
    }
  }, "100 adet \xFCzeri 50 TL dahil et", dahil50 && (para.c50 || 0) > 100 && React.createElement("span", {
    style: {
      color: "#8b5cf6",
      marginLeft: 6
    }
  }, "(+", fmtN(para.c50 - 100), " adet = \u20BA", fmt((para.c50 - 100) * 50), ")"), dahil50 && (para.c50 || 0) <= 100 && React.createElement("span", {
    style: {
      color: "#94a3b8",
      marginLeft: 6
    }
  }, "(50 TL adedi \u2264 100)"))), React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      cursor: "pointer",
      background: "#0f1117",
      border: `1px solid ${bankaYedek.aktif ? "#3b82f6" : "#1e293b"}`,
      borderRadius: 8,
      padding: "10px 12px",
      marginBottom: bankaYedek.aktif ? 8 : 10
    }
  }, React.createElement("input", {
    type: "checkbox",
    checked: bankaYedek.aktif,
    onChange: e => setBankaYedek({
      aktif: e.target.checked
    })
  }), React.createElement("span", {
    style: {
      fontSize: 11,
      color: bankaYedek.aktif ? "#93c5fd" : "#a2b1c6"
    }
  }, "Kasa yap\u0131m\u0131 i\xE7in gerekli 100 TL'yi dahil etme")), bankaYedek.aktif && React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      flexWrap: "wrap",
      background: "#0f1117",
      border: "1px solid #3b82f633",
      borderRadius: 8,
      padding: "10px 12px",
      marginBottom: 10
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, "Kasada tutmak istedi\u011Fim 100 TL adedi:"), React.createElement("input", {
    type: "number",
    min: 0,
    value: istenen100,
    onChange: e => setBankaYedek({
      adet: parseInt(e.target.value) || 0
    }),
    style: {
      background: "#141825",
      border: "1px solid #2d3748",
      borderRadius: 7,
      color: "#e2e8f0",
      padding: "6px 10px",
      fontSize: 12,
      fontFamily: "'IBM Plex Mono',monospace",
      width: 80,
      textAlign: "center"
    }
  }), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#94a3b8"
    }
  }, "(kasa yap\u0131m\u0131 gereken: ", fmtN(gereken100), ")"), bankaYedek.adet !== null && bankaYedek.adet !== gereken100 && React.createElement("button", {
    onClick: () => setBankaYedek({
      adet: null
    }),
    style: {
      marginLeft: "auto",
      background: "none",
      border: "none",
      color: "#a2b1c6",
      cursor: "pointer",
      fontSize: 11,
      fontFamily: "inherit",
      textDecoration: "underline"
    }
  }, "Varsay\u0131lana d\xF6n")), React.createElement("div", {
    style: {
      background: "linear-gradient(135deg,#1e3a5f,#1a2a4a)",
      border: "1px solid #3b82f6",
      borderRadius: 10,
      padding: "14px 16px",
      textAlign: "center"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase",
      marginBottom: 6
    }
  }, "TOPLAM BANKAYA YATACAK"), React.createElement("div", {
    style: {
      fontSize: 26,
      fontWeight: 700,
      color: "#60a5fa"
    }
  }, "\u20BA ", fmt(bankaTutar)))))), React.createElement("div", null, React.createElement(Card, {
    title: "KASA YAPIMI \u0130\xC7\u0130N GEREKL\u0130",
    accent: "#22c55e"
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 10
    }
  }, kasaSayisi, " kasa \xD7 (", kupurler.map(k => `${k.tutar}TL:${k.adet}`).join(" + "), ")"), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: 5,
      marginBottom: 4
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      padding: "4px 0"
    }
  }, "KUP\xDCR"), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      textAlign: "center"
    }
  }, "GEREKEN"), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      textAlign: "center"
    }
  }, "FARK")), kupurler.map(({
    tutar,
    adet
  }, i) => {
    const color = KUPUR_RENK[tutar] || ["#8b5cf6", "#22c55e", "#06b6d4", "#f97316", "#eab308"][i % 5];
    const gereken = (adet || 0) * kasaSayisi;
    const mevcut = paraMevcut(tutar);
    const fark = mevcut - gereken;
    return React.createElement("div", {
      key: tutar,
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr 1fr",
        gap: 5,
        alignItems: "center",
        marginBottom: 5,
        padding: "7px 10px",
        background: "#0f1117",
        borderRadius: 7,
        border: `1px solid ${color}22`
      }
    }, React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 5
      }
    }, React.createElement("div", {
      style: {
        width: 6,
        height: 6,
        borderRadius: 1,
        background: color
      }
    }), React.createElement("span", {
      style: {
        fontSize: 12,
        color: "#e2e8f0"
      }
    }, tutar, " TL")), React.createElement("div", {
      style: {
        textAlign: "center",
        fontSize: 12,
        color: "#94a3b8"
      }
    }, fmtN(gereken), " adet"), React.createElement("div", {
      style: {
        textAlign: "center",
        fontSize: 13,
        fontWeight: 700,
        color: fark >= 0 ? "#4ade80" : "#f87171"
      }
    }, fark >= 0 ? "+" : "", fmtN(fark)));
  })), React.createElement(Card, {
    title: "KASA FAZLASI / EKS\u0130\u011E\u0130 TAK\u0130B\u0130",
    accent: "#f97316"
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14,
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      background: "#0f1117",
      border: "1px solid #22c55e33",
      borderRadius: 10,
      padding: "14px 16px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#4ade80",
      letterSpacing: 1,
      marginBottom: 10,
      fontWeight: 700
    }
  }, "\u2795 KASA FAZLASI"), React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 700,
      color: "#4ade80",
      marginBottom: 12
    }
  }, "\u20BA ", fmt(kasaDurum.fazla || 0)), React.createElement(ParaInput, {
    value: fazlaInput,
    onChange: setFazlaInput,
    placeholder: "Tutar girin...",
    onEnter: applyFazla,
    style: {
      background: "#0a0e18",
      border: "1px solid #22c55e33",
      borderRadius: 8,
      color: "#e2e8f0",
      padding: "8px 11px",
      fontSize: 13,
      fontFamily: "'IBM Plex Mono',monospace",
      width: "100%",
      marginBottom: 8,
      textAlign: "right"
    }
  }), React.createElement("button", {
    className: "btn-hover",
    onClick: applyFazla,
    style: {
      width: "100%",
      background: "#14301f",
      border: "1px solid #22c55e",
      borderRadius: 8,
      color: "#4ade80",
      cursor: "pointer",
      padding: "8px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\u2795 EKLE")), React.createElement("div", {
    style: {
      background: "#0f1117",
      border: "1px solid #ef444433",
      borderRadius: 10,
      padding: "14px 16px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#f87171",
      letterSpacing: 1,
      marginBottom: 10,
      fontWeight: 700
    }
  }, "\u2796 KASA EKS\u0130\u011E\u0130"), React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 700,
      color: "#f87171",
      marginBottom: 12
    }
  }, "\u20BA ", fmt(kasaDurum.eksik || 0)), React.createElement(ParaInput, {
    value: eksikInput,
    onChange: setEksikInput,
    placeholder: "Tutar girin...",
    onEnter: applyEksik,
    style: {
      background: "#0a0e18",
      border: "1px solid #ef444433",
      borderRadius: 8,
      color: "#e2e8f0",
      padding: "8px 11px",
      fontSize: 13,
      fontFamily: "'IBM Plex Mono',monospace",
      width: "100%",
      marginBottom: 8,
      textAlign: "right"
    }
  }), React.createElement("button", {
    className: "btn-hover",
    onClick: applyEksik,
    style: {
      width: "100%",
      background: "#2d1a1a",
      border: "1px solid #ef4444",
      borderRadius: 8,
      color: "#f87171",
      cursor: "pointer",
      padding: "8px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\u2796 EKLE"))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexWrap: "wrap",
      marginTop: 4
    }
  }, React.createElement("div", {
    style: {
      background: "#0f1117",
      border: `1px solid ${net >= 0 ? "#22c55e33" : "#ef444433"}`,
      borderRadius: 10,
      padding: "12px 18px",
      flex: 1,
      minWidth: 180
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      textTransform: "uppercase",
      marginBottom: 4
    }
  }, "NET DURUM"), React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 700,
      color: net >= 0 ? "#4ade80" : "#f87171"
    }
  }, net > 0 ? "✓ Fazla" : net === 0 ? "= Sıfır" : "✗ Eksik", " \xA0\u20BA ", fmt(Math.abs(net)))), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      marginBottom: 2
    }
  }, "SON KAYIT TAR\u0130H\u0130"), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, React.createElement("button", {
    onClick: () => setKdTarih(addD(kdTarih, -1)),
    style: {
      background: "#0f1117",
      border: "1px solid #2d3748",
      borderRadius: 7,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "6px 10px",
      fontSize: 13,
      fontFamily: "inherit"
    }
  }, "\u25C0"), React.createElement("div", {
    style: {
      textAlign: "center",
      minWidth: 110
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "#f1f5f9"
    }
  }, fDSh(kdTarih)), kdTarih === addD(toS(new Date()), -1) && React.createElement("div", {
    style: {
      fontSize: 9,
      color: "#a2b1c6"
    }
  }, "d\xFCn"), kdTarih === toS(new Date()) && React.createElement("div", {
    style: {
      fontSize: 9,
      color: "#4ade80"
    }
  }, "bug\xFCn")), React.createElement("button", {
    onClick: () => setKdTarih(addD(kdTarih, 1)),
    style: {
      background: "#0f1117",
      border: "1px solid #2d3748",
      borderRadius: 7,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "6px 10px",
      fontSize: 13,
      fontFamily: "inherit"
    }
  }, "\u25B6"), React.createElement("input", {
    type: "date",
    value: kdTarih,
    onChange: e => setKdTarih(e.target.value),
    style: {
      background: "#0f1117",
      border: "1px solid #2d3748",
      borderRadius: 7,
      color: "#a2b1c6",
      padding: "5px 8px",
      fontSize: 11,
      fontFamily: "'IBM Plex Mono',monospace",
      width: 36,
      opacity: 0.7,
      cursor: "pointer"
    },
    title: "Tarih se\xE7"
  })), kasaDurum.tarih && React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8"
    }
  }, "Son kaydedilen: ", fDSh(kasaDurum.tarih))), React.createElement("button", {
    className: "btn-hover",
    onClick: () => setResetConfirm(true),
    style: {
      background: "#1e293b",
      border: "1px solid #475569",
      borderRadius: 9,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "10px 18px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\uD83D\uDD04 SIFIRLA"))))), resetConfirm && React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "#00000099",
      zIndex: 500,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #ef4444",
      borderRadius: 14,
      padding: "28px",
      width: 400,
      maxWidth: "90vw",
      textAlign: "center"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 28,
      marginBottom: 12
    }
  }, "\u26A0\uFE0F"), React.createElement("div", {
    style: {
      fontSize: 15,
      color: "#f1f5f9",
      fontWeight: 600,
      marginBottom: 8
    }
  }, "Tutarlar\u0131 S\u0131f\u0131rla"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "#94a3b8",
      marginBottom: 20
    }
  }, "Kasa fazlas\u0131 ve eksi\u011Fi s\u0131f\u0131rlamak istedi\u011Finizden emin misiniz?"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      justifyContent: "center"
    }
  }, React.createElement("button", {
    onClick: () => setResetConfirm(false),
    style: {
      background: "#1e293b",
      border: "1px solid #2d3748",
      borderRadius: 8,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "9px 24px",
      fontSize: 12,
      fontFamily: "inherit"
    }
  }, "\u0130ptal"), React.createElement("button", {
    className: "btn-hover",
    onClick: doReset,
    style: {
      background: "#7f1d1d",
      border: "1px solid #ef4444",
      borderRadius: 8,
      color: "#f87171",
      cursor: "pointer",
      padding: "9px 24px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "Evet, S\u0131f\u0131rla")))));
}
const SAYIM_BANKNOT = [["b200", "200 TL", 200, "#f59e0b"], ["b100", "100 TL", 100, "#3b82f6"], ["b50", "50 TL", 50, "#8b5cf6"], ["b20", "20 TL", 20, "#22c55e"], ["b10", "10 TL", 10, "#06b6d4"], ["b5", "5 TL (Kağıt)", 5, "#f97316"], ["b5m", "5 TL (Madeni)", 5, "#94a3b8"]];
const SAYIM_BOZUK = [["bp1", "1 TL", 1], ["bp05", "50 Kr", 0.5], ["bp025", "25 Kr", 0.25], ["bp01", "10 Kr", 0.1], ["bp005", "5 Kr", 0.05]];
const SAYIM_YEDEK = [["yk1", "1 TL", 1], ["yk05", "50 Kr", 0.5], ["yk025", "25 Kr", 0.25], ["yk01", "10 Kr", 0.1], ["yk005", "5 Kr", 0.05]];
function KasaSayimiTab({
  sayimlar,
  saveSayimlar
}) {
  const today = toS(new Date());
  const [tarih, setTarih] = useState(today);
  const [f, setF] = useState({
    ...DEF_SAYIM
  });
  const [savedMsg, setSavedMsg] = useState("");
  const [silId, setSilId] = useState(null);
  const I = {
    background: "#0f1117",
    border: "1px solid #2d3748",
    borderRadius: 7,
    color: "#e2e8f0",
    padding: "6px 9px",
    fontSize: 12,
    fontFamily: "'IBM Plex Mono',monospace",
    width: "100%"
  };
  const setNum = (k, v) => setF(p => ({
    ...p,
    [k]: v
  }));
  const g = k => parseTR(f[k]);
  const calc = useMemo(() => hesaplaSayim(f), [f]);
  const oncekiSayim = useMemo(() => {
    const eskiler = sayimlar.filter(s => s.tarih < tarih).sort((a, b) => a.tarih < b.tarih ? 1 : -1);
    return eskiler[0] || null;
  }, [sayimlar, tarih]);
  const oncekiFE = oncekiSayim ? hesaplaSayim(oncekiSayim).fazlaEksik : null;
  const fark = oncekiFE !== null ? calc.fazlaEksik - oncekiFE : null;
  const kaydet = () => {
    const kayit = {
      id: uid(),
      tarih,
      ...f,
      toplam: calc.toplam,
      fazlaEksik: calc.fazlaEksik
    };
    const yeni = [...sayimlar.filter(s => s.id !== kayit.id), kayit].sort((a, b) => a.tarih < b.tarih ? -1 : 1);
    saveSayimlar(yeni);
    setSavedMsg("✓ Sayım kaydedildi");
    setTimeout(() => setSavedMsg(""), 2500);
  };
  const sayimYukle = s => {
    setTarih(s.tarih);
    const nf = {
      ...DEF_SAYIM
    };
    SAYIM_KEYS.forEach(k => {
      if (k !== "tarih") nf[k] = s[k] ?? 0;
    });
    nf.kasaBirim = s.kasaBirim ?? 2000;
    nf.avansBirim = s.avansBirim ?? 2000;
    setF(nf);
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };
  const sayimSil = id => {
    saveSayimlar(sayimlar.filter(s => s.id !== id));
    setSilId(null);
  };
  return React.createElement(React.Fragment, null, savedMsg && React.createElement("div", {
    className: "fi",
    style: {
      background: "#14301f",
      border: "1px solid #22c55e",
      borderRadius: 9,
      padding: "10px 16px",
      marginBottom: 12,
      fontSize: 12,
      color: "#4ade80"
    }
  }, savedMsg), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap",
      marginBottom: 14,
      alignItems: "stretch"
    }
  }, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #1e293b",
      borderRadius: 12,
      padding: "14px 18px",
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1
    }
  }, "SAYIM TAR\u0130H\u0130"), React.createElement("input", {
    type: "date",
    value: tarih,
    onChange: e => setTarih(e.target.value),
    style: {
      ...I,
      width: 150,
      fontSize: 13
    }
  })), React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 180,
      background: "linear-gradient(135deg,#141825,#1a2035)",
      border: "1px solid #2d3a5c",
      borderRadius: 12,
      padding: "12px 18px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      marginBottom: 2
    }
  }, "SAYIM TOPLAMI"), React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 700,
      color: "#f1f5f9"
    }
  }, "\u20BA ", fmt(calc.toplam))), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      marginBottom: 2
    }
  }, "KASA FAZLASI/EKS\u0130\u011E\u0130"), React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 700,
      color: calc.fazlaEksik >= 0 ? "#4ade80" : "#f87171"
    }
  }, calc.fazlaEksik >= 0 ? "+" : "", fmt(calc.fazlaEksik)), fark !== null && React.createElement("div", {
    style: {
      fontSize: 11,
      color: fark >= 0 ? "#4ade80" : "#f87171",
      marginTop: 2
    }
  }, "\xF6nceki say\u0131ma g\xF6re: ", fark >= 0 ? "+" : "", fmt(fark)))), React.createElement("button", {
    className: "btn-hover",
    onClick: kaydet,
    style: {
      background: "#166534",
      border: "1px solid #22c55e",
      borderRadius: 12,
      color: "#4ade80",
      cursor: "pointer",
      padding: "0 28px",
      fontSize: 14,
      fontFamily: "inherit",
      fontWeight: 700,
      letterSpacing: 1
    }
  }, "\uD83D\uDCBE SAYIMI KAYDET")), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: 12,
      marginBottom: 14
    }
  }, React.createElement(Card, {
    title: "BANKNOTLAR (KA\u011EIT)",
    accent: "#3b82f6"
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 70px 90px",
      gap: 6,
      marginBottom: 4,
      fontSize: 9,
      color: "#94a3b8",
      letterSpacing: 1
    }
  }, React.createElement("div", null, "KUP\xDCR"), React.createElement("div", {
    style: {
      textAlign: "center"
    }
  }, "ADET"), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, "TUTAR")), SAYIM_BANKNOT.map(([k, label, birim, renk]) => React.createElement("div", {
    key: k,
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 70px 90px",
      gap: 6,
      alignItems: "center",
      padding: "3px 0"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, React.createElement("div", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 1,
      background: renk
    }
  }), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#cbd5e1"
    }
  }, label)), React.createElement("input", {
    type: "number",
    min: "0",
    value: f[k] === 0 ? "" : f[k],
    placeholder: "0",
    onChange: e => setNum(k, e.target.value),
    style: {
      ...I,
      textAlign: "center"
    }
  }), React.createElement("div", {
    style: {
      textAlign: "right",
      fontSize: 11,
      color: renk
    }
  }, "\u20BA", fmt(g(k) * birim))))), React.createElement(Card, {
    title: "BOZUK PARA (MADEN\u0130)",
    accent: "#f59e0b"
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 70px 90px",
      gap: 6,
      marginBottom: 4,
      fontSize: 9,
      color: "#94a3b8",
      letterSpacing: 1
    }
  }, React.createElement("div", null, "KUP\xDCR"), React.createElement("div", {
    style: {
      textAlign: "center"
    }
  }, "ADET"), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, "TUTAR")), SAYIM_BOZUK.map(([k, label, birim]) => React.createElement("div", {
    key: k,
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 70px 90px",
      gap: 6,
      alignItems: "center",
      padding: "3px 0"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, React.createElement("div", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 1,
      background: "#f59e0b"
    }
  }), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#cbd5e1"
    }
  }, label)), React.createElement("input", {
    type: "number",
    min: "0",
    value: f[k] === 0 ? "" : f[k],
    placeholder: "0",
    onChange: e => setNum(k, e.target.value),
    style: {
      ...I,
      textAlign: "center"
    }
  }), React.createElement("div", {
    style: {
      textAlign: "right",
      fontSize: 11,
      color: "#f59e0b"
    }
  }, "\u20BA", fmt(g(k) * birim)))), React.createElement("div", {
    style: {
      height: 1,
      background: "#1e293b",
      margin: "8px 0"
    }
  }), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 90px",
      gap: 6,
      alignItems: "center"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#cbd5e1"
    }
  }, "Bozuk Para Kar\u0131\u015F\u0131k (\u20BA)"), React.createElement(ParaInput, {
    value: f.bozukKarisik === 0 ? "" : f.bozukKarisik,
    onChange: v => setNum("bozukKarisik", v),
    style: {
      ...I,
      textAlign: "right"
    }
  }))), React.createElement(Card, {
    title: "D\u0130\u011EER KALEMLER",
    accent: "#a855f7"
  }, React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 3,
      letterSpacing: .5
    }
  }, "ALACAK (\u20BA)"), React.createElement(ParaInput, {
    value: f.alacak === 0 ? "" : f.alacak,
    onChange: v => setNum("alacak", v),
    style: {
      ...I,
      textAlign: "right"
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 3,
      letterSpacing: .5
    }
  }, "KASALAR"), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 74px 90px",
      gap: 6,
      alignItems: "center"
    }
  }, React.createElement("input", {
    type: "number",
    value: f.kasalarAdet === 0 ? "" : f.kasalarAdet,
    placeholder: "adet",
    onChange: e => setNum("kasalarAdet", e.target.value),
    style: {
      ...I
    }
  }), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 3
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, "\xD7"), React.createElement(ParaInput, {
    value: f.kasaBirim === 0 ? "" : f.kasaBirim,
    onChange: v => setNum("kasaBirim", v),
    placeholder: "2000",
    style: {
      ...I,
      padding: "6px 8px",
      fontSize: 11,
      textAlign: "center"
    }
  })), React.createElement("div", {
    style: {
      textAlign: "right",
      fontSize: 11,
      color: "#c084fc"
    }
  }, "\u20BA", fmt(calc.kasalar)))), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 3,
      letterSpacing: .5
    }
  }, "KASALAR AVANS"), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 74px 90px",
      gap: 6,
      alignItems: "center"
    }
  }, React.createElement("input", {
    type: "number",
    value: f.avansAdet === 0 ? "" : f.avansAdet,
    placeholder: "adet",
    onChange: e => setNum("avansAdet", e.target.value),
    style: {
      ...I
    }
  }), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 3
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, "\xD7"), React.createElement(ParaInput, {
    value: f.avansBirim === 0 ? "" : f.avansBirim,
    onChange: v => setNum("avansBirim", v),
    placeholder: "2000",
    style: {
      ...I,
      padding: "6px 8px",
      fontSize: 11,
      textAlign: "center"
    }
  })), React.createElement("div", {
    style: {
      textAlign: "right",
      fontSize: 11,
      color: "#c084fc"
    }
  }, "\u20BA", fmt(calc.avans)))), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 3,
      letterSpacing: .5
    }
  }, "KASA YEDEK SAB\u0130T (\u20BA)"), React.createElement(ParaInput, {
    value: f.kasaYedekSabit === 0 ? "" : f.kasaYedekSabit,
    onChange: v => setNum("kasaYedekSabit", v),
    placeholder: "1750",
    style: {
      ...I,
      textAlign: "right"
    }
  })), React.createElement("div", {
    style: {
      height: 1,
      background: "#1e293b",
      margin: "2px 0"
    }
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 3,
      letterSpacing: .5,
      fontWeight: 600,
      color: "#ef4444"
    }
  }, "\u2605 MERKEZ KASA (Olmas\u0131 gereken \u20BA)"), React.createElement(ParaInput, {
    value: f.merkezKasa === 0 ? "" : f.merkezKasa,
    onChange: v => setNum("merkezKasa", v),
    style: {
      ...I,
      border: "1px solid #ef444455",
      textAlign: "right"
    }
  }))))), React.createElement(Card, {
    title: "KASA YEDEK BOZUK PARA (Sabit Rezerv)",
    accent: "#14b8a6"
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill,minmax(150px,1fr))",
      gap: 10
    }
  }, SAYIM_YEDEK.map(([k, label, birim]) => React.createElement("div", {
    key: k,
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 60px 80px",
      gap: 5,
      alignItems: "center"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#cbd5e1"
    }
  }, label), React.createElement("input", {
    type: "number",
    value: f[k] === 0 ? "" : f[k],
    placeholder: "0",
    onChange: e => setNum(k, e.target.value),
    style: {
      ...I,
      textAlign: "center",
      fontSize: 11,
      padding: "5px"
    }
  }), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#2dd4bf",
      textAlign: "right"
    }
  }, "\u20BA", fmt(g(k) * birim))))), React.createElement("div", {
    style: {
      marginTop: 8,
      fontSize: 11,
      color: "#a2b1c6",
      textAlign: "right"
    }
  }, "Yedek bozuk toplam: ", React.createElement("span", {
    style: {
      color: "#2dd4bf",
      fontWeight: 600
    }
  }, "\u20BA", fmt(calc.yedekBozuk)))), React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #1e293b",
      borderRadius: 12,
      overflow: "hidden",
      marginTop: 4
    }
  }, React.createElement("div", {
    style: {
      padding: "11px 16px",
      borderBottom: "1px solid #1e293b",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 2,
      textTransform: "uppercase"
    }
  }, "GE\xC7M\u0130\u015E SAYIMLAR"), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, sayimlar.length, " say\u0131m")), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "110px 1fr 1fr 1fr 130px 70px 60px",
      gap: 6,
      padding: "7px 14px",
      borderBottom: "1px solid #1e293b",
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1
    }
  }, React.createElement("div", null, "TAR\u0130H"), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, "TOPLAM"), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, "MERKEZ KASA"), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, "FAZLA/EKS\u0130K"), React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, "\xD6NCEK\u0130 FARK"), React.createElement("div", {
    style: {
      textAlign: "center"
    }
  }, "Y\xDCKLE"), React.createElement("div", {
    style: {
      textAlign: "center"
    }
  }, "S\u0130L")), React.createElement("div", {
    style: {
      maxHeight: 300,
      overflowY: "auto"
    }
  }, sayimlar.length === 0 && React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "30px",
      color: "#94a3b8",
      fontSize: 12
    }
  }, "Hen\xFCz say\u0131m yok"), [...sayimlar].sort((a, b) => a.tarih < b.tarih ? 1 : -1).map((s, i, arr) => {
    const c = hesaplaSayim(s);
    const oncekiList = sayimlar.filter(x => x.tarih < s.tarih).sort((a, b) => a.tarih < b.tarih ? 1 : -1);
    const onceki = oncekiList[0];
    const oFark = onceki ? c.fazlaEksik - hesaplaSayim(onceki).fazlaEksik : null;
    return React.createElement("div", {
      key: s.id,
      className: "row-hover",
      style: {
        display: "grid",
        gridTemplateColumns: "110px 1fr 1fr 1fr 130px 70px 60px",
        gap: 6,
        padding: "8px 14px",
        background: i % 2 === 0 ? "transparent" : "#0d1020",
        borderBottom: "1px solid #1e293b1a",
        alignItems: "center",
        fontSize: 12
      }
    }, React.createElement("div", {
      style: {
        color: "#e2e8f0"
      }
    }, fDSh(s.tarih)), React.createElement("div", {
      style: {
        textAlign: "right",
        color: "#f1f5f9",
        fontWeight: 600
      }
    }, "\u20BA", fmt(c.toplam)), React.createElement("div", {
      style: {
        textAlign: "right",
        color: "#94a3b8"
      }
    }, "\u20BA", fmt(s.merkezKasa || 0)), React.createElement("div", {
      style: {
        textAlign: "right",
        fontWeight: 700,
        color: c.fazlaEksik >= 0 ? "#4ade80" : "#f87171"
      }
    }, c.fazlaEksik >= 0 ? "+" : "", fmt(c.fazlaEksik)), React.createElement("div", {
      style: {
        textAlign: "right",
        fontSize: 11,
        color: oFark === null ? "#94a3b8" : oFark >= 0 ? "#4ade80" : "#f87171"
      }
    }, oFark === null ? "—" : (oFark >= 0 ? "+" : "") + fmt(oFark)), React.createElement("div", {
      style: {
        textAlign: "center"
      }
    }, React.createElement("button", {
      onClick: () => sayimYukle(s),
      style: {
        background: "#1e3a5f",
        border: "1px solid #3b82f633",
        borderRadius: 6,
        color: "#60a5fa",
        cursor: "pointer",
        padding: "3px 9px",
        fontSize: 11,
        fontFamily: "inherit"
      }
    }, "\u2191 Y\xFCkle")), React.createElement("div", {
      style: {
        textAlign: "center"
      }
    }, React.createElement("button", {
      "aria-label": "Kapat",
      onClick: () => setSilId(s.id),
      style: {
        background: "none",
        border: "none",
        color: "#94a3b8",
        cursor: "pointer",
        fontSize: 13,
        fontFamily: "inherit"
      },
      onMouseEnter: e => e.target.style.color = "#ef4444",
      onMouseLeave: e => e.target.style.color = "#94a3b8"
    }, React.createElement(UiIcon, {
      kind: "close"
    }))));
  }))), silId && React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "#00000099",
      zIndex: 500,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #ef4444",
      borderRadius: 14,
      padding: "26px",
      width: 380,
      maxWidth: "90vw",
      textAlign: "center"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 26,
      marginBottom: 10
    }
  }, "\u26A0\uFE0F"), React.createElement("div", {
    style: {
      fontSize: 14,
      color: "#f1f5f9",
      fontWeight: 600,
      marginBottom: 8
    }
  }, "Say\u0131m\u0131 Sil"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "#94a3b8",
      marginBottom: 18
    }
  }, "Bu kasa say\u0131m\u0131 kayd\u0131 silinsin mi?"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      justifyContent: "center"
    }
  }, React.createElement("button", {
    onClick: () => setSilId(null),
    style: {
      background: "#1e293b",
      border: "1px solid #2d3748",
      borderRadius: 8,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "9px 22px",
      fontSize: 12,
      fontFamily: "inherit"
    }
  }, "\u0130ptal"), React.createElement("button", {
    className: "btn-hover",
    onClick: () => sayimSil(silId),
    style: {
      background: "#7f1d1d",
      border: "1px solid #ef4444",
      borderRadius: 8,
      color: "#f87171",
      cursor: "pointer",
      padding: "9px 22px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "Evet, Sil")))));
}
function KasaAyarSatiri({
  k,
  bankalar,
  onSave,
  onDelete
}) {
  const [editing, setEditing] = useState(false),
    [draft, setDraft] = useState({
      ...k
    }),
    [error, setError] = useState("");
  useEffect(() => {
    if (!editing) setDraft({
      ...k
    });
  }, [k, editing]);
  const I = {
    background: editing ? "#0f1117" : "#101723",
    border: "1px solid #2d3748",
    borderRadius: 7,
    color: editing ? "#e2e8f0" : "#94a3b8",
    padding: "7px 9px",
    fontSize: 12,
    fontFamily: "inherit",
    width: "100%"
  };
  const B = {
    background: "#1e3a5f",
    border: "1px solid #36577c",
    borderRadius: 7,
    color: "#bfdbfe",
    padding: "7px 10px",
    fontSize: 11,
    fontFamily: "inherit",
    cursor: "pointer"
  };
  return React.createElement("div", {
    "data-kasa-row": k.id,
    style: {
      background: "#0f1117",
      border: "1px solid #28374c",
      borderRadius: 9,
      padding: 12
    }
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(130px,1fr) 120px minmax(120px,1fr) 150px auto",
      alignItems: "center",
      gap: 10
    }
  }, React.createElement("input", {
    "aria-label": "Kasa ad\u0131",
    disabled: !editing,
    style: I,
    value: draft.ad,
    onChange: e => setDraft(v => ({
      ...v,
      ad: e.target.value
    }))
  }), React.createElement("input", {
    "aria-label": "Kasa numaras\u0131",
    disabled: !editing,
    style: I,
    value: draft.kod,
    onChange: e => setDraft(v => ({
      ...v,
      kod: e.target.value
    }))
  }), React.createElement("select", {
    "aria-label": "Kasa bankas\u0131",
    disabled: !editing,
    style: I,
    value: draft.bankaId,
    onChange: e => setDraft(v => ({
      ...v,
      bankaId: e.target.value
    }))
  }, bankalar.map(b => React.createElement("option", {
    key: b.id,
    value: b.id
  }, b.ad))), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#cbd5e1",
      lineHeight: 1.8
    }
  }, React.createElement("label", null, React.createElement("input", {
    type: "checkbox",
    disabled: !editing,
    checked: draft.aktif !== false,
    onChange: e => setDraft(v => ({
      ...v,
      aktif: e.target.checked
    }))
  }), " Aktif"), React.createElement("br", null), React.createElement("label", null, React.createElement("input", {
    type: "checkbox",
    disabled: !editing,
    checked: !!draft.toplamModu,
    onChange: e => setDraft(v => ({
      ...v,
      toplamModu: e.target.checked
    }))
  }), " Toplam POS takibi")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 6,
      flexWrap: "wrap",
      maxWidth: 190
    }
  }, editing ? React.createElement(React.Fragment, null, React.createElement("button", {
    style: B,
    onClick: () => {
      try {
        onSave(draft);
        setEditing(false);
        setError("");
      } catch (e) {
        setError(e.message);
      }
    }
  }, "Kaydet"), React.createElement("button", {
    style: B,
    onClick: () => {
      setDraft({
        ...k
      });
      setEditing(false);
      setError("");
    }
  }, "Vazge\xE7"), React.createElement("button", {
    style: {
      ...B,
      color: "#fca5a5"
    },
    onClick: onDelete
  }, "Sil")) : React.createElement("button", {
    "aria-label": "Düzenle: " + k.ad,
    style: B,
    onClick: () => setEditing(true)
  }, React.createElement(UiIcon, {
    kind: "edit"
  }), " D\xFCzenle"))), error && React.createElement("p", {
    role: "alert",
    style: {
      color: "#fca5a5",
      fontSize: 12,
      marginTop: 8
    }
  }, error));
}
function AyarlarTab({
  cfg,
  saveCfg,
  txs,
  paraLog,
  kasaLog,
  sayimlar,
  onReload
}) {
  const [dVade, setDVade] = useState({
    ...cfg.vadeGunleri
  });
  const [dB, setDB] = useState([...cfg.bankalar]);
  const [dK, setDK] = useState([...cfg.kasalar]);
  const [dKY, setDKY] = useState({
    ...cfg.kasaYapim
  } || {
    ...DEF_CFG.kasaYapim
  });
  const [newBAd, setNewBAd] = useState("");
  const [newK, setNewK] = useState({
    ad: "",
    kod: "",
    bankaId: cfg.bankalar[0]?.id || ""
  });
  const [ok, setOk] = useState(false);
  const [yedekMsg, setYedekMsg] = useState("");
  const [pendingFile, setPendingFile] = useState(null);
  const fileInputRef = useRef(null);
  const I = {
    background: "#0f1117",
    border: "1px solid #2d3748",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "9px 12px",
    fontSize: 13,
    fontFamily: "'IBM Plex Mono',monospace",
    width: "100%"
  };
  const addBanka = () => {
    if (!newBAd.trim()) return;
    setDB(p => [...p, {
      id: uid(),
      ad: newBAd.trim()
    }]);
    setNewBAd("");
  };
  const delBanka = id => {
    if (dK.some(k => k.bankaId === id)) {
      alert("Önce bu bankaya ait kasaları silin!");
      return;
    }
    setDB(p => p.filter(b => b.id !== id));
  };
  const addKasa = () => {
    if (!newK.ad.trim() || !newK.kod.trim()) return;
    setDK(p => [...p, {
      id: uid(),
      ...newK
    }]);
    setNewK({
      ad: "",
      kod: "",
      bankaId: dB[0]?.id || ""
    });
  };
  const delKasa = id => {
    if (txs.some(t => t.kasaId === id)) {
      alert("Bu kasanın geçmiş işlemleri var. Silmek yerine pasife alın.");
      return;
    }
    if (confirm("Kasa silinsin mi?")) setDK(p => p.filter(k => k.id !== id));
  };
  const doSave = () => {
    try {
      POSGuard.config({
        ...cfg,
        vadeGunleri: dVade,
        bankalar: dB,
        kasalar: dK
      });
    } catch (e) {
      alert(e.message);
      return;
    }
    if (dK.some(k => !k.ad.trim() || !k.kod.trim())) {
      alert("Kasa adı ve numarası boş bırakılamaz.");
      return;
    }
    if (saveCfg({
      ...cfg,
      vadeGunleri: dVade,
      bankalar: dB,
      kasalar: dK,
      kasaYapim: dKY
    }) === false) return;
    setOk(true);
    setTimeout(() => setOk(false), 2200);
  };
  const yMsg = m => {
    setYedekMsg(m);
    setTimeout(() => setYedekMsg(""), 3000);
  };
  const handleFileSelect = e => {
    const f = e.target.files[0];
    if (f) setPendingFile(f);
    e.target.value = "";
  };
  const confirmRestore = () => {
    jsonGeriYukle(pendingFile, (success, msg) => {
      if (success) {
        setPendingFile(null);
        yMsg("✓ " + msg);
        setTimeout(() => onReload(), 900);
      } else {
        setPendingFile(null);
        alert(msg);
      }
    });
  };
  return React.createElement(React.Fragment, null, React.createElement(SB, {
    label: "VADE G\xDCNLER\u0130",
    accent: "#3b82f6"
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginBottom: 12
    }
  }, "\u2139 De\u011Fi\u015Fiklikler yaln\u0131zca yeni kay\u0131tlara uygulan\u0131r."), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap"
    }
  }, ["KREDİ KARTI", "DEBİT KART"].map(tur => React.createElement("div", {
    key: tur,
    style: {
      background: "#0f1117",
      border: "1px solid #1e293b",
      borderRadius: 10,
      padding: "13px 16px",
      minWidth: 180
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      letterSpacing: 1,
      marginBottom: 7
    }
  }, tur === "KREDİ KARTI" ? "💳 KREDİ KARTI" : "🏧 DEBİT KART"), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("input", {
    type: "number",
    min: 0,
    max: 365,
    step: 1,
    value: dVade[tur] || 0,
    onChange: e => setDVade(v => ({
      ...v,
      [tur]: e.target.value === "" ? 0 : Number(e.target.value)
    })),
    style: {
      ...I,
      width: 70,
      textAlign: "center"
    }
  }), React.createElement("span", {
    style: {
      color: "#a2b1c6",
      fontSize: 12
    }
  }, "g\xFCn")))))), React.createElement(SB, {
    label: "KASA YAPIMI VARSAYILANLARI",
    accent: "#22c55e"
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginBottom: 12
    }
  }, "Her kasa i\xE7in gereken kup\xFCr adedi ve toplam kasa say\u0131s\u0131. \u0130stedi\u011Fin kup\xFCr\xFC (100, 200 TL dahil) ekleyip \xE7\u0131karabilirsin."), React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 7,
      letterSpacing: .5
    }
  }, "KASA SAYISI"), React.createElement("input", {
    type: "number",
    min: 0,
    value: dKY.kasaSayisi ?? 0,
    onChange: e => setDKY(v => ({
      ...v,
      kasaSayisi: parseInt(e.target.value) || 0
    })),
    style: {
      ...I,
      width: 140,
      textAlign: "center"
    }
  })), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7,
      marginBottom: 12
    }
  }, (dKY.kupurler || []).slice().sort((a, b) => b.tutar - a.tutar).map((k, i) => {
    const renk = KUPUR_RENK[k.tutar] || "#94a3b8";
    return React.createElement("div", {
      key: k.tutar,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10,
        background: "#0f1117",
        border: `1px solid ${renk}33`,
        borderRadius: 9,
        padding: "9px 14px"
      }
    }, React.createElement("div", {
      style: {
        width: 8,
        height: 8,
        borderRadius: 2,
        background: renk,
        flexShrink: 0
      }
    }), React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#e2e8f0",
        width: 70
      }
    }, k.tutar, " TL"), React.createElement("span", {
      style: {
        fontSize: 11,
        color: "#a2b1c6"
      }
    }, "kasa ba\u015F\u0131na adet:"), React.createElement("input", {
      type: "number",
      min: 0,
      value: k.adet ?? 0,
      onChange: e => {
        const yeni = parseInt(e.target.value) || 0;
        setDKY(v => ({
          ...v,
          kupurler: v.kupurler.map(x => x.tutar === k.tutar ? {
            ...x,
            adet: yeni
          } : x)
        }));
      },
      style: {
        ...I,
        width: 80,
        textAlign: "center"
      }
    }), React.createElement("button", {
      onClick: () => setDKY(v => ({
        ...v,
        kupurler: v.kupurler.filter(x => x.tutar !== k.tutar)
      })),
      style: {
        marginLeft: "auto",
        background: "none",
        border: "none",
        color: "#94a3b8",
        cursor: "pointer",
        fontSize: 12,
        fontFamily: "inherit"
      },
      onMouseEnter: e => e.target.style.color = "#ef4444",
      onMouseLeave: e => e.target.style.color = "#94a3b8"
    }, "\u2715 Sil"));
  })), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#a2b1c6"
    }
  }, "Yeni kup\xFCr ekle:"), [200, 100, 50, 20, 10, 5].filter(t => !(dKY.kupurler || []).some(k => k.tutar === t)).map(t => React.createElement("button", {
    key: t,
    onClick: () => setDKY(v => ({
      ...v,
      kupurler: [...(v.kupurler || []), {
        tutar: t,
        adet: 0
      }]
    })),
    style: {
      background: "#0f1117",
      border: `1px solid ${KUPUR_RENK[t]}55`,
      borderRadius: 7,
      color: KUPUR_RENK[t],
      cursor: "pointer",
      padding: "6px 13px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "+ ", t, " TL")), [200, 100, 50, 20, 10, 5].every(t => (dKY.kupurler || []).some(k => k.tutar === t)) && React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#94a3b8"
    }
  }, "T\xFCm standart kup\xFCrler eklendi")), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginTop: 12
    }
  }, "Toplam ihtiya\xE7 (", dKY.kasaSayisi || 0, " kasa): ", (dKY.kupurler || []).slice().sort((a, b) => b.tutar - a.tutar).map(k => `${k.tutar}TL×${(k.adet || 0) * (dKY.kasaSayisi || 0)}`).join(" · "))), React.createElement(SB, {
    label: "BANKALAR",
    accent: "#ec4899"
  }, React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7,
      marginBottom: 12
    }
  }, dB.map((b, bi) => React.createElement("div", {
    key: b.id,
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      background: "#0f1117",
      border: `1px solid ${BCOLS[bi % BCOLS.length]}33`,
      borderRadius: 8,
      padding: "9px 14px"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("div", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 2,
      background: BCOLS[bi % BCOLS.length]
    }
  }), React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#e2e8f0"
    }
  }, b.ad), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "#94a3b8"
    }
  }, "(", dK.filter(k => k.bankaId === b.id).length, " kasa)")), React.createElement("button", {
    onClick: () => delBanka(b.id),
    style: {
      background: "none",
      border: "none",
      color: "#94a3b8",
      cursor: "pointer",
      fontSize: 12,
      fontFamily: "inherit"
    },
    onMouseEnter: e => e.target.style.color = "#ef4444",
    onMouseLeave: e => e.target.style.color = "#94a3b8"
  }, "\u2715 Sil")))), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, React.createElement("input", {
    placeholder: "Yeni banka ad\u0131...",
    value: newBAd,
    onChange: e => setNewBAd(e.target.value),
    onKeyDown: e => e.key === "Enter" && addBanka(),
    style: {
      ...I,
      flex: 1
    }
  }), React.createElement("button", {
    onClick: addBanka,
    style: {
      background: "#1e3a5f",
      border: "1px solid #3b82f6",
      borderRadius: 8,
      color: "#60a5fa",
      cursor: "pointer",
      padding: "9px 16px",
      fontSize: 12,
      fontFamily: "inherit",
      whiteSpace: "nowrap"
    }
  }, "+ Ekle"))), React.createElement(SB, {
    label: "KASALAR / POS TERM\u0130NALLER\u0130",
    accent: "#f97316"
  }, React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      marginBottom: 12
    }
  }, dK.map(k => React.createElement(KasaAyarSatiri, {
    key: k.id,
    k: k,
    bankalar: dB,
    onSave: next => {
      const cleaned = {
        ...next,
        ad: next.ad.trim(),
        kod: next.kod.trim()
      };
      if (!cleaned.ad || !cleaned.kod) throw Error("Kasa adı ve numarası boş bırakılamaz.");
      if (!cfg.bankalar.some(b => b.id === cleaned.bankaId)) throw Error("Önce bankayı genel Kaydet ile kaydedin.");
      if (dK.some(x => x.id !== cleaned.id && x.bankaId === cleaned.bankaId && x.kod === cleaned.kod)) throw Error("Bu bankada aynı kasa numarası zaten var.");
      const exists = cfg.kasalar.some(x => x.id === cleaned.id);
      if (saveCfg({
        ...cfg,
        kasalar: exists ? cfg.kasalar.map(x => x.id === cleaned.id ? cleaned : x) : [...cfg.kasalar, cleaned]
      }) === false) throw Error("Kasa kaydedilemedi.");
      setDK(p => p.map(x => x.id === cleaned.id ? cleaned : x));
    },
    onDelete: () => delKasa(k.id)
  }))), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 120px 1fr auto",
      gap: 8,
      alignItems: "end"
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "KASA ADI"), React.createElement("input", {
    placeholder: "KASA 5",
    value: newK.ad,
    onChange: e => setNewK(v => ({
      ...v,
      ad: e.target.value
    })),
    style: {
      ...I
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "KOD"), React.createElement("input", {
    placeholder: "123456",
    value: newK.kod,
    onChange: e => setNewK(v => ({
      ...v,
      kod: e.target.value
    })),
    style: {
      ...I
    }
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#a2b1c6",
      marginBottom: 5,
      letterSpacing: 1
    }
  }, "BANKA"), React.createElement("select", {
    value: newK.bankaId,
    onChange: e => setNewK(v => ({
      ...v,
      bankaId: e.target.value
    })),
    style: {
      ...I
    }
  }, dB.map(b => React.createElement("option", {
    key: b.id,
    value: b.id
  }, b.ad)))), React.createElement("button", {
    onClick: addKasa,
    style: {
      background: "#1e3a5f",
      border: "1px solid #3b82f6",
      borderRadius: 8,
      color: "#60a5fa",
      cursor: "pointer",
      padding: "9px 16px",
      fontSize: 12,
      fontFamily: "inherit",
      whiteSpace: "nowrap"
    }
  }, "+ Ekle"))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginBottom: 14
    }
  }, React.createElement("button", {
    className: "btn-hover",
    onClick: doSave,
    style: {
      background: "#166534",
      border: "1px solid #22c55e",
      borderRadius: 10,
      color: "#4ade80",
      cursor: "pointer",
      padding: "11px 28px",
      fontSize: 13,
      fontFamily: "inherit",
      fontWeight: 600,
      letterSpacing: 1
    }
  }, "\u2713 KAYDET"), ok && React.createElement("span", {
    className: "fi",
    style: {
      fontSize: 12,
      color: "#4ade80"
    }
  }, "\u2713 Ayarlar kaydedildi")), React.createElement(SB, {
    label: "YEDEKLEME VE DI\u015EA AKTARMA",
    accent: "#a855f7"
  }, yedekMsg && React.createElement("div", {
    className: "fi",
    style: {
      background: "#14301f",
      border: "1px solid #22c55e",
      borderRadius: 8,
      padding: "9px 14px",
      marginBottom: 12,
      fontSize: 12,
      color: "#4ade80"
    }
  }, yedekMsg), React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginBottom: 8,
      fontWeight: 600
    }
  }, "\uD83D\uDCBE TAM YEDEK (T\xFCm veriler \u2014 ba\u015Fka bilgisayara ta\u015F\u0131mak i\xE7in)"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, React.createElement("button", {
    className: "btn-hover",
    onClick: jsonYedekAl,
    style: {
      background: "#1e3a5f",
      border: "1px solid #3b82f6",
      borderRadius: 8,
      color: "#60a5fa",
      cursor: "pointer",
      padding: "10px 18px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, React.createElement(UiIcon, {
    kind: "download"
  }), " Yedek Dosyas\u0131 \u0130ndir (.json)"), React.createElement("button", {
    className: "btn-hover",
    onClick: () => fileInputRef.current?.click(),
    style: {
      background: "#2d1f3d",
      border: "1px solid #a855f7",
      borderRadius: 8,
      color: "#c084fc",
      cursor: "pointer",
      padding: "10px 18px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, React.createElement(UiIcon, {
    kind: "upload"
  }), " Yedekten Geri Y\xFCkle"), React.createElement("input", {
    ref: fileInputRef,
    type: "file",
    accept: ".json",
    onChange: handleFileSelect,
    style: {
      display: "none"
    }
  })), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginTop: 6
    }
  }, "Yedek dosyas\u0131 i\u015Flemleri, ayarlar\u0131, para say\u0131m\u0131n\u0131 ve kasa durumunu i\xE7erir.")), React.createElement("div", {
    style: {
      height: 1,
      background: "#1e293b",
      margin: "14px 0"
    }
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginBottom: 8,
      fontWeight: 600
    }
  }, "\uD83D\uDCCA EXCEL'E AKTAR"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, React.createElement("button", {
    className: "btn-hover",
    onClick: () => excelIslemGecmisi(txs, cfg),
    style: {
      background: "#14301f",
      border: "1px solid #22c55e",
      borderRadius: 8,
      color: "#4ade80",
      cursor: "pointer",
      padding: "10px 16px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\uD83D\uDCCB \u0130\u015Flem Ge\xE7mi\u015Fi"), React.createElement("button", {
    className: "btn-hover",
    onClick: () => excelGunlukRapor(txs, cfg),
    style: {
      background: "#14301f",
      border: "1px solid #22c55e",
      borderRadius: 8,
      color: "#4ade80",
      cursor: "pointer",
      padding: "10px 16px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\uD83D\uDCC5 G\xFCnl\xFCk Yat\u0131\u015F Raporu"), React.createElement("button", {
    className: "btn-hover",
    onClick: () => excelParaLog(paraLog),
    style: {
      background: "#2d2410",
      border: "1px solid #f59e0b",
      borderRadius: 8,
      color: "#fbbf24",
      cursor: "pointer",
      padding: "10px 16px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\uD83D\uDCB5 Para Giri\u015F/\xC7\u0131k\u0131\u015F D\xF6k\xFCm\xFC"), React.createElement("button", {
    className: "btn-hover",
    onClick: () => excelKasaLog(kasaLog),
    style: {
      background: "#2d1810",
      border: "1px solid #f97316",
      borderRadius: 8,
      color: "#fb923c",
      cursor: "pointer",
      padding: "10px 16px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\u2696\uFE0F Kasa Fazla/Eksik D\xF6k\xFCm\xFC"), React.createElement("button", {
    className: "btn-hover",
    onClick: () => excelKasaSayimi(sayimlar),
    style: {
      background: "#1a2d2a",
      border: "1px solid #14b8a6",
      borderRadius: 8,
      color: "#2dd4bf",
      cursor: "pointer",
      padding: "10px 16px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "\uD83E\uDDEE Kasa Say\u0131m\u0131 D\xF6k\xFCm\xFC")), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "#94a3b8",
      marginTop: 6
    }
  }, txs.length, " i\u015Flem \xB7 ", (paraLog || []).length, " para kayd\u0131 \xB7 ", (kasaLog || []).length, " kasa kayd\u0131 \xB7 ", (sayimlar || []).length, " say\u0131m \xB7 Dosyalar \"\u0130ndirilenler\" klas\xF6r\xFCne kaydedilir."))), pendingFile && React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "#00000099",
      zIndex: 500,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, React.createElement("div", {
    style: {
      background: "#141825",
      border: "1px solid #a855f7",
      borderRadius: 14,
      padding: "28px",
      width: 430,
      maxWidth: "90vw",
      textAlign: "center"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 28,
      marginBottom: 12
    }
  }, "\u26A0\uFE0F"), React.createElement("div", {
    style: {
      fontSize: 15,
      color: "#f1f5f9",
      fontWeight: 600,
      marginBottom: 8
    }
  }, "Yedekten Geri Y\xFCkle"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "#94a3b8",
      marginBottom: 6
    }
  }, "Se\xE7ilen dosya: ", React.createElement("span", {
    style: {
      color: "#c084fc"
    }
  }, pendingFile.name)), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "#f87171",
      marginBottom: 20
    }
  }, "\xD6nce dosya do\u011Frulanacak, de\u011Fi\u015Fecek alanlar g\xF6sterilecek ve g\xFCvenlik yede\u011Fi istenecek. Devam edilsin mi?"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      justifyContent: "center"
    }
  }, React.createElement("button", {
    onClick: () => setPendingFile(null),
    style: {
      background: "#1e293b",
      border: "1px solid #2d3748",
      borderRadius: 8,
      color: "#94a3b8",
      cursor: "pointer",
      padding: "9px 24px",
      fontSize: 12,
      fontFamily: "inherit"
    }
  }, "\u0130ptal"), React.createElement("button", {
    className: "btn-hover",
    onClick: confirmRestore,
    style: {
      background: "#2d1f3d",
      border: "1px solid #a855f7",
      borderRadius: 8,
      color: "#c084fc",
      cursor: "pointer",
      padding: "9px 24px",
      fontSize: 12,
      fontFamily: "inherit",
      fontWeight: 600
    }
  }, "Evet, Geri Y\xFCkle")))));
}
let bootError = "";
try {
  POSGuard.recover(localStorage);
  const raw = {};
  for (const k of POSGuard.KEYS) {
    const text = localStorage.getItem("pos:" + k);
    if (text !== null) raw[k] = JSON.parse(text);
  }
  if (Object.hasOwn(raw, "cfg") || Object.hasOwn(raw, "txs")) POSGuard.validatePackage(raw, {}, DEF_CFG);
} catch (e) {
  bootError = e.message;
}
const root = ReactDOM.createRoot(document.getElementById("root"));
if (!bootError) root.render(React.createElement(App));else root.render(React.createElement("div", {
  style: {
    padding: 32,
    color: "#fca5a5"
  }
}, React.createElement("h2", null, "Kay\u0131t g\xFCvenli\u011Fi nedeniyle a\xE7\u0131l\u0131\u015F durduruldu"), React.createElement("p", null, bootError), React.createElement("p", null, "Mevcut kay\u0131tlar otomatik s\u0131f\u0131rlanmad\u0131. Verileri temizlemeyin."), React.createElement("button", {
  onClick: async () => {
    try {
      const raw = {};
      for (const k of [...POSGuard.KEYS, "restoreSafetyBackup", "restoreJournal"]) raw[k] = localStorage.getItem("pos:" + k);
      await saveBackupDocument("POS-HAM-KURTARMA.json", JSON.stringify(raw, null, 2));
    } catch (e) {
      alert(e.message);
    }
  }
}, "Ham kurtarma kopyas\u0131n\u0131 kaydet"), React.createElement("label", null, " Do\u011Frulanm\u0131\u015F tam yedekten kurtar ", React.createElement("input", {
  type: "file",
  accept: ".json",
  onChange: e => {
    const f = e.target.files[0];
    if (f) jsonGeriYukle(f, (ok, msg) => {
      alert(msg);
      if (ok) window.location.reload();
    });
  }
}))));
window.addEventListener("error", e => {
  if (/Kayıt yazılamadı/.test(e.message)) alert(e.message);
});
