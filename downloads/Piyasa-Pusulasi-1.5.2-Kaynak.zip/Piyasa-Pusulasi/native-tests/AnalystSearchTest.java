package tr.piyasapusulasi.mobile;
import java.net.*;import java.io.*;import java.nio.charset.StandardCharsets;
public final class AnalystSearchTest{
 static Fake last;static int requests;
 static class Fake extends HttpURLConnection{
  ByteArrayOutputStream sent=new ByteArrayOutputStream();Fake(URL u){super(u);last=this;requests++;}
  public void connect(){}public void disconnect(){}public boolean usingProxy(){return false;}
  public OutputStream getOutputStream(){return sent;}
  public int getResponseCode(){return 200;}
  public InputStream getInputStream(){return new ByteArrayInputStream("<li>result</li>".getBytes(StandardCharsets.UTF_8));}
 }
 public static void main(String[]args)throws Exception{
  URL.setURLStreamHandlerFactory(p->"https".equals(p)?new URLStreamHandler(){protected URLConnection openConnection(URL u){return new Fake(u);}}:null);
  String url="https://www.hedeffiyat.com.tr/ajax/senet-ara.php";
  MarketHttp.Reply r=MarketHttp.read(url,"POST","kelime=THYAO&auth=1","");
  if(r.status!=200||!last.sent.toString("UTF-8").equals("kelime=THYAO&auth=1")||!"application/x-www-form-urlencoded".equals(last.getRequestProperty("Content-Type"))||!"https://www.hedeffiyat.com.tr/".equals(last.getRequestProperty("Referer")))throw new AssertionError("Search protocol broken");
  int count=requests;for(String body:new String[]{"kelime=THYAO&auth=1&other=2","kelime=THYAO&auth=0","kelime=THYAO%26x&auth=1","{\"kelime\":\"THYAO\",\"auth\":1}"}){try{MarketHttp.read(url,"POST",body,"");throw new AssertionError("Bad form accepted");}catch(IOException expected){}}
  try{MarketHttp.read(url,"GET","","");throw new AssertionError("GET accepted");}catch(IOException expected){}
  if(requests!=count)throw new AssertionError("Invalid requests reached network");System.out.println("PASS native analyst search: exact form, content-type, referer, invalid body/method rejected");
 }
}
