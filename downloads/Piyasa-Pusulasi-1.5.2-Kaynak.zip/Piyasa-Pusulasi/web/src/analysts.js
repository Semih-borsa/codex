import {normalize} from './core.js';
const origin='https://www.hedeffiyat.com.tr';
const fold=s=>String(s||'').toLocaleLowerCase('tr-TR').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ı/g,'i').replace(/[^a-z0-9]/g,'');
export function stockSourceUrl(path,symbol){const s=normalize('BIST',symbol);if(!/^[A-Z0-9]{1,12}$/.test(s))throw Error('Standart BIST kodu gerekli.');const u=new URL(path,origin);if(u.origin!==origin||u.username||u.password||u.search||u.hash||!u.pathname.toLowerCase().startsWith('/senet/'+s.toLowerCase()+'-')||!/^\/senet\/[a-z0-9.%_-]+$/i.test(u.pathname))throw Error('Şirket kaynak adresi doğrulanamadı.');return u.href;}
function documentFrom(html){if(typeof html!=='string'||html.length>4000000)throw Error('Kaynak sayfası geçersiz veya çok büyük.');const clean=html.replace(/<(script|style|iframe|object|embed|video|audio)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'').replace(/<(?:img|link|source|base|meta)\b[^>]*>/gi,'');return new DOMParser().parseFromString(clean,'text/html');}
export function findAnalystPage(html,symbol){const doc=documentFrom(html),urls=new Set();for(const e of doc.querySelectorAll('option[value],a[href]')){try{urls.add(stockSourceUrl(e.getAttribute('value')||e.getAttribute('href'),symbol));}catch{}}if(urls.size!==1)throw Error(urls.size?'Şirket için birden fazla kaynak adresi var; eşleştirme belirsiz.':'Şirketin analist sayfası bulunamadı.');return [...urls][0];}
export function reportDate(value,now=Date.now()){
 let text=String(value).trim(),m=text.match(/^(\d{2})[./-](\d{2})[./-](\d{4})$/),key=m?m[3]+'-'+m[2]+'-'+m[1]:/^\d{4}-\d{2}-\d{2}$/.test(text)?text:null;
 if(!key)return null;const stamp=Date.parse(key+'T00:00:00Z');if(!Number.isFinite(stamp)||new Date(stamp).toISOString().slice(0,10)!==key)return null;
 const parts=new Intl.DateTimeFormat('en',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(now));const d=Object.fromEntries(parts.map(p=>[p.type,p.value])),todayKey=d.year+'-'+d.month+'-'+d.day;
 if(key>todayKey)return null;return {key,stamp,ageDays:Math.floor((Date.parse(todayKey+'T00:00:00Z')-stamp)/86400000)};
}
export function recommendation(text){const s=fold(text);return ['al','alim','guclual','guclualim'].includes(s)?'buy':['tut','tutma'].includes(s)?'hold':['sat','satim','guclusat','guclusatim'].includes(s)?'sell':s.includes('endeks')?'relative':s==='notr'?'neutral':'unknown';}
export function targetValue(text,header=''){
 const value=String(text).trim(),combined=(value+' '+header).toUpperCase();const currencies=[[/\b(?:USD|DOLAR)\b|\$/,'USD'],[/\bEUR\b|€/,'EUR'],[/\b(?:TRY|TL)\b|₺/,'TRY']].filter(([re])=>re.test(combined)).map(([,c])=>c);let currency=currencies.length===1?currencies[0]:null;
 const token=value.replace(/\b(?:TRY|TL|USD|EUR)\b/gi,'').replace(/[₺$€\s]/g,'');let numeric=null;
 if(/^\d{1,3}(?:\.\d{3})*(?:,\d{1,4})?$/.test(token)&&token.includes(','))numeric=Number(token.replaceAll('.','').replace(',','.'));
 else if(/^\d+(?:,\d{1,4})?$/.test(token)&&token.includes(','))numeric=Number(token.replace(',','.'));
 else if(/^\d+$/.test(token))numeric=Number(token);
 else if(/^\d+\.\d{1,2}$/.test(token))numeric=Number(token);
 if(!Number.isFinite(numeric)||numeric<=0)numeric=null;return {value:numeric,currency,raw:value.slice(0,100)};
}
export function parseAnalystPage(html,symbol,url,{now=Date.now(),imported=false}={}){
 const sourceUrl=stockSourceUrl(url,symbol),doc=documentFrom(html),rows=[];let rejected=0;
 for(const table of doc.querySelectorAll('table')){
  const lines=[...table.querySelectorAll('tr')];let indices=null,headers;
  for(const tr of lines){const cells=[...tr.children].filter(c=>/^(TH|TD)$/.test(c.tagName));if(cells.length<3)continue;const texts=cells.map(c=>c.textContent.trim().replace(/\s+/g,' ')),keys=texts.map(fold);
   const broker=keys.findIndex(k=>['kurum','aracikurum','kurumadi','aracikurulus','aracikurumadi'].includes(k)),date=keys.findIndex(k=>['tarih','raportarihi','guncellemetarihi','yayintarihi'].includes(k)),rec=keys.findIndex(k=>['tavsiye','oneri','tavsiyeoneri','yatirimtavsiyesi'].includes(k));
   if(broker>=0&&date>=0&&rec>=0){const targets=keys.map((k,i)=>({k,i})).filter(({k})=>k.includes('hedef')&&k.includes('fiyat')&&!/onceki|eski/.test(k));const newer=targets.filter(({k})=>/yeni|guncel/.test(k));indices={broker,date,rec,target:(newer.length===1?newer:targets).length===1?(newer.length===1?newer:targets)[0].i:-1};headers=texts;continue;}
   if(!indices)continue;if([indices.broker,indices.date,indices.rec].some(i=>i>=texts.length)){rejected++;continue;}const brokerName=texts[indices.broker],dateRaw=texts[indices.date],advice=texts[indices.rec];if(!brokerName||brokerName.length>150||!advice||advice.length>150){rejected++;continue;}
   const parsedDate=reportDate(dateRaw,now),target=indices.target>=0?targetValue(texts[indices.target]||'',headers[indices.target]):{value:null,currency:null,raw:'Hedef sütunu yok veya belirsiz'};
   rows.push({broker:brokerName,dateRaw:dateRaw.slice(0,100),date:parsedDate?.key??null,ageDays:parsedDate?.ageDays??null,advice,category:recommendation(advice),target,sourceUrl,dateHeading:headers[indices.date],imported});
  }
 }
 // Public report cards, verified against the current source markup (2026-10-16).
 for(const card of doc.querySelectorAll('.senetbox[data-href]')){
  const company=card.querySelector('a.senetbox-title[href]');try{if(!company||stockSourceUrl(company.getAttribute('href'),symbol)!==sourceUrl)continue;}catch{continue;}
  const broker=card.querySelector('a.kurumLogo[title]')?.getAttribute('title')?.trim();
  const adviceLink=[...card.querySelectorAll('a[href]')].find(e=>e.getAttribute('href')===card.getAttribute('data-href'));
  const advice=adviceLink?.textContent?.trim();const dateRaw=card.querySelector('.senettarih')?.textContent?.trim().replace(/\s+/g,' ')||'';
  const months=['ocak','subat','mart','nisan','mayis','haziran','temmuz','agustos','eylul','ekim','kasim','aralik'];
  const match=dateRaw.match(/(?:^|,\s*)(\d{1,2})\s+([^\s]+)\s+(\d{4})$/);const month=match?months.indexOf(fold(match[2]))+1:0;
  const dateText=match&&month?match[3]+'-'+String(month).padStart(2,'0')+'-'+match[1].padStart(2,'0'):dateRaw;
  const parsedDate=reportDate(dateText,now),price=card.querySelector('.hedeffiyat.badge span')?.textContent?.trim()||'';
  if(!broker||broker.length>150||!advice||advice.length>150){rejected++;continue;}
  rows.push({broker,dateRaw:dateRaw.slice(0,100),date:parsedDate?.key??null,ageDays:parsedDate?.ageDays??null,advice,category:recommendation(advice),target:targetValue(price),sourceUrl,dateHeading:'Kaynak rapor tarihi',imported});
 }
 if(rows.length>1000)throw Error('Kaynakta beklenenden fazla rapor satırı var; yapı doğrulanamadı.');
 if(!rows.length)throw Error('Doğrulanabilir kurum raporu bulunamadı. Bu hissede rapor olmayabilir veya kaynak sayfa yapısı değişmiş olabilir.');
 return {symbol:normalize('BIST',symbol),sourceUrl,provider:'Hedef Fiyat · derleme kaynağı',loadedAt:now,rows,rejected,imported};
}
export function analystSummary(rows,days=90){
 const unique=[...new Map(rows.map(r=>[[fold(r.broker),r.date||r.dateRaw,r.advice,r.target.raw].join('|'),r])).values()],recent=unique.filter(r=>r.date&&r.ageDays<=days),groups=new Map();
 for(const r of recent){const key=fold(r.broker),list=groups.get(key)||[];groups.set(key,[...list,r]);}
 const latest=[],conflicts=[];for(const list of groups.values()){const date=list.map(r=>r.date).sort().at(-1),same=list.filter(r=>r.date===date);if(same.length!==1){conflicts.push(...same);continue;}latest.push(same[0]);}
 const counts={buy:0,hold:0,sell:0,relative:0,neutral:0,unknown:0};latest.forEach(r=>counts[r.category]++);
 const targets=latest.filter(r=>r.target.currency==='TRY'&&r.target.value!==null).map(r=>r.target.value).sort((a,b)=>a-b),n=targets.length;
 return {latest:latest.sort((a,b)=>b.date.localeCompare(a.date)),old:unique.filter(r=>r.date&&r.ageDays>days),undated:unique.filter(r=>!r.date),conflicts,counts,targetCount:n,mean:n?targets.reduce((a,b)=>a+b,0)/n:null,median:n?(n%2?targets[(n-1)/2]:(targets[n/2-1]+targets[n/2])/2):null,low:n?targets[0]:null,high:n?targets.at(-1):null,days};
}
export async function fetchAnalysts(requestPage,symbol){
 symbol=normalize('BIST',symbol);if(!/^[A-Z0-9]{1,12}$/.test(symbol))throw Error('Standart BIST kodu gerekli.');const warnings=[];
 const read=async(url,stage)=>{try{const r=await requestPage(url);if(!r||typeof r.body!=='string'||(![200,201,202,203,204,205,206,404].includes(r.status)))throw Error('Geçerli sayfa yanıtı alınamadı.');return r;}catch(e){throw Error(stage+': '+e.message);}};
 const search=await readSearch();
 async function readSearch(){try{const r=await requestPage(origin+'/ajax/senet-ara.php','POST',{kelime:symbol,auth:1});if(!r||r.status!==200||typeof r.body!=='string')throw Error('Geçerli arama yanıtı alınamadı.');return r;}catch(e){throw Error('Analist şirket araması: '+e.message);}}
 let url;try{url=findAnalystPage(search.body,symbol);}catch{throw Error(symbol+' için kaynakta eşleşen şirket bulunamadı; hedef fiyat üretilmedi.');}
 const page=await read(url,'Analist hisse sayfası');if(page.status===404){const doc=documentFrom(page.body),pattern=new RegExp('(^|[^A-Z0-9])'+symbol+'([^A-Z0-9]|$)');const identified=[...doc.querySelectorAll('title,h1,h2')].some(e=>pattern.test(e.textContent.toUpperCase()));if(!identified)throw Error('Analist hisse sayfası HTTP404: içerikte '+symbol+' şirket kimliği doğrulanamadı; hata sayfası rapor olarak kullanılmadı.');}let result;try{result=parseAnalystPage(page.body,symbol,url);}catch(e){throw Error('Analist hisse sayfası HTTP'+page.status+': '+e.message);}
 if(page.status===404)warnings.push('Kaynak hisse sayfası HTTP404 ile rapor içeriği döndürdü; yalnız tanınan kurum/tarih/tavsiye satırları okundu.');return {...result,transportWarnings:warnings,httpStatus:page.status};
}
