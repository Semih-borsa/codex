# POS Kasa Yönetim — Build v44 / 1.5.4

Güncel belgeler **KULLANIM-v44.md** ve **SONUC-RAPORU-v44.md**. Önceki belgeler arşivdir.

Özet'e gün sonu POS/nakit kayıt kontrolü ve satış dağılımı pay değişimi yorumları eklendi. Kontrol tarihinin varsayılanı dün;0 TL girilmiş kayıt ile kayıtsız gün ayrıdır. Görüntüleme finans verilerini değiştirmez.

Tam kaynak paketidir. Windows'ta `pos-app/BUILD.bat` ile derleyin. Oluşan win-unpacked klasörünün tamamını kullanın. Gömülü OCR ayrıca dil kurulumu gerektirmez. Önce JSON yedeği alın; uygulama verilerini temizlemeyin.
