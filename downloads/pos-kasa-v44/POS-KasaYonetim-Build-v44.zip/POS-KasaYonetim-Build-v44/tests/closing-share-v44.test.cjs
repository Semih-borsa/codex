const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm'),G=require('../pos-app/safety');
const source=fs.readFileSync(__dirname+'/../pos-app/app-source.jsx','utf8'),ctx=vm.createContext({POSGuard:G,Date,Math,Number,String,Error,toS:d=>d.toISOString().slice(0,10)});vm.runInContext(source.slice(source.indexOf('function posAmount'),source.indexOf('function PosMutabakat')),ctx);
const cfg={bankalar:[{id:'b',ad:'BANKA'}],kasalar:[{id:'k1',ad:'KASA 1',kod:'1',bankaId:'b'},{id:'k2',ad:'KASA 2',kod:'2',bankaId:'b'},{id:'off',ad:'PASİF',kod:'3',bankaId:'b',aktif:false}],vadeGunleri:{'KREDİ KARTI':21,'DEBİT KART':1}},day='2026-10-27';
const tx=(id,kasaId='k1',tutar=100,date=day)=>({id,kasaId,bankaId:'b',tutar,islemTarihi:date,yatacakTarih:'2026-11-17',tur:'KREDİ KARTI'}),cash=(id,kasaId='k1',tutar=0,date=day)=>({id,kasaId,tutar,tarih:date});
const close=(txs=[],nakit=[])=>ctx.gunSonuKontrol(txs,nakit,cfg,day);
test('Eksik aktif kasa görünür; pasif boş kasa uyarı üretmez',()=>{const d=close();assert.equal(d.toplam,2);assert.equal(d.tamam,0);assert.ok(d.kasalar.every(k=>k.pos.durum==='eksik'&&k.nakit.durum==='eksik'));});
test('Girilen sıfır nakit ile hiç kayıt bulunmaması farklıdır',()=>{const d=close([tx('p')],[cash('c')]);assert.equal(d.kasalar[0].nakit.durum,'sifir');assert.equal(d.kasalar[1].nakit.durum,'eksik');assert.equal(d.tamam,1);assert.equal(d.posGirilen,1);assert.equal(d.nakitGirilen,1);});
test('POS kontrolünde satış günü esas, bankaya yatış günü değil',()=>{assert.equal(close([tx('p')]).kasalar[0].pos.tutar,100);assert.equal(ctx.gunSonuKontrol([tx('p')],[],cfg,'2026-11-17').kasalar[0].pos.durum,'eksik');});
test('Toplam POS ve bağlı debit yalnız bir satış; kalan kredi0 satış0 değildir',()=>{const c={...tx('p'),tutar:0,posToplam:100,mutabakatId:'g'},d={...tx('d'),tur:'DEBİT KART',tutar:100,mutabakatId:'g',tahsilEdildi:true,yatacakTarih:'2026-10-28'};const r=close([c,d]).kasalar[0].pos;assert.equal(r.tutar,100);assert.equal(r.adet,1);assert.equal(r.durum,'girildi');});
test('Yalnız bağlı debit satış toplamı yokken tamam işareti üretmez',()=>assert.equal(close([{...tx('d'),tur:'DEBİT KART',mutabakatId:'missing',tahsilEdildi:true}]).kasalar[0].pos.durum,'eksik'));
test('Normal kredi/debit veya fiş parçalarının toplamı korunur',()=>assert.equal(close([tx('c'),{...tx('d'),tur:'DEBİT KART',tutar:50}]).kasalar[0].pos.tutar,150));
test('Birden çok nakit kaydı kuruşla toplanır ve kayıt sayısı korunur',()=>{const r=close([],[cash('1','k1',0.1),cash('2','k1',0.2)]).kasalar[0].nakit;assert.equal(r.tutar,0.3);assert.equal(r.adet,2);assert.equal(r.durum,'girildi');});
test('Tarihsel pasif kasa kaydı görünür, eksik diğer gün kaydı eklenmez',()=>{const d=close([tx('off','off')],[cash('c','off')]);assert.equal(d.toplam,3);assert.equal(d.kasalar[2].kasa.aktif,false);assert.equal(d.tamam,1);});
test('Silme durumu yeniden okununca eksik olur; sıfır kayıt yaratılmaz',()=>{const records=[cash('c')];close([],records);assert.equal(close([],[]).kasalar[0].nakit.durum,'eksik');assert.equal(records.length,1);});
test('Kontrol tarihi geçersizse reddedilir',()=>assert.throws(()=>ctx.gunSonuKontrol([],[],cfg,'2026-02-30')));
const prev=(a,b,f)=>JSON.parse(JSON.stringify(ctx.dagilimOncekiAralik(a,b,f)));
for(const [a,b,f,expected] of [
 ['2026-10-22','2026-10-28','hafta',['2026-10-15','2026-10-21']],
 ['2026-10-15','2026-10-21','gecenHafta',['2026-10-08','2026-10-14']],
 ['2026-10-01','2026-10-26','ay',['2026-09-01','2026-09-26']],
 ['2026-03-01','2026-03-31','ay',['2026-02-01','2026-02-28']],
 ['2028-03-01','2028-03-31','ay',['2028-02-01','2028-02-29']],
 ['2026-01-01','2026-01-12','ay',['2025-12-01','2025-12-12']],
 ['2026-02-01','2026-02-28','gecenAy',['2026-01-01','2026-01-31']],
 ['2028-01-01','2028-02-29','yil',['2027-01-01','2027-02-28']],
 ['2026-10-25','2026-10-27','ozel',['2026-10-22','2026-10-24']],
 ['2026-01-01','2026-01-01','ozel',['2025-12-31','2025-12-31']]
])test('Önceki karşılaştırma aralığı '+f+' '+a+' / '+b,()=>{const r=prev(a,b,f);assert.equal(r.bas,expected[0]);assert.equal(r.bit,expected[1]);});
const calc=(txs,nakit,veresiye=[],bas='2026-10-22',bit='2026-10-28',filter='hafta')=>ctx.satisDagilimKiyas(txs,nakit,cfg,bas,bit,veresiye,filter);
test('Nakit payı20den25e: artış5 puan, yüzde25 olarak yanlış ifade edilmez',()=>{const d=calc([tx('now','k1',75),tx('old','k1',80,'2026-10-20')],[cash('now','k1',25),cash('old','k1',20,'2026-10-20')]);assert.equal(d.durum,'hazir');assert.equal(d.degisimler.find(r=>r.key==='nakit').puan,5);assert.equal(ctx.dagilimYorumMetni('Nakit',5,d.onceki.etiket),'Nakit payı geçen haftaya göre 5 puan arttı.');});
test('Pay azalması ve değişmeme ayrı kısa yorum üretir',()=>{assert.match(ctx.dagilimYorumMetni('POS',-5,'geçen haftaya'),/5 puan azaldı/);assert.match(ctx.dagilimYorumMetni('Veresiye',0,'geçen haftaya'),/değişmedi/);});
test('Çok küçük fark0 puan arttı şeklinde gösterilmez',()=>assert.match(ctx.dagilimYorumMetni('POS',0.001,'önceki eşit döneme'),/0,1 puandan az arttı/));
test('Önceki dönemde veri yokken sahte karşılaştırma yok',()=>{const d=calc([tx('p')],[]);assert.equal(d.durum,'onceEksik');assert.ok(d.degisimler.every(r=>r.puan===null));});
test('Seçili dönem sıfır veya boşsa oran karşılaştırılmaz',()=>{assert.equal(calc([],[]).durum,'simdiEksik');assert.equal(calc([],[cash('zero')]).durum,'simdiEksik');});
test('Veresiye payı da üçlü toplamdan hesaplanır',()=>{const d=calc([tx('now','k1',50),tx('old','k1',100,'2026-10-20')],[],[{id:'v',tarih:day,tutar:50}]);assert.equal(d.degisimler.find(r=>r.key==='veresiye').puan,50);assert.equal(d.degisimler.find(r=>r.key==='pos').puan,-50);});
test('Bağlı debit değişse de dağılım payı değişmez',()=>{const c={...tx('p'),posToplam:100,mutabakatId:'g'},d={...tx('d'),tur:'DEBİT KART',tutar:20,mutabakatId:'g',tahsilEdildi:true};assert.equal(calc([c,d,tx('old','k1',100,'2026-10-20')],[]).simdi.pos,100);});
test('Kontrol ve karşılaştırma kaynakları değiştirmez',()=>{const ts=[tx('p')],ns=[cash('n')],before=JSON.stringify([ts,ns,cfg]);close(ts,ns);calc(ts,ns);assert.equal(JSON.stringify([ts,ns,cfg]),before);});
test('Geçersiz karşılaştırma aralığı reddedilir',()=>{assert.throws(()=>prev('2026-10-28','2026-10-22','ozel'));assert.throws(()=>prev('2026-02-30','2026-10-22','hafta'));});
