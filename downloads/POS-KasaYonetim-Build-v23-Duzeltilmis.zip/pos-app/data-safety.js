/* Existing pos:* keys and record objects are retained. No automatic reset. */
(function(global){
  const keys=['cfg','txs','para','kasadurum','paralog','kasalog','sayimlar','odemeler','plan'].map(k=>'pos:'+k);
  const journal='pos:pending-write';
  let locked=false;
  const object=v=>v!==null && typeof v==='object' && !Array.isArray(v);
  const fail=message=>{throw new Error(message);};
  function parseMoney(value){
    if(value===null || value===undefined || value==='')return 0;
    if(typeof value==='number')return Number.isFinite(value)?value:NaN;
    const s=String(value).trim(); if(!s)return 0;
    let normal;
    if(s.includes(',')) {
      if(!/^[+-]?(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d{0,2})?$/.test(s))return NaN;
      normal=s.replace(/\./g,'').replace(',','.');
    }else if(/^[+-]?\d{1,3}(?:\.\d{3})+$/.test(s))normal=s.replace(/\./g,'');
    else if(/^[+-]?\d+(?:\.\d{0,2})?$/.test(s))normal=s;
    else return NaN;
    const n=Number(normal);return Number.isFinite(n)?n:NaN;
  }
  function validDate(s){
    if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;
    const d=new Date(s+'T12:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===s;
  }
  function validate(name,value){
    if(name==='cfg'){
      if(!object(value)||!Array.isArray(value.bankalar)||!Array.isArray(value.kasalar)||!object(value.vadeGunleri))fail('Ayarların banka/kasa yapısı geçersiz.');
      for(const row of [...value.bankalar,...value.kasalar])if(!object(row)||!row.id||typeof row.ad!=='string')fail('Banka/kasa kaydı geçersiz.');
      if(value.kasaYapim!==undefined&&!object(value.kasaYapim))fail('Kasa yapımı ayarı geçersiz.');
      if(value.kasaYapim?.kupurler!==undefined&&(!Array.isArray(value.kasaYapim.kupurler)||value.kasaYapim.kupurler.some(k=>!object(k)||!Number.isFinite(Number(k.tutar))||!Number.isFinite(Number(k.adet)))))fail('Kupür ayarı geçersiz.');
    }else if(['txs','paralog','kasalog','sayimlar','odemeler'].includes(name)){
      if(!Array.isArray(value))fail(name+' bir liste olmalı.');
      value.forEach((row,i)=>{
        if(!object(row))fail(name+': '+(i+1)+'. kayıt geçersiz.');
        if(name==='txs'&&(!row.id||!row.kasaId||!row.bankaId||!validDate(row.islemTarihi)||!validDate(row.yatacakTarih)||!['KREDİ KARTI','DEBİT KART'].includes(row.tur)||typeof row.tutar!=='number'||!Number.isFinite(row.tutar)))fail('POS işlem kaydı geçersiz: '+(i+1));
        if(name==='odemeler'&&(!row.id||typeof row.ad!=='string'||!validDate(row.sonOdeme)||typeof row.tutar!=='number'||!Number.isFinite(row.tutar)||typeof row.odendi!=='boolean'))fail('Ödeme kaydı geçersiz: '+(i+1));
        if(name==='sayimlar'&&(!row.id||!validDate(row.tarih)||Object.entries(row).some(([k,v])=>!['id','tarih'].includes(k)&&(['alacak','kasalarAdet','kasaBirim','avansAdet','avansBirim','kasaYedekSabit','yk1','yk05','yk025','yk01','yk005','bp1','bp05','bp025','bp01','bp005','bozukKarisik','b200','b100','b50','b20','b10','b5','b5m','merkezKasa','toplam','fazlaEksik'].includes(k))&&!Number.isFinite(parseMoney(v)))))fail('Sayım kaydı geçersiz: '+(i+1));
        if(['paralog','kasalog'].includes(name)){
          for(const field of ['tutar','toplam','c200','c100','c50','c20','c10','c5k','c5m'])if(row[field]!==undefined&&(typeof row[field]!=='number'||!Number.isFinite(row[field])))fail('Hareket tutarı geçersiz.');
        }
      });
    }else if(['para','kasadurum','plan'].includes(name)){
      if(!object(value))fail(name+' veri yapısı geçersiz.');
      const fields=name==='para'?['c200','c100','c50','c20','c10','c5k','c5m']:name==='kasadurum'?['fazla','eksik']:['maasTutari','bankaBakiye','nakitTahmini'];
      for(const k of fields)if(value[k]!==undefined&&!Number.isFinite(parseMoney(value[k])))fail(name+': geçersiz tutar ('+k+').');
    }
    return value;
  }
  function read(k,fallback){
    const raw=localStorage.getItem(k);if(raw===null)return fallback;
    let v;try{v=JSON.parse(raw);}catch(e){fail(k+' okunamadı. Kayıt korunuyor; otomatik sıfırlama yapılmadı.');}
    if(v===null)fail(k+' boş/geçersiz. Kayıt korunuyor.');
    validate(k.replace('pos:',''),v);return v;
  }
  function recover(){
    const raw=localStorage.getItem(journal);if(raw===null)return;
    try{const before=JSON.parse(raw);if(!object(before)||Object.keys(before).some(k=>!keys.includes(k)))fail('Geçersiz kayıt günlüğü.');
      for(const [k,v] of Object.entries(before)){if(v===null)localStorage.removeItem(k);else if(typeof v==='string')localStorage.setItem(k,v);else fail('Geçersiz kayıt günlüğü.');}
      localStorage.removeItem(journal);
    }catch(e){locked=true;fail('Yarım kalan kayıt kurtarılamadı. Ham yedeği alın; veriler sıfırlanmadı. '+e.message);}
  }
  function batch(updates){
    let before=null,started=false;
    try{
      if(locked)fail('Kayıt kilitli. Programı kapatmadan ham yedek alın.');
      recover();
      const serial={};before={};
      for(const [k,v] of Object.entries(updates)){
        if(!keys.includes(k))fail('Bilinmeyen kayıt alanı.');validate(k.slice(4),v);
        serial[k]=JSON.stringify(v);before[k]=localStorage.getItem(k);
      }
      localStorage.setItem(journal,JSON.stringify(before));started=true;
      for(const [k,v] of Object.entries(serial))localStorage.setItem(k,v);
      localStorage.removeItem(journal);return true;
    }catch(e){
      if(started){try{for(const [k,v] of Object.entries(before)){if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v);}localStorage.removeItem(journal);}catch(rollback){locked=true;}}
      global.alert('KAYIT YAPILAMADI. İşlem başarılı sayılmadı.\n'+e.message+(locked?'\nKayıt kilitlendi; ham yedek alın.':''));return false;
    }
  }
  function rawSnapshot(){
    const data={};for(const k of keys)data[k]=localStorage.getItem(k);
    const pending=localStorage.getItem(journal);
    // Export the pre-operation values when a write could not be rolled back.
    if(pending){try{const before=JSON.parse(pending);for(const [k,v] of Object.entries(before))if(keys.includes(k)&&(v===null||typeof v==='string'))data[k]=v;}catch(e){}}
    return {surum:'POS-Ham-Yedek-1',tarih:new Date().toISOString(),raw:data,pendingWrite:pending};
  }
  function validateBackup(data){
    if(!object(data))fail('Yedek kökü bir nesne olmalı.');
    let d=data;
    if(data.surum==='POS-Ham-Yedek-1'){
      if(!object(data.raw))fail('Ham yedek geçersiz.');d={};
      for(const k of keys){const raw=data.raw[k];if(raw!==null&&raw!==undefined){if(typeof raw!=='string')fail('Ham yedek alanı geçersiz.');d[k.slice(4)]=JSON.parse(raw);}}
    }
    if(!Array.isArray(d.txs)&&!object(d.cfg))fail('Yedekte geçerli işlem listesi veya ayarlar bulunamadı.');
    const updates={};
    for(const k of keys){const name=k.slice(4);if(d[name]!==undefined&&d[name]!==null){validate(name,d[name]);updates[k]=d[name];}}
    if(!Object.keys(updates).length)fail('Yedekte yüklenebilir veri alanı bulunamadı.');
    return updates;
  }
  function restore(data){
    const updates=validateBackup(data);
    // Keep raw pre-restore data even when its JSON is damaged. Failure blocks restore.
    localStorage.setItem('pos:restore-backup',JSON.stringify(rawSnapshot()));
    if(!batch(updates))fail('Yedek uygulanmadı. Önceki veriler korundu veya kurtarma günlüğünde tutuluyor.');
    return updates;
  }
  global.PosSafety={keys,parseMoney,validDate,validate,read,recover,batch,rawSnapshot,restore};
})(typeof window!=='undefined'?window:globalThis);
