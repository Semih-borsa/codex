# v23 doğrulaması

- Eski biçimdeki kayıtların ilk okuma ve yeniden açılışta anahtar, kimlik ve
  bilinmeyen ek alanlarıyla değişmeden kaldığı kontrol edildi.
- Yetersiz stokla para çıkışı reddedildi; geçerli çıkışta hareket ve stok tutarı eşleşti.
- İkinci depolama yazmasında hata enjekte edildi: eski stok ve geçmiş geri alındı,
  kullanıcı girdisi korundu ve kayıt hatası bildirildi.
- Kesilen yazmanın kurtarma günlüğünden açılış öncesi geri alınması geçti.
- Hatalı JSON ve hatalı kayıt yapısı eski verileri değiştirmeden reddedildi.
- Eski tam/kısmi yedek ve yeni ham yedek geri yüklemesi, önceki verinin kurtarma
  kopyası ve kopyanın indirilebilmesi doğrulandı.
- Bozuk mevcut kayıt için boş ekran yerine kurtarma ekranı açıldı; ham kayıt korunuyor.
- Banka rezervi ve bilinmeyen mevcut ayarlar Ayarları Kaydet sonrası korundu.
- Negatif/hatalı yeni POS tutarı reddedildi; Türkçe tutarlar ve ondalık yazımı geçti.
- Tekrarlı sayım kaydı ve eski sayım yükleyip güncelleme kimlik/sayı kontrolleri geçti.
- Nakit planının standart senaryosu önceki sonuçla aynı; gecikmiş/ödenmiş fatura,
  maaş günü POS sınırı, sıfır kasa birimi ve yıl/ay sonu örnekleri doğrulandı.
- Altı sekme normal açılış/gezinmede JavaScript hatası vermedi.
- Beş mevcut Excel dışa aktarımı dosya indirdi. Kaynak karşılaştırmasında bu
  Excel fonksiyonları değişmedi.
- 960 piksel genişlikte dış yatay taşma görülmedi; rezerv alanı satıra yayılıyor.
- Ana Electron dosyası, appId/paket adı ve eski başlangıç sabitleri değişmedi.

Test ortamı: Chromium, Node.js, Europe/Istanbul saat dilimi; örnek veriler.
Windows EXE derleme, gerçek kullanıcı kayıtları ve fiziksel banka mutabakatı test edilmedi.
Electron sürümü ve güvenlik ayarları bu dar kapsamlı hata düzeltmesinde değiştirilmedi.
