package tr.piyasapusulasi.mobile;
public final class MarketHttpSecurityTest {
 public static void main(String[] args)throws Exception{
  String[] blocked={"http://api.collectapi.com/economy/hisseSenedi","https://example.com/economy/hisseSenedi","https://api.collectapi.com.evil.test/economy/hisseSenedi","https://user@api.collectapi.com/economy/hisseSenedi","https://api.collectapi.com:444/economy/hisseSenedi","https://api.collectapi.com/economy/hisseSenedi?key=ignored","https://api.collectapi.com/economy/goldPrice","https://api.collectapi.com/economy/hisseSenedi/extra"};
  for(String url:blocked){try{MarketHttp.request(url,"GET","","");throw new AssertionError("Expected URL rejection");}catch(java.io.IOException e){if(!e.getMessage().equals("Bu veri adresine izin verilmiyor."))throw new AssertionError("Unexpected rejection path");}}
  try{MarketHttp.request("https://api.collectapi.com/economy/hisseSenedi","POST","","");throw new AssertionError("Expected method rejection");}catch(java.io.IOException e){if(!e.getMessage().equals("Bu veri adresine izin verilmiyor."))throw e;}
  try{MarketHttp.request("https://api.collectapi.com/economy/hisseSenedi","GET","","");throw new AssertionError("Expected missing-key rejection before network");}catch(java.io.IOException e){if(!e.getMessage().startsWith("CollectAPI için"))throw e;}
  System.out.println("PASS 10 native URL/method/missing-key cases; no network or real keys used");
 }
}
