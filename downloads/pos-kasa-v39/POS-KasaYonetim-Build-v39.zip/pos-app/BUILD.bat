@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo POS Kasa Yonetim - Build v39
where node >nul 2>&1
if errorlevel 1 (
 echo Node.js 22 veya daha yeni LTS surumunu kurun.
 pause
 exit /b 1
)
node -e "if(Number(process.versions.node.split('.')[0])<22)process.exit(1)"
if errorlevel 1 (
 echo Node.js 22 veya daha yeni LTS gerekli.
 pause
 exit /b 1
)
call npm ci --no-fund
if errorlevel 1 goto failed
call npm test
if errorlevel 1 goto failed
call npm run dist
if errorlevel 1 goto failed
echo HAZIR: %CD%\dist\win-unpacked
explorer.exe "%CD%\dist\win-unpacked"
pause
exit /b 0
:failed
echo Islem tamamlanamadi. Yukaridaki ilk hata mesajini kontrol edin.
pause
exit /b 1
