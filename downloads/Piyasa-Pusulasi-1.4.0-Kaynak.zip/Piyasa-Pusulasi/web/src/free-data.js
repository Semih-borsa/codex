import {normalize,sma,rsi,ema} from './core.js';
const base='https://www.isyatirim.com.tr/_layouts/15/IsYatirim.Website/Common/Data.aspx/';
const fold=s=>String(s||'').toLocaleLowerCase('tr-TR').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ı/g,'i').replace(/[^a-z0-9]/g,'');
export const isBank=s=>['AKBNK','ALBRK','GARAN','HALKB','ICBCT','ISATR','ISBTR','ISCTR','ISKUR','QNBTR','QNBFB','SKBNK','TSKB','VAKBN','YKBNK'].includes(s);
// Explicit labels only. Ambiguous duplicated fields are not silently summed or selected.
const labels={assets:['Toplam Varlıklar','Toplam Aktifler','Varlıklar'],equity:['Özkaynaklar','Toplam Özkaynaklar'],currentAssets:['Dönen Varlıklar'],currentLiabilities:['Kısa Vadeli Yükümlülükler'],longLiabilities:['Uzun Vadeli Yükümlülükler'],revenue:['Hasılat','Satış Gelirleri','Net Satışlar'],grossProfit:['Brüt Kar (Zarar)','Brüt Kar/Zarar','Brüt Kar'],profit:['Dönem Karı (Zararı)','Dönem Net Kar/Zararı','Net Dönem Karı','Dönem Karı/Zararı','Net Dönem Karı (Zararı)'],cashflow:['İşletme Faaliyetlerinden Nakit Akışları','İşletme Faaliyetlerinden Kaynaklanan Net Nakit','İşletme Faaliyetlerinden Elde Edilen Nakit Akışları'],shares:['Dolaşımdaki Pay Sayısı','Dolaşımdaki Hisse Sayısı']};
function num(v){if(typeof v==='number')return Number.isFinite(v)?v:null;if(typeof v==='string'&&/^-?\d+(?:\.\d+)?$/.test(v.trim())){const n=Number(v);return Number.isFinite(n)?n:null;}return null;}
export function periodsFor(mode='annual',now=new Date()){
 const y=now.getUTCFullYear(),m=now.getUTCMonth()+1;
 if(mode==='annual')return Array.from({length:4},(_,i)=>({year:y-1-i,month:12}));
 let year=y,month=Math.floor((m-1)/3)*3;if(!month){year--;month=12;}
 return Array.from({length:4},()=>{const p={year,month};month-=3;if(!month){year--;month=12;}return p;});
}
export function financialUrl(symbol,periods,bank=false,alternative=false){symbol=normalize('BIST',symbol);if(!/^[A-Z0-9]{1,12}$/.test(symbol))throw Error('Bu kaynak için standart BIST kodu gerekli.');const q=new URLSearchParams({companyCode:symbol,exchange:'TRY',financialGroup:alternative?(bank?'2':'1'):(bank?'UFRS':'XI_29')});periods.forEach((p,i)=>{q.set('year'+(i+1),p.year);q.set('period'+(i+1),p.month);});return base+'MaliTablo?'+q;}
export function parseFinancial(data,symbol,periods,mode='annual',now=Date.now()){
 const items=data?.value;if(!Array.isArray(items)||!items.length||items.length>2500)throw Error('Kaynak mali tablo satırı döndürmedi.');
 const rows=items.filter(x=>x&&typeof x.itemDescTr==='string'&&x.itemDescTr.trim()&&/^[1-4][a-z0-9._-]{0,30}$/i.test(String(x.itemCode))).map(x=>({code:String(x.itemCode),name:x.itemDescTr.trim().slice(0,250),values:periods.map((_,i)=>num(x['value'+(i+1)]))}));
 if(!rows.some(r=>r.values.some(Number.isFinite)))throw Error('İstenen dönemlere ait sayısal mali tablo bulunamadı.');
 const normalized={};const conflicts=[];
 for(const [key,aliases]of Object.entries(labels)){const prefix=['revenue','grossProfit','profit'].includes(key)?'3':key==='cashflow'?'4':key==='assets'||key==='currentAssets'?'1':'2';const accepted=new Set(aliases.map(fold));const matches=rows.filter(r=>r.code.startsWith(prefix)&&accepted.has(fold(r.name)));if(matches.length===1)normalized[key]=matches[0];else if(matches.length>1)conflicts.push(key);}
 const available=periods.map((p,i)=>({...p,index:i,count:rows.filter(r=>r.values[i]!==null).length})).filter(p=>p.count>0&&rows.some(r=>r.values[p.index]!==null&&r.values[p.index]!==0));
 if(!available.length)throw Error('Kaynak yalnız boş/sıfır dönem sütunları döndürdü.');
 const bank=isBank(symbol),result={symbol,periods,available,rows,normalized,conflicts,mode,bank,loadedAt:now,source:'İş Yatırım · herkese açık mali tablo',currency:'TRY'};
 return {...result,metrics:financialMetrics(result),fscore:financialScore(result)};
}
const divide=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&b>0?a/b:null;
function financialMetrics(r){const i=r.available[0].index,get=k=>r.normalized[k]?.values[i]??null;return {period:r.periods[i],profitMargin:divide(get('profit'),get('revenue')),grossMargin:divide(get('grossProfit'),get('revenue')),currentRatio:r.bank?null:divide(get('currentAssets'),get('currentLiabilities')),cashQuality:r.bank?null:divide(get('cashflow'),get('profit')),equityAssets:divide(get('equity'),get('assets'))};}
export function financialScore(r){
 if(r.bank||r.mode!=='annual')return {eligible:false,total:null,rules:[],reason:r.bank?'Banka tablolarına sanayi şirketi F-Score modeli uygulanmaz.':'F-Score karşılaştırılabilir yıllık dönemler gerektirir; ara dönemler yılbaşından birikimlidir.'};
 const start=r.available[0]?.index??0,p=r.periods.slice(start,start+3),get=(k,i)=>r.normalized[k]?.values[start+i]??null,avg=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)?(a+b)/2:null;
 if(p.length<3||p.some(x=>x.month!==12)||p[0].year-p[1].year!==1||p[1].year-p[2].year!==1)return {eligible:false,total:null,rules:[],reason:'Üç ardışık yıllık bilanço tarihi gerekli.'};
 const a0=avg(get('assets',0),get('assets',1)),a1=avg(get('assets',1),get('assets',2)),roa0=divide(get('profit',0),a0),roa1=divide(get('profit',1),a1),cfo=divide(get('cashflow',0),a0),lev0=divide(get('longLiabilities',0),get('assets',0)),lev1=divide(get('longLiabilities',1),get('assets',1)),liq0=divide(get('currentAssets',0),get('currentLiabilities',0)),liq1=divide(get('currentAssets',1),get('currentLiabilities',1)),gm0=divide(get('grossProfit',0),get('revenue',0)),gm1=divide(get('grossProfit',1),get('revenue',1)),turn0=divide(get('revenue',0),a0),turn1=divide(get('revenue',1),a1);
 const sign=(v)=>v===null?null:v>0,gt=(a,b)=>a===null||b===null?null:a>b,lt=(a,b)=>a===null||b===null?null:a<b;
 const rules=[['ROA pozitif',sign(roa0)],['Faaliyet nakit akışı pozitif',sign(cfo)],['ROA arttı',gt(roa0,roa1)],['Nakit akışı / aktif > ROA',gt(cfo,roa0)],['Uzun yükümlülük / aktif azaldı',lt(lev0,lev1)],['Cari oran arttı',gt(liq0,liq1)],['Yeni pay ihracı yok',null],['Brüt marj arttı',gt(gm0,gm1)],['Aktif devir hızı arttı',gt(turn0,turn1)]].map(([name,passed])=>({name,passed}));
 // A paid-in-capital balance, zero cash proceeds, or missing row does not prove no equity issue.
 return {eligible:true,total:null,known:rules.filter(r=>r.passed!==null).length,positive:rules.filter(r=>r.passed===true).length,rules,reason:'Bu kaynaktan pay ihracı ve dönemlerin enflasyon/yeniden düzenleme karşılaştırılabilirliği doğrulanamadı. Uzun yükümlülükler finansal borçla aynı değildir. Gözlemsel koşullar gösterilir; resmi toplam F-Score üretilmez.'};
}
export async function fetchFinancial(request,symbol,mode='annual',now=new Date()){
 symbol=normalize('BIST',symbol);const periods=periodsFor(mode,now);let data=await request(financialUrl(symbol,periods,isBank(symbol)));if(Array.isArray(data?.value)&&!data.value.length)data=await request(financialUrl(symbol,periods,isBank(symbol),true));return parseFinancial(data,symbol,periods,mode,now.getTime());
}
export function historyUrl(symbol,now=new Date()){symbol=normalize('BIST',symbol);if(!/^[A-Z0-9]{1,12}$/.test(symbol))throw Error('Standart BIST kodu gerekli.');const date=d=>String(d.getUTCDate()).padStart(2,'0')+'-'+String(d.getUTCMonth()+1).padStart(2,'0')+'-'+d.getUTCFullYear(),start=new Date(now);start.setUTCFullYear(start.getUTCFullYear()-2);return base.replace('IsYatirim.Website','Isyatirim.Website')+'HisseTekil?'+new URLSearchParams({hisse:symbol,startdate:date(start),enddate:date(now)});}
export function parseCloseHistory(data,symbol,now=Date.now()){
 if(!Array.isArray(data?.value)||data.value.length>3000)throw Error('Günlük fiyat listesi bulunamadı.');const map=new Map();let rejected=0;
 for(const r of data.value){const m=String(r.HGDG_TARIH||'').match(/^(\d{2})-(\d{2})-(\d{4})$/),c=num(r.HGDG_KAPANIS);if(!m||r.HGDG_HS_KODU!==symbol||c===null||c<=0){rejected++;continue;}const date=m[3]+'-'+m[2]+'-'+m[1],t=Date.parse(date+'T00:00:00Z');if(!Number.isFinite(t)||new Date(t).toISOString().slice(0,10)!==date||t>now){rejected++;continue;}if(map.has(date)&&map.get(date).c!==c)throw Error('Aynı gün için çelişkili kapanışlar var; seri gösterilmedi.');map.set(date,{date,c,t});}
 const candles=[...map.values()].sort((a,b)=>a.t-b.t);if(candles.length<20)throw Error('En az 20 geçerli günlük kapanış gerekli.');if(now-candles.at(-1).t>7*86400000)throw Error('Alternatif kaynağın son kapanışı 7 günden eski; gösterilmedi.');
 const a=candles.map(c=>c.c),fast=ema(a,12),slow=ema(a,26),line=a.map((_,i)=>fast[i]!==null&&slow[i]!==null?fast[i]-slow[i]:null).filter(v=>v!==null),signal=ema(line,9).at(-1)??null;
 return {symbol,candles,rejected,source:'İş Yatırım · günlük kapanış',loadedAt:now,currency:'TRY',last:a.at(-1),date:candles.at(-1).date,technical:{ma20:sma(a,20),ma50:sma(a,50),ma200:sma(a,200),rsi:rsi(a),macd:line.at(-1)??null,signal,hist:signal===null?null:line.at(-1)-signal}};
}

export function csvText(value){const s=String(value),safe=/^\s*[=+@-]/.test(s)?"'"+s:s;return '"'+safe.replaceAll('"','""')+'"';}
