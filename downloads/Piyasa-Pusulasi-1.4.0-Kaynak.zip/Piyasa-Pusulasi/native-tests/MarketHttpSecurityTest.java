package tr.piyasapusulasi.mobile;
public final class MarketHttpSecurityTest {
 public static void main(String[] args)throws Exception{
  String[] blocked={"http://api.collectapi.com/economy/hisseSenedi","https://example.com/economy/hisseSenedi","https://api.collectapi.com.evil.test/economy/hisseSenedi","https://user@api.collectapi.com/economy/hisseSenedi","https://api.collectapi.com:444/economy/hisseSenedi","https://api.collectapi.com/economy/hisseSenedi?key=ignored","https://api.collectapi.com/economy/goldPrice","https://api.collectapi.com/economy/hisseSenedi/extra","https://www.isyatirim.com.tr/evil","https://www.isyatirim.com.tr.evil.test/_layouts/15/IsYatirim.Website/Common/Data.aspx/MaliTablo","https://user@www.isyatirim.com.tr/_layouts/15/IsYatirim.Website/Common/Data.aspx/MaliTablo","https://www.isyatirim.com.tr:444/_layouts/15/IsYatirim.Website/Common/Data.aspx/MaliTablo","http://www.isyatirim.com.tr/_layouts/15/IsYatirim.Website/Common/Data.aspx/MaliTablo"};
  for(String url:blocked){try{MarketHttp.request(url,"GET","","");throw new AssertionError("Expected URL rejection");}catch(java.io.IOException e){if(!e.getMessage().equals("Bu veri adresine izin verilmiyor."))throw new AssertionError("Unexpected rejection path");}}
  try{MarketHttp.request("https://api.collectapi.com/economy/hisseSenedi","POST","","");throw new AssertionError("Expected method rejection");}catch(java.io.IOException e){if(!e.getMessage().equals("Bu veri adresine izin verilmiyor."))throw e;}
  try{MarketHttp.request("https://api.collectapi.com/economy/hisseSenedi","GET","","");throw new AssertionError("Expected missing-key rejection before network");}catch(java.io.IOException e){if(!e.getMessage().startsWith("CollectAPI için"))throw e;}
  try{MarketHttp.request("https://www.isyatirim.com.tr/_layouts/15/IsYatirim.Website/Common/Data.aspx/MaliTablo","POST","","");throw new AssertionError("Expected method rejection");}catch(java.io.IOException e){if(!e.getMessage().equals("Bu veri adresine izin verilmiyor."))throw e;}
  System.out.println("PASS 16 native URL/method/missing-key cases; no network or real keys used");
 }
}
