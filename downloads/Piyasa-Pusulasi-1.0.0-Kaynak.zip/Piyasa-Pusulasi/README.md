# Piyasa Pusulası 1.0.0

Yeni uygulama: `tr.piyasapusulasi.mobile`. Android 8.0+ ve WebView 80+.
Yeni pusula simgesi, açık/koyu görünüm ve mobil gezinme. Referans uygulamanın
paketinden ayrıdır; o uygulamanın kayıtlarını taşımaz veya değiştirmez.

## Kullanım

APK'yı telefonda açıp kurun. Keşfet'ten BIST/ABD/emtia ve sembol seçin.
Analiz ekranındaki yıldız takip listesine, zil fiyat hedefine ekler.
Günlük teknik tarama ve iki sembol karşılaştırması Keşfet'tedir.
Ayarlar'dan görünüm değiştirilebilir.

Teknik analiz ve fiyat sorguları kişisel API anahtarı istemez.
AI açıklaması isteğe bağlıdır: kendi Gemini anahtarınızı Ayarlar'dan kaydedin,
Güncel modelleri getir ile o anda sağlayıcının sunduğu bir modeli seçin.
Anahtar Android Keystore AES-GCM ile şifrelenir; kaynakta gömülü anahtar yoktur.
Fiyat verisi ve hesaplanmış göstergeler yalnız açıklama istediğinizde AI'a gönderilir.

## Veri doğruluğu

- Kaynak Yahoo Finance; gerçek zamanlı veri lisansı iddiası yoktur.
- Sunucudan yanıt alma zamanı ile borsanın son işlem zamanı ayrı tutulur.
- Piyasa kapalıysa son işlem zamanı gösterilir; canlı fiyat olarak adlandırılmaz.
- Açık seansta 20 dakikadan eski, genel olarak 7 günden eski veya gelecekte
  görünen fiyatlar reddedilir. Zamanı/fiyatı doğrulanamayan yanıt kullanılmaz.
- Teknik analiz için en az 20 geçerli günlük mum gerekir; yeterli geçmişi olmayan
  SMA50/SMA200/MACD alanları uydurulmaz. Eski son mumu olan geçmiş reddedilir.
- Hata/yenilemede önceki analiz temizlenir. Ekran değiştikten sonra tamamlanan
  eski istekler ekranı geri açamaz. Ön plandaki analiz yaklaşık dakikada yenilenir.
- Kalıcı fiyat/analiz önbelleği veya örnek fiyat verisi yoktur.
- Altın/gümüş fiyatı vadeli kontrat referansıdır. Teorik gram, ons × USD/TRY / 31,1034768
  ile hesaplanır; banka/kuyumcu alış-satış fiyatı değildir. Eski ons geçmişine bugünün
  kuru uygulanmaz: gram detayında grafik ve teknik göstergeler açıkça USD ons referansıdır.
- RSI Wilder yöntemidir; MACD 12/26/9, SMA 20/50/200, 30 günlük yüksek/düşük sınırları
  ve 14 günlük ortalama gerçek aralık kullanılır. Bunlar kesin getiri tahmini değildir.

## Hedef bildirimleri

Android JobScheduler, ağ uygunsa yaklaşık 15 dakikalık dönemle fiyatı kontrol eder.
Doze, pil kısıtları, izin, sağlayıcı ve bağlantı süreyi etkiler. Anlık alarm garantisi yoktur.
20 dakikadan eski fiyatla hedef tetiklenmez. Kaynak başarısızsa hedef aktif kalır.
Android 13+ bildirim izni, internet ve arka plan çalışmasına izin gerekir.

## Derleme

JDK17, Android SDK35, Build-Tools34.0.0, Node22.12+ / Node24.

1. `cd web && npm ci && npm test && npm run build`
2. Yalnız üretilen `app/src/main/assets/public` klasörünü temizleyip `web/dist` içeriğini buraya kopyalayın.
3. `./gradlew :app:assembleDebug :app:lintDebug` (Windows: `gradlew.bat`).
4. İmzalı release için `PIYASA_SIGNING_PROPERTIES` değişkenini özel bir properties dosyasına yönlendirin:
   `storeFile`, `storePassword`, `keyAlias`, `keyPassword` alanları gerekir.
   Ardından `:app:assembleRelease :app:lintRelease` çalıştırın.

Dağıtılan APK'nın özel imza anahtarı ve şifreleri bu kaynak paketine eklenmedi.
Aynı uygulamayı güncellemek için aynı imza korunmalıdır. Yeni anahtarla üretilen
aynı paket, mevcut sürümün üzerine güncelleme olarak kurulamaz.

Mevcut proje dizini kullanılabilir; yeni bir Git worktree gerekmez.
Tarayıcı testleri kontrollü sağlayıcı yanıtlarıyla yürütülür. Test fiyatları APK'ya girmez.
