# POS Kasa Yönetim — Build v42 / 1.5.2

Güncel yönergeler: **KULLANIM-v42.md** ve **SONUC-RAPORU-v42.md**. Önceki sürümlerin belgeleri arşivdir.

Veresiye girişi ve kapalı geçmiş listesi, POS/nakit/veresiye dağılımı, veresiye analizi ve kaydırmasız kasa performansı eklenmiştir. POS, nakit, ödeme ve gömülü OCR özellikleri korunur.

Bu tam kaynak paketidir. Windows'ta `pos-app/BUILD.bat` ile derleyin. Ayrı OCR veya Windows dil bileşeni kurulumu gerekmez. `ocr-runtime` klasörünü silmeyin; programı taşırken `win-unpacked` klasörünün tamamını taşıyın. Güncellemeden önce JSON yedeği alın; uygulama verilerini temizlemeyin.
