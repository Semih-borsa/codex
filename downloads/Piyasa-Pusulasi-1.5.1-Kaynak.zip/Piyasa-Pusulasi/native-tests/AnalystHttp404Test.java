package tr.piyasapusulasi.mobile;
import java.net.*;import java.io.*;import java.nio.charset.StandardCharsets;
public final class AnalystHttp404Test{
 static int status=404,requests=0;static String content="<h1>THYAO</h1><table>report</table>";static boolean empty=false;
 static class Fake extends HttpURLConnection{
  Fake(URL u){super(u);}public void connect(){}public void disconnect(){}public boolean usingProxy(){return false;}
  public int getResponseCode(){requests++;return status;}
  public InputStream getInputStream()throws IOException{if(status>=400)throw new FileNotFoundException();return new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));}
  public InputStream getErrorStream(){return empty?null:new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));}
 }
 public static void main(String[]args)throws Exception{
  URL.setURLStreamHandlerFactory(protocol->"https".equals(protocol)?new URLStreamHandler(){protected URLConnection openConnection(URL u){return new Fake(u);}}:null);
  String source="https://www.hedeffiyat.com.tr/senet/thyao-test-1";
  MarketHttp.Reply reply=MarketHttp.read(source,"GET","","");if(reply.status!=404||!reply.body.equals(content))throw new AssertionError("404 error stream lost");
  empty=true;reply=MarketHttp.read(source,"GET","","");if(reply.status!=404||!reply.body.isEmpty())throw new AssertionError("Empty404 must reach search fallback");empty=false;
  MarketHttp.read("https://www.hedeffiyat.com.tr/arama?q=THYAO","GET","","");int prior=requests;
  try{MarketHttp.read("https://www.hedeffiyat.com.tr/arama?q=THYAO&other=1","GET","","");throw new AssertionError("Bad search accepted");}catch(IOException expected){}if(requests!=prior)throw new AssertionError("Bad query reached network");
  try{MarketHttp.read("https://query1.finance.yahoo.com/v8/finance/chart/THYAO.IS","GET","","");throw new AssertionError("Yahoo404 accepted");}catch(IOException expected){}
  status=403;try{MarketHttp.read(source,"GET","","");throw new AssertionError("403 accepted");}catch(IOException expected){}
  status=200;reply=MarketHttp.read(source,"GET","","");if(reply.status!=200||!reply.body.equals(content))throw new AssertionError("200 changed");
  System.out.println("PASS 7 native mock HTTP cases:404 body/empty/search/query/JSON404/403/200; no live network");
 }
}
