import {sma,indicators} from './core.js';
const finite=Number.isFinite;
// Monday-based UTC weeks; always drop the current calendar week and the first (possibly truncated) week.
export function completedWeeks(candles,now=Date.now()){
 const key=t=>{const d=new Date(t);d.setUTCHours(0,0,0,0);d.setUTCDate(d.getUTCDate()-(d.getUTCDay()+6)%7);return d.getTime();};
 const groups=new Map();for(const c of candles){const k=key(c.t);if(k>=key(now))continue;const prev=groups.get(k);groups.set(k,prev?{...prev,h:Math.max(prev.h,c.h),l:Math.min(prev.l,c.l),c:c.c,v:finite(prev.v)&&finite(c.v)?prev.v+c.v:null}:{...c,t:k});}
 return [...groups.values()].slice(1);
}
export function directional(c,p=14){
 if(c.length<2*p)return {adx:null,plus:null,minus:null};
 const tr=[],plus=[],minus=[];for(let i=1;i<c.length;i++){const a=c[i],b=c[i-1],up=a.h-b.h,down=b.l-a.l;tr.push(Math.max(a.h-a.l,Math.abs(a.h-b.c),Math.abs(a.l-b.c)));plus.push(up>down&&up>0?up:0);minus.push(down>up&&down>0?down:0);}
 let atr=sma(tr.slice(0,p),p),pos=sma(plus.slice(0,p),p),neg=sma(minus.slice(0,p),p);const dx=[];let pd=0,nd=0;
 for(let i=p-1;i<tr.length;i++){if(i>=p){atr=(atr*(p-1)+tr[i])/p;pos=(pos*(p-1)+plus[i])/p;neg=(neg*(p-1)+minus[i])/p;}pd=atr?100*pos/atr:0;nd=atr?100*neg/atr:0;dx.push(pd+nd?100*Math.abs(pd-nd)/(pd+nd):0);}
 const adx=dx.length<p?null:dx.slice(p).reduce((v,x)=>(v*(p-1)+x)/p,sma(dx.slice(0,p),p));return {adx,plus:pd,minus:nd};
}
export function moneyFlow(c){
 const period=c.slice(-20),volumeAvailable=c.length>=21&&period.every(x=>finite(x.v)&&x.v>=0)&&period.some(x=>x.v>0);
 if(!volumeAvailable)return {cmf:null,mfi:null,obvChange:null};
 const total=period.reduce((s,x)=>s+x.v,0),cmf=period.reduce((s,x)=>s+(x.h===x.l?0:(2*x.c-x.h-x.l)/(x.h-x.l))*x.v,0)/total;
 let positive=0,negative=0;for(let i=c.length-14;i<c.length;i++){const a=c[i],b=c[i-1],tp=(a.h+a.l+a.c)/3,prior=(b.h+b.l+b.c)/3;if(tp>prior)positive+=tp*a.v;else if(tp<prior)negative+=tp*a.v;}
 const mfi=negative===0?(positive===0?50:100):100-100/(1+positive/negative);
 let obvChange=0;for(let i=c.length-20;i<c.length;i++)obvChange+=Math.sign(c[i].c-c[i-1].c)*c[i].v;
 return {cmf,mfi,obvChange};
}
export function traderAnalysis(candles,{derived=false,now=Date.now()}={}){
 const t=indicators(candles),d=directional(candles),flow=derived?{cmf:null,mfi:null,obvChange:null}:moneyFlow(candles),last=t.last,previous=candles.at(-2),lookback=candles.slice(-21,-1);
 const upper=lookback.length===20?Math.max(...lookback.map(c=>c.h)):null,lower=lookback.length===20?Math.min(...lookback.map(c=>c.l)):null;
 const pivot=previous?(previous.h+previous.l+previous.c)/3:null,pivots=previous?{p:pivot,r1:2*pivot-previous.l,s1:2*pivot-previous.h,r2:pivot+previous.h-previous.l,s2:pivot-previous.h+previous.l}:null;
 const roc=candles.length>10?(last/candles.at(-11).c-1)*100:null,range=candles.slice(-14),high=range.length===14?Math.max(...range.map(c=>c.h)):null,low=range.length===14?Math.min(...range.map(c=>c.l)):null,stoch=high===null?null:high===low?50:100*(last-low)/(high-low);
 const weeks=completedWeeks(candles,now),weekly=weeks.length>=20?indicators(weeks):null;
 const weeklyDirection=weekly?weekly.last>weekly.ma20?1:weekly.last<weekly.ma20?-1:0:null;
 const rule=(group,name,value,explanation)=>({group,name,value,explanation});
 const rules=[
 rule('Trend','Fiyat / SMA50',t.ma50===null?null:Math.sign(last-t.ma50),'Kapanış SMA50 üzerinde +1, altında −1.'),
 rule('Trend','SMA50 / SMA200',t.ma50===null||t.ma200===null?null:Math.sign(t.ma50-t.ma200),'Orta ve uzun vadeli ortalama sıralaması.'),
 rule('Momentum','RSI14',t.rsi===null?null:t.rsi>55?1:t.rsi<45?-1:0,'55 üstü +1, 45 altı −1, arası 0. Aşırı alım tek başına satış değildir.'),
 rule('Momentum','MACD histogramı',t.hist===null?null:Math.sign(t.hist),'MACD çizgisi ile sinyalinin farkının işareti.'),
 rule('Katılım','CMF20',flow.cmf===null?null:flow.cmf>.05?1:flow.cmf<-.05?-1:0,'±0,05 dışında yönlü hacim teyidi. Gerçek alıcı/satıcı emir akışı değildir.'),
 rule('Katılım','OBV 20 değişimi',flow.obvChange===null?null:Math.sign(flow.obvChange),'Yükselen/düşen kapanışlara atanan hacim farkı; net takas değildir.'),
 rule('Üst zaman','Tamamlanan hafta / SMA20',weeklyDirection,'Mevcut takvim haftası çıkarılır; haftalık kapanış SMA20 ile karşılaştırılır.')];
 const groups=['Trend','Momentum','Katılım','Üst zaman'].map(name=>{const valid=rules.filter(r=>r.group===name&&r.value!==null);return {name,value:valid.length?valid.reduce((s,r)=>s+r.value,0)/valid.length:null};});
 const available=groups.filter(g=>g.value!==null),score=available.length>=3?Math.round(50+50*available.reduce((s,g)=>s+g.value,0)/available.length):null;
 const bullish=rules.filter(r=>r.value>0).length,bearish=rules.filter(r=>r.value<0).length,coverage=rules.filter(r=>r.value!==null).length;
 const warnings=[];if(bullish&&bearish)warnings.push('Göstergeler çelişiyor: '+bullish+' yukarı, '+bearish+' aşağı yönlü koşul.');if(d.adx!==null&&d.adx<20)warnings.push('ADX 20 altında: trend zayıf; kırılma sinyalleri yalancı olabilir.');if(t.rsi>=70)warnings.push('RSI aşırı alım bölgesinde; güçlü trend devam edebilse de geri çekilme riski artabilir.');if(t.rsi!==null&&t.rsi<=30)warnings.push('RSI aşırı satımda; tek başına dönüş teyidi değildir.');if(!derived&&flow.cmf===null)warnings.push('Hacim teyidi hesaplanamadı; eksik değer nötr oya çevrilmedi.');if(weeklyDirection===null)warnings.push('Tamamlanmış en az 20 haftalık gözlem yok; üst zaman teyidi yok.');
 const breakout=upper!==null?last>upper?'Üst sınır aşıldı':last<lower?'Alt sınır aşıldı':'20 günlük kanal içinde':'Yetersiz veri';
 const width=t.ma20?(t.upper-t.lower)/t.ma20*100:null;
 // Illustrative long breakout plan, not an expected return or an instruction.
 const entry=upper!==null&&t.atr>0?upper+.1*t.atr:null,stop=entry!==null?entry-1.5*t.atr:null,risk=entry!==null?entry-stop:null;
 const plan=entry!==null&&stop>0?{entry,stop,risk,target:entry+2*risk,active:last<entry}:null;
 return {score,groups,rules,coverage,bullish,bearish,d,flow,roc,stoch,pivots,upper,lower,breakout,width,weeks:weeks.length,weekly,weeklyDirection,warnings,plan};
}
export function positionSize(capital,riskPercent,entry,stop){
 if(![capital,riskPercent,entry,stop].every(finite)||capital<=0||riskPercent<=0||riskPercent>5||entry<=0||stop<=0||stop>=entry)return null;
 const budget=capital*riskPercent/100,perUnit=entry-stop,units=Math.floor(Math.min(budget/perUnit,capital/entry));return {budget,perUnit,units,cost:units*entry,maxLoss:units*perUnit};
}
export function parseScan(market,text,normalize){const values=String(text).split(/[\s,;]+/).filter(Boolean);const symbols=[...new Set(values.map(s=>normalize(market,s)))];if(!symbols.length||symbols.length>20)throw Error('Tarama için 1–20 farklı sembol yazın.');return symbols;}
