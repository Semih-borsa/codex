const prefix='piyasa-pusulasi:v1:';
export function read(key,fallback){try{const raw=localStorage.getItem(prefix+key);if(raw===null)return fallback;const value=JSON.parse(raw);if(Array.isArray(fallback)&&!Array.isArray(value))throw Error();return value;}catch{throw Error('Kayıtlı tercihler okunamadı. Otomatik silme yapılmadı.');}}
export function save(key,value){try{localStorage.setItem(prefix+key,JSON.stringify(value));return true;}catch{throw Error('Tercih kaydedilemedi. Depolama alanınızı kontrol edin.');}}
export function readAlarms(){if(window.MarketBridge){try{const v=JSON.parse(window.MarketBridge.getAlarms());if(!Array.isArray(v))throw Error();return v;}catch{throw Error('Alarm kayıtları okunamadı; silinmedi.');}}return read('alarms',[]);}
export function saveAlarms(alarms){if(window.MarketBridge){if(!window.MarketBridge.saveAlarms(JSON.stringify(alarms)))throw Error('Alarmlar kaydedilemedi.');}else save('alarms',alarms);}
