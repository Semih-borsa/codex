import {parseChart} from './core.js';
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
export function createMarketData(request,{now=Date.now,wait=pause}={}){
 const inflight=new Map();let quotaUntil=0;
 async function fetchRange(symbol,range,history){
  let error;
  for(const [i,host] of ['query1','query2'].entries()){
   let json;
   try{json=await request(`https://${host}.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=${range}&interval=${history?'1d':'5m'}`);}
   catch(e){error=e;if(e.status===400||e.status===404)throw e;if(i===0)await wait(e.status===429||/429|istek sınır/i.test(e.message)?1200:300);continue;}
   // A stale or malformed data response is not a transient network failure.
   const result=parseChart(json,now(),history?'history':'quote',history?{minCandles:1}:{});
   return {...result,provenance:{provider:'Yahoo Finance',host:host+'.finance.yahoo.com',range,attempts:i+1}};
  }
  if(error?.status===429||/istek sınır/i.test(error?.message||''))quotaUntil=now()+30000;
  throw error;
 }
 return function chart(symbol,history=false){
  if(now()<quotaUntil){const error=Error('Sağlayıcı kota sınırında. 30 saniyelik bekleme sonrası yeniden deneyin.');error.status=429;return Promise.reject(error);}
  const key=symbol+'|'+history;
  if(inflight.has(key))return inflight.get(key);
  const job=(async()=>{
   let result=await fetchRange(symbol,history?'2y':'1d',history);
   if(history&&result.candles.length<200){
    try{const extended=await fetchRange(symbol,'5y',true);if(extended.candles.length>result.candles.length)result=extended;else result={...result,extension:'5 yıllık sorgu da daha fazla geçerli mum sağlamadı.'};}
    catch(e){result={...result,extension:'Uzun geçmiş alınamadı: '+e.message};}
   }
   if(history&&result.candles.length<20)throw Error(result.candles.length+'/20 geçerli günlük mum var; güvenilir analiz için geçmiş yetersiz.');
   return result;
  })();
  inflight.set(key,job);job.finally(()=>{if(inflight.get(key)===job)inflight.delete(key);}).catch(()=>{});return job;
 };
}
