// Older Android system WebViews can run the same app without crashing on newer helpers.
if(!Array.prototype.at)Object.defineProperty(Array.prototype,'at',{value:function(index){let i=Math.trunc(index)||0;if(i<0)i+=this.length;return this[i]},configurable:true,writable:true});
if(!Object.hasOwn)Object.defineProperty(Object,'hasOwn',{value:(o,p)=>Object.prototype.hasOwnProperty.call(o,p),configurable:true,writable:true});
if(!String.prototype.replaceAll)Object.defineProperty(String.prototype,'replaceAll',{value:function(search,replacement){if(search instanceof RegExp){if(!search.global)throw new TypeError('Global regex required');return this.replace(search,replacement)}return this.split(String(search)).join(replacement)},configurable:true,writable:true});
