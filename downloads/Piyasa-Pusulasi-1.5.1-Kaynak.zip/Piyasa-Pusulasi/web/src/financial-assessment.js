// Transparent checklist, not a validated credit rating or investment recommendation.
const finite=Number.isFinite;
const ratio=(a,b)=>finite(a)&&finite(b)&&b>0?a/b:null;
export const fieldNames={assets:'Toplam varlıklar',equity:'Özkaynaklar',currentAssets:'Dönen varlıklar',currentLiabilities:'Kısa vadeli yükümlülükler',longLiabilities:'Uzun vadeli yükümlülükler',revenue:'Hasılat',grossProfit:'Brüt kâr',profit:'Dönem net kârı',cashflow:'Faaliyet nakit akışı',longDebt:'Uzun vadeli finansal borç',shares:'Dolaşımdaki pay sayısı'};
export function assessFinancial(r){
 const start=r.available[0]?.index??0,period=r.periods[start],prior=r.periods[start+1],older=r.periods[start+2];
 const get=(key,i=0)=>r.normalized[key]?.values[start+i]??null;
 const inputs=Object.entries(fieldNames).map(([key,name])=>({key,name,row:r.normalized[key]?.name??null,code:r.normalized[key]?.code??null,values:[0,1,2].map(i=>get(key,i)),reason:r.conflicts?.includes(key)?'Birden fazla kaynak satırı eşleşti; seçim yapılmadı.':'Kaynakta eşleşen sayısal satır bulunamadı.'}));
 const namePeriod=p=>p?p.year+'/'+String(p.month).padStart(2,'0'):'Dönem yok';
 const annual=r.mode==='annual'&&period?.month===12,compare=annual&&prior?.month===12&&period.year-prior.year===1;
 const avg=(a,b)=>finite(a)&&finite(b)?(a+b)/2:null;
 const avg0=avg(get('assets'),get('assets',1)),avg1=avg(get('assets',1),get('assets',2));
 const roa0=ratio(get('profit'),avg0),roa1=ratio(get('profit',1),avg1),cfo0=ratio(get('cashflow'),avg0),liq0=ratio(get('currentAssets'),get('currentLiabilities')),liq1=ratio(get('currentAssets',1),get('currentLiabilities',1)),gm0=ratio(get('grossProfit'),get('revenue')),gm1=ratio(get('grossProfit',1),get('revenue',1)),lev0=finite(get('longDebt'))&&get('longDebt')>=0?ratio(get('longDebt'),get('assets')):null,lev1=finite(get('longDebt',1))&&get('longDebt',1)>=0?ratio(get('longDebt',1),get('assets',1)):null,turn0=ratio(get('revenue'),avg0),turn1=ratio(get('revenue',1),avg1);
 const avgCompare=compare&&older?.month===12&&prior.year-older.year===1;
 const rules=[];
 const add=(id,name,fields,current,previous,test,needsComparison=false,extra='')=>{
  let reason='';const missing=fields.filter(([k,i])=>!finite(get(k,i))).map(([k,i])=>fieldNames[k]+' ('+namePeriod(r.periods[start+i])+')');
  if(r.bank)reason='Banka için bu sanayi şirketi modeli uygulanmaz.';else if(!annual)reason='F-Score için yıllık dönem seçin; ara dönemler birikimlidir.';else if(needsComparison&&!compare)reason='İki ardışık yıllık dönem gerekli.';else if(missing.length)reason='Eksik: '+missing.join(', ');else if(current===null||(needsComparison&&previous===null))reason='Oran için pozitif/geçerli payda veya yeterli dönem gerekli.';
  const passed=reason?null:test(current,previous);
  rules.push({id,name,passed,current,previous,reason,extra,fields:fields.map(([key,i])=>({name:fieldNames[key],period:namePeriod(r.periods[start+i]),value:get(key,i),row:r.normalized[key]?.name??null}))});
 };
 add('roa','ROA pozitif',[['profit',0],['assets',0],['assets',1]],roa0,null,a=>a>0,false,'Net kâr / iki bilanço tarihinin ortalama aktifi > 0.');
 add('cfo','Faaliyet nakit akışı pozitif',[['cashflow',0]],get('cashflow'),null,a=>a>0,false,'Faaliyet nakit akışı > 0.');
 add('roa-change','ROA arttı',[['profit',0],['profit',1],['assets',0],['assets',1],['assets',2]],roa0,avgCompare?roa1:null,(a,b)=>a>b,true,'Cari ROA > önceki ROA; her yıl için ortalama aktif.');
 add('accrual','Faaliyet nakdi / ortalama aktif > ROA',[['cashflow',0],['profit',0],['assets',0],['assets',1]],cfo0,roa0,(a,b)=>a>b,true,'Aynı dönem nakit akışı ve net kâr, aynı ortalama aktif paydasıyla karşılaştırılır.');
 add('leverage','Uzun finansal borç / aktif azaldı',[['longDebt',0],['longDebt',1],['assets',0],['assets',1]],lev0,lev1,(a,b)=>a<b,true,'Uzun yükümlülük toplamı finansal borç yerine kullanılmaz.');
 add('liquidity','Cari oran arttı',[['currentAssets',0],['currentAssets',1],['currentLiabilities',0],['currentLiabilities',1]],liq0,liq1,(a,b)=>a>b,true,'Cari dönem cari oranı > önceki dönem.');
 add('issuance','Yeni pay ihracı yok',[],null,null,()=>false,false,'Pay sayısı bakiyesi veya eksik nakit girişi satırı ihraç yapılmadığını kanıtlamaz.');
 const issue=rules.at(-1);issue.passed=null;issue.reason=r.bank?'Banka için model uygulanmaz.':'Dönem içi pay ihracı/kurumsal aksiyon kaydı doğrulanamadı.';
 add('margin','Brüt marj arttı',[['grossProfit',0],['grossProfit',1],['revenue',0],['revenue',1]],gm0,gm1,(a,b)=>a>b,true,'Brüt kâr / hasılat oranı arttı.');
 add('turnover','Aktif devir hızı arttı',[['revenue',0],['revenue',1],['assets',0],['assets',1],['assets',2]],turn0,avgCompare?turn1:null,(a,b)=>a>b,true,'Hasılat / ortalama aktif arttı.');
 const known=rules.filter(x=>x.passed!==null).length,positive=rules.filter(x=>x.passed===true).length,negative=known-positive;
 const fscore={rules,known,positive,negative,missing:9-known,total:null,range:[positive,positive+9-known],comparable:false,reason:'Dönemlerin enflasyon/yeniden düzenleme karşılaştırılabilirliği ve pay ihracı doğrulanmadı; toplam resmi F-Score değildir.'};
 const healthRules=[];
 const h=(group,name,weight,value,test,reason,formula)=>healthRules.push({group,name,weight,value,passed:r.bank?null:value===null?null:test(value),reason:r.bank?'Bankaya bu model uygulanmaz.':value===null?reason:'',formula});
 h('Kârlılık','Net kâr marjı pozitif',15,ratio(get('profit'),get('revenue')),v=>v>0,'Net kâr/hasılat eksik veya hasılat pozitif değil.','Net kâr / hasılat > 0');
 h('Kârlılık','Faaliyet nakdi pozitif',15,get('cashflow'),v=>v>0,'Faaliyet nakit akışı eksik.','Faaliyet nakit akışı > 0');
 h('Borç / sermaye','Özkaynak / aktif en az %40',15,ratio(get('equity'),get('assets')),v=>v>=.4,'Özkaynak/aktif eksik veya aktif pozitif değil.','Özkaynak / aktif ≥ 0,40');
 const liabilities=finite(get('currentLiabilities'))&&get('currentLiabilities')>=0&&finite(get('longLiabilities'))&&get('longLiabilities')>=0?get('currentLiabilities')+get('longLiabilities'):null;
 h('Borç / sermaye','Toplam yükümlülük / aktif en fazla %60',15,ratio(liabilities,get('assets')),v=>v<=.6,'Kısa/uzun yükümlülük veya aktif eksik.','(Kısa + uzun yükümlülük) / aktif ≤ 0,60; finansal borç değildir');
 const nominal=compare?ratio(get('revenue')-get('revenue',1),get('revenue',1)):null;
 h('Büyüme','Yıllık nominal hasılat artışı',10,nominal,v=>v>0,'İki yıllık karşılaştırılabilir hasılat ve pozitif önceki değer gerekli.','Cari hasılat / önceki hasılat − 1 > 0; reel büyüme değildir');
 h('Büyüme','Reel hasılat artışı',10,null,()=>false,'Döneme uygun enflasyon ve yeniden düzenleme temeli doğrulanmadı.','Uygun fiyat endeksi/enflasyon muhasebesi temeli gerekir');
 h('Likidite','Cari oran en az 1',10,liq0,v=>v>=1,'Dönen varlık veya pozitif kısa yükümlülük eksik.','Dönen varlık / kısa yükümlülük ≥ 1');
 h('Likidite','Faaliyet nakdi / net kâr en az 1',10,ratio(get('cashflow'),get('profit')),v=>v>=1,'Faaliyet nakdi ve pozitif net kâr gerekli.','Faaliyet nakdi / pozitif net kâr ≥ 1');
 const maximum=healthRules.filter(x=>x.passed!==null).reduce((s,x)=>s+x.weight,0),earned=healthRules.filter(x=>x.passed===true).reduce((s,x)=>s+x.weight,0);
 const groups=['Kârlılık','Borç / sermaye','Büyüme','Likidite'].map(name=>{const rows=healthRules.filter(x=>x.group===name);return {name,weight:rows.reduce((s,x)=>s+x.weight,0),maximum:rows.filter(x=>x.passed!==null).reduce((s,x)=>s+x.weight,0),earned:rows.filter(x=>x.passed===true).reduce((s,x)=>s+x.weight,0),rules:rows};});
 return {inputs,periods:[period,prior,older],fscore,health:{groups,rules:healthRules,maximum,earned,missingWeight:100-maximum,range:[earned,earned+100-maximum],total:null}};
}
