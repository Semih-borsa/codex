import {normalize,indicators} from './core.js';
import {traderAnalysis} from './trader.js';
import {dataCoverage} from './coverage.js';
const key='piyasa-pusulasi:analysis-archive:v1',limit=4;
function read(store){const raw=store.getItem(key);if(!raw)return [];let list;try{list=JSON.parse(raw);}catch{throw Error('Kayıtlı analiz arşivi okunamadı; silinmedi.');}if(!Array.isArray(list)||list.length>limit)throw Error('Kayıtlı analiz arşivi okunamadı; silinmedi.');return list;}
function valid(r,now){
 if(!r||!['BIST','US','METAL'].includes(r.market)||normalize(r.market,r.symbol)!==r.symbol||!Number.isFinite(r.price)||r.price<=0||!Number.isFinite(r.timestamp)||!Number.isFinite(r.receivedAt)||!Number.isFinite(r.savedAt)||r.timestamp>r.receivedAt+120000||r.receivedAt>r.savedAt+120000||r.savedAt>now+120000||now-r.savedAt>30*86400000||r.timestamp<=0||!Array.isArray(r.candles)||r.candles.length<20||r.candles.length>1500||!['TRY','USD'].includes(r.currency)||r.currency!==r.chartCurrency)return false;
 return r.candles.every((c,i)=>[c.t,c.c,c.o,c.h,c.l].every(Number.isFinite)&&c.t>0&&c.t<=r.savedAt+120000&&c.l>0&&c.l<=Math.min(c.o,c.c)&&c.h>=Math.max(c.o,c.c)&&(!i||c.t>r.candles[i-1].t))&&r.analysisTime===r.candles.at(-1).t;
}
export function archiveAnalysis(result,store=localStorage,now=Date.now()){
 if(result.offline)return;
 const record={...result,savedAt:now};if(!valid(record,now))throw Error('Bu analiz güvenli arşiv biçimine uygun değil.');
 const list=read(store),next=[record,...list.filter(r=>r.market!==record.market||r.symbol!==record.symbol)].slice(0,limit);store.setItem(key,JSON.stringify(next));
}
export function loadArchived(market,symbol,store=localStorage,now=Date.now()){
 const result=read(store).find(r=>r?.market===market&&r?.symbol===symbol);if(!result)return null;if(!valid(result,now))throw Error('Kayıtlı analiz geçersiz veya 30 günden eski; gösterilmedi.');
 const r={...result,offline:true,status:'offline',technical:indicators(result.candles),trader:traderAnalysis(result.candles,{derived:result.derived,now:result.savedAt})};r.coverage=dataCoverage(r,result.savedAt);return r;
}
