import {completedWeeks} from './trader.js';
export function dataCoverage(r,now=Date.now()){
 const count=r.candles.length,weeks=completedWeeks(r.candles,now).length,tail=r.candles.slice(-20),missingVolume=tail.filter(c=>!Number.isFinite(c.v)||c.v<0).length,volumePositive=tail.some(c=>c.v>0);
 const rows=[];
 const need=(key,label,required)=>rows.push({key,label,status:count>=required?'available':'insufficient',reason:count>=required?`${count} geçerli günlük mum`:`${count}/${required} geçerli günlük mum; ${required-count} mum daha gerekli.`,count,required});
 for(const [key,label,n] of [['rsi','RSI14',15],['macd','MACD histogramı',34],['ma20','SMA20',20],['ma50','SMA50',50],['ma200','SMA200',200],['adx','ADX14',28]])need(key,label,n);
 rows.push({key:'weekly',label:'Haftalık SMA20',status:weeks>=20?'available':'insufficient',reason:weeks>=20?`${weeks} tamamlanan hafta`:`${weeks}/20 tamamlanan hafta; mevcut hafta dahil edilmez.`,count:weeks,required:20});
 rows.push({key:'volume',label:'Hacim göstergeleri',status:r.derived?'unsupported':count<21?'insufficient':missingVolume||!volumePositive?'missing':'available',reason:r.derived?'Türetilmiş gram serisinde işlem hacmi yok.':count<21?`${count}/21 günlük mum gerekli.`:missingVolume?`Son 20 mumun ${missingVolume} tanesinde hacim eksik; sıfırla doldurulmadı.`:!volumePositive?'Son 20 mumda pozitif işlem hacmi yok.':'Son 20 mumda geçerli hacim var.'});
 const relevant=rows.filter(x=>x.status!=='unsupported'),ready=relevant.filter(x=>x.status==='available').length;
 const longGaps=r.candles.slice(1).filter((c,i)=>c.t-r.candles[i].t>7*86400000).length;
 return {rows,ready,total:relevant.length,weeks,count,start:r.candles[0]?.t,end:r.candles.at(-1)?.t,longGaps,missingVolume};
}
export function metricReason(r,key){return r.coverage?.rows.find(x=>x.key===key)?.reason||'Gerekli veri henüz sağlanamadı.';}
export function goldFactors(metal,fx,period=21){
 const rates=new Map(fx.map(c=>[new Date(c.t).toISOString().slice(0,10),c.c]));const pairs=metal.filter(c=>rates.has(new Date(c.t).toISOString().slice(0,10))).map(c=>({t:c.t,metal:c.c,fx:rates.get(new Date(c.t).toISOString().slice(0,10))}));
 if(pairs.length<=period)return null;const a=pairs.at(-1-period),b=pairs.at(-1),m=b.metal/a.metal-1,f=b.fx/a.fx-1;return {period,start:a.t,end:b.t,metal:m*100,fx:f*100,interaction:m*f*100,total:((1+m)*(1+f)-1)*100};
}
