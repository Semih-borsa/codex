// CollectAPI Economy stock-list endpoint. Connection diagnostics only: no timestamp guessing.
const endpoint='https://api.collectapi.com/economy/hisseSenedi';
export function collectSummary(data){
 if(data?.success!==true||!Array.isArray(data.result))throw Error('CollectAPI başarılı hisse listesi döndürmedi. Paket/erişim yetkisini kontrol edin.');
 const rows=data.result,valid=rows.filter(r=>typeof r.code==='string'&&/^[A-Z0-9.]{1,20}$/.test(r.code)&&typeof r.lastprice==='number'&&Number.isFinite(r.lastprice)&&r.lastprice>0);
 return {received:rows.length,validPrices:valid.length,history:false,financials:false,provider:'CollectAPI',endpoint,checkedAt:Date.now(),message:'Bu bağlantı denetimi yalnız hisse listesi içindir. Günlük OHLCV, tarihli bilanço ve sağlayıcı fiyat zamanı doğrulanmadı. Bu liste teknik analiz, alarm veya güncel fiyat yerine kullanılmaz.'};
}
export async function testCollect(request){return collectSummary(await request(endpoint));}
