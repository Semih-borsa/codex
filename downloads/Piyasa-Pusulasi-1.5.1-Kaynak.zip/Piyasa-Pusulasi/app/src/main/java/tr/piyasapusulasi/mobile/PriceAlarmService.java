package tr.piyasapusulasi.mobile;
import android.app.*;import android.app.job.*;import android.content.*;import android.os.*;import org.json.*;import java.net.URLEncoder;import java.nio.charset.StandardCharsets;import java.util.concurrent.*;
public class PriceAlarmService extends JobService{
 private ExecutorService worker;private volatile boolean stopped;
 static void schedule(Context c){JobScheduler scheduler=(JobScheduler)c.getSystemService(JOB_SCHEDULER_SERVICE);scheduler.schedule(new JobInfo.Builder(3517,new ComponentName(c,PriceAlarmService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(15*60*1000L).setPersisted(true).build());}
 static double[] quote(String symbol)throws Exception{
  JSONObject data=new JSONObject(MarketHttp.request("https://query1.finance.yahoo.com/v8/finance/chart/"+URLEncoder.encode(symbol,"UTF-8")+"?range=1d&interval=5m","GET","",""));JSONObject m=data.getJSONObject("chart").getJSONArray("result").getJSONObject(0).getJSONObject("meta");double p=m.getDouble("regularMarketPrice");long t=m.getLong("regularMarketTime");if(!Double.isFinite(p)||p<=0||System.currentTimeMillis()/1000-t>1200||t-System.currentTimeMillis()/1000>120)throw new Exception("Veri güncel değil");return new double[]{p,t};
 }
 @Override public boolean onStartJob(JobParameters params){stopped=false;worker=Executors.newSingleThreadExecutor();worker.execute(()->{try{
  NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(!nm.areNotificationsEnabled())return;
  nm.createNotificationChannel(new NotificationChannel("price-targets","Fiyat hedefleri",NotificationManager.IMPORTANCE_DEFAULT));
  JSONArray all=new JSONArray(getSharedPreferences("alarms",0).getString("items","[]"));
  for(int i=0;i<all.length()&&!stopped;i++){JSONObject a=all.getJSONObject(i);if(!a.optBoolean("active"))continue;
   try{String market=a.getString("market"),symbol=a.getString("symbol"),ys=symbol;boolean gram=false;
    if("BIST".equals(market))ys=symbol+".IS";
    else if("METAL".equals(market)){gram=symbol.startsWith("GRAM");ys=symbol.contains("GUMUS")?"SI=F":"GC=F";}
    double[] q=quote(ys);double price=q[0];if(gram){double[] fx=quote("USDTRY=X");if(Math.abs(q[1]-fx[1])>1200)continue;price=price/31.1034768*fx[0];}
    double target=a.getDouble("target");boolean hit="above".equals(a.getString("condition"))?price>=target:price<=target;
    if(!hit)continue;
    // Re-read: never resurrect a target removed or edited while the network was running.
    JSONArray latest=new JSONArray(getSharedPreferences("alarms",0).getString("items","[]"));
    for(int j=0;j<latest.length();j++){JSONObject x=latest.getJSONObject(j);if(x.optString("id").equals(a.optString("id"))&&x.optBoolean("active")&&x.optDouble("target")==target&&x.optString("condition").equals(a.optString("condition"))){
     Intent launch=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,launch,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
     nm.notify(a.getString("id").hashCode()&0x7fffffff,new Notification.Builder(this,"price-targets").setSmallIcon(tr.piyasapusulasi.mobile.R.drawable.ic_notification).setContentTitle(symbol+" fiyat hedefine ulaştı").setContentText(String.format(java.util.Locale.forLanguageTag("tr"),"Son fiyat: %,.2f · Hedef: %,.2f",price,target)).setContentIntent(pi).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).build());
     x.put("active",false);x.put("triggeredAt",System.currentTimeMillis());getSharedPreferences("alarms",0).edit().putString("items",latest.toString()).commit();break;
    }}
   }catch(Exception ignored){/* No notification from missing, stale or failed price data. */}
  }
 }catch(Exception ignored){}finally{if(!stopped)jobFinished(params,false);worker.shutdown();}});return true;}
 @Override public boolean onStopJob(JobParameters params){stopped=true;if(worker!=null)worker.shutdownNow();return true;}
}
