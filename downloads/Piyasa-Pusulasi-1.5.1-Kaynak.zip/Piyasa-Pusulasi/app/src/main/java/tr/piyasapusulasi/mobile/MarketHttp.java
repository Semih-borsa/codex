package tr.piyasapusulasi.mobile;
import java.net.*;import java.io.*;import java.nio.charset.StandardCharsets;
final class MarketHttp {
 static final class Reply{final int status;final String body;Reply(int status,String body){this.status=status;this.body=body;}}
 static String request(String address,String method,String body,String apiKey)throws Exception{return read(address,method,body,apiKey).body;}
 static Reply read(String address,String method,String body,String apiKey)throws Exception{
  URI u=new URI(address);String host=u.getHost(),path=u.getPath();
  boolean yahoo=("query1.finance.yahoo.com".equals(host)||"query2.finance.yahoo.com".equals(host))&&path.startsWith("/v8/finance/chart/")&&"GET".equals(method);
  boolean collect="api.collectapi.com".equals(host)&&"/economy/hisseSenedi".equals(path)&&"GET".equals(method)&&u.getQuery()==null;
  boolean isyatirim="www.isyatirim.com.tr".equals(host)&&"GET".equals(method)&&(path.equalsIgnoreCase("/_layouts/15/IsYatirim.Website/Common/Data.aspx/MaliTablo")||path.equalsIgnoreCase("/_layouts/15/IsYatirim.Website/Common/Data.aspx/HisseTekil"));
  boolean analysts="www.hedeffiyat.com.tr".equals(host)&&"GET".equals(method)&&((u.getQuery()==null&&("/senetler".equals(path)||path.matches("/senet/[a-zA-Z0-9._%-]+")))||("/arama".equals(path)&&u.getRawQuery()!=null&&u.getRawQuery().matches("q=[A-Z0-9]{1,12}")));
  boolean google="generativelanguage.googleapis.com".equals(host)&&path.startsWith("/v1beta/models")&&("GET".equals(method)||"POST".equals(method));
  if(!"https".equals(u.getScheme())||u.getUserInfo()!=null||u.getPort()!=-1||(!yahoo&&!google&&!collect&&!isyatirim&&!analysts))throw new IOException("Bu veri adresine izin verilmiyor.");
  HttpURLConnection c=(HttpURLConnection)u.toURL().openConnection();
  try{c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setInstanceFollowRedirects(false);c.setRequestMethod(method);c.setRequestProperty("Accept",analysts?"text/html":"application/json");c.setRequestProperty("User-Agent","Mozilla/5.0 PiyasaPusulasi/1.0");c.setRequestProperty("Cache-Control","no-cache");
   if(isyatirim)c.setRequestProperty("Referer","https://www.isyatirim.com.tr/tr-tr/analiz/hisse/Sayfalar/sirket-karti.aspx");
   if(collect){if(apiKey==null||!apiKey.matches("[a-zA-Z0-9._:-]{10,300}"))throw new IOException("CollectAPI için Ayarlar’dan kendi anahtarınızı kaydedin.");c.setRequestProperty("Authorization","apikey "+apiKey);}
   if(google){if(apiKey==null||apiKey.trim().isEmpty())throw new IOException("AI için Ayarlar'dan kendi Gemini API anahtarınızı ekleyin.");c.setRequestProperty("x-goog-api-key",apiKey);}
   if("POST".equals(method)){if(body.length()>100000)throw new IOException("İstek çok büyük.");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream out=c.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}}
   int status=c.getResponseCode();if((status<200||status>=300)&&!(analysts&&status==404))throw new IOException(status==429?"Veri sağlayıcısının istek sınırına ulaşıldı. Biraz sonra yenileyin.":status==401||status==403?"Veri sağlayıcısı erişimi reddetti ("+status+").":"Veri sağlayıcısı yanıt veremedi ("+status+").");
   InputStream stream=status==404?c.getErrorStream():c.getInputStream();if(stream==null&&analysts&&status==404)return new Reply(status,"");if(stream==null)throw new IOException("Kaynak boş yanıt döndürdü ("+status+").");
   try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>4000000)throw new IOException("Veri yanıtı çok büyük.");}return new Reply(status,new String(out.toByteArray(),StandardCharsets.UTF_8));}
  }finally{c.disconnect();}
 }
}
