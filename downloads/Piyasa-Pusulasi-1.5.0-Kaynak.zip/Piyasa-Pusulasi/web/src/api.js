import {convertGram,gramHistory,indicators,yahooSymbol,METALS,normalize} from './core';
import {traderAnalysis} from './trader';
import {createMarketData} from './market-data';
import {dataCoverage,goldFactors} from './coverage';
const pending=new Map();let sequence=0;
window.__nativeReply=(id,ok,data)=>{const p=pending.get(id);if(!p)return;pending.delete(id);clearTimeout(p.timer);if(ok){try{p.resolve(p.raw?data:JSON.parse(data));}catch{p.reject(Error('Veri sağlayıcısının yanıtı okunamadı.'));}}else {const error=Error(data||'Bağlantı kurulamadı.'),match=String(data).match(/\((400|401|403|404|429|5\d\d)\)/);if(match)error.status=Number(match[1]);else if(/istek sınır/i.test(String(data)))error.status=429;p.reject(error);}};
export async function request(url,method='GET',body=null,format='json'){
 if(window.MarketBridge)return new Promise((resolve,reject)=>{const id='req_'+(++sequence);const timer=setTimeout(()=>{pending.delete(id);reject(Error('Bağlantı zaman aşımına uğradı. Yeniden deneyin.'));},32000);pending.set(id,{resolve,reject,timer,raw:format==='text'});try{window.MarketBridge.request(id,url,method,body?JSON.stringify(body):'');}catch{clearTimeout(timer);pending.delete(id);reject(Error('Bağlantı başlatılamadı.'));}});
 const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),20000);
 try{const r=await fetch(url,{method,headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,signal:ctrl.signal,cache:'no-store'});if(!r.ok){const error=Error(r.status===429?'İstek sınırına ulaşıldı. Biraz sonra deneyin.':'Veri sağlayıcısına ulaşılamadı ('+r.status+').');error.status=r.status;throw error;}return format==='text'?await r.text():await r.json();}catch(e){if(e.name==='AbortError')throw Error('Bağlantı zaman aşımı.');if(e.message==='Failed to fetch')throw Error('Bağlantı kurulamadı. İnternetinizi kontrol edip yenileyin.');throw e;}finally{clearTimeout(timer);}
}
export const requestText=url=>request(url,'GET',null,'text');
const chart=createMarketData(request);
export async function quote(market,input){const symbol=normalize(market,input);let q=await chart(yahooSymbol(market,symbol));if(q.currency!==(market==='BIST'?'TRY':'USD'))throw Error('Fiyatın para birimi seçilen piyasayla uyuşmuyor.');if(market==='METAL'){const m=METALS[symbol];if(m.unit==='gram'){const fx=await chart('USDTRY=X');if(q.currency!=='USD'||fx.currency!=='TRY')throw Error('Metal veya kur para birimi doğrulanamadı.');q=convertGram(q,fx);}q.name=m.name;}return{...q,market,symbol,change:q.previous?(q.price/q.previous-1)*100:null};}
export async function analyze(market,input){
 const symbol=normalize(market,input),derived=market==='METAL'&&METALS[symbol].unit==='gram';
 const [q,h,fx]=await Promise.all([quote(market,symbol),chart(yahooSymbol(market,symbol),true),derived?chart('USDTRY=X',true):Promise.resolve(null)]);
 if(Math.abs(q.timestamp-h.timestamp)>2*86400000)throw Error('Fiyat ve analiz tarihleri uyuşmuyor. Analiz gösterilmedi.');
 if(h.currency!==(market==='BIST'?'TRY':'USD'))throw Error('Beklenen analiz para birimi sağlayıcıyla uyuşmuyor.');
 if(derived&&fx.currency!=='TRY')throw Error('USD/TRY geçmişinin para birimi doğrulanamadı.');
 const candles=derived?gramHistory(h.candles,fx.candles):h.candles;
 const result={...q,candles,technical:indicators(candles),trader:traderAnalysis(candles,{derived}),chartCurrency:derived?'TRY':h.currency,reference:false,derived,analysisTime:candles.at(-1).t,historyProvenance:h.provenance,historyQuality:h.quality,extension:h.extension||null};
 if(derived){result.historyQuality={...h.quality,unmatched:h.candles.length-candles.length};result.fxProvenance=fx.provenance;result.factors=goldFactors(h.candles,fx.candles);result.fxExtension=fx.extension||null;}
 result.coverage=dataCoverage(result);return result;
}

export async function aiExplain(result,model){
 if(!/^[a-zA-Z0-9._-]+$/.test(model))throw Error('Geçerli bir model adı seçin.');
 if(result.offline)throw Error('Kayıtlı analizle AI yorumu üretilmez; önce güncel veriyi alın.');
 const stamp=result.timestamp;if(Date.now()-result.receivedAt>120000)throw Error('AI yorumundan önce fiyatı yenileyin.');
 const prompt=`Türkçe, en fazla 200 kelimelik dengeli bir teknik analiz açıklaması yaz. Bu bir yatırım emri değildir. Kesin al/sat veya garanti verme. Gelecekteki hedef fiyat, bilanço, haber veya oran uydurma. Web aramasından gelen bir bilgiyi kullanırsan tarihini belirt. Eski haberi güncel diye sunma. Kaynak verinin zamanı ${new Date(stamp).toISOString()}; sembol ${result.symbol}; fiyat ${result.price} ${result.currency}. Teknik veri ${JSON.stringify(result.technical)}. Kural tabanlı inceleme ${JSON.stringify(result.trader)}. Teknik denge puanı olasılık veya doğrulanmış başarı oranı değildir. Hacimden gerçek net alıcı, takas veya kesin para girişi çıkarma. Doğrulanmış bilanço yoksa F-Score, sağlık skoru, emsal oran veya 12 aylık hedef üretme. Teknik birim ${result.chartCurrency}. ${result.derived?'Gram TL geçmişi aynı UTC tarihli kur kapanışlarıyla teorik olarak çevrilmiştir.':''}`;
 const r=await request(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,'POST',{contents:[{parts:[{text:prompt}]}],tools:[{google_search:{}}],generationConfig:{temperature:0.2,maxOutputTokens:1600}});
 if(r.error)throw Error('AI sağlayıcısı: '+(r.error.message||'İstek karşılanamadı.'));
 const candidate=r.candidates?.[0],text=candidate?.content?.parts?.filter(p=>!p.thought).map(p=>p.text||'').join('\n');if(!text)throw Error('AI açıklaması alınamadı. Teknik analiz kullanılabilir.');
 const sources=(candidate.groundingMetadata?.groundingChunks||[]).map(s=>s.web).filter(s=>s&&/^https:\/\//.test(s.uri));return{text,sources,at:Date.now(),quoteTime:stamp};
}
