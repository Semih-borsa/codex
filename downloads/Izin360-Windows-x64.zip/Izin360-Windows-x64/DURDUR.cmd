@echo off
start "" "%~dp0Izin360-Durdur.exe"
