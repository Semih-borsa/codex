package tr.piyasapusulasi.mobile;
import java.net.*;import java.io.*;import java.nio.charset.StandardCharsets;
final class MarketHttp {
 static String request(String address,String method,String body,String apiKey)throws Exception{
  URI u=new URI(address);String host=u.getHost(),path=u.getPath();
  boolean yahoo=("query1.finance.yahoo.com".equals(host)||"query2.finance.yahoo.com".equals(host))&&path.startsWith("/v8/finance/chart/")&&"GET".equals(method);
  boolean google="generativelanguage.googleapis.com".equals(host)&&path.startsWith("/v1beta/models")&&("GET".equals(method)||"POST".equals(method));
  if(!"https".equals(u.getScheme())||u.getUserInfo()!=null||u.getPort()!=-1||(!yahoo&&!google))throw new IOException("Bu veri adresine izin verilmiyor.");
  HttpURLConnection c=(HttpURLConnection)u.toURL().openConnection();
  try{c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setInstanceFollowRedirects(false);c.setRequestMethod(method);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","Mozilla/5.0 PiyasaPusulasi/1.0");c.setRequestProperty("Cache-Control","no-cache");
   if(google){if(apiKey==null||apiKey.trim().isEmpty())throw new IOException("AI için Ayarlar'dan kendi Gemini API anahtarınızı ekleyin.");c.setRequestProperty("x-goog-api-key",apiKey);}
   if("POST".equals(method)){if(body.length()>100000)throw new IOException("İstek çok büyük.");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream out=c.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}}
   int status=c.getResponseCode();if(status<200||status>=300)throw new IOException(status==429?"Veri sağlayıcısının istek sınırına ulaşıldı. Biraz sonra yenileyin.":status==401||status==403?"Veri sağlayıcısı erişimi reddetti ("+status+").":"Veri sağlayıcısı yanıt veremedi ("+status+").");
   try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>4000000)throw new IOException("Veri yanıtı çok büyük.");}return new String(out.toByteArray(),StandardCharsets.UTF_8);}
  }finally{c.disconnect();}
 }
}
