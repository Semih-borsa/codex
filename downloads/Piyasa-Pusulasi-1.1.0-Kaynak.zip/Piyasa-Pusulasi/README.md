# Piyasa Pusulası 1.1.0
Android 8+; package tr.piyasapusulasi.mobile. Version code 2. Same signing identity as 1.0.0; install as an update without uninstalling to retain local preferences, watch list and targets. No migration or deletion of saved records.

## Corrections
Comparison fields have independent controlled state. Empty values remain empty; validation rejects missing or identical symbols. Edits invalidate prior results and in-flight requests. Comparison returns use exactly matched UTC dates and each instrument's own currency.

Gram gold/silver history uses the metal futures daily series multiplied by the same UTC date's USDTRY close and divided by 31.1034768. Missing dates are excluded; a missing FX value on the final metal date rejects analysis. SMA/MACD/support/Bollinger/ATR are calculated on the converted TRY/gram series. Daily OHLC is synthetic using daily FX close, not synchronized intraday spot quotes. Volume is unavailable. No historical price is multiplied by today's exchange rate.

## Analysis
Wilder RSI14 and ATR14; MACD12/26/9; SMA20/50/200; Bollinger20 with population standard deviation; 5/21/63/126 observation returns; sample standard deviation of daily log returns annualized by sqrt252; maximum peak-to-trough drawdown over available history; latest volume divided by prior20 mean. Current daily candle can change. Risk metrics use all available daily history, independent of chart zoom. Price returns are not total returns or inflation-adjusted returns. Provider corporate-action adjustment is not normalized by this app; splits and futures rolls can distort metrics.

Fundamental data is unavailable: no invented financial ratios, valuation scores or target prices. Gold depends on dollar metal price and FX; domestic dealer premiums/spreads are excluded. Scenario boundaries are historical observations, not orders or guaranteed turning points. Optional Gemini explanations require the user's key.

## Build
Node with npm ci in web, then npm run build and npm test. Copy web/dist to app/src/main/assets/public, including THIRD-PARTY-NOTICES.txt. JDK17, Android SDK35, Gradle wrapper8.9. Set PIYASA_SIGNING_PROPERTIES to an external properties file containing storeFile/storePassword/keyAlias/keyPassword. Run ./gradlew :app:assembleRelease :app:lintRelease. Signing secrets are deliberately excluded. A separately signed source rebuild cannot replace the distributed APK without the matching private key.
