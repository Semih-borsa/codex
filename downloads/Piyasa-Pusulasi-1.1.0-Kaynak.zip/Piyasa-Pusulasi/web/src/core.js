export const OUNCE=31.1034768;
export const METALS={GRAM_ALTIN:{name:'Gram altın',y:'GC=F',unit:'gram',currency:'TRY'},ONS_ALTIN:{name:'Ons altın',y:'GC=F',unit:'ons',currency:'USD'},GRAM_GUMUS:{name:'Gram gümüş',y:'SI=F',unit:'gram',currency:'TRY'},ONS_GUMUS:{name:'Ons gümüş',y:'SI=F',unit:'ons',currency:'USD'}};
export const PRESETS={BIST:[['THYAO','Türk Hava Yolları'],['ASELS','Aselsan'],['TUPRS','Tüpraş'],['BIMAS','BİM'],['KCHOL','Koç Holding'],['SISE','Şişecam'],['EREGL','Ereğli Demir Çelik'],['AKBNK','Akbank'],['GARAN','Garanti BBVA'],['SAHOL','Sabancı Holding']],US:[['AAPL','Apple'],['MSFT','Microsoft'],['NVDA','NVIDIA'],['AMZN','Amazon'],['GOOGL','Alphabet'],['META','Meta Platforms'],['TSLA','Tesla']],METAL:Object.entries(METALS).map(([s,m])=>[s,m.name])};
export const fmt=(n,d=2)=>Number.isFinite(n)?n.toLocaleString('tr-TR',{minimumFractionDigits:d,maximumFractionDigits:d}):'—';
export const dateTime=t=>Number.isFinite(t)?new Date(t).toLocaleString('tr-TR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',timeZone:'Europe/Istanbul'}):'Zaman doğrulanamadı';
export function normalize(market,input){const s=String(input).trim().toLocaleUpperCase('tr-TR').replace(/İ/g,'I').replace(/\.IS$/,'');if(!Object.hasOwn(PRESETS,market)||!s||!(/^[A-Z0-9^][A-Z0-9._^=-]{0,19}$/.test(s)))throw Error('Geçerli bir sembol yazın. Örnek: THYAO veya AAPL.');if(market==='METAL'&&!METALS[s])throw Error('Listeden altın veya gümüş türünü seçin.');return s;}
export function yahooSymbol(market,symbol){return market==='BIST'?symbol+'.IS':market==='METAL'?METALS[symbol].y:symbol;}
const number=v=>typeof v==='number'&&Number.isFinite(v);
export function parseChart(json,now=Date.now(),kind='quote'){
 const root=json?.chart;if(root?.error)throw Error(root.error.description||'Sembol verisi bulunamadı.');const r=root?.result?.[0];if(!r)throw Error('Veri sağlayıcısı geçerli bir fiyat döndürmedi.');
 const m=r.meta||{},timestamp=m.regularMarketTime*1000,price=m.regularMarketPrice;
 if(!number(price)||price<=0||!number(timestamp)||timestamp<=0||timestamp>now+120000)throw Error('Fiyat veya veri zamanı doğrulanamadı.');
 const age=now-timestamp;if(age>7*86400000)throw Error('Veri 7 günden eski. Eski fiyatla analiz yapılmadı.');
 const q=r.indicators?.quote?.[0]||{},candles=[];
 for(let i=0;i<(r.timestamp||[]).length;i++){const t=r.timestamp[i]*1000,c=q.close?.[i],o=q.open?.[i],h=q.high?.[i],l=q.low?.[i],v=q.volume?.[i];if(!number(t)||t>now+120000||!number(c)||c<=0||!number(h)||!number(l)||h<l||h<c||l>c)continue;candles.push({t,c,o:number(o)?o:c,h,l,v:number(v)&&v>=0?v:0});}
 candles.sort((a,b)=>a.t-b.t);const unique=candles.filter((c,i)=>!i||c.t!==candles[i-1].t);
 if(kind==='history'&&unique.length<20)throw Error('Güvenilir analiz için en az 20 günlük fiyat gerekli.');
 if(kind==='history'&&timestamp-unique.at(-1).t>4*86400000)throw Error('Grafiğin son mumu eski; teknik analiz yapılmadı.');
 const p=m.currentTradingPeriod?.regular,open=number(p?.start)&&number(p?.end)&&now>=p.start*1000&&now<=p.end*1000;
 // A recent HTTP response alone never establishes a fresh exchange price.
 const status=!number(p?.start)||!number(p?.end)?'unknown':open?(age<=20*60000?'recent':'stale'):'closed';
 if(open&&status==='stale')throw Error('Piyasa açık ancak fiyat zamanı eski. Yeniden deneyin.');
 const previous=number(m.previousClose)&&m.previousClose>0?m.previousClose:kind==='quote'&&number(m.chartPreviousClose)&&m.chartPreviousClose>0?m.chartPreviousClose:null;
 return{price,previous,timestamp,receivedAt:now,age,status,delay:m.exchangeDataDelayedBy??null,name:m.longName||m.shortName||m.symbol,currency:m.currency||'USD',candles:unique,exchange:m.exchangeName||'',timezone:m.exchangeTimezoneName||'UTC'};
}
export function convertGram(quote,fx){
 if(Math.abs(quote.timestamp-fx.timestamp)>24*3600000)throw Error('Ons ve kur verisinin tarihleri uyuşmuyor; gram fiyatı hesaplanmadı.');
 const previous=quote.previous&&fx.previous?quote.previous/OUNCE*fx.previous:null;
 return{...quote,price:quote.price/OUNCE*fx.price,previous,currency:'TRY',status:quote.status==='recent'&&fx.status==='recent'?'recent':quote.status==='unknown'||fx.status==='unknown'?'unknown':'closed',timestamp:Math.min(quote.timestamp,fx.timestamp),fxTimestamp:fx.timestamp,fx:fx.price,theoretical:true};
}
// Match UTC trading dates exactly; never fill a missing rate with a future rate.
export function gramHistory(metal,fx){
 const day=t=>new Date(t).toISOString().slice(0,10), rates=new Map(fx.map(c=>[day(c.t),c.c]));
 const candles=metal.filter(c=>rates.has(day(c.t))).map(c=>{const k=rates.get(day(c.t))/OUNCE;return {...c,o:c.o*k,h:c.h*k,l:c.l*k,c:c.c*k,v:0};});
 if(candles.length<20)throw Error('Gram analizinde en az 20 eşleşen günlük kur gerekli.');
 if(day(candles.at(-1).t)!==day(metal.at(-1).t))throw Error('Son metal gününün kuru bulunamadı; eski gram analizi gösterilmedi.');
 return candles;
}
export function comparisonStats(left,right){
 const day=t=>new Date(t).toISOString().slice(0,10), r=new Map(right.candles.map(c=>[day(c.t),c.c]));
 const pairs=left.candles.filter(c=>r.has(day(c.t))).map(c=>({t:c.t,a:c.c,b:r.get(day(c.t))}));
 if(pairs.length<20)throw Error('Karşılaştırma için en az 20 ortak işlem günü gerekli.');
 const base=pairs[0],last=pairs.at(-1);return {count:pairs.length,start:base.t,end:last.t,left:(last.a/base.a-1)*100,right:(last.b/base.b-1)*100};
}
export function sma(a,p){return a.length<p?null:a.slice(-p).reduce((s,v)=>s+v,0)/p;}
export function ema(a,p){let e=null;return a.map((v,i)=>{if(i<p-1)return null;if(i===p-1)e=a.slice(0,p).reduce((s,x)=>s+x,0)/p;else e=(v-e)*2/(p+1)+e;return e;});}
export function rsi(a,p=14){if(a.length<p+1)return null;let gain=0,loss=0;for(let i=1;i<=p;i++){let d=a[i]-a[i-1];gain+=Math.max(d,0);loss+=Math.max(-d,0);}gain/=p;loss/=p;for(let i=p+1;i<a.length;i++){let d=a[i]-a[i-1];gain=(gain*(p-1)+Math.max(d,0))/p;loss=(loss*(p-1)+Math.max(-d,0))/p;}return loss===0?(gain===0?50:100):100-100/(1+gain/loss);}
export function indicators(candles){
 const a=candles.map(c=>c.c),f=ema(a,12),s=ema(a,26),line=a.map((_,i)=>f[i]!==null&&s[i]!==null?f[i]-s[i]:null).filter(v=>v!==null),signal=ema(line,9).at(-1)??null,macd=line.at(-1)??null;
 const last=a.at(-1),ma20=sma(a,20),ma50=sma(a,50),ma200=sma(a,200),relative=rsi(a),range=candles.slice(-30),support=range.length?Math.min(...range.map(c=>c.l)):null,resistance=range.length?Math.max(...range.map(c=>c.h)):null;
 const tr=candles.map((c,i)=>{const previous=i?candles[i-1].c:c.o;return Math.max(c.h-c.l,Math.abs(c.h-previous),Math.abs(c.l-previous));}),atr=tr.length>=14?tr.slice(14).reduce((v,x)=>(v*13+x)/14,sma(tr.slice(0,14),14)):null,volatility=atr!==null?atr/last*100:null;
 const trend=ma50===null?'Yetersiz veri':last>ma20&&last>ma50?'Yukarı eğilim':last<ma20&&last<ma50?'Aşağı eğilim':'Kararsız / yatay';
 const momentum=relative===null?'Hesaplanamadı':relative>=70?'Aşırı alım bölgesi':relative<=30?'Aşırı satım bölgesi':'Dengeli momentum';
 const returns=Object.fromEntries([[5,'week'],[21,'month'],[63,'quarter'],[126,'half']].map(([n,k])=>[k,a.length>n?(last/a[a.length-1-n]-1)*100:null]));
 const logs=a.slice(1).map((v,i)=>Math.log(v/a[i])),mean=sma(logs,logs.length),annualVol=logs.length>1?Math.sqrt(logs.reduce((s,v)=>s+(v-mean)**2,0)/(logs.length-1)*252)*100:null;
 let peak=a[0],drawdown=0;for(const v of a){peak=Math.max(peak,v);drawdown=Math.min(drawdown,(v/peak-1)*100);}
 const sd=ma20===null?null:Math.sqrt(a.slice(-20).reduce((s,v)=>s+(v-ma20)**2,0)/20),upper=sd===null?null:ma20+2*sd,lower=sd===null?null:ma20-2*sd;
 const baseVol=sma(candles.slice(0,-1).map(c=>c.v),20),volumeRatio=baseVol>0?candles.at(-1).v/baseVol:null;
 return{returns,annualVol,drawdown,atr,upper,lower,volumeRatio,count:a.length,rsi:relative,macd,signal,hist:macd!==null&&signal!==null?macd-signal:null,ma20,ma50,ma200,support,resistance,volatility,trend,momentum,last};
}
export function describe(t){return `${t.trend}. ${t.momentum}. ${t.hist===null?'MACD için yeterli veri yok.':t.hist>0?'MACD histogramı pozitif; kısa vadeli momentum güçlü.':'MACD histogramı negatif veya nötr; momentum zayıf.'} Destek ve direnç, son 30 günlük mumların en düşük/en yüksek fiyatlarıdır; kesin dönüş seviyesi değildir.`;}
export function freshForAlarm(q,now=Date.now()){return q&&q.status==='recent'&&now-q.timestamp<=20*60000&&now-q.receivedAt<=2*60000;}
export function parseTarget(value){const s=String(value).trim();let normalized;if(s.includes(',')){if(!/^(?:\d+|\d{1,3}(?:\.\d{3})+),\d{1,4}$/.test(s))return NaN;normalized=s.replaceAll('.','').replace(',','.');}else if(/^\d{1,3}(?:\.\d{3})+$/.test(s))normalized=s.replaceAll('.','');else if(/^\d+(?:\.\d{1,4})?$/.test(s))normalized=s;else return NaN;const n=Number(normalized);return Number.isFinite(n)?n:NaN;}
