# Piyasa Pusulası 1.3.1
Android8+, WebView80+, package `tr.piyasapusulasi.mobile`, versionCode5. Same signing identity as previous releases; install on top without uninstalling to keep user records.

## Data reliability
Yahoo chart history requests2y of daily OHLCV; below200 valid observations requests5y once. Short-listed companies retain their real bar count; missing history is never fabricated. Fewer than20 bars rejects analysis after extension. Coalesces in-flight identical symbol/range requests, including FX; completed responses are not silently reused as new data. Two Yahoo hosts are alternatives of the same provider, not independent price confirmation. Transient network failures try the second endpoint with bounded delay; invalid/stale responses fail validation instead of blind retry. 429 failures trigger30s cooldown. Native status messages preserve useful HTTP categories.

Valid OHLC must be positive, finite and internally consistent. Missing volume stays null, not zero; zero volume is permitted as a real observation when the window has positive aggregate volume. Currency must be present and match the expected market. Source, endpoint/range, timestamps, rejected/duplicate bars and long calendar intervals are visible. Coverage distinguishes short history, missing volume and non-applicable indicators. No split-adjustment verification or licensed real-time feed is claimed.

Gram gold/silver uses metal futuresUSD × same UTC-date USDTRYclose /31.1034768. Missing final FX day rejects analysis; other unmatched dates are excluded without future-rate fill. SMA/MACD/ATR are TRY/gram. OHLC is synthetic using each day's closing FX, not synchronous intraday spot gram. Volume/financial-statement cards are removed for gram;21-observation metal/FX/interaction return decomposition is displayed. Dealer spreads and local premiums are excluded.

## Analysis
Wilder RSI14, ATR14 and ADX14/+DI/-DI; MACD12/26/9; SMA20/50/200; Bollinger20±2 population standard deviations; ROC10; raw Stochastic%K14; MFI14; CMF20; OBV20 change; previous20-candle channel and previous-candle classic pivots. OBV/CMF are OHLCV proxies, not actual order flow, net money or custody data.

Weekly candles use Monday UTC aggregation, excluding current week and first possibly truncated week. Technical balance averages valid rules within trend/momentum/participation/weekly groups, then equally across present groups; maps [-1,1] to[0,100], requiring at least3 groups. RSI55/45, CMF±0.05, other directional signs. Missing rules are not neutral votes; unsupported gram participation excluded from UI denominator. Model is not backtested or probability calibrated. No personalized buy/sell order or invented target price.

Performance5/21/63/126 observations; annual volatility sample SD of daily log returns ×sqrt252; max drawdown across available daily history. Metrics use entire loaded history, independent of chart zoom. Price returns exclude total-return, inflation and additional corporate-action normalization. Futures rolls can distort readings. Charts toggle SMA overlays; candle/date ranges match. Custom scans validate/deduplicate up to20 symbols, two analyses concurrently, rank by technical balance.

Hypothetical long-breakout arithmetic: previous20 high+0.1ATR trigger,1.5ATR invalidation distance,2R illustrative level. Crossed triggers marked obsolete. Optional full-share count capped by both available capital and nominal loss budget. Same-currency, unleveraged, no fees/slippage/gap protection; metal contract sizing disabled.

## Offline archive
Separate localStorage namespace stores last4 successful analyses, max1500 bars each. Only explicit user action opens a matching archive after failure. Original source time is retained, permanent offline banner shown, AI disabled; it is never fed to alarms or treated as fresh. Expired(30d)/invalid records are rejected without clearing user storage. Favorite/alarm/theme schemas stay unchanged. Storage quota failure does not discard live result or overwrite user preferences.

## CollectAPI — connection diagnostic, not a completed market-feed migration
Optional Android settings store a personal CollectAPI key using a separate AndroidKeystore AES/GCM alias and encrypted preference, retaining existing Gemini encryption compatibility. Key is never returned to JavaScript, written to source, or sent outside allowlisted `https://api.collectapi.com/economy/hisseSenedi` GET with no query. Native Authorization header uses `apikey <key>`; HTTP redirects disabled. No built-in API key. User's account/package/quota required. Test button can consume quota.

Diagnostic expects successful `result` array with code/lastprice fields; reports instrument count and valid numeric code/price pairs. Receipt time is explicitly not verified price time. CollectAPI docs/API were blocked by the cloud network and no user key/account was available; current API response schema and package capability remain unverified. This adapter therefore does not replace Yahoo analysis/quotes/alarms and does not claim historical OHLCV, financial statements or current verified quotes. API keys in distributed personal clients are not equivalent to server-only secrets.

Without dated complete financial statements, F-Score, financial health, peer valuations and12-month target are not produced. Stocks show a single source-connection explanation with KAP/SEC link, rather than rows of empty ratios. Gemini cannot fill those gaps.

## Build and tests
Node/npm: `cd web && npm ci && npm test && npm run build`. Copy web/dist into app/src/main/assets/public, plus THIRD-PARTY-NOTICES.txt. JDK17, Android SDK35, Gradle wrapper8.9/AGP8.7.3. External `PIYASA_SIGNING_PROPERTIES` provides storeFile/storePassword/keyAlias/keyPassword; signing files are excluded. `./gradlew :app:assembleRelease :app:lintRelease`. A separate signature cannot upgrade the distributed APK without the matching key.

`node web/browser-tests.cjs` uses Playwright/Chromium and Vite localhost8767 with controlled responses. Native HTTP boundary test: javac MarketHttp.java and native-tests/MarketHttpSecurityTest.java with package output, then run tr.piyasapusulasi.mobile.MarketHttpSecurityTest. See VALIDATION.md for verified scope and limitations.


## 1.3.1 reading and AI refresh fix
Automatic65-second/foreground/online refresh now uses an independent background request token. It never clears the current result or AI explanation, changes chart range, or closes expanded panels. React retains the same result subtree and restores scroll position after a background commit/error. Failed refresh keeps original data timestamps and shows an explicit unchanged-data message. This is distinct from loading an offline archive.

AI pending and alarm form open pause background analysis refresh. Starting AI or opening the form invalidates any earlier in-flight background response; manual analysis/navigation also invalidates it. Current AI explanation keeps its original quote timestamp even if a later background refresh succeeds. Explicit user refresh can still replace/cancel an analysis; timers cannot. Data/indicator/financial calculation code and stored record schemas are unchanged in this patch. See VERI-KAYNAKLARI.md for candidate-provider research, actual access outcomes and unverified capabilities.

Regression suite `node web/refresh-browser-tests.cjs` uses a mock native bridge, held Gemini response and virtual clock to cross the65-second refresh boundary during a valid20-second AI wait. It also tests successful/failed quiet refresh, alarm form pause and late background-response races. No real key or AI account is used.
