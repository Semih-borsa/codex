# POS Kasa Yönetim — v41

Güncel yönergeler: KULLANIM-v41.md ve SONUC-RAPORU-v41.md.
Eski sürüm belgeleri arşivdir. V41’de Windows OCR dili/PowerShell şartı yoktur; motor ve Türkçe/İngilizce verileri gömülüdür.
Bu tam kaynak paketidir. Windows’ta pos-app/BUILD.bat ile derleyin. OCR için ayrı kurulum gerekmez. ocr-runtime klasörünü silmeyin; programı taşırken win-unpacked klasörünün tamamını taşıyın.
Güncellemeden önce JSON yedeği alın; mevcut verileri temizlemeyin.
