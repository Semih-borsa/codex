package com.semih.nobet;

import java.time.*;
import java.util.*;

/** Pure scheduling model. No Android, networking, or persistent mutations. */
public final class Roster {
  public static final String WORK = "İşyeri", BRANCH = "Şube", ALL = "Her iki yer";

  // Place IDs never change when the user renames a location.
  public static final class Place {
    public String id, name;
    public int days, limit;
    public boolean automatic = true;
    public boolean deleted = false;

    public Place(String id, String name, int days, int limit) {
      this.id = id;
      this.name = name;
      this.days = days;
      this.limit = limit;
    }

    public boolean on(LocalDate date) {
      return (days & (1 << (date.getDayOfWeek().getValue() - 1))) != 0;
    }
  }

  public static final class Person {
    public String id, name;
    public boolean active = true;

    public Person(String id, String name) {
      this.id = id;
      this.name = name;
    }
  }

  public static final class Leave {
    public String person, place, reason;
    public LocalDate start, end;
    public int days; // 0: dated leave; otherwise Monday=bit 0 ... Sunday=bit 6.

    public Leave(String person, String place, LocalDate start, LocalDate end, String reason) {
      this(person, place, start, end, reason, 0);
    }

    public Leave(
        String person, String place, LocalDate start, LocalDate end, String reason, int days) {
      if (days < 0 || days > 127) throw new IllegalArgumentException("Geçersiz tekrar günleri.");
      this.days = days;
      if (end.isBefore(start))
        throw new IllegalArgumentException("Bitiş başlangıçtan önce olamaz.");
      this.person = person;
      this.place = place;
      this.start = start;
      this.end = end;
      this.reason = reason;
    }

    public boolean blocks(String p, String where, LocalDate date) {
      return person.equals(p)
          && (place.equals(ALL) || place.equals(where))
          && !date.isBefore(start)
          && !date.isAfter(end)
          && (days == 0 || (days & (1 << (date.getDayOfWeek().getValue() - 1))) != 0);
    }
  }

  public static final class Duty {
    public LocalDate date;
    public String place, person;

    public Duty(LocalDate date, String place, String person) {
      this.date = date;
      this.place = place;
      this.person = person;
    }
  }

  public static final class Debt {
    public String person;
    public LocalDate end;

    public Debt(String person, LocalDate end) {
      this.person = person;
      this.end = end;
    }
  }

  public static final class Week {
    public LocalDate monday;
    public String cursor = "";
    public int rotationRevision = 0;
    public List<Duty> duties = new ArrayList<>();
    public List<Debt> debts = new ArrayList<>();
    public Set<String> limitOverrides = new HashSet<>();
    public List<String> warnings = new ArrayList<>();

    public Week(LocalDate monday) {
      this.monday = monday;
    }
  }

  public static final class State {
    public Set<String> hiddenPlaces = new HashSet<>();
    public List<String> weekendOrder = new ArrayList<>();
    public int rotationRevision = 0;
    public List<Place> places =
        new ArrayList<>(
            Arrays.asList(new Place(WORK, WORK, 127, 0), new Place(BRANCH, BRANCH, 31, 1)));
    public List<Person> people = new ArrayList<>();
    public List<Leave> leaves = new ArrayList<>();
    public List<Week> weeks = new ArrayList<>();

    public Place place(String id) {
      return places.stream()
          .filter(p -> p.id.equals(id))
          .findFirst()
          .orElseThrow(() -> new IllegalArgumentException("Görev yeri bulunamadı."));
    }

    public String placeName(String id) {
      if (ALL.equals(id)) return "Tüm görev yerleri";
      return places.stream().filter(p -> p.id.equals(id)).map(p -> p.name).findFirst().orElse(id);
    }

    public String name(String id) {
      return people.stream()
          .filter(p -> p.id.equals(id))
          .map(p -> p.name)
          .findFirst()
          .orElse("Kaldırılmış personel");
    }
  }

  public static LocalDate monday(LocalDate date) {
    return date.minusDays(date.getDayOfWeek().getValue() - 1);
  }

  public static boolean weekend(LocalDate date) {
    return date.getDayOfWeek().getValue() >= 6;
  }

  public static boolean available(State s, String p, String place, LocalDate date) {
    return s.people.stream().anyMatch(x -> x.id.equals(p) && x.active)
        && s.leaves.stream().noneMatch(l -> l.blocks(p, place, date));
  }

  static boolean free(State s, Week w, Person p, String place, LocalDate date) {
    return !rest(w, p.id, date)
        && available(s, p.id, place, date)
        && w.duties.stream().noneMatch(d -> d.date.equals(date) && d.person.equals(p.id));
  }

  public static boolean rest(Week w, String person, LocalDate date) {
    return (date.equals(w.monday.plusDays(3)) || date.equals(w.monday.plusDays(4)))
        && w.duties.stream()
            .anyMatch(d -> d.person.equals(person) && d.place.equals(WORK) && weekend(d.date));
  }

  static long count(State s, Week w, String id, String place, boolean weekend) {
    return java.util.stream.Stream.concat(
            s.weeks.stream()
                .filter(x -> x.monday.isBefore(w.monday))
                .flatMap(x -> x.duties.stream()),
            w.duties.stream())
        .filter(d -> d.person.equals(id) && d.place.equals(place) && weekend(d.date) == weekend)
        .count();
  }

  public static List<Debt> pendingDebts(State s, LocalDate before) {
    List<Week> history = new ArrayList<>();
    for (Week w : s.weeks) if (w.monday.isBefore(before)) history.add(w);
    history.sort(Comparator.comparing(w -> w.monday));
    Set<String> visited = new HashSet<>();
    Map<String, Debt> result = new LinkedHashMap<>();
    for (Week origin : history)
      for (Debt d : origin.debts) {
        String key = d.person + "|" + d.end;
        if (!visited.add(key)) continue;
        boolean served =
            history.stream()
                .filter(w -> !w.monday.isBefore(origin.monday))
                .anyMatch(
                    w ->
                        w.duties.stream()
                            .anyMatch(
                                x ->
                                    x.person.equals(d.person)
                                        && x.place.equals(WORK)
                                        && weekend(x.date)
                                        && x.date.isAfter(d.end)));
        if (!served) {
          Debt old = result.get(d.person);
          if (old == null || d.end.isAfter(old.end))
            result.put(d.person, new Debt(d.person, d.end));
        }
      }
    return new ArrayList<>(result.values());
  }

  static void debt(Week w, String p, LocalDate end) {
    Debt old = w.debts.stream().filter(d -> d.person.equals(p)).findFirst().orElse(null);
    if (old == null) w.debts.add(new Debt(p, end));
    else if (end.isAfter(old.end)) old.end = end;
  }

  public static List<LocalDate> workWeekendDays(State s, LocalDate monday) {
    List<LocalDate> result = new ArrayList<>();
    for (int i = 5; i < 7; i++) {
      LocalDate d = monday.plusDays(i);
      if (s.place(WORK).on(d)) result.add(d);
    }
    return result;
  }

  public static boolean weekendAvailable(State s, String person, LocalDate monday) {
    for (LocalDate d : workWeekendDays(s, monday)) if (!available(s, person, WORK, d)) return false;
    return true;
  }

  public static void deletePlace(State s, String id, LocalDate today) {
    if (id.equals(WORK) || id.equals(BRANCH))
      throw new IllegalArgumentException(
          "İlk iki yer silinmez; adını/günlerini düzenleyebilirsiniz.");
    Place p = s.place(id);
    p.deleted = true;
    for (Week w : s.weeks) w.duties.removeIf(d -> d.place.equals(id) && d.date.isAfter(today));
  }

  public static List<Place> displayPlaces(State s, Week w) {
    List<Place> list = new ArrayList<>();
    for (Place p : s.places)
      if ((!p.deleted || w.duties.stream().anyMatch(d -> d.place.equals(p.id)))
          && !s.hiddenPlaces.contains(p.id)) list.add(p);
    return list;
  }

  public static List<Person> weekendOrder(State s) {
    List<Person> result = new ArrayList<>();
    Set<String> seen = new HashSet<>();
    for (String id : s.weekendOrder)
      for (Person p : s.people) if (p.id.equals(id) && seen.add(id)) result.add(p);
    for (Person p : s.people) if (seen.add(p.id)) result.add(p);
    return result;
  }

  public static void setWeekendOrder(State s, List<String> ids) {
    Set<String> active = new HashSet<>();
    for (Person p : s.people) if (p.active) active.add(p.id);
    if (ids.size() != active.size() || !new HashSet<>(ids).equals(active))
      throw new IllegalArgumentException("Her aktif personel sırada bir kez bulunmalı.");
    s.weekendOrder = new ArrayList<>(ids);
    for (Person p : weekendOrder(s)) if (!p.active) s.weekendOrder.add(p.id);
    s.rotationRevision++;
  }

  public static Week generate(State s, LocalDate date) {
    return generate(s, date, null);
  }

  public static Week generate(State s, LocalDate date, String replacement) {
    Week w = new Week(monday(date));
    w.rotationRevision = s.rotationRevision;
    List<Person> active =
        s.people.stream().filter(p -> p.active).collect(java.util.stream.Collectors.toList());
    if (active.isEmpty())
      throw new IllegalArgumentException("Önce en az bir aktif personel ekleyin.");
    Week previous =
        s.weeks.stream()
            .filter(x -> x.monday.isBefore(w.monday))
            .max(Comparator.comparing(x -> x.monday))
            .orElse(null);
    if (previous != null && previous.rotationRevision == s.rotationRevision) {
      w.cursor = previous.cursor;
    }
    w.debts.addAll(pendingDebts(s, w.monday));
    // Reserve the weekend block first; an owed turn never consumes the regular rotation.
    LocalDate sat = w.monday.plusDays(5), sun = sat.plusDays(1);
    List<LocalDate> weekendDates = workWeekendDays(s, w.monday);
    if (!weekendDates.isEmpty()) {
      LocalDate firstWeekend = weekendDates.get(0);
      Person chosen = null;
      List<Debt> due = new ArrayList<>(w.debts);
      due.sort(Comparator.comparing(d -> d.end));
      for (Debt d : due)
        if (d.end.isBefore(firstWeekend)) {
          Person p = active.stream().filter(x -> x.id.equals(d.person)).findFirst().orElse(null);
          if (p != null && weekendAvailable(s, p.id, w.monday)) {
            chosen = p;
            break;
          }
        }
      if (chosen != null && due.stream().filter(d -> d.end.isBefore(firstWeekend)).count() > 1)
        w.warnings.add(
            "Birden fazla bekleyen hafta sonu var. En erken mazereti biten uygun kişi öncelikli;"
                + " diğerleri sırada tutuluyor.");
      if (chosen == null) {
        List<Person> order = weekendOrder(s);
        int last = -1;
        for (int i = 0; i < order.size(); i++) if (order.get(i).id.equals(w.cursor)) last = i;
        for (int n = 1; n <= order.size(); n++) {
          Person p = order.get((last + n) % order.size());
          if (!p.active) continue;
          w.cursor = p.id;
          if (weekendAvailable(s, p.id, w.monday)) {
            chosen = p;
            break;
          }
          LocalDate until =
              s.leaves.stream()
                  .filter(l -> weekendDates.stream().anyMatch(d -> l.blocks(p.id, WORK, d)))
                  .map(l -> l.end)
                  .max(Comparator.naturalOrder())
                  .orElse(sun);
          debt(w, p.id, until);
          w.warnings.add(
              s.name(p.id)
                  + " hafta sonu atlandı; mazeret sonu "
                  + until
                  + ". İlk uygun hafta sonuna öncelikli.");
        }
      }
      if (replacement != null) {
        Person requested =
            active.stream()
                .filter(p -> p.id.equals(replacement))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Aktif personel seçin."));
        if (!weekendAvailable(s, requested.id, w.monday))
          throw new IllegalArgumentException("Seçilen kişinin hafta sonunda mazereti var.");
        if (chosen != null && !chosen.id.equals(requested.id)) {
          // Manual cover does not erase the proposed person's turn; retain it as a pending turn.
          debt(w, chosen.id, sun);
        }
        chosen = requested;
        w.warnings.add("Hafta sonu elle seçildi; yerini devreden personelin sırası korunur.");
      }
      if (chosen != null) {
        for (LocalDate day : weekendDates) w.duties.add(new Duty(day, WORK, chosen.id));
        String id = chosen.id;
        w.debts.removeIf(d -> d.person.equals(id));
      } else w.warnings.add("Hafta sonu uygun personel yok; işyeri iki gün BOŞ.");
    }
    assignPlace(s, w, s.place(BRANCH), active);
    for (int i = 0; i < 5; i++) {
      LocalDate d = w.monday.plusDays(i);
      if (!s.place(WORK).on(d)) continue;
      Person p =
          active.stream()
              .filter(x -> free(s, w, x, WORK, d))
              .min(
                  Comparator.<Person>comparingLong(x -> count(s, w, x.id, WORK, false))
                      .thenComparingLong(x -> count(s, w, x.id, BRANCH, false)))
              .orElse(null);
      if (p != null) w.duties.add(new Duty(d, WORK, p.id));
      else w.warnings.add(d + " işyeri BOŞ: uygun personel yok.");
    }
    for (Place place : s.places)
      if (!place.id.equals(WORK) && !place.id.equals(BRANCH)) assignPlace(s, w, place, active);
    for (Person p : active)
      if (s.place(BRANCH).days != 0
          && w.duties.stream().noneMatch(d -> d.person.equals(p.id) && d.place.equals(BRANCH)))
        w.warnings.add(
            p.name
                + " bu hafta şubeye atanmadı ("
                + s.placeName(BRANCH)
                + ", mazeret/kapasite). Onayınız gerekiyor.");
    w.warnings.addAll(validate(s, w));
    return w;
  }

  static void assignPlace(State s, Week w, Place place, List<Person> people) {
    if (place.deleted || !place.automatic) return;
    List<LocalDate> days = new ArrayList<>();
    for (int i = 0; i < 7; i++) {
      LocalDate d = w.monday.plusDays(i);
      if (place.on(d)) days.add(d);
    }
    days.sort(
        Comparator.comparingLong(
            d -> people.stream().filter(p -> free(s, w, p, place.id, d)).count()));
    if (!placeSearch(s, w, place, days, people, 0, new int[] {0})) {
      w.duties.removeIf(d -> d.place.equals(place.id));
      for (LocalDate date : days) {
        Person p =
            people.stream()
                .filter(x -> free(s, w, x, place.id, date) && belowLimit(w, x.id, place))
                .min(
                    Comparator.comparingLong(
                        x ->
                            count(s, w, x.id, place.id, false) + count(s, w, x.id, place.id, true)))
                .orElse(null);
        if (p != null) w.duties.add(new Duty(date, place.id, p.id));
        else
          w.warnings.add(
              date + " " + place.name + " BOŞ: uygun personel veya haftalık kapasite yok.");
      }
    }
  }

  static boolean belowLimit(Week w, String id, Place p) {
    return p.limit == 0
        || w.duties.stream().filter(d -> d.place.equals(p.id) && d.person.equals(id)).count()
            < p.limit;
  }

  static boolean placeSearch(
      State s,
      Week w,
      Place place,
      List<LocalDate> days,
      List<Person> people,
      int index,
      int[] nodes) {
    if (index == days.size()) return true;
    if (++nodes[0] > 100000) return false;
    LocalDate date = days.get(index);
    List<Person> options = new ArrayList<>(people);
    options.sort(
        Comparator.comparingLong(
            p -> count(s, w, p.id, place.id, false) + count(s, w, p.id, place.id, true)));
    for (Person p : options)
      if (free(s, w, p, place.id, date) && belowLimit(w, p.id, place)) {
        Duty duty = new Duty(date, place.id, p.id);
        w.duties.add(duty);
        if (placeSearch(s, w, place, days, people, index + 1, nodes)) return true;
        w.duties.remove(duty);
      }
    return false;
  }

  public static long expectedSlots(State s) {
    long count = 0;
    for (Place p : s.places) if (!p.deleted) count += Integer.bitCount(p.days);
    return count;
  }

  public static long[] totals(State s, String person, String place, LocalDate today) {
    long[] result = new long[3];
    for (Week w : s.weeks)
      for (Duty d : w.duties)
        if (d.person.equals(person) && d.place.equals(place)) {
          if (d.date.isAfter(today)) result[2]++;
          else result[weekend(d.date) ? 1 : 0]++;
        }
    return result;
  }

  public static final class StatRow {
    public Person person;
    public long[] counts;

    public StatRow(Person person, int size) {
      this.person = person;
      counts = new long[size];
    }
  }

  public static List<Place> statisticPlaces(State s) {
    List<Place> places = new ArrayList<>();
    for (Place p : s.places)
      if (!p.id.equals(WORK)
          && (!p.deleted
              || s.weeks.stream()
                  .anyMatch(w -> w.duties.stream().anyMatch(d -> d.place.equals(p.id)))))
        places.add(p);
    return places;
  }

  public static List<StatRow> statistics(State s, LocalDate today, boolean future) {
    List<Place> places = statisticPlaces(s);
    List<Person> people = new ArrayList<>(s.people);
    java.text.Collator collator = java.text.Collator.getInstance(new Locale("tr", "TR"));
    people.sort(
        (a, b) -> {
          int n = collator.compare(a.name, b.name);
          return n != 0 ? n : a.id.compareTo(b.id);
        });
    List<StatRow> result = new ArrayList<>();
    for (Person person : people) {
      StatRow row = new StatRow(person, places.size() + 2);
      for (Week week : s.weeks)
        for (Duty duty : week.duties)
          if (duty.person.equals(person.id) && duty.date.isAfter(today) == future) {
            if (duty.place.equals(WORK)) row.counts[weekend(duty.date) ? 1 : 0]++;
            else
              for (int i = 0; i < places.size(); i++)
                if (places.get(i).id.equals(duty.place)) row.counts[i + 2]++;
          }
      result.add(row);
    }
    return result;
  }

  public static List<String> validate(State s, Week w) {
    List<String> errors = new ArrayList<>();
    Set<String> slots = new HashSet<>(), persons = new HashSet<>();
    Map<String, Integer> branch = new HashMap<>();
    for (Duty d : w.duties) {
      if (d.date.isBefore(w.monday) || d.date.isAfter(w.monday.plusDays(6)))
        errors.add("Hafta dışı tarih.");
      if (!slots.add(d.date + d.place)) errors.add("Aynı yerde birden fazla kişi.");
      if (!persons.add(d.date + d.person)) errors.add("Aynı kişi aynı gün iki yerde.");
      if (rest(w, d.person, d.date))
        errors.add(s.name(d.person) + " hafta sonu nöbetinden önce perşembe/cuma izinli olmalı.");
      if (!available(s, d.person, d.place, d.date))
        errors.add(s.name(d.person) + " için mazeret veya pasif personel çakışması.");
      Place location = s.places.stream().filter(p -> p.id.equals(d.place)).findFirst().orElse(null);
      if (location == null) {
        errors.add("Bilinmeyen görev yeri.");
        continue;
      }
      boolean recorded =
          s.weeks.stream()
              .filter(old -> old.monday.equals(w.monday))
              .flatMap(old -> old.duties.stream())
              .anyMatch(
                  old ->
                      old.place.equals(d.place)
                          && old.person.equals(d.person)
                          && old.date.equals(d.date));
      if (location.deleted && !recorded)
        errors.add(location.name + " silinmiş; yeni atama yapılamaz.");
      if (!location.on(d.date) && !recorded) errors.add(location.name + " seçilen gün kapalı.");
      if (location.limit > 0) {
        String key = d.place + "|" + d.person;
        int n = branch.merge(key, 1, Integer::sum);
        if (n > location.limit && !w.limitOverrides.contains(key))
          errors.add(location.name + " kişi başı haftalık sınırı aşıldı.");
      }
    }

    String sat =
        w.duties.stream()
            .filter(d -> d.date.equals(w.monday.plusDays(5)) && d.place.equals(WORK))
            .map(d -> d.person)
            .findFirst()
            .orElse("");
    String sun =
        w.duties.stream()
            .filter(d -> d.date.equals(w.monday.plusDays(6)) && d.place.equals(WORK))
            .map(d -> d.person)
            .findFirst()
            .orElse("");
    if ((workWeekendDays(s, w.monday).size() == 2 || (!sat.isEmpty() && !sun.isEmpty()))
        && !sat.equals(sun)) errors.add("Cumartesi ve pazar aynı kişi olmalı.");
    return errors;
  }

  public static void approve(State s, Week w) {
    List<String> invalid = validate(s, w);
    if (!invalid.isEmpty()) throw new IllegalArgumentException(String.join("\n", invalid));
    s.weeks.removeIf(x -> x.monday.equals(w.monday));
    s.weeks.add(w);
    s.weeks.sort(Comparator.comparing(x -> x.monday));
  }

  public static Week copy(Week w) {
    Week c = new Week(w.monday);
    c.cursor = w.cursor;
    c.rotationRevision = w.rotationRevision;
    for (Duty d : w.duties) c.duties.add(new Duty(d.date, d.place, d.person));
    for (Debt d : w.debts) c.debts.add(new Debt(d.person, d.end));
    c.warnings.addAll(w.warnings);
    c.limitOverrides.addAll(w.limitOverrides);
    return c;
  }
}
