'use strict';
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),{spawn}=require('node:child_process');
const PNG=Buffer.from([137,80,78,71,13,10,26,10]);
function imageBuffer(args){if(!args||typeof args.image!=='string'||args.image.length>20000000||!/^data:image\/png;base64,[A-Za-z0-9+/]+=*$/.test(args.image))throw Error('Fotoğraf isteği geçersiz.');const b=Buffer.from(args.image.slice(22),'base64');if(b.length<24||b.length>15000000||!b.subarray(0,8).equals(PNG)||b.subarray(12,16).toString()!=='IHDR')throw Error('Geçerli bir PNG fotoğrafı gerekli.');const w=b.readUInt32BE(16),h=b.readUInt32BE(20);if(w<1||h<1||w>2400||h>2400)throw Error('Fotoğraf boyutu en fazla 2400 piksel olmalı.');return b;}
async function recognize(args,{platform=process.platform,spawnProcess=spawn,tempRoot=os.tmpdir(),timeoutMs=60000}={}){
 const image=imageBuffer(args);if(platform!=='win32')throw Error('Yerel fotoğraf okuma Windows 10/11 masaüstü uygulamasında çalışır.');
 const dir=await fs.mkdtemp(path.join(tempRoot,'pos-local-ocr-'));try{
 const file=path.join(dir,'receipt.png');await fs.writeFile(file,image,{flag:'wx'});const script=await fs.readFile(path.join(__dirname,'native-ocr.ps1'),'utf8');
 const systemRoot=process.env.SystemRoot||'C:\\Windows',exe=path.join(systemRoot,'System32','WindowsPowerShell','v1.0','powershell.exe');
 const output=await new Promise((resolve,reject)=>{let child,stdout='',stderr='',done=false;const finish=(error,value)=>{if(done)return;done=true;clearTimeout(timer);if(error){child?.kill();reject(error);}else resolve(value);};const timer=setTimeout(()=>finish(Error('Fotoğraf okuma zaman aşımına uğradı; daha net bir fotoğraf deneyin.')),timeoutMs);
 try{child=spawnProcess(exe,['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{windowsHide:true,shell:false,env:{...process.env,POS_OCR_IMAGE_PATH:file}});}catch(e){finish(Error('Windows fotoğraf okuyucusu başlatılamadı.'));return;}
 child.stdout.setEncoding?.('utf8');child.stderr.setEncoding?.('utf8');child.stdout.on('data',d=>{stdout+=d.toString('utf8');if(Buffer.byteLength(stdout)>1000000)finish(Error('Okunan fiş çok büyük.'));});child.stderr.on('data',d=>{stderr+=d.toString('utf8');if(stderr.length>20000)finish(Error('Windows OCR çalıştırılamadı.'));});child.on('error',()=>finish(Error('Windows fotoğraf okuyucusu başlatılamadı.')));child.on('close',()=>finish(null,stdout));});
 let result;try{result=JSON.parse(output.replace(/^\uFEFF/,''));}catch{throw Error('Windows OCR yanıtı okunamadı. Windows dil/OCR bileşenini kontrol edin.');}
 if(!result.ok){if(result.code==='language')throw Error('Windows OCR dili bulunamadı. Windows dil seçeneklerinden Türkçe veya İngilizce OCR bileşenini yükleyin.');if(result.code==='size')throw Error('Fotoğraf Windows OCR için fazla büyük.');throw Error('Fotoğraf okunamadı. Daha net fotoğraf deneyin veya fiş penceresindeki tutarları kontrol ederek girin.');}
 if(typeof result.text!=='string'||result.text.length>200000)throw Error('Okunan fiş metni geçersiz.');return {text:result.text,language:String(result.language||'')};
 }finally{await fs.rm(dir,{recursive:true,force:true,maxRetries:10,retryDelay:100});}
}
module.exports={imageBuffer,recognize};
