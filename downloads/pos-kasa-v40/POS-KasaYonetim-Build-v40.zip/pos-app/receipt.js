(function(root){'use strict';
const G=typeof module!=='undefined'?require('./safety'):root.POSGuard;
const FIELDS=[['creditDomestic','Kredi kartı · Yurtiçi satış','KREDİ KARTI'],['creditForeign','Kredi kartı · Yurtdışı satış','KREDİ KARTI'],['creditVakif','Kredi kartı · VakıfBank satış','KREDİ KARTI'],['world','Worldpuan satış','KREDİ KARTI'],['debitForeign','Debit kart · Yurtdışı satış','KREDİ KARTI'],['debitDomestic','Debit kart · Yurtiçi satış','DEBİT KART'],['debitVakif','Debit kart · VakıfBank satış','DEBİT KART']];
const normal=s=>String(s||'').toLocaleUpperCase('tr-TR').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/İ|ı/g,'I').replace(/[^A-Z0-9,.:/\s]/g,' ').replace(/\s+/g,' ').trim();
function amounts(line){return [...String(line).matchAll(/(?<![\d.,])(?:\d{1,3}(?:[. ]\d{3})+|\d+)[,.]\s*\d{2}(?!\d)/g)].map(m=>{const raw=m[0].replace(/\s/g,'');try{return {raw,value:/[-−]\s*$/.test(String(line).slice(0,m.index))?null:G.money(raw,true)};}catch{return {raw,value:null};}});}
function parse(text){
 if(typeof text!=='string'||text.length>200000)throw Error('Okunan fiş metni geçersiz.');
 const values=Object.fromEntries(FIELDS.map(([key])=>[key,'0'])),found=[],issues=[];let section='',kind='',pending=false,totalMode=false,total='',date='',pos='';
 const lines=text.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
 for(let i=0;i<lines.length;i++){
  const fixLabel=s=>normal(s).replace(/TOPLAN/g,'TOPLAM').replace(/(?:ISLEN|ISLER|TSLEN|TSLEM)/g,'ISLEM').replace(/TUTRRI/g,'TUTARI').replace(/YURT[IL1][CG][IL1]/g,'YURTICI').replace(/YURTIC(?=\s|$)/g,'YURTICI');
  const line=fixLabel(lines[i]);const combined=fixLabel(lines.slice(i,i+2).join(' '));
  if(!date){const m=line.match(/(?:TARIH\s*[:.]?\s*)?(\d{2})[/.](\d{2})[/.](\d{4})/);if(m){const d=`${m[3]}-${m[2]}-${m[1]}`;if(G.day(d))date=d;}}
  if(!pos){const m=line.match(/POS\s*(?:NO|NUMARA)\s*[:.]?\s*(\d+)/);if(m)pos=m[1];}
  if(/GENEL\s*TOPLAM/.test(line)||(/^GENEL$/.test(line)&&/^TOPLAM/.test(normal(lines[i+1])))){totalMode=true;pending=false;kind='';}
  else if(/GUNSONU\s*TAMAM|POS\s*DESTEK|PROVIZYON/.test(line)){totalMode=false;pending=false;kind='';}
  else if(/DEBIT\s*KART/.test(line)){section='debit';kind='';pending=false;}
  else if(/KRED[I1L]?\s*KART/.test(line)){section='credit';kind='';pending=false;}
  else if(/WORLD\s*PUAN/.test(line)){kind='world';pending=false;}
  else if(/YURT\s*DISI/.test(line)){kind=section==='debit'?'debitForeign':section==='credit'?'creditForeign':'';pending=false;}
  else if(/YURT\s*ICI/.test(line)){kind=section==='debit'?'debitDomestic':section==='credit'?'creditDomestic':'';pending=false;}
  else if(/VAKIF\s*BANK/.test(line)&&section){kind=section==='debit'?'debitVakif':'creditVakif';pending=false;}
  if(/IADE|IPTAL/.test(line)&&!totalMode){issues.push('İade/iptal satırı bulundu; bu raporu satış olarak otomatik kaydetmeyin.');kind='';pending=false;}
  if(/TOPLAM\s*(?:ISLEM\s*)?TUTAR/.test(combined)&&!totalMode)pending=true;
  const nums=amounts(lines[i]);
  if(totalMode&&nums.length){if(total!==''||nums.length!==1||nums[0].value===null)issues.push('Genel toplam tek ve geçerli bir tutar olarak okunamadı.');else total=nums[0].raw;totalMode=false;}
  else if((pending||kind&&!/ADEDI/.test(line))&&nums.length){if(!kind||nums.length!==1||nums[0].value===null)issues.push('Sınıflandırılamayan veya belirsiz satış tutarı: '+lines[i]);else{if(found.includes(kind))issues.push('Aynı satış başlığı birden fazla kez okundu: '+FIELDS.find(f=>f[0]===kind)[1]);values[kind]=nums[0].raw;found.push(kind);}pending=false;}
 }
 if(total==='')issues.push('Fişteki genel toplam okunamadı; fotoğraftan kontrol edip girin.');
 if(!found.length)issues.push('Satış kalemleri okunamadı; fotoğraftan kontrol edip doldurun.');
 return {values,total,date,pos,found,issues:[...new Set(issues)]};
}
function check(values,total){let credit=0,debit=0;const clean={};for(const [key,,type] of FIELDS){const n=G.money(values?.[key]??'',true),cents=Math.round(n*100);clean[key]=n;if(type==='KREDİ KARTI')credit+=cents;else debit+=cents;}
 const declared=Math.round(G.money(total)*100),sum=credit+debit;return {values:clean,total:declared/100,sum:sum/100,credit:credit/100,debit:debit/100,difference:(sum-declared)/100,matches:sum===declared};}
function due(day,n){if(!G.day(day)||!Number.isInteger(n)||n<0||n>365)throw Error('Vade ayarı geçersiz.');const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);}
function prepare({txs,cfg,kasaId,date,values,total,id,replaceId='',confirmed=false,today}){
 if(!confirmed)throw Error('Fotoğrafı ve satış türlerini kontrol ettiğinizi onaylayın.');
 if(!G.day(date)||!G.day(today)||date>today)throw Error('İşlem tarihi bugün veya geçmiş bir gün olmalı.');
 const kasa=cfg.kasalar.find(k=>k.id===kasaId);if(!kasa||kasa.aktif===false)throw Error('Aktif bir kasa seçin.');
 const c=check(values,total);if(!c.matches)throw Error('Kalem toplamı fiş toplamıyla uyuşmuyor. Kayıt yapılmadı.');
 if(typeof id!=='string'||!id||(!replaceId&&txs.some(t=>t.fisId===id)))throw Error('Fiş kimliği geçersiz veya tekrarlı.');
 if(replaceId&&(replaceId!==id||!txs.some(t=>t.fisId===replaceId&&t.fisDetay)))throw Error('Düzenlenecek fiş kaydı bulunamadı.');
 const base=txs.filter(t=>!replaceId||t.fisId!==replaceId),meta={version:1,values:c.values,total:c.total};
 const rows=[['KREDİ KARTI',c.credit],['DEBİT KART',c.debit]].filter(([,n])=>n>0).map(([tur,tutar],i)=>({id:id+'-'+i,fisId:id,kasaId,bankaId:kasa.bankaId,islemTarihi:date,tur,tutar,yatacakTarih:due(date,cfg.vadeGunleri[tur]),...(i===0?{fisDetay:meta}:{})}));
 if(rows.some(r=>base.some(t=>t.id===r.id)))throw Error('İşlem kimliği tekrarlı.');
 return {txs:[...rows,...base],rows,totals:c};
}
function validate(txs){const groups=new Map();for(const t of txs){if(t.fisDetay&&!t.fisId)throw Error('Fiş bağlantısı eksik.');if(t.fisId){if(typeof t.fisId!=='string'||t.mutabakatId||t.posToplam!=null)throw Error('Fiş bağlantısı geçersiz.');const rows=groups.get(t.fisId)||[];rows.push(t);groups.set(t.fisId,rows);}}
 for(const rows of groups.values()){const anchors=rows.filter(t=>t.fisDetay);if(anchors.length!==1||rows.length>2)throw Error('Fiş ayrıntısı eksik veya tekrarlı.');const a=anchors[0],m=a.fisDetay;if(m.version!==1)throw Error('Fiş sürümü desteklenmiyor.');const c=check(m.values,m.total);if(!c.matches||rows.some(t=>t.kasaId!==a.kasaId||t.bankaId!==a.bankaId||t.islemTarihi!==a.islemTarihi))throw Error('Fiş toplamı veya kayıt bağlantıları tutarsız.');for(const [type,n] of [['KREDİ KARTI',c.credit],['DEBİT KART',c.debit]]){const r=rows.filter(t=>t.tur===type);if(n>0&&(r.length!==1||Math.round(r[0].tutar*100)!==Math.round(n*100))||n===0&&r.length)throw Error('Fiş kredi/debit tutarları ayrıntıyla uyuşmuyor.');}}
}
const api={FIELDS,parse,check,due,prepare,validate};if(typeof module!=='undefined')module.exports=api;else root.POSReceipt=api;
})(globalThis);
