$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
try {
 Add-Type -AssemblyName System.Runtime.WindowsRuntime
 $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
 $null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType=WindowsRuntime]
 $null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
 $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
 $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
 $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
 $null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType=WindowsRuntime]
 $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
 function Wait-Result($operation, [Type]$resultType) {
  $task = $asTask.MakeGenericMethod($resultType).Invoke($null, @($operation))
  return $task.GetAwaiter().GetResult()
 }
 $languages = @([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages)
 if ($languages.Count -eq 0) { throw 'OCR_LANGUAGE_MISSING' }
 $language = $languages | Where-Object { $_.LanguageTag -like 'tr*' } | Select-Object -First 1
 if (-not $language) { $language = $languages | Where-Object { $_.LanguageTag -like 'en*' } | Select-Object -First 1 }
 if (-not $language) { $language = $languages[0] }
 $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language)
 if (-not $engine) { throw 'OCR_LANGUAGE_MISSING' }
 $file = Wait-Result ([Windows.Storage.StorageFile]::GetFileFromPathAsync($env:POS_OCR_IMAGE_PATH)) ([Windows.Storage.StorageFile])
 $stream = Wait-Result ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
 try {
  $decoder = Wait-Result ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $bitmap = Wait-Result ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  try {
   if ($bitmap.PixelWidth -gt [Windows.Media.Ocr.OcrEngine]::MaxImageDimension -or $bitmap.PixelHeight -gt [Windows.Media.Ocr.OcrEngine]::MaxImageDimension) { throw 'OCR_IMAGE_SIZE' }
   $result = Wait-Result ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
   $lines = @($result.Lines | ForEach-Object { $_.Text })
   @{ ok=$true; text=($lines -join "`n"); language=$language.LanguageTag } | ConvertTo-Json -Compress -Depth 4
  } finally { if ($bitmap) { $bitmap.Dispose() } }
 } finally { if ($stream) { $stream.Dispose() } }
} catch {
 $message = $_.Exception.Message
 @{ ok=$false; code= $(if($message -like '*OCR_LANGUAGE_MISSING*'){'language'}elseif($message -like '*OCR_IMAGE_SIZE*'){'size'}else{'failed'}) } | ConvertTo-Json -Compress
 exit 1
}
