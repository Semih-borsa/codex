const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 960,
    minHeight: 640,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: false
    },
    title: 'POS - Kasa Yönetim',
    backgroundColor: '#0f1117',
    show: false
  });

  win.loadFile(path.join(__dirname, 'index.html'));

  win.once('ready-to-show', () => {
    win.show();
  });

  win.setMenuBarVisibility(false);
}

app.whenReady().then(() => {
  // Windows bildirimlerinde uygulama adının doğru görünmesi için
  if (process.platform === 'win32') {
    app.setAppUserModelId('POS - Kasa Yönetim');
  }
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
