@echo off
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

echo ================================================
echo   POS TAKIP - EXE Build Sistemi
echo ================================================
echo.
echo [1/2] Paketler yukleniyor...
call npm install
if errorlevel 1 ( echo HATA: npm install basarisiz! & pause & exit /b 1 )

echo.
echo [2/2] EXE olusturuluyor...
call npm run dist
if errorlevel 1 ( echo HATA: Build basarisiz! & pause & exit /b 1 )

echo.
echo ================================================
echo   TAMAMLANDI!
echo   EXE dosyasi: dist\win-unpacked\POS Takip.exe
echo ================================================
echo.
pause
