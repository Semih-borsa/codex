
const { useState, useEffect, useMemo, useRef, useCallback } = React;

/* ── Seed data ─────────────────────────────────────────────────────────────── */
const SEED_RAW=[["KASA 1","2025-11-04","KREDİ KARTI",37859.57,"2025-11-25"],["KASA 1","2025-11-04","DEBİT KART",23095.69,"2025-11-20"],["KASA 2","2025-11-04","KREDİ KARTI",29914.08,"2025-11-25"],["KASA 2","2025-11-04","DEBİT KART",19043.93,"2025-11-20"],["EMNİYET","2025-11-04","KREDİ KARTI",4139.75,"2025-11-25"],["EMNİYET","2025-11-04","DEBİT KART",4521.85,"2025-11-20"],["EMNİYET","2025-11-05","KREDİ KARTI",7470,"2025-11-26"],["EMNİYET","2025-11-05","DEBİT KART",3795.05,"2025-11-21"],["KASA 2","2025-11-05","KREDİ KARTI",47403.55,"2025-11-26"],["KASA 2","2025-11-05","DEBİT KART",11845.2,"2025-11-21"],["KASA 1","2025-11-05","KREDİ KARTI",56083.65,"2025-11-26"],["KASA 1","2025-11-05","DEBİT KART",15724.95,"2025-11-21"],["EMNİYET","2025-11-06","KREDİ KARTI",7158.75,"2025-11-27"],["EMNİYET","2025-11-06","DEBİT KART",2772.2,"2025-11-22"],["KASA 2","2025-11-06","KREDİ KARTI",37048.42,"2025-11-27"],["KASA 2","2025-11-06","DEBİT KART",13457.86,"2025-11-22"],["KASA 1","2025-11-06","KREDİ KARTI",38191.22,"2025-11-27"],["KASA 1","2025-11-06","DEBİT KART",12535.93,"2025-11-22"],["EMNİYET","2025-11-07","KREDİ KARTI",4012.25,"2025-11-28"],["EMNİYET","2025-11-07","DEBİT KART",3630.95,"2025-11-23"],["KASA 2","2025-11-07","KREDİ KARTI",28274.3,"2025-11-28"],["KASA 2","2025-11-07","DEBİT KART",17861.74,"2025-11-23"],["KASA 1","2025-11-07","KREDİ KARTI",37277.68,"2025-11-28"],["KASA 1","2025-11-07","DEBİT KART",17984.72,"2025-11-23"],["KASA 2","2025-11-08","KREDİ KARTI",61473.34,"2025-11-29"],["KASA 2","2025-11-08","DEBİT KART",26056.12,"2025-11-24"],["KASA 1","2025-11-08","KREDİ KARTI",47715.47,"2025-11-29"],["KASA 1","2025-11-08","DEBİT KART",11738.26,"2025-11-24"],["KASA 1","2025-11-09","KREDİ KARTI",38306.41,"2025-11-30"],["KASA 1","2025-11-09","DEBİT KART",6792.82,"2025-11-25"],["KASA 2","2025-11-09","KREDİ KARTI",37087.69,"2025-11-30"],["KASA 2","2025-11-09","DEBİT KART",20874.75,"2025-11-25"],["EMNİYET","2025-11-10","KREDİ KARTI",6407.4,"2025-12-01"],["EMNİYET","2025-11-10","DEBİT KART",3574.25,"2025-11-26"],["KASA 2","2025-11-10","KREDİ KARTI",35257.82,"2025-12-01"],["KASA 2","2025-11-10","DEBİT KART",10198.51,"2025-11-26"],["KASA 1","2025-11-10","KREDİ KARTI",34056.71,"2025-12-01"],["KASA 1","2025-11-10","DEBİT KART",15898.82,"2025-11-26"],["EMNİYET","2025-11-11","KREDİ KARTI",4120.95,"2025-12-02"],["EMNİYET","2025-11-11","DEBİT KART",3087.7,"2025-11-27"],["KASA 2","2025-11-11","KREDİ KARTI",28067.37,"2025-12-02"],["KASA 2","2025-11-11","DEBİT KART",12144.7,"2025-11-27"],["KASA 1","2025-11-11","KREDİ KARTI",45187.55,"2025-12-02"],["KASA 1","2025-11-11","DEBİT KART",17434.59,"2025-11-27"],["EMNİYET","2025-11-12","KREDİ KARTI",2859.75,"2025-12-03"],["EMNİYET","2025-11-12","DEBİT KART",3957.25,"2025-11-28"],["KASA 2","2025-11-12","KREDİ KARTI",38629.58,"2025-12-03"],["KASA 2","2025-11-12","DEBİT KART",23826.57,"2025-11-28"],["KASA 1","2025-11-12","KREDİ KARTI",29444.3,"2025-12-03"],["KASA 1","2025-11-12","DEBİT KART",2476.92,"2025-11-28"],["EMNİYET","2025-11-13","KREDİ KARTI",5231.25,"2025-12-04"],["EMNİYET","2025-11-13","DEBİT KART",2901.5,"2025-11-29"],["KASA 2","2025-11-13","KREDİ KARTI",30088.04,"2025-12-04"],["KASA 2","2025-11-13","DEBİT KART",10096.82,"2025-11-29"],["KASA 1","2025-11-13","KREDİ KARTI",27895.75,"2025-12-04"],["KASA 1","2025-11-13","DEBİT KART",11853.46,"2025-11-29"],["EMNİYET","2025-11-14","KREDİ KARTI",6634.4,"2025-12-05"],["EMNİYET","2025-11-14","DEBİT KART",3233.25,"2025-11-30"],["KASA 2","2025-11-14","KREDİ KARTI",25933.8,"2025-12-05"],["KASA 2","2025-11-14","DEBİT KART",8632.5,"2025-11-30"],["KASA 1","2025-11-14","KREDİ KARTI",39848.28,"2025-12-05"],["KASA 1","2025-11-14","DEBİT KART",14496.42,"2025-11-30"],["KASA 2","2025-11-15","KREDİ KARTI",55610.36,"2025-12-06"],["KASA 2","2025-11-15","DEBİT KART",30088.86,"2025-12-01"],["KASA 1","2025-11-15","KREDİ KARTI",40982.86,"2025-12-06"],["KASA 1","2025-11-15","DEBİT KART",26059.12,"2025-12-01"],["KASA 2","2025-11-16","KREDİ KARTI",42070.64,"2025-12-07"],["KASA 2","2025-11-16","DEBİT KART",19179,"2025-12-02"],["KASA 1","2025-11-16","KREDİ KARTI",42203.98,"2025-12-07"],["KASA 1","2025-11-16","DEBİT KART",30524.94,"2025-12-02"],["EMNİYET","2025-11-17","KREDİ KARTI",9666.55,"2025-12-08"],["EMNİYET","2025-11-17","DEBİT KART",4229.75,"2025-12-03"],["KASA 3","2025-11-17","KREDİ KARTI",516.6,"2025-12-08"],["KASA 2","2025-11-17","KREDİ KARTI",41782.03,"2025-12-08"],["KASA 2","2025-11-17","DEBİT KART",14661.76,"2025-12-03"],["KASA 1","2025-11-17","KREDİ KARTI",49702.82,"2025-12-08"],["KASA 1","2025-11-17","DEBİT KART",15663.45,"2025-12-03"],["EMNİYET","2025-11-18","KREDİ KARTI",14429.75,"2025-12-09"],["EMNİYET","2025-11-18","DEBİT KART",7630.1,"2025-12-04"],["KASA 2","2025-11-18","KREDİ KARTI",33839.52,"2025-12-09"],["KASA 2","2025-11-18","DEBİT KART",22556.45,"2025-12-04"],["KASA 1","2025-11-18","KREDİ KARTI",36999.72,"2025-12-09"],["KASA 1","2025-11-18","DEBİT KART",12579.76,"2025-12-04"],["EMNİYET","2025-11-19","KREDİ KARTI",7922.55,"2025-12-10"],["EMNİYET","2025-11-19","DEBİT KART",4617,"2025-12-05"],["KASA 2","2025-11-19","KREDİ KARTI",26243.52,"2025-12-10"],["KASA 2","2025-11-19","DEBİT KART",19051.76,"2025-12-05"],["KASA 1","2025-11-19","KREDİ KARTI",48802.54,"2025-12-10"],["KASA 1","2025-11-19","DEBİT KART",17427.25,"2025-12-05"],["EMNİYET","2025-11-20","KREDİ KARTI",7235.25,"2025-12-11"],["EMNİYET","2025-11-20","DEBİT KART",5252.75,"2025-12-06"],["KASA 2","2025-11-20","KREDİ KARTI",49890.83,"2025-12-11"],["KASA 2","2025-11-20","DEBİT KART",11714.06,"2025-12-06"],["KASA 1","2025-11-20","KREDİ KARTI",25331.93,"2025-12-11"],["KASA 1","2025-11-20","DEBİT KART",10113.56,"2025-12-06"],["EMNİYET","2025-11-21","KREDİ KARTI",10230.6,"2025-12-12"],["EMNİYET","2025-11-21","DEBİT KART",6340.05,"2025-12-07"],["KASA 2","2025-11-21","KREDİ KARTI",33940.03,"2025-12-12"],["KASA 2","2025-11-21","DEBİT KART",18634.66,"2025-12-07"],["KASA 1","2025-11-21","KREDİ KARTI",36911.02,"2025-12-12"],["KASA 1","2025-11-21","DEBİT KART",11744.3,"2025-12-07"],["KASA 2","2025-11-22","KREDİ KARTI",54774.98,"2025-12-13"],["KASA 2","2025-11-22","DEBİT KART",18164.84,"2025-12-08"],["KASA 1","2025-11-22","KREDİ KARTI",42154.39,"2025-12-13"],["KASA 1","2025-11-22","DEBİT KART",13043.32,"2025-12-08"],["KASA 2","2025-11-23","KREDİ KARTI",45771.92,"2025-12-14"],["KASA 2","2025-11-23","DEBİT KART",12501.81,"2025-12-09"],["KASA 1","2025-11-23","KREDİ KARTI",31508.87,"2025-12-14"],["KASA 1","2025-11-23","DEBİT KART",9143.47,"2025-12-09"],["EMNİYET","2025-11-24","KREDİ KARTI",7051.85,"2025-12-15"],["EMNİYET","2025-11-24","DEBİT KART",3122.25,"2025-12-10"],["KASA 2","2025-11-24","KREDİ KARTI",33453.6,"2025-12-15"],["KASA 2","2025-11-24","DEBİT KART",10046.72,"2025-12-10"],["KASA 1","2025-11-24","KREDİ KARTI",27290.41,"2025-12-15"],["KASA 1","2025-11-24","DEBİT KART",17354.86,"2025-12-10"],["KASA 3","2025-11-25","DEBİT KART",866.95,"2025-12-11"],["KASA 2","2025-11-25","KREDİ KARTI",37733.47,"2025-12-16"],["KASA 2","2025-11-25","DEBİT KART",14404.67,"2025-12-11"],["KASA 1","2025-11-25","KREDİ KARTI",29914.75,"2025-12-16"],["KASA 1","2025-11-25","DEBİT KART",19679.12,"2025-12-11"],["EMNİYET","2025-11-25","KREDİ KARTI",4176.5,"2025-12-16"],["EMNİYET","2025-11-25","DEBİT KART",3534.45,"2025-12-11"],["EMNİYET","2025-11-26","KREDİ KARTI",8639.9,"2025-12-17"],["EMNİYET","2025-11-26","DEBİT KART",9413,"2025-12-12"],["KASA 3","2025-11-26","KREDİ KARTI",2015.12,"2025-12-17"],["KASA 2","2025-11-26","KREDİ KARTI",39076.5,"2025-12-17"],["KASA 2","2025-11-26","DEBİT KART",16945.95,"2025-12-12"],["KASA 1","2025-11-26","KREDİ KARTI",45675.52,"2025-12-17"],["KASA 1","2025-11-26","DEBİT KART",19701.35,"2025-12-12"],["EMNİYET","2025-11-27","KREDİ KARTI",9471.75,"2025-12-18"],["EMNİYET","2025-11-27","DEBİT KART",6397,"2025-12-13"],["KASA 1","2025-11-27","KREDİ KARTI",29798.77,"2025-12-18"],["KASA 1","2025-11-27","DEBİT KART",13633.65,"2025-12-13"],["KASA 2","2025-11-27","KREDİ KARTI",37974.08,"2025-12-18"],["KASA 2","2025-11-27","DEBİT KART",17257.35,"2025-12-13"]];

/* ── Defaults ─────────────────────────────────────────────────────────────── */
const DEF_CFG={
  vadeGunleri:{"KREDİ KARTI":21,"DEBİT KART":16},
  bankalar:[{id:"b1",ad:"VAKIFBANK"}],
  kasalar:[{id:"k1",ad:"KASA 1",kod:"1065626",bankaId:"b1"},{id:"k2",ad:"KASA 2",kod:"1065624",bankaId:"b1"},{id:"k3",ad:"KASA 3",kod:"1573325",bankaId:"b1"},{id:"k4",ad:"EMNİYET",kod:"PS957956",bankaId:"b1"}],
  kasaYapim:{kasaSayisi:14,kupurler:[{tutar:50,adet:4},{tutar:20,adet:16},{tutar:10,adet:19},{tutar:5,adet:23}]},
  bankaYedek:{aktif:false,adet:null}
};
const DEF_PARA={c200:0,c100:0,c50:0,c20:0,c10:0,c5k:0,c5m:0};
const DEF_KASA_DURUM={fazla:0,eksik:0,tarih:""};

/* ── Kasa Sayımı: geçmiş veriler (yüklenen Excel'den) ── */
const SAYIM_KEYS=["tarih","alacak","kasalarAdet","kasaYedekSabit","yk1","yk05","yk025","yk01","yk005","bp1","bp05","bp025","bp01","bp005","bozukKarisik","avansAdet","b200","b100","b50","b20","b10","b5","b5m","merkezKasa"];
const SAYIM_SEED_RAW=[
["2025-06-15",465,7,1750,300,300,300,300,300,1900,600,2200,4900,3800,109.45,1,0,0,74,347,569,445,0,37735.15],
["2025-07-15",0,3,1750,300,300,300,300,300,4300,1800,3100,4400,3300,104.25,1,263,59,75,367,571,779,12,93334.64],
["2025-08-10",0,3,1750,300,300,300,300,300,5400,1900,3000,1500,1500,90.55,1,246,44,102,458,689,779,5,93235.75],
["2025-08-20",1719,7,1750,300,300,300,300,300,3600,1100,2100,1500,1500,77.4,1,2,0,44,366,513,495,9,39412.38],
["2025-09-18",722.95,6,1750,300,300,300,300,300,2600,900,1700,1600,1500,96.65,1,163,19,72,357,400,296,8,68159.09],
["2025-10-10",0,5,1750,300,300,300,300,300,3300,1000,1600,1900,1700,42.3,1,0,0,61,239,234,343,25,27360.49],
["2025-11-07",0,5,1750,300,300,300,300,300,4200,900,1500,2400,2000,105.95,1,0,0,72,263,194,305,18,28950.44],
["2025-11-12",0,6,1750,300,300,300,300,300,4100,600,1200,2400,2000,126.3,1,146,59,71,299,393,243,31,68248.43],
["2025-12-13",339.9,4,1750,300,300,300,300,300,2600,1700,1600,2500,2000,98.75,1,462,75,44,100,316,281,73,122689.38],
["2026-01-11",0,3,1750,300,300,300,300,300,2500,1700,1300,2500,2000,113,1,521,127,112,202,215,225,39,141100.86],
["2026-02-08",0,3,1750,300,300,300,300,300,3200,1600,1600,2800,2100,116.5,1,760,197,119,347,453,305,77,202620.7],
["2026-03-08",0,3,1750,300,300,300,300,300,2900,1400,1400,2900,2300,103.95,1,761,136,71,136,448,539,22,190542.25],
["2026-05-02",0,4,1750,300,300,300,300,300,5100,2100,2000,1200,1100,32,1,470,96,104,419,508,362,243,140700.33],
["2026-05-20",0,10,1750,300,300,300,300,300,2700,400,700,1200,1100,135.85,1,3,0,30,108,120,280,6,30780.71],
["2026-06-07",0,3,1750,300,300,300,300,300,3100,1500,2100,1300,1300,106.15,1,670,193,114,337,289,526,56,182644.79]
];
const DEF_SAYIM={alacak:0,kasalarAdet:0,kasaBirim:2000,avansAdet:0,avansBirim:2000,kasaYedekSabit:1750,yk1:300,yk05:300,yk025:300,yk01:300,yk005:300,bp1:0,bp05:0,bp025:0,bp01:0,bp005:0,bozukKarisik:0,b200:0,b100:0,b50:0,b20:0,b10:0,b5:0,b5m:0,merkezKasa:0};

/* Sayım hesaplama */
function hesaplaSayim(f){
  const g=k=>parseTR(f[k]);
  const yedekBozuk=g("yk1")*1+g("yk05")*0.5+g("yk025")*0.25+g("yk01")*0.1+g("yk005")*0.05;
  const bozuk=g("bp1")*1+g("bp05")*0.5+g("bp025")*0.25+g("bp01")*0.1+g("bp005")*0.05;
  const banknot=g("b200")*200+g("b100")*100+g("b50")*50+g("b20")*20+g("b10")*10+g("b5")*5+g("b5m")*5;
  const kasalar=g("kasalarAdet")*(g("kasaBirim")||2000);
  const avans=g("avansAdet")*(g("avansBirim")||2000);
  const toplam=g("alacak")+kasalar+g("kasaYedekSabit")+yedekBozuk+bozuk+g("bozukKarisik")+avans+banknot;
  const fazlaEksik=toplam-g("merkezKasa");
  return{toplam,fazlaEksik,yedekBozuk,bozuk,banknot,kasalar,avans};
}

/* ── Utils ───────────────────────────────────────────────────────────────── */
const fmt  = n=>new Intl.NumberFormat("tr-TR",{minimumFractionDigits:2,maximumFractionDigits:2}).format(n);
const fmtN = n=>new Intl.NumberFormat("tr-TR").format(n);
const toS  = d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const addD = (s,n)=>{const d=new Date(s+"T00:00:00");d.setDate(d.getDate()+n);return toS(d);};
const fDSh = s=>{if(!s)return"—";const d=new Date(s+"T00:00:00");return`${String(d.getDate()).padStart(2,"0")}.${String(d.getMonth()+1).padStart(2,"0")}.${d.getFullYear()}`;};
const uid  = ()=>`${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
const BCOLS=["#3b82f6","#ec4899","#f97316","#a855f7","#14b8a6","#f59e0b"];
const BACCS=["#60a5fa","#f472b6","#fb923c","#c084fc","#2dd4bf","#fbbf24"];
const LS   = {get:(k,d)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):d;}catch{return d;}},set:(k,v)=>{try{if(localStorage.getItem("pos:restoreJournal"))throw Error("Yarım geri yükleme var; uygulamayı yeniden açın.");localStorage.setItem(k,JSON.stringify(v));}catch{throw Error("Kayıt yazılamadı. Depolama alanını kontrol edin.");}}};

/* ── Dosya indirme yardımcısı ── */
function downloadBlob(blob,filename){
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");
  a.href=url;a.download=filename;
  document.body.appendChild(a);a.click();
  document.body.removeChild(a);
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}
const bugünTS=()=>{const d=new Date();return`${d.getFullYear()}${String(d.getMonth()+1).padStart(2,"0")}${String(d.getDate()).padStart(2,"0")}_${String(d.getHours()).padStart(2,"0")}${String(d.getMinutes()).padStart(2,"0")}`;};
const simdiZaman=()=>{const d=new Date();return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")} ${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}:${String(d.getSeconds()).padStart(2,"0")}`;};

/* ── Tam JSON yedek ── */
function currentBackup(){
 const data={surum:"ParaTakip-1.0",tarih:new Date().toISOString()};
 for(const k of POSGuard.KEYS){const text=localStorage.getItem("pos:"+k);if(text!==null)data[k]=JSON.parse(text);}
 POSGuard.validatePackage(data,{},DEF_CFG);return data;
}
async function saveBackupDocument(name,text){
 if(!window.posFiles?.save)throw Error("Doğrulanmış dosya kaydı için masaüstü uygulamasını açın.");
 const r=await window.posFiles.save({name,text});if(r.canceled)return false;if(!r.saved)throw Error("Dosya kaydedilemedi.");return true;
}
async function jsonYedekAl(){try{const data=currentBackup();if(await saveBackupDocument(`ParaTakip_Yedek_${bugünTS()}.json`,JSON.stringify(data,null,2)))alert("Yedek dosyası kaydedildi ve doğrulandı.");}catch(e){alert("Yedek alınamadı: "+e.message);}}
function jsonGeriYukle(file,onDone){
 if(file.size>15000000){onDone(false,"Yedek en fazla 15 MB olabilir.");return;}
 const reader=new FileReader();reader.onerror=()=>onDone(false,"Yedek dosyası okunamadı.");
 reader.onload=async e=>{try{
 const before=POSGuard.snapshot(localStorage),current={};let corrupt=false;for(const [k,text] of Object.entries(before))if(text!==null){try{current[k]=JSON.parse(text);}catch{corrupt=true;}}
 const raw=JSON.parse(e.target.result.replace(/^\uFEFF/,"")),next=POSGuard.validatePackage(raw,current,DEF_CFG);
 const complete=!!next.cfg&&Object.hasOwn(next,"txs");if(corrupt&&!complete)throw Error("Bozuk mevcut kaydı kurtarmak için ayar ve işlemleri içeren tam yedek gerekli.");
 const oldCount=(current.txs||[]).length,newCount=next.txs?.length??oldCount;
 if(!confirm(`${complete?"Tam yedek":"Kısmi paket"}: ${Object.keys(next).join(", ")} alanları değişecek. İşlemler: ${oldCount} → ${newCount}. Eksik alanlar korunacak. Devam edilsin mi?`)){onDone(false,"Geri yükleme iptal edildi; kayıtlar değişmedi.");return;}
 const protection=corrupt?{hamKurtarma:true,rawRecords:before}:{surum:"ParaTakip-1.0",tarih:new Date().toISOString(),...current};
 if(!await saveBackupDocument(`GeriYuklemeOncesi_${bugünTS()}.json`,JSON.stringify(protection,null,2))){onDone(false,"Güvenlik yedeği iptal edildi; kayıtlar değişmedi.");return;}
 POSGuard.restore(localStorage,next,before);onDone(true,`${newCount} işlem; geri yükleme doğrulandı.`);
 }catch(err){onDone(false,"Geri yüklenemedi: "+err.message);}};reader.readAsText(file);
}

/* ── Excel export: İşlem Geçmişi ── */
function excelIslemGecmisi(txs,cfg){
  if(!window.XLSX){alert("Excel kütüphanesi yüklenemedi");return;}
  const rows=txs.map(t=>{
    const kasa=cfg.kasalar.find(k=>k.id===t.kasaId);
    const banka=cfg.bankalar.find(b=>b.id===t.bankaId);
    return{
      "Banka":banka?.ad||"",
      "Kasa":kasa?.ad||t.kasaId,
      "Kasa Kodu":kasa?.kod||"",
      "İşlem Tarihi":fDSh(t.islemTarihi),
      "Kart Türü":t.tur,
      "Tutar":t.tutar,
      "Yatacağı Tarih":fDSh(t.yatacakTarih),
    };
  });
  const ws=XLSX.utils.json_to_sheet(rows);
  ws["!cols"]=[{wch:14},{wch:12},{wch:12},{wch:13},{wch:14},{wch:14},{wch:14}];
  const wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,ws,"İşlem Geçmişi");
  XLSX.writeFile(wb,`ParaTakip_IslemGecmisi_${bugünTS()}.xlsx`);
}

/* ── Excel export: Para Giriş/Çıkış Dökümü ── */
function excelParaLog(paraLog){
  if(!window.XLSX){alert("Excel kütüphanesi yüklenemedi");return;}
  if(!paraLog||!paraLog.length){alert("Henüz para giriş/çıkış kaydı yok");return;}
  const rows=paraLog.slice().sort((a,b)=>(a.zaman||a.tarih||"")<(b.zaman||b.tarih||"")?1:-1).map(l=>({
    "Tarih / Saat":(l.zaman?fDSh(l.zaman.slice(0,10))+" "+l.zaman.slice(11):(l.tarih?fDSh(l.tarih):"")),
    "İşlem":l.islem==="giris"?"GİRİŞ":"ÇIKIŞ",
    "200 TL":l.c200||0,
    "100 TL":l.c100||0,
    "50 TL":l.c50||0,
    "20 TL":l.c20||0,
    "10 TL":l.c10||0,
    "5 TL Kağıt":l.c5k||0,
    "5 TL Madeni":l.c5m||0,
    "Toplam Tutar":l.toplam||0,
  }));
  const ws=XLSX.utils.json_to_sheet(rows);
  ws["!cols"]=[{wch:19},{wch:8},{wch:8},{wch:8},{wch:8},{wch:8},{wch:8},{wch:11},{wch:12},{wch:13}];
  const wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,ws,"Para Giriş-Çıkış");
  XLSX.writeFile(wb,`ParaTakip_ParaDokumu_${bugünTS()}.xlsx`);
}

/* ── Excel export: Kasa Fazlası/Eksiği Dökümü ── */
function excelKasaLog(kasaLog){
  if(!window.XLSX){alert("Excel kütüphanesi yüklenemedi");return;}
  if(!kasaLog||!kasaLog.length){alert("Henüz kasa fazlası/eksiği kaydı yok");return;}
  let kümülatif=0;
  // Eskiden yeniye sıralı kümülatif net hesapla (SIFIRLAMA kaydı kümülatifi sıfırlar)
  const sirali=kasaLog.slice().sort((a,b)=>a.tarih<b.tarih?-1:1);
  const rows=sirali.map(l=>{
    if(l.tur==="sifirla"){
      kümülatif=0;
      return{"Tarih":fDSh(l.tarih),"Tür":"— SIFIRLAMA —","Fazla":"","Eksik":"","Kümülatif Net":0};
    }
    const fazla=l.tur==="fazla"?l.tutar:0;
    const eksik=l.tur==="eksik"?l.tutar:0;
    kümülatif+=fazla-eksik;
    return{
      "Tarih":fDSh(l.tarih),
      "Tür":l.tur==="fazla"?"FAZLA":"EKSİK",
      "Fazla":fazla||"",
      "Eksik":eksik||"",
      "Kümülatif Net":kümülatif,
    };
  }).reverse();
  const ws=XLSX.utils.json_to_sheet(rows);
  ws["!cols"]=[{wch:12},{wch:8},{wch:12},{wch:12},{wch:14}];
  const wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,ws,"Kasa Fazla-Eksik");
  XLSX.writeFile(wb,`ParaTakip_KasaDokumu_${bugünTS()}.xlsx`);
}

/* ── Excel export: Kasa Sayımı Dökümü ── */
function excelKasaSayimi(sayimlar){
  if(!window.XLSX){alert("Excel kütüphanesi yüklenemedi");return;}
  if(!sayimlar||!sayimlar.length){alert("Henüz kasa sayımı kaydı yok");return;}
  const sirali=[...sayimlar].sort((a,b)=>a.tarih<b.tarih?-1:1);
  let oncekiFE=null;
  const rows=sirali.map(s=>{
    const c=hesaplaSayim(s);
    const fark=oncekiFE!==null?c.fazlaEksik-oncekiFE:"";
    oncekiFE=c.fazlaEksik;
    return{
      "Tarih":fDSh(s.tarih),"Alacak":s.alacak||0,
      "Kasalar Adet":(s.kasalarAdet||0),"Kasalar ₺":c.kasalar,
      "Avans Adet":(s.avansAdet||0),"Avans ₺":c.avans,
      "Kasa Yedek Sabit":s.kasaYedekSabit||0,"Yedek Bozuk ₺":c.yedekBozuk,
      "Bozuk Para ₺":c.bozuk,"Bozuk Karışık":s.bozukKarisik||0,
      "200 TL":s.b200||0,"100 TL":s.b100||0,"50 TL":s.b50||0,"20 TL":s.b20||0,"10 TL":s.b10||0,"5 TL":s.b5||0,"5 TL Madeni":s.b5m||0,
      "Banknot ₺":c.banknot,"TOPLAM":c.toplam,"Merkez Kasa":s.merkezKasa||0,
      "Fazla/Eksik":c.fazlaEksik,"Önceki Farkı":fark,
    };
  }).reverse();
  const ws=XLSX.utils.json_to_sheet(rows);
  ws["!cols"]=Object.keys(rows[0]||{}).map(()=>({wch:13}));
  const wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,ws,"Kasa Sayımı");
  XLSX.writeFile(wb,`ParaTakip_KasaSayimi_${bugünTS()}.xlsx`);
}

function excelGunlukRapor(txs,cfg){
  if(!window.XLSX){alert("Excel kütüphanesi yüklenemedi");return;}
  // Yatacak tarihe göre grupla
  const byDate={};
  txs.forEach(t=>{
    const d=t.yatacakTarih;
    if(!byDate[d])byDate[d]={};
    const kasa=cfg.kasalar.find(k=>k.id===t.kasaId);
    const ad=kasa?.ad||t.kasaId;
    if(!byDate[d][ad])byDate[d][ad]={kredi:0,debit:0};
    if(t.tur==="DEBİT KART")byDate[d][ad].debit+=t.tutar;
    else byDate[d][ad].kredi+=t.tutar;
  });
  const kasaSirala=(a,b)=>{const s=ad=>{const m=ad.match(/^KASA\s+(\d+)$/i);if(m)return parseInt(m[1]);if(ad.toUpperCase()==="EMNİYET")return 9000;return 9999;};return s(a)-s(b);};
  const rows=[];
  Object.keys(byDate).sort().forEach(d=>{
    const kasalar=Object.keys(byDate[d]).sort(kasaSirala);
    let gunToplam=0;
    kasalar.forEach(ad=>{
      const {kredi,debit}=byDate[d][ad];
      const tplm=kredi+debit;gunToplam+=tplm;
      rows.push({"Yatacağı Tarih":fDSh(d),"Kasa":ad,"Kredi Kartı":kredi,"Debit Kart":debit,"Toplam":tplm});
    });
    rows.push({"Yatacağı Tarih":fDSh(d),"Kasa":"► GÜN TOPLAMI","Kredi Kartı":"","Debit Kart":"","Toplam":gunToplam});
  });
  const ws=XLSX.utils.json_to_sheet(rows);
  ws["!cols"]=[{wch:14},{wch:16},{wch:14},{wch:14},{wch:14}];
  const wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,ws,"Günlük Yatış Raporu");
  XLSX.writeFile(wb,`ParaTakip_GunlukRapor_${bugünTS()}.xlsx`);
}

/* ── Türkçe para girişi: "350.000,25" gösterir, düzenlerken ham değer ── */
function parseTR(s){
  if(s===null||s===undefined)return 0;
  s=String(s).trim();
  if(!s)return 0;
  if(s.includes(",")) return parseFloat(s.replace(/\./g,"").replace(",","."))||0;
  const p=s.split(".");
  if(p.length===2 && p[1].length!==3) return parseFloat(s)||0;   // 12.5 → ondalık
  if(p.length>=2) return parseFloat(s.replace(/\./g,""))||0;      // 350.000 → binlik
  return parseFloat(s)||0;
}
function ParaInput({value,onChange,placeholder,style,onEnter,inputRef}){
  const [odakta,setOdakta]=useState(false);
  const bos = value===""||value===null||value===undefined;
  let invalid=false;try{if(!bos)POSGuard.money(value,true);}catch{invalid=true;}
  const goster = odakta||invalid ? (value??"") : (bos ? "" : fmt(parseTR(value)));
  return(
    <input type="text" inputMode="decimal" ref={inputRef}
      value={goster} placeholder={placeholder||"0,00"}
      onFocus={()=>setOdakta(true)}
      onBlur={()=>setOdakta(false)}
      onChange={e=>onChange(e.target.value)}
      onKeyDown={e=>{if(e.key==="Enter"&&onEnter)onEnter();}}
      style={style}/>
  );
}

/* ── Ödeme hatırlatma bildirimi (Windows toast) ── */
function bildirimGonder(list){
  try{
    if(typeof Notification==="undefined")return;
    const bugun=toS(new Date());
    const goster=()=>{
      list.slice(0,4).forEach((o,i)=>{
        setTimeout(()=>{
          const gecikti=o.sonOdeme<bugun;
          try{
            new Notification(gecikti?"⚠ Ödeme Gecikti":"🔔 Bugün Son Ödeme Günü",{
              body:`${o.ad} — ₺${fmt(o.tutar)}${gecikti?"  (son gün: "+fDSh(o.sonOdeme)+")":""}`,
              silent:false
            });
          }catch(e){}
        },i*700);
      });
    };
    if(Notification.permission==="granted")goster();
    else if(Notification.permission!=="denied")Notification.requestPermission().then(p=>{if(p==="granted")goster();}).catch(()=>{});
  }catch(e){}
}

/* ══════════════════════════════════════════════════════════════════════════ */
function App(){
  const today=toS(new Date());
  const [cfg,setCfg]     =useState(DEF_CFG);
  const [txs,setTxs]     =useState([]);
  const [tab,setTab]     =useState("takip");
  const [loading,setL]   =useState(true);
  const [tDate,setTDate] =useState(today);
  const [rangeBas,setRangeBas]=useState("");
  const [rangeBit,setRangeBit]=useState("");
  const [sorgu,setSorgu]=useState(null);
  const [odemeler,setOdemeler]=useState([]);
  const [plan,setPlan]=useState(null);
  const [hatirlatma,setHatirlatma]=useState(null);
  // para takip state
  const [para,setPara]   =useState(DEF_PARA);
  const [kasaDurum,setKD]=useState(DEF_KASA_DURUM);
  const [paraLog,setParaLog]=useState([]);
  const [kasaLog,setKasaLog]=useState([]);
  const [sayimlar,setSayimlar]=useState([]);

  useEffect(()=>{
    const c=LS.get("pos:cfg",DEF_CFG);
    if(!c.kasaYapim) c.kasaYapim=DEF_CFG.kasaYapim;
    else if(!c.kasaYapim.kupurler){
      // eski format: {s50,s20,s10,s5,kasaSayisi} -> yeni: {kasaSayisi,kupurler:[{tutar,adet}]}
      const eski=c.kasaYapim;
      c.kasaYapim={
        kasaSayisi:eski.kasaSayisi||14,
        kupurler:[
          {tutar:50,adet:eski.s50||0},
          {tutar:20,adet:eski.s20||0},
          {tutar:10,adet:eski.s10||0},
          {tutar:5,adet:eski.s5||0},
        ]
      };
    }
    if(!c.bankaYedek) c.bankaYedek={aktif:false,adet:null};
    setCfg(c);
    const t=LS.get("pos:txs",null);
    if(t){
      setTxs(t);
      const dates=[...new Set(t.map(x=>x.yatacakTarih))].sort();
      setTDate(dates.includes(today)?today:dates[0]||today);
    }else{
      const s=buildSeed(c);setTxs(s);LS.set("pos:txs",s);
      const dates=[...new Set(s.map(x=>x.yatacakTarih))].sort();
      setTDate(dates.includes(today)?today:dates[0]||today);
    }
    setPara(LS.get("pos:para",DEF_PARA));
    setKD(LS.get("pos:kasadurum",{...DEF_KASA_DURUM,tarih:addD(today,-1)}));
    setParaLog(LS.get("pos:paralog",[]));
    setKasaLog(LS.get("pos:kasalog",[]));
    // Kasa sayımları — ilk açılışta Excel geçmişiyle doldur
    const savedSayim=LS.get("pos:sayimlar",null);
    if(savedSayim){setSayimlar(savedSayim);}
    else{
      const seeded=SAYIM_SEED_RAW.map((row,i)=>{
        const o={id:`sseed_${i}`};
        SAYIM_KEYS.forEach((k,j)=>o[k]=row[j]);
        return o;
      });
      setSayimlar(seeded);LS.set("pos:sayimlar",seeded);
    }
    setOdemeler(LS.get("pos:odemeler",[]));
    const d1=new Date();d1.setMonth(d1.getMonth()+1);d1.setDate(1);
    const sp=LS.get("pos:plan",null);
    const varsayilan={bakiyeTarihi:today,odemeGunu:today,maasTarihi:toS(d1),maasTutari:"",bankaBakiye:"",nakitTahmini:"",bugunPosHaric:true,maasGunuPosHaric:true};
    // eski sürümden geçiş
    if(sp&&sp.planTarihi&&!sp.odemeGunu){sp.odemeGunu=sp.planTarihi;sp.bakiyeTarihi=today;sp.bugunPosHaric=true;delete sp.planTarihi;delete sp.planGunuPos;}
    setPlan(sp?{...varsayilan,...sp,bakiyeTarihi:(sp.bakiyeTarihi&&sp.bakiyeTarihi>=today)?sp.bakiyeTarihi:today}:varsayilan);
    setL(false);
  },[]);

  /* Sekme değişince en üste dön */
  useEffect(()=>{ window.scrollTo(0,0); },[tab]);

  /* Ödeme hatırlatması — program açılışında */
  useEffect(()=>{
    if(loading)return;
    const bugun=toS(new Date());
    const due=odemeler.filter(o=>!o.odendi&&o.sonOdeme<=bugun)
      .sort((a,b)=>a.sonOdeme<b.sonOdeme?-1:1);
    if(due.length){setHatirlatma(due);bildirimGonder(due);}
  },[loading]);

  const buildSeed=c=>SEED_RAW.map(([ka,iT,tur,tutar,yT],i)=>{
    const k=c.kasalar.find(x=>x.ad===ka)||c.kasalar[0];
    return{id:`seed_${i}`,kasaId:k.id,bankaId:k.bankaId,islemTarihi:iT,tur,tutar,yatacakTarih:yT};
  });

  const saveTxs=d=>{POSGuard.validatePackage({txs:d},{cfg},DEF_CFG);try{if(localStorage.getItem("pos:restoreJournal"))throw Error("Geri yükleme bekliyor.");localStorage.setItem("pos:txs",JSON.stringify(d));}catch{throw Error("Kayıt kaydedilemedi. Depolama alanını kontrol edin; mevcut kayıtlar korundu.");}setTxs(d);};
  const saveCfg=c=>{try{POSGuard.validatePackage({cfg:c},{txs},DEF_CFG);}catch(e){alert(e.message);return false;}try{if(localStorage.getItem("pos:restoreJournal"))throw Error("Geri yükleme bekliyor.");localStorage.setItem("pos:cfg",JSON.stringify(c));}catch{alert("Ayarlar kaydedilemedi. Depolama alanını kontrol edin.");return false;}setCfg(c);return true;};
  const savePara=d=>{LS.set("pos:para",d);setPara(d);};
  const saveKD=d=>{LS.set("pos:kasadurum",d);setKD(d);};
  const saveParaLog=d=>{LS.set("pos:paralog",d);setParaLog(d);};
  const saveKasaLog=d=>{LS.set("pos:kasalog",d);setKasaLog(d);};
  const saveSayimlar=d=>{LS.set("pos:sayimlar",d);setSayimlar(d);};
  const saveOdemeler=d=>{LS.set("pos:odemeler",d);setOdemeler(d);};
  const savePlan=d=>{LS.set("pos:plan",d);setPlan(d);};

  /* Takip */
  const DA=["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"];
  const MO=["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"];
  const shiftDate=n=>{const d=new Date(tDate+"T00:00:00");d.setDate(d.getDate()+n);setTDate(toS(d));};
  const dateLabel=()=>{if(tDate===today)return"Bugün";const d=new Date(tDate+"T00:00:00");return`${DA[d.getDay()]}, ${d.getDate()} ${MO[d.getMonth()]} ${d.getFullYear()}`;};

  const filtered=useMemo(()=>txs.filter(t=>t.yatacakTarih===tDate),[txs,tDate]);
  const takipData=useMemo(()=>{
    const byB={};
    cfg.bankalar.forEach((b,bi)=>{byB[b.id]={banka:b,color:BCOLS[bi%BCOLS.length],accent:BACCS[bi%BACCS.length],kasalar:{},total:0,kredi:0,debit:0};});
    filtered.forEach(t=>{
      if(!byB[t.bankaId])return;
      const ki=cfg.kasalar.find(k=>k.id===t.kasaId);if(!ki)return;
      const bs=byB[t.bankaId];
      if(!bs.kasalar[t.kasaId])bs.kasalar[t.kasaId]={kasa:ki,debit:0,kredi:0};
      if(t.tur==="DEBİT KART"){bs.kasalar[t.kasaId].debit+=t.tutar;bs.debit+=t.tutar;}
      else{bs.kasalar[t.kasaId].kredi+=t.tutar;bs.kredi+=t.tutar;}
      bs.total+=t.tutar;
    });
    const kasaSirala=(a,b)=>{const s=ad=>{const m=ad.match(/^KASA\s+(\d+)$/i);if(m)return parseInt(m[1]);if(ad.toUpperCase()==="EMNİYET")return 9000;return 9999;};return s(a.kasa.ad)-s(b.kasa.ad);};
    const result=Object.values(byB).filter(b=>b.total>0);
    result.forEach(b=>{b.kasalarSorted=Object.values(b.kasalar).sort(kasaSirala);});
    return result;
  },[filtered,cfg]);

  const gTotal=takipData.reduce((s,b)=>s+b.total,0);
  const gKredi=takipData.reduce((s,b)=>s+b.kredi,0);
  const gDebit=takipData.reduce((s,b)=>s+b.debit,0);

  const haftalik=useMemo(()=>({simdi:takipGunOzeti(txs,cfg,tDate),once:takipGunOzeti(txs,cfg,(POSGuard.day(tDate)?addD(tDate,-7):"")),tarih:(POSGuard.day(tDate)?addD(tDate,-7):"")}),[txs,cfg,tDate]);

  /* Tarih aralığı toplamı — sadece Sorgula'ya basınca hesaplanır */
  const aralikHesap=useMemo(()=>{
    if(!sorgu)return null;
    const bas=sorgu.bas<=sorgu.bit?sorgu.bas:sorgu.bit;
    const bit=sorgu.bas<=sorgu.bit?sorgu.bit:sorgu.bas;
    let toplam=0,kredi=0,debit=0,adet=0;
    const gunler={};
    txs.forEach(t=>{
      if(t.yatacakTarih>=bas&&t.yatacakTarih<=bit){
        toplam+=t.tutar;adet++;
        if(t.tur==="DEBİT KART")debit+=t.tutar;else kredi+=t.tutar;
        gunler[t.yatacakTarih]=(gunler[t.yatacakTarih]||0)+t.tutar;
      }
    });
    return{toplam,kredi,debit,adet,gunSayisi:Object.keys(gunler).length,bas,bit};
  },[txs,sorgu]);

  const sorgula=()=>{ if(rangeBas&&rangeBit) setSorgu({bas:rangeBas,bit:rangeBit}); };

  const I={background:"#0f1117",border:"1px solid #2d3748",borderRadius:8,color:"#e2e8f0",padding:"9px 12px",fontSize:13,fontFamily:"'IBM Plex Mono',monospace",width:"100%"};

  if(loading)return<div style={{height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",color:"#94a3b8",fontSize:13}}><span className="pulse">⟳ Yükleniyor...</span></div>;

  const TABS=[["takip","TAKİP","chart"],["giris","GİRİŞ","edit"],["para","PARA","money"],["plan","NAKİT PLAN","calendar"],["sayim","KASA SAYIMI","money"],["ayarlar","AYARLAR","settings"]];

  return(
    <div style={{minHeight:"100vh",background:"#0f1117"}}>
      {/* Header */}
      <div style={{background:"#0d1020",borderBottom:"1px solid #1e293b",padding:"14px 20px",position:"sticky",top:0,zIndex:200}}>
        <div style={{maxWidth:1140,margin:"0 auto",display:"flex",alignItems:"center",justifyContent:"space-between",gap:16,flexWrap:"wrap"}}>
          <div>
            <div style={{fontSize:11,color:"#94a3b8",letterSpacing:3,textTransform:"uppercase",marginBottom:2}}><img src="icon.png" alt="" style={{width:22,height:22,verticalAlign:"middle",borderRadius:5,marginRight:7}}/> POS - KASA YÖNETİM</div>
            <div style={{fontSize:17,fontWeight:700,color:"#f1f5f9",letterSpacing:-.5}}>POS - Kasa Yönetim</div>
          </div>
          <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
            {TABS.map(([t,l,kind])=>(
              <button key={t} onClick={()=>setTab(t)} style={{background:tab===t?"#1e293b":"transparent",border:`1px solid ${tab===t?"#3b82f6":"#1e293b"}`,borderRadius:8,color:tab===t?"#f1f5f9":"#a2b1c6",cursor:"pointer",padding:"7px 13px",fontSize:11,letterSpacing:.5,fontFamily:"inherit",transition:"all .15s"}}><UiIcon kind={kind}/> {l}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{maxWidth:1140,margin:"0 auto",padding:"20px 16px"}}>

        {/* ═══════════ TAKİP ═══════════ */}
        {tab==="takip"&&<>
          <div style={{background:"#141825",border:"1px solid #1e293b",borderRadius:12,padding:"12px 16px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:10,marginBottom:16}}>
            <button onClick={()=>shiftDate(-1)} style={{...I,width:40,padding:"7px",textAlign:"center",cursor:"pointer",border:"1px solid #2d3748"}}>◀</button>
            <div style={{flex:1,textAlign:"center"}}>
              <div style={{fontSize:16,fontWeight:600,color:"#f1f5f9",marginBottom:2}}>{dateLabel()}</div>
              <div style={{fontSize:11,color:"#a2b1c6"}}>{fDSh(tDate)}</div>
            </div>
            <button onClick={()=>shiftDate(1)} style={{...I,width:40,padding:"7px",textAlign:"center",cursor:"pointer",border:"1px solid #2d3748"}}>▶</button>
            <div style={{display:"flex",flexDirection:"column",gap:5}}>
              <input aria-label="Takip tarihi" type="date" value={tDate} onChange={e=>setTDate(e.target.value)} style={{...I,width:160,padding:"7px 10px",fontSize:12}}/>
              {tDate!==today&&<button onClick={()=>setTDate(today)} style={{background:"#1e3a5f",border:"1px solid #3b82f6",borderRadius:7,color:"#60a5fa",cursor:"pointer",padding:"4px",fontSize:11,fontFamily:"inherit"}}>BUGÜN</button>}
            </div>
          </div>
          <div className="fi" style={{background:"linear-gradient(135deg,#141825,#1a2035)",border:"1px solid #2d3a5c",borderRadius:12,padding:"16px 20px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12,marginBottom:14}}>
            <div>
              <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase",marginBottom:5}}>TOPLAM YATIŞ</div>
              <div style={{fontSize:28,fontWeight:700,color:"#f1f5f9",letterSpacing:-1}}>₺ {fmt(gTotal)}</div><HaftalikDegisim simdi={haftalik.simdi.total} once={haftalik.once.total} etiket="Toplam yatış haftalık değişim" tarih={haftalik.tarih}/>
              <div style={{fontSize:11,color:"#a2b1c6",marginTop:3}}>{takipData.length} banka · {filtered.length} işlem</div>
            </div>
            <div style={{display:"flex",gap:18}}>
              <div style={{textAlign:"right"}}><div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,textTransform:"uppercase",marginBottom:3}}>KREDİ KARTI</div><div style={{fontSize:16,fontWeight:600,color:"#93c5fd"}}>₺ {fmt(gKredi)}</div><HaftalikDegisim simdi={haftalik.simdi.kredi} once={haftalik.once.kredi} etiket="Kredi haftalık değişim" tarih={haftalik.tarih}/></div>
              <div style={{width:1,background:"#1e293b"}}/>
              <div style={{textAlign:"right"}}><div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,textTransform:"uppercase",marginBottom:3}}>DEBİT KART</div><div style={{fontSize:16,fontWeight:600,color:"#86efac"}}>₺ {fmt(gDebit)}</div><HaftalikDegisim simdi={haftalik.simdi.debit} once={haftalik.once.debit} etiket="Debit haftalık değişim" tarih={haftalik.tarih}/></div>
            </div>
          </div>
          {takipData.length===0&&<div style={{textAlign:"center",padding:"50px",color:"#94a3b8",background:"#141825",borderRadius:12,border:"1px dashed #1e293b",fontSize:13}}>Bu tarihte yatış kaydı yok</div>}
          {takipData.map((bD,bi)=>{
            const kList=bD.kasalarSorted||Object.values(bD.kasalar);
            return(
              <div key={bD.banka.id} className="fi" style={{marginBottom:14,animationDelay:`${bi*.06}s`}}>
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 14px",background:`${bD.color}11`,border:`1px solid ${bD.color}33`,borderRadius:"10px 10px 0 0"}}>
                  <div style={{display:"flex",alignItems:"center",gap:8}}><div style={{width:10,height:10,borderRadius:2,background:bD.color,boxShadow:`0 0 6px ${bD.color}`}}/><span style={{fontSize:13,fontWeight:700,color:bD.accent,letterSpacing:1}}>{bD.banka.ad}</span></div>
                  <div><span style={{fontSize:16,fontWeight:700,color:"#f1f5f9"}}>₺ {fmt(bD.total)}</span><span style={{fontSize:11,color:"#a2b1c6",marginLeft:8}}>({gTotal>0?((bD.total/gTotal)*100).toFixed(1):0}%)</span><HaftalikDegisim simdi={haftalik.simdi.bankalar[bD.banka.id]?.total} once={haftalik.once.bankalar[bD.banka.id]?.total} etiket={bD.banka.ad+" toplam haftalık değişim"} tarih={haftalik.tarih}/></div>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(210px,1fr))",gap:8,background:`${bD.color}08`,border:`1px solid ${bD.color}22`,borderTop:"none",borderRadius:"0 0 10px 10px",padding:8}}>
                  {kList.map(({kasa,debit,kredi})=>{
                    const tot=debit+kredi;
                    return(
                      <div key={kasa.id} style={{background:"#141825",border:`1px solid ${bD.color}33`,borderRadius:10,padding:"13px 15px"}}>
                        <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:8}}><div style={{width:7,height:7,borderRadius:1,background:bD.color}}/><span style={{fontSize:12,fontWeight:700,color:bD.accent,letterSpacing:.5}}>{kasa.ad}</span><span style={{fontSize:11,color:"#94a3b8",marginLeft:"auto"}}>{kasa.kod}</span></div>
                        <div style={{fontSize:18,fontWeight:700,color:"#f1f5f9",marginBottom:8}}>₺ {fmt(tot)}<HaftalikDegisim simdi={haftalik.simdi.kasalar[kasa.id]?.total} once={haftalik.once.kasalar[kasa.id]?.total} etiket={kasa.ad+" toplam haftalık değişim"} tarih={haftalik.tarih}/></div>
                        <div style={{height:2,background:"#1e293b",borderRadius:2,marginBottom:8,overflow:"hidden"}}><div style={{height:"100%",borderRadius:2,width:`${bD.total>0?(tot/bD.total)*100:0}%`,background:`linear-gradient(90deg,${bD.color},${bD.accent})`,transition:"width .5s"}}/></div>
                        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:5}}>
                          {kredi>0&&<div style={{background:"#00000022",borderRadius:6,padding:"6px 9px",borderLeft:"2px solid #3b82f6"}}><div style={{fontSize:9,color:"#a2b1c6",letterSpacing:1,marginBottom:2}}>KREDİ</div><div style={{fontSize:11,fontWeight:600,color:"#93c5fd"}}>₺{fmt(kredi)}</div><HaftalikDegisim simdi={haftalik.simdi.kasalar[kasa.id]?.kredi} once={haftalik.once.kasalar[kasa.id]?.kredi} etiket={kasa.ad+" kredi haftalık değişim"} tarih={haftalik.tarih} compact/></div>}
                          {debit>0&&<div style={{background:"#00000022",borderRadius:6,padding:"6px 9px",borderLeft:"2px solid #22c55e"}}><div style={{fontSize:9,color:"#a2b1c6",letterSpacing:1,marginBottom:2}}>DEBİT</div><div style={{fontSize:11,fontWeight:600,color:"#86efac"}}>₺{fmt(debit)}</div><HaftalikDegisim simdi={haftalik.simdi.kasalar[kasa.id]?.debit} once={haftalik.once.kasalar[kasa.id]?.debit} etiket={kasa.ad+" debit haftalık değişim"} tarih={haftalik.tarih} compact/></div>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {/* ── Tarih Aralığı Toplamı ── */}
          <div style={{marginTop:20,background:"#141825",border:"1px solid #8b5cf633",borderRadius:12,overflow:"hidden"}}>
            <div style={{padding:"12px 16px",borderBottom:"1px solid #1e293b",display:"flex",alignItems:"center",gap:8}}>
              <div style={{width:6,height:6,borderRadius:1,background:"#8b5cf6"}}/>
              <span style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase"}}>TARİH ARALIĞI TOPLAMI</span>
            </div>
            <div style={{padding:"16px 18px"}}>
              {/* Tarih seçiciler */}
              <div style={{display:"flex",alignItems:"flex-end",gap:12,flexWrap:"wrap",marginBottom:16}}>
                <div>
                  <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>BAŞLANGIÇ TARİHİ</div>
                  <input type="date" value={rangeBas} onChange={e=>setRangeBas(e.target.value)} style={{...I,width:160,fontSize:13}}/>
                </div>
                <div style={{color:"#94a3b8",fontSize:18,paddingBottom:6}}>→</div>
                <div>
                  <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>BİTİŞ TARİHİ</div>
                  <input type="date" value={rangeBit} onChange={e=>setRangeBit(e.target.value)} style={{...I,width:160,fontSize:13}}/>
                </div>
                <button onClick={sorgula} disabled={!rangeBas||!rangeBit} style={{background:(rangeBas&&rangeBit)?"#5b21b6":"#1e293b",border:`1px solid ${(rangeBas&&rangeBit)?"#8b5cf6":"#2d3748"}`,borderRadius:8,color:(rangeBas&&rangeBit)?"#c4b5fd":"#94a3b8",cursor:(rangeBas&&rangeBit)?"pointer":"not-allowed",padding:"9px 22px",fontSize:12,fontFamily:"inherit",fontWeight:600,letterSpacing:1}}>🔍 SORGULA</button>
                {sorgu&&<button onClick={()=>{setSorgu(null);setRangeBas("");setRangeBit("");}} style={{background:"#0f1117",border:"1px solid #2d3748",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"9px 14px",fontSize:11,fontFamily:"inherit"}}>Temizle</button>}
              </div>

              {/* Sonuç — sadece sorgulandıysa */}
              {!aralikHesap ? (
                <div style={{textAlign:"center",padding:"24px",color:"#94a3b8",fontSize:12,background:"#0f1117",borderRadius:10,border:"1px dashed #2d3748"}}>
                  İki tarih seçip <span style={{color:"#8b5cf6"}}>Sorgula</span>'ya basın
                </div>
              ) : (
                <div style={{background:"linear-gradient(135deg,#1a1530,#221a3d)",border:"1px solid #8b5cf644",borderRadius:10,padding:"16px 20px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:14}}>
                  <div>
                    <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase",marginBottom:5}}>
                      {fDSh(aralikHesap.bas)} — {fDSh(aralikHesap.bit)} ARASI TOPLAM
                    </div>
                    <div style={{fontSize:28,fontWeight:700,color:"#c4b5fd",letterSpacing:-1}}>₺ {fmt(aralikHesap.toplam)}</div>
                    <div style={{fontSize:11,color:"#a2b1c6",marginTop:3}}>{aralikHesap.gunSayisi} gün · {aralikHesap.adet} işlem</div>
                  </div>
                  <div style={{display:"flex",gap:18}}>
                    <div style={{textAlign:"right"}}><div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,textTransform:"uppercase",marginBottom:3}}>KREDİ KARTI</div><div style={{fontSize:16,fontWeight:600,color:"#93c5fd"}}>₺ {fmt(aralikHesap.kredi)}</div></div>
                    <div style={{width:1,background:"#2d2447"}}/>
                    <div style={{textAlign:"right"}}><div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,textTransform:"uppercase",marginBottom:3}}>DEBİT KART</div><div style={{fontSize:16,fontWeight:600,color:"#86efac"}}>₺ {fmt(aralikHesap.debit)}</div></div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ── Aylık Ödeme Takibi ── */}
          <AylikOdemeler odemeler={odemeler} saveOdemeler={saveOdemeler}/>
        </>}

        {/* ═══════════ VERİ GİRİŞİ ═══════════ */}
        {tab==="giris"&&<GirisTab cfg={cfg} txs={txs} saveTxs={saveTxs}/>}

        {/* ═══════════ PARA TAKİP ═══════════ */}
        {tab==="para"&&<ParaTab cfg={cfg} saveCfg={saveCfg} para={para} savePara={savePara} kasaDurum={kasaDurum} saveKD={saveKD} paraLog={paraLog} saveParaLog={saveParaLog} kasaLog={kasaLog} saveKasaLog={saveKasaLog}/>}

        {/* ═══════════ KASA SAYIMI ═══════════ */}
        {tab==="plan"&&plan&&<NakitPlanTab txs={txs} odemeler={odemeler} plan={plan} savePlan={savePlan}/>}

        {tab==="sayim"&&<KasaSayimiTab sayimlar={sayimlar} saveSayimlar={saveSayimlar}/>}

        {/* ═══════════ AYARLAR ═══════════ */}
        {tab==="ayarlar"&&<AyarlarTab cfg={cfg} saveCfg={saveCfg} txs={txs} paraLog={paraLog} kasaLog={kasaLog} sayimlar={sayimlar} onReload={()=>window.location.reload()}/>}

        <div style={{marginTop:24,textAlign:"center",color:"#1e293b",fontSize:11,letterSpacing:1}}>
          POS-Kasa Yönetim · {txs.length} işlem · {sayimlar.length} sayım · {odemeler.length} ödeme · {cfg.bankalar.length} banka · {cfg.kasalar.length} kasa
        </div>
      </div>

      {/* ── Ödeme hatırlatma penceresi ── */}
      {hatirlatma&&(
        <div style={{position:"fixed",inset:0,background:"#000000aa",zIndex:900,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
          <div className="fi" style={{background:"#141825",border:"1px solid #f97316",borderRadius:16,padding:"26px 28px",width:520,maxWidth:"94vw",maxHeight:"85vh",overflowY:"auto",boxShadow:"0 20px 60px #000000cc"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}>
              <span style={{fontSize:26}}>🔔</span>
              <div>
                <div style={{fontSize:16,fontWeight:700,color:"#fb923c"}}>Ödeme Hatırlatması</div>
                <div style={{fontSize:11,color:"#a2b1c6"}}>{hatirlatma.length} ödemenin vadesi geldi veya geçti</div>
              </div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:7,margin:"16px 0"}}>
              {hatirlatma.map(o=>{
                const bugun=toS(new Date());
                const gecikti=o.sonOdeme<bugun;
                const gun=Math.round((new Date(bugun+"T00:00:00")-new Date(o.sonOdeme+"T00:00:00"))/86400000);
                return(
                  <div key={o.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",background:gecikti?"#2d1414":"#2a2410",border:`1px solid ${gecikti?"#ef444455":"#eab30855"}`,borderRadius:9,padding:"12px 15px"}}>
                    <div>
                      <div style={{fontSize:14,fontWeight:600,color:"#f1f5f9"}}>{o.ad}</div>
                      <div style={{fontSize:11,color:gecikti?"#f87171":"#fbbf24",marginTop:2}}>
                        {gecikti?`${gun} gün gecikti · son gün ${fDSh(o.sonOdeme)}`:`BUGÜN son ödeme günü`}
                      </div>
                    </div>
                    <div style={{fontSize:16,fontWeight:700,color:gecikti?"#f87171":"#fbbf24"}}>₺ {fmt(o.tutar)}</div>
                  </div>
                );
              })}
            </div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:10,flexWrap:"wrap"}}>
              <span style={{fontSize:12,color:"#a2b1c6"}}>Toplam: <b style={{color:"#fb923c"}}>₺{fmt(hatirlatma.reduce((s,o)=>s+o.tutar,0))}</b></span>
              <div style={{display:"flex",gap:8}}>
                <button className="btn-hover" onClick={()=>{setTab("takip");setHatirlatma(null);setTimeout(()=>window.scrollTo({top:document.body.scrollHeight,behavior:"smooth"}),300);}} style={{background:"#7c2d12",border:"1px solid #f97316",borderRadius:8,color:"#fb923c",cursor:"pointer",padding:"10px 18px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>Ödemelere Git</button>
                <button onClick={()=>setHatirlatma(null)} style={{background:"#1e293b",border:"1px solid #2d3748",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"10px 20px",fontSize:12,fontFamily:"inherit"}}>Tamam</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   GirisTab
══════════════════════════════════════════════════════════════════════════ */

/* Toplam POS mutabakatı: aynı tx listesine bağlı kredi/debit satırları üretir. */
const POS_KAYDET_STILI={background:"#166534",border:"1px solid #22c55e",borderRadius:9,color:"#4ade80",cursor:"pointer",padding:"10px 26px",fontSize:13,fontFamily:"inherit",fontWeight:600,letterSpacing:1};
function posAmount(value){return POSGuard.money(value);}
function posTutarGoster(value){
 try{return fmt(POSGuard.money(value,true));}catch{return value;}
}
function posMutabakatKaydet({mode,gid,txs,kasa,tarih,toplam,vade,debitler,newId}){
 const saved=txs.find(t=>t.mutabakatId===gid&&t.posToplam!=null);
 if(mode!=="total"&&mode!=="debit")throw Error("Kaydetme türü geçersiz.");
 if(mode==="debit"&&!saved)throw Error("Önce kasa, işlem günü ve toplam POS tutarını girip Toplamı kaydet düğmesine basın.");
 const isTotal=mode==="total",id=saved?.mutabakatId||newId;
 if(!id)throw Error("Kayıt kimliği eksik.");
 if(isTotal&&!String(toplam??"").trim())throw Error("Toplam POS tutarını girin.");
 const existingDebits=saved?txs.filter(t=>t.mutabakatId===gid&&t.tur==="DEBİT KART").map(t=>({id:t.id,tarih:t.yatacakTarih,tutar:String(t.tutar)})):[];
 const list=posMutabakatOlustur({id,kasa:saved?{...kasa,id:saved.kasaId,bankaId:saved.bankaId}:kasa,
 tarih:isTotal?tarih:saved.islemTarihi,toplam:isTotal?toplam:String(saved.posToplam),vade:isTotal?vade:saved.yatacakTarih,debitler:isTotal?existingDebits:debitler});
 return {id,list,txs:[...list,...txs.filter(t=>t.mutabakatId!==id)]};
}
function posMutabakatOlustur({id,kasa,tarih,toplam,vade,debitler}){
  const valid=d=>typeof d==="string"&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&!isNaN(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d;
  const kurus=n=>Math.round(n*100);
  if(!kasa||!valid(tarih)||tarih>toS(new Date())||!valid(vade)||vade<tarih)throw Error("İşlem ve kredi vade tarihlerini kontrol edin.");
  const total=posAmount(toplam);if(!Number.isFinite(total)||total<=0||total>1e10)throw Error("Geçerli bir toplam POS tutarı girin.");
  const rows=debitler.filter(r=>String(r.tutar).trim()).map(r=>{const n=posAmount(r.tutar);if(!valid(r.tarih)||r.tarih<tarih||r.tarih>toS(new Date())||!Number.isFinite(n)||n<=0||n>1e10)throw Error("Debit tarihi işlem tarihinden önce veya bugünden sonra olamaz; tutar pozitif olmalı.");return {...r,tutar:kurus(n)/100};});
  const paid=rows.reduce((n,r)=>n+kurus(r.tutar),0),remaining=kurus(total)-paid;if(remaining<0)throw Error("Yatan debit toplamı POS toplamını aşamaz.");
  const base={kasaId:kasa.id,bankaId:kasa.bankaId,islemTarihi:tarih,mutabakatId:id};
  return [{...base,id:id+"-kredi",tur:"KREDİ KARTI",tutar:remaining/100,yatacakTarih:vade,posToplam:kurus(total)/100},...rows.map(r=>({...base,id:r.id,tur:"DEBİT KART",tutar:r.tutar,yatacakTarih:r.tarih,tahsilEdildi:true}))];
}
function posDebitAdaylari({txs,kasaId,yatisTarihi,vadeGun}){
 if(!POSGuard.day(yatisTarihi)||!Number.isInteger(vadeGun)||vadeGun<0||vadeGun>365)return [];
 return txs.filter(t=>{
  if(t.kasaId!==kasaId||!t.mutabakatId||t.posToplam==null||!POSGuard.day(t.islemTarihi))return false;
  const day=new Date(t.islemTarihi+"T12:00:00Z");day.setUTCDate(day.getUTCDate()+vadeGun);
  return day.toISOString().slice(0,10)===yatisTarihi;
 });
}
function posYeniDebitEkle({txs,kasaId,yatisTarihi,tutar,vadeGun,kayitId,id}){
 if(!kasaId)throw Error("Debit için kasa seçin.");
 if(!POSGuard.day(yatisTarihi)||yatisTarihi>toS(new Date()))throw Error("Geçerli bir yatış tarihi seçin; gelecekte olamaz.");
 const amount=posAmount(tutar),adaylar=posDebitAdaylari({txs,kasaId,yatisTarihi,vadeGun});
 const group=kayitId?txs.find(t=>t.kasaId===kasaId&&t.mutabakatId===kayitId&&t.posToplam!=null):(adaylar.length===1?adaylar[0]:null);
 if(!group)throw Error(adaylar.length>1?"Birden fazla POS kaydı eşleşti. İlgili satış kaydını seçin.":"Debit vadesine göre POS toplamı bulunamadı. İlgili satış kaydını seçin veya önce toplamı kaydedin.");
 if(!POSGuard.day(group.islemTarihi)||group.islemTarihi>yatisTarihi)throw Error("Debit yatış tarihi satış gününden önce olamaz.");
 const kalan=Math.round(group.tutar*100)-Math.round(amount*100);if(kalan<0)throw Error("Yatan debit tutarı kalan POS tutarını aşamaz.");
 if(!id||txs.some(t=>t.id===id))throw Error("Debit kayıt kimliği geçersiz veya tekrarlı.");
 const debit={id,kasaId:group.kasaId,bankaId:group.bankaId,islemTarihi:group.islemTarihi,mutabakatId:group.mutabakatId,tur:"DEBİT KART",tutar:amount,yatacakTarih:yatisTarihi,tahsilEdildi:true};
 return {group:{...group,tutar:kalan/100},debit,txs:[debit,...txs.map(t=>t.id===group.id?{...t,tutar:kalan/100}:t)]};
}
function posYeniToplamEkle({txs,kasa,tarih,toplam,vade,id}){
 if(!id||txs.some(t=>t.mutabakatId===id||t.id===id+"-kredi"))throw Error("Yeni toplam kimliği geçersiz veya tekrarlı.");
 if(!kasa||kasa.aktif===false||!kasa.toplamModu)throw Error("Toplam POS takibi açık, aktif bir kasa seçin.");
 return posMutabakatKaydet({mode:"total",gid:"",txs,kasa,tarih,toplam,vade,debitler:[],newId:id});
}
function posGecmistenSil(txs,id){
 const row=txs.find(t=>t.id===id);if(!row)throw Error("Silinecek işlem bulunamadı.");
 if(!row.mutabakatId)return txs.filter(t=>t.id!==id);
 const group=txs.filter(t=>t.mutabakatId===row.mutabakatId),credit=group.filter(t=>t.posToplam!=null);
 if(credit.length!==1)throw Error("Bağlı POS toplamı doğrulanamadı; kayıtlar değiştirilmedi.");
 if(row.id===credit[0].id)return txs.filter(t=>t.mutabakatId!==row.mutabakatId);
 if(row.tur!=="DEBİT KART")throw Error("Silinecek bağlı işlem türü geçersiz.");
 const restored=(Math.round(credit[0].tutar*100)+Math.round(row.tutar*100))/100;
 return txs.filter(t=>t.id!==id).map(t=>t.id===credit[0].id?{...t,tutar:restored}:t);
}
function posVadeTarihi(tarih,gun){
 if(!POSGuard.day(tarih)||!Number.isInteger(gun)||gun<0||gun>365)return "";
 const d=new Date(tarih+"T12:00:00Z");d.setUTCDate(d.getUTCDate()+gun);return d.toISOString().slice(0,10);
}
function takipGunOzeti(txs,cfg,tarih){
 const empty=()=>({total:{tutar:0,adet:0},kredi:{tutar:0,adet:0},debit:{tutar:0,adet:0}});
 const out={...empty(),bankalar:Object.create(null),kasalar:Object.create(null)};
 const banks=new Set(cfg.bankalar.map(b=>b.id)),kasalar=new Set(cfg.kasalar.map(k=>k.id));
 for(const t of txs){if(t.yatacakTarih!==tarih||!banks.has(t.bankaId)||!kasalar.has(t.kasaId))continue;
  const tur=t.tur==="DEBİT KART"?"debit":"kredi";
  for(const target of [out,out.bankalar[t.bankaId]||(out.bankalar[t.bankaId]=empty()),out.kasalar[t.kasaId]||(out.kasalar[t.kasaId]=empty())])for(const key of ["total",tur]){target[key].tutar+=Math.round(t.tutar*100);target[key].adet++;}
 }
 for(const target of [out,...Object.values(out.bankalar),...Object.values(out.kasalar)])for(const key of ["total","kredi","debit"])target[key].tutar/=100;
 return out;
}
function haftalikFark(simdi,once){
 if(!once?.adet)return {durum:"eksik",oran:null,aciklama:"Önceki haftanın aynı gününde bu türde kayıt yok."};
 if(!simdi?.adet)return {durum:"eksik",oran:null,aciklama:"Seçili günde bu türde kayıt yok."};
 if(once.tutar===0)return {durum:"sifir",oran:null,aciklama:"Önceki tutar 0 TL; yüzdesel değişim hesaplanamaz."};
 const oran=(Math.round(simdi.tutar*100)-Math.round(once.tutar*100))/Math.round(once.tutar*100)*100;
 return {durum:oran>0?"artis":oran<0?"azalis":"ayni",oran,aciklama:"Önceki haftanın aynı günüyle karşılaştırma."};
}
function PosMutabakat({cfg,txs,saveTxs,initialId,onClose}){
 const [date,setDate]=useState(""),[total,setTotal]=useState(""),[due,setDue]=useState(""),[debits,setDebits]=useState([]),[error,setError]=useState(""),[msg,setMsg]=useState("");
 const group=txs.find(t=>t.mutabakatId===initialId&&t.posToplam!=null);
 useEffect(()=>{const t=txs.find(x=>x.mutabakatId===initialId&&x.posToplam!=null);if(!t)return;setDate(t.islemTarihi);setTotal(posTutarGoster(t.posToplam));setDue(t.yatacakTarih);setDebits(txs.filter(x=>x.mutabakatId===initialId&&x.tur==="DEBİT KART").map(x=>({id:x.id,tarih:x.yatacakTarih,tutar:posTutarGoster(x.tutar)})));},[initialId]);
 const I={background:"#0f1117",border:"1px solid #334155",borderRadius:8,color:"#e2e8f0",padding:"8px 10px",fontSize:12,width:"100%",fontFamily:"inherit"};
 const close=()=>{
  const same=(a,b)=>{try{return POSGuard.money(a,true)===POSGuard.money(b,true);}catch{return a===b;}};
  const saved=txs.filter(t=>t.mutabakatId===initialId&&t.tur==="DEBİT KART");
  const dirty=group&&(date!==group.islemTarihi||due!==group.yatacakTarih||!same(total,group.posToplam)||debits.length!==saved.length||debits.some(r=>!saved.some(t=>t.id===r.id&&t.yatacakTarih===r.tarih&&same(r.tutar,t.tutar))));
  if(!dirty||confirm("Kaydedilmemiş değişiklikler var. Kaydetmeden kapatılsın mı?"))onClose();
 };
 const save=mode=>{try{if(!group)throw Error("POS kaydı bulunamadı.");const result=posMutabakatKaydet({mode,gid:initialId,txs,kasa:cfg.kasalar.find(k=>k.id===group.kasaId),tarih:date,toplam:total,vade:due,debitler:debits});saveTxs(result.txs);setError("");setMsg("Değişiklikler kaydedildi.");}catch(e){setMsg("");setError(e.message);}};
 return <div style={{position:"fixed",inset:0,background:"#00000099",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}}><div style={{background:"#141825",border:"1px solid #36577c",borderRadius:14,padding:22,width:650,maxWidth:"94vw",maxHeight:"90vh",overflowY:"auto"}}>
 <h3 style={{fontSize:14,marginBottom:12}}>POS kaydını düzenle — {cfg.kasalar.find(k=>k.id===group?.kasaId)?.ad}</h3>
 <div style={{display:"grid",gridTemplateColumns:"repeat(3,minmax(0,1fr))",gap:10,fontSize:12}}>
 <label>POS günü<input aria-label="Düzenlenen POS günü" type="date" style={I} value={date} onChange={e=>{setDate(e.target.value);setDue(posVadeTarihi(e.target.value,cfg.vadeGunleri["KREDİ KARTI"]??21));setMsg("");setError("");}}/></label>
 <label>Toplam POS<input aria-label="Düzenlenen POS toplamı" inputMode="decimal" style={I} value={total} onChange={e=>setTotal(e.target.value)} onBlur={()=>setTotal(v=>posTutarGoster(v))}/></label>
 <label>Kredi vadesi<input aria-label="Düzenlenen kredi vadesi" type="date" style={I} value={due} onChange={e=>setDue(e.target.value)}/></label></div>
 <button className="btn-hover" style={{...POS_KAYDET_STILI,marginTop:12}} onClick={()=>save("total")}><UiIcon kind="save"/> Toplam değişikliğini kaydet</button>
 <h4 style={{fontSize:12,margin:"18px 0 8px"}}>Kayıtlı debitler</h4>
 {debits.map((r,i)=><div key={r.id} style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}><label style={{fontSize:11}}>Yatış tarihi<input aria-label={"Düzenlenen debit tarihi "+(i+1)} type="date" style={I} value={r.tarih} onChange={e=>setDebits(v=>v.map(x=>x.id===r.id?{...x,tarih:e.target.value}:x))}/></label><label style={{fontSize:11}}>Debit tutarı<input aria-label={"Düzenlenen debit tutarı "+(i+1)} style={I} value={r.tutar} onChange={e=>setDebits(v=>v.map(x=>x.id===r.id?{...x,tutar:e.target.value}:x))}/></label></div>)}
 {debits.length>0&&<button className="btn-hover" style={POS_KAYDET_STILI} onClick={()=>save("debit")}><UiIcon kind="save"/> Debit değişikliklerini kaydet</button>}
 {error&&<p role="alert" style={{color:"#f87171",marginTop:12}}>{error}</p>}{msg&&<p role="status" style={{color:"#86efac",marginTop:12}}>{msg}</p>}
 <button style={{...I,width:"auto",marginTop:16,cursor:"pointer"}} onClick={close}>Kapat</button>
 </div></div>;
}

function HaftalikDegisim({simdi,once,etiket,tarih,compact=false}){
 const fark=haftalikFark(simdi,once),color=fark.durum==="artis"?"#4ade80":fark.durum==="azalis"?"#f87171":"#94a3b8";
 return <div aria-label={etiket} data-weekly-state={fark.durum} title={`${fDSh(tarih)}: ${once?.adet?"₺ "+fmt(once.tutar):"Kayıt yok"}. ${fark.aciklama}`} style={{fontSize:11,fontWeight:500,color,marginTop:4,lineHeight:1.4,whiteSpace:compact?"nowrap":undefined}}>{fark.oran==null?"–":`${fark.oran>0?"↑ ":fark.oran<0?"↓ ":""}%${Math.abs(fark.oran).toLocaleString("tr-TR",{maximumFractionDigits:1})}`}{!compact&&<span style={{fontSize:11,marginLeft:5,color:"#94a3b8"}}>önceki hafta</span>}</div>;
}

function PosYeniDebit({cfg,txs,saveTxs}){
 const [kasaId,setKasaId]=useState(""),[yatis,setYatis]=useState(toS(new Date())),[tutar,setTutar]=useState(""),[secim,setSecim]=useState(""),[error,setError]=useState(""),[msg,setMsg]=useState("");
 const busy=useRef(false),vade=cfg.vadeGunleri["DEBİT KART"]??16;
 const records=txs.filter(t=>t.kasaId===kasaId&&t.mutabakatId&&t.posToplam!=null&&t.islemTarihi<=yatis);
 const adaylar=posDebitAdaylari({txs,kasaId,yatisTarihi:yatis,vadeGun:vade});
 const selected=secim?records.find(t=>t.mutabakatId===secim):adaylar.length===1?adaylar[0]:null;
 const kasalar=cfg.kasalar.filter(k=>k.aktif!==false&&k.toplamModu||txs.some(t=>t.kasaId===k.id&&t.mutabakatId&&t.posToplam!=null));
 const I={background:"#0f1117",border:"1px solid #334155",borderRadius:8,color:"#e2e8f0",padding:"7px 9px",fontSize:12,width:"100%",fontFamily:"inherit"};
 const changed=()=>{setSecim("");setError("");setMsg("");};
 const save=()=>{if(busy.current)return;busy.current=true;try{
  const result=posYeniDebitEkle({txs,kasaId,yatisTarihi:yatis,tutar,vadeGun:vade,kayitId:secim,id:uid()});
  saveTxs(result.txs);setTutar("");setYatis(toS(new Date()));setSecim("");setError("");setMsg(`${fDSh(result.group.islemTarihi)} POS kaydına debit eklendi. Kalan kredi: ₺ ${fmt(result.group.tutar)} · Kredi vadesi: ${fDSh(result.group.yatacakTarih)}`);
 }catch(e){setMsg("");setError(e.message);}finally{busy.current=false;}};
 return <div aria-label="Yeni yatan debit girişi" style={{marginBottom:14,paddingBottom:14,borderBottom:"1px solid #334155"}}>
 <div style={{display:"grid",gridTemplateColumns:"repeat(3,minmax(0,1fr))",gap:10,fontSize:11}}>
 <label>Kasa<select aria-label="Yatış kasası" style={I} value={kasaId} onChange={e=>{setKasaId(e.target.value);changed();}}><option value="">Kasa seçin</option>{kasalar.map(k=><option key={k.id} value={k.id}>{k.ad} / {k.kod}{k.aktif===false?" (Pasif)":""}</option>)}</select></label>
 <label>Bankaya yatış tarihi<input aria-label="Yeni debit yatış tarihi" type="date" max={toS(new Date())} style={I} value={yatis} onChange={e=>{setYatis(e.target.value);changed();}}/></label>
 <label>Yatan debit (TL)<input aria-label="Yeni debit tutarı" inputMode="decimal" style={I} value={tutar} onChange={e=>{setTutar(e.target.value);setMsg("");setError("");}} onBlur={()=>setTutar(v=>posTutarGoster(v))}/></label>
 </div>
 <p style={{fontSize:11,color:"#94a3b8",margin:"9px 0"}}>Debit vadesi: {vade} gün. {selected?`Eşleşen POS günü: ${fDSh(selected.islemTarihi)} · Kalan kredi: ₺ ${fmt(selected.tutar)} · Vade: ${fDSh(selected.yatacakTarih)}`:kasaId?adaylar.length>1?"Birden fazla kayıt eşleşti; satış kaydını seçin.":"Bu yatış tarihi için POS toplamı bulunamadı. Satış kaydını seçin veya toplamı kaydedin.":"Kasa ve yatış gününü seçin; POS kaydı vade ayarından bulunur."}</p>
 {kasaId&&<label style={{fontSize:11}}>Satış kaydı (gerekirse düzeltin)<select aria-label="Yeni debit satış kaydı" style={I} value={secim} onChange={e=>{setSecim(e.target.value);setError("");setMsg("");}}><option value="">Vade ayarına göre otomatik bul</option>{records.map(t=><option key={t.id} value={t.mutabakatId}>{t.islemTarihi} — Toplam ₺ {fmt(t.posToplam)} — Kalan ₺ {fmt(t.tutar)}</option>)}</select></label>}
 {error&&<p role="alert" style={{color:"#f87171",fontSize:12}}>{error}</p>}{msg&&<p role="status" style={{color:"#86efac",fontSize:12}}>{msg}</p>}
 <button className="btn-hover" style={{...POS_KAYDET_STILI,marginTop:10}} onClick={save}><UiIcon kind="save"/> Yatan debiti kaydet</button>
 </div>;
}

function PosToplamGiris({cfg,txs,saveTxs}){
 const [kid,setKid]=useState(""),[date,setDate]=useState(addD(toS(new Date()),-1)),[total,setTotal]=useState(""),[due,setDue]=useState(""),[error,setError]=useState(""),[msg,setMsg]=useState("");
 const lock=useRef(false),I={background:"#0f1117",border:"1px solid #334155",borderRadius:8,color:"#e2e8f0",padding:"8px 10px",fontSize:12,width:"100%",fontFamily:"inherit"};
 const save=()=>{if(lock.current)return;lock.current=true;try{
  const result=posYeniToplamEkle({txs,kasa:cfg.kasalar.find(k=>k.id===kid),tarih:date,toplam:total,vade:due||(date?addD(date,cfg.vadeGunleri["KREDİ KARTI"]??21):""),id:uid()});
  if(txs.some(t=>t.kasaId===kid&&t.mutabakatId&&t.posToplam!=null&&t.islemTarihi===date)&&!confirm("Bu kasa ve gün için POS toplamı zaten var. Önceki kaydı değiştirmeden ayrı bir toplam kaydı daha eklensin mi?"))return;
  saveTxs(result.txs);setTotal("");setDate(addD(toS(new Date()),-1));setDue("");setError("");setMsg(`${fDSh(result.list[0].islemTarihi)} için ₺ ${fmt(result.list[0].posToplam)} yeni POS toplamı kaydedildi. Önceki kayıtlar korundu.`);
 }catch(e){setMsg("");setError(e.message);}finally{lock.current=false;}};
 return <section style={{background:"#141825",border:"1px solid #36577c",borderRadius:12,padding:"14px 16px",marginBottom:18}}>
 <h3 style={{fontSize:12,marginBottom:10}}>TOPLAM POS / YATAN DEBİT TAKİBİ</h3>
 <div style={{display:"grid",gridTemplateColumns:"repeat(4,minmax(0,1fr))",gap:10,fontSize:11}}>
 <label>Kasa<select aria-label="Toplam POS kasası" style={I} value={kid} onChange={e=>{setKid(e.target.value);setMsg("");setError("");}}><option value="">Kasa seçin</option>{cfg.kasalar.filter(k=>k.aktif!==false&&k.toplamModu).map(k=><option key={k.id} value={k.id}>{k.ad} / {k.kod}</option>)}</select></label>
 <label>POS günü<input aria-label="POS işlem günü" type="date" style={I} value={date} onChange={e=>{setDate(e.target.value);setDue("");setMsg("");}}/></label>
 <label>Toplam POS (TL)<input aria-label="Toplam POS tutarı" inputMode="decimal" style={I} value={total} onChange={e=>{setTotal(e.target.value);setMsg("");setError("");}} onBlur={()=>setTotal(v=>posTutarGoster(v))}/></label>
 <label>Kredi vadesi<input aria-label="Kredi vadesi" type="date" style={I} value={due||(date?addD(date,cfg.vadeGunleri["KREDİ KARTI"]??21):"")} onChange={e=>setDue(e.target.value)}/></label></div>
 <button className="btn-hover" style={{...POS_KAYDET_STILI,marginTop:12}} onClick={save}><UiIcon kind="save"/> Toplamı kaydet</button>
 {error&&<p role="alert" style={{color:"#f87171",fontSize:12}}>{error}</p>}{msg&&<p role="status" style={{color:"#86efac",fontSize:12}}>{msg}</p>}
 <p style={{fontSize:11,color:"#94a3b8",margin:"10px 0 16px"}}>Bu alan her zaman yeni toplam ekler. Kayıt düzenleme ve silme işlemleri İşlem Geçmişi'ndedir.</p>
 <h4 style={{fontSize:12,marginBottom:10}}>Bankaya yatan debitler</h4><PosYeniDebit cfg={cfg} txs={txs} saveTxs={saveTxs}/>
 </section>;
}

function GirisTab({cfg,txs,saveTxs}){
  const today=toS(new Date());
  const yesterday=addD(today,-1);
  const [fBanka,setFBanka]=useState(cfg.bankalar[0]?.id||"");
  const [fKasa,setFKasa]=useState(cfg.kasalar[0]?.id||"");
  const [fDate,setFDate]=useState(yesterday);
  const blank=()=>["","",""];
  const [krediRows,setKrediRows]=useState(blank());
  const [debitRows,setDebitRows]=useState(blank());
  const [editTx,setEditTx]=useState(null);
  const [histQuery,setHistQuery]=useState(""),[histStart,setHistStart]=useState(""),[histEnd,setHistEnd]=useState(""),[histPage,setHistPage]=useState(1);
  const historyRows=useMemo(()=>txs.filter(t=>{const k=cfg.kasalar.find(k=>k.id===t.kasaId),b=cfg.bankalar.find(b=>b.id===t.bankaId);return (!histStart||t.islemTarihi>=histStart)&&(!histEnd||t.islemTarihi<=histEnd)&&(!histQuery||`${k?.ad} ${k?.kod} ${b?.ad} ${t.tur} ${t.tutar}`.toLocaleLowerCase('tr-TR').includes(histQuery.toLocaleLowerCase('tr-TR')));}),[txs,cfg,histQuery,histStart,histEnd]);
  const pages=Math.max(1,Math.ceil(historyRows.length/50)),page=Math.min(histPage,pages);

  const [delConfirm,setDelConfirm]=useState(null);
  const [editGroup,setEditGroup]=useState(null),[deleteError,setDeleteError]=useState("");
  const [saved,setSaved]=useState(false);

  useEffect(()=>{
    const bankaIds=cfg.bankalar.map(b=>b.id);
    const gb=bankaIds.includes(fBanka)?fBanka:(cfg.bankalar[0]?.id||"");
    setFBanka(gb);
    const ki=cfg.kasalar.filter(k=>k.aktif!==false&&k.bankaId===gb).map(k=>k.id);
    if(!ki.includes(fKasa))setFKasa(ki[0]||"");
  },[cfg.bankalar,cfg.kasalar]);

  const kasalarForBanka=cfg.kasalar.filter(k=>k.aktif!==false&&k.bankaId===fBanka);
  const vadeK=cfg.vadeGunleri["KREDİ KARTI"]??21;
  const vadeD=cfg.vadeGunleri["DEBİT KART"]??16;
  const yatK=fDate?addD(fDate,vadeK):"";
  const yatD=fDate?addD(fDate,vadeD):"";
  const I={background:"#0f1117",border:"1px solid #2d3748",borderRadius:8,color:"#e2e8f0",padding:"8px 11px",fontSize:13,fontFamily:"'IBM Plex Mono',monospace",width:"100%"};

  const handleKasaForBanka=bid=>{setFBanka(bid);const ks=cfg.kasalar.filter(k=>k.aktif!==false&&k.bankaId===bid);setFKasa(ks[0]?.id||"");};

  const handleSave=()=>{
    const selected=cfg.kasalar.find(k=>k.id===fKasa);if(!selected||selected.aktif===false){alert("Aktif bir kasa seçin.");return;}if(selected.toplamModu){alert("Bu kasa için Yeni işlem girişinin altındaki Toplam POS / Debit takibini kullanın.");return;}
    if(!POSGuard.day(fDate)||fDate>today){alert("İşlem tarihi bugün veya geçmiş bir gün olmalı.");return;}
    const newTxs=[];
    try{
    krediRows.forEach(v=>{if(!String(v).trim())return;const n=POSGuard.money(v);newTxs.push({id:uid(),kasaId:fKasa,bankaId:fBanka,islemTarihi:fDate,tur:"KREDİ KARTI",tutar:n,yatacakTarih:yatK});});
    debitRows.forEach(v=>{if(!String(v).trim())return;const n=POSGuard.money(v);newTxs.push({id:uid(),kasaId:fKasa,bankaId:fBanka,islemTarihi:fDate,tur:"DEBİT KART",tutar:n,yatacakTarih:yatD});});
    }catch(e){alert(e.message);return;}
    if(!newTxs.length)return;
    saveTxs([...newTxs,...txs]);
    setKrediRows(blank());setDebitRows(blank());
    setSaved(true);setTimeout(()=>setSaved(false),2000);
  };
  const delTx=id=>{try{const next=posGecmistenSil(txs,id);saveTxs(next);setDelConfirm(null);setDeleteError("");}catch(e){setDeleteError(e.message);}};
  const updateTx=upd=>{if(upd.mutabakatId){alert("Bağlı kayıtlar Yeni işlem girişinin altındaki Toplam POS bölümünden düzenlenir.");return;}saveTxs(txs.map(t=>t.id===upd.id?upd:t));};

  return(<>
    <div style={{background:"#141825",border:"1px solid #1e293b",borderRadius:12,padding:"18px 20px",marginBottom:18}}>
      <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase",marginBottom:14}}>YENİ İŞLEM GİRİŞİ</div>
      <div style={{display:"flex",gap:10,flexWrap:"wrap",marginBottom:16,alignItems:"flex-end"}}>
        <div style={{flex:"1 1 160px"}}><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>BANKA</div><select value={fBanka} onChange={e=>handleKasaForBanka(e.target.value)} style={{...I}}>{cfg.bankalar.map(b=><option key={b.id} value={b.id}>{b.ad}</option>)}</select></div>
        <div style={{flex:"1 1 160px"}}><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>KASA</div><select value={fKasa} onChange={e=>setFKasa(e.target.value)} style={{...I}}>{kasalarForBanka.map(k=><option key={k.id} value={k.id}>{k.ad} ({k.kod})</option>)}</select></div>
        <div style={{flex:"1 1 160px"}}><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>İŞLEM TARİHİ</div><input type="date" value={fDate} onChange={e=>setFDate(e.target.value)} style={{...I}}/></div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:16}}>
        <div style={{background:"#0f1117",border:"1px solid #3b82f633",borderRadius:10,padding:"14px 16px"}}>
          <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:10}}><div style={{width:8,height:8,borderRadius:1,background:"#3b82f6"}}/><span style={{fontSize:12,fontWeight:700,color:"#60a5fa",letterSpacing:.5}}>💳 KREDİ KARTI</span></div>
          {krediRows.map((v,i)=>(
            <div key={i} style={{marginBottom:8}}><div style={{fontSize:11,color:"#94a3b8",marginBottom:4,letterSpacing:1}}>TUTAR {i+1} (₺)</div><ParaInput value={v} onChange={val=>{const r=[...krediRows];r[i]=val;setKrediRows(r);}} onEnter={handleSave} style={{...I,textAlign:"right"}}/></div>
          ))}
        </div>
        <div style={{background:"#0f1117",border:"1px solid #22c55e33",borderRadius:10,padding:"14px 16px"}}>
          <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:10}}><div style={{width:8,height:8,borderRadius:1,background:"#22c55e"}}/><span style={{fontSize:12,fontWeight:700,color:"#4ade80",letterSpacing:.5}}>🏧 DEBİT KART</span></div>
          {debitRows.map((v,i)=>(
            <div key={i} style={{marginBottom:8}}><div style={{fontSize:11,color:"#94a3b8",marginBottom:4,letterSpacing:1}}>TUTAR {i+1} (₺)</div><ParaInput value={v} onChange={val=>{const r=[...debitRows];r[i]=val;setDebitRows(r);}} onEnter={handleSave} style={{...I,textAlign:"right"}}/></div>
          ))}
        </div>
      </div>
      <div style={{display:"flex",alignItems:"center",gap:12}}>
        <button className="btn-hover" onClick={handleSave} style={POS_KAYDET_STILI}><UiIcon kind="save"/> KAYDET</button>
        {saved&&<span className="fi" style={{fontSize:12,color:"#4ade80"}}>✓ Kaydedildi</span>}
        <span style={{marginLeft:"auto",fontSize:11,color:"#94a3b8"}}>Kredi vade: {vadeK}g &nbsp;|&nbsp; Debit vade: {vadeD}g</span>
      </div>
    </div>
    <PosToplamGiris cfg={cfg} txs={txs} saveTxs={saveTxs}/>
    <div style={{display:"flex",gap:8,marginBottom:12,flexWrap:"wrap"}}><input aria-label="Geçmişte ara" placeholder="Kasa, banka, tür veya tutar ara" style={{...I,flex:2,minWidth:180}} value={histQuery} onChange={e=>{setHistQuery(e.target.value);setHistPage(1);}}/><input aria-label="Geçmiş başlangıç" type="date" style={{...I,flex:1}} value={histStart} onChange={e=>{setHistStart(e.target.value);setHistPage(1);}}/><input aria-label="Geçmiş bitiş" type="date" style={{...I,flex:1}} value={histEnd} onChange={e=>{setHistEnd(e.target.value);setHistPage(1);}}/></div>
    {histStart&&histEnd&&histStart>histEnd&&<p role="alert">Başlangıç tarihi bitişten sonra olamaz.</p>}
    {/* Transaction list */}
    <div style={{background:"#141825",border:"1px solid #1e293b",borderRadius:12,overflow:"hidden"}}>
      <div style={{padding:"11px 16px",borderBottom:"1px solid #1e293b",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <span style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase"}}>İŞLEM GEÇMİŞİ</span>
        <span style={{fontSize:11,color:"#a2b1c6"}}>{historyRows.length} eşleşme / {txs.length} kayıt</span>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 90px 80px 110px 100px 60px 36px",gap:4,padding:"7px 14px",borderBottom:"1px solid #1e293b",fontSize:11,color:"#a2b1c6",letterSpacing:1}}>
        <div>BANKA</div><div>KASA</div><div>İŞLEM TAR.</div><div>TÜR</div><div style={{textAlign:"right"}}>TUTAR</div><div style={{textAlign:"center"}}>YATACAK</div><div style={{textAlign:"center"}}>GÜNCELLE</div><div/>
      </div>
      <div style={{maxHeight:440,overflowY:"auto"}}>
        {txs.length===0&&<div style={{textAlign:"center",padding:"40px",color:"#94a3b8",fontSize:12}}>Henüz kayıt yok</div>}
        {historyRows.slice((page-1)*50,page*50).map((t,i)=>{
          const kasa=cfg.kasalar.find(k=>k.id===t.kasaId);
          const banka=cfg.bankalar.find(b=>b.id===t.bankaId);
          const bi=cfg.bankalar.findIndex(b=>b.id===t.bankaId);
          const col=BCOLS[bi%BCOLS.length]||"#94a3b8";
          const isK=t.tur==="KREDİ KARTI";
          return(
            <div key={t.id} data-tx-id={t.id} className="row-hover" style={{display:"grid",gridTemplateColumns:"1fr 1fr 90px 80px 110px 100px 60px 36px",gap:4,padding:"8px 14px",background:i%2===0?"transparent":"#0d1020",borderBottom:"1px solid #1e293b1a",alignItems:"center",fontSize:12,transition:"background .1s"}}>
              <div style={{color:col,fontSize:11}}>{banka?.ad||"-"}</div>
              <div style={{color:"#e2e8f0"}}>{kasa?.ad||t.kasaId}</div>
              <div style={{color:"#94a3b8",fontSize:11}}>{fDSh(t.islemTarihi)}</div>
              <div><span style={{fontSize:11,padding:"2px 7px",borderRadius:4,fontWeight:600,background:isK?"#1e3a5f22":"#14301f22",color:isK?"#60a5fa":"#4ade80",border:`1px solid ${isK?"#3b82f633":"#22c55e33"}`}}>{isK?"KREDİ":"DEBİT"}</span></div>
              <div style={{textAlign:"right",fontWeight:600,color:"#f1f5f9"}}>₺ {fmt(t.tutar)}</div>
              <div style={{textAlign:"center",fontSize:11,color:"#4ade80"}}>{fDSh(t.yatacakTarih)}</div>
              <div style={{textAlign:"center"}}><button aria-label="İşlemi düzenle" onClick={()=>{if(t.mutabakatId){setEditGroup(t.mutabakatId);return;}setEditTx(t);}} style={{background:"#1e3a5f",border:"1px solid #3b82f633",borderRadius:6,color:"#60a5fa",cursor:"pointer",padding:"3px 8px",fontSize:11,fontFamily:"inherit"}}><UiIcon kind="edit"/></button></div>
              <div style={{textAlign:"center"}}><button aria-label="İşlemi sil" onClick={()=>{setDeleteError("");setDelConfirm(t);}} style={{background:"none",border:"none",color:"#94a3b8",cursor:"pointer",fontSize:13,fontFamily:"inherit",transition:"color .15s"}} onMouseEnter={e=>e.target.style.color="#ef4444"} onMouseLeave={e=>e.target.style.color="#94a3b8"}><UiIcon kind="close"/></button></div>
            </div>
          );
        })}
        <div style={{display:"flex",gap:12,alignItems:"center",justifyContent:"center",padding:12,fontSize:12}}><button disabled={page<=1} onClick={()=>setHistPage(page-1)}>Önceki</button><span>Sayfa {page} / {pages} · {historyRows.length} eşleşme</span><button disabled={page>=pages} onClick={()=>setHistPage(page+1)}>Sonraki</button></div>
      </div>
    </div>
    {editGroup&&<PosMutabakat cfg={cfg} txs={txs} saveTxs={saveTxs} initialId={editGroup} onClose={()=>setEditGroup(null)}/>}
    {editTx&&<EditModal tx={editTx} cfg={cfg} onSave={upd=>{updateTx(upd);setEditTx(null);}} onClose={()=>setEditTx(null)}/>}

    {/* Silme onayı */}
    {delConfirm&&(()=>{
      const kasa=cfg.kasalar.find(k=>k.id===delConfirm.kasaId);
      return(
        <div style={{position:"fixed",inset:0,background:"#00000099",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <div style={{background:"#141825",border:"1px solid #ef4444",borderRadius:14,padding:"26px",width:400,maxWidth:"90vw",textAlign:"center"}}>
            <div style={{fontSize:26,marginBottom:10}}>⚠️</div>
            <div style={{fontSize:14,color:"#f1f5f9",fontWeight:600,marginBottom:10}}>İşlemi Sil</div>
            <div style={{fontSize:12,color:"#94a3b8",marginBottom:6}}>
              {kasa?.ad||""} · {delConfirm.tur==="KREDİ KARTI"?"KREDİ":"DEBİT"} · <span style={{color:"#f1f5f9",fontWeight:600}}>₺{fmt(delConfirm.tutar)}</span>
            </div>
            <div style={{fontSize:11,color:"#f87171",marginBottom:18}}>{delConfirm.mutabakatId?(delConfirm.posToplam!=null?"Bu POS toplamı ve ona bağlı tüm debitler silinecek. Emin misiniz?":"Yalnız bu debit silinecek; tutarı kalan krediye geri eklenecek. Emin misiniz?"):"Bu işlem kalıcı olarak silinecek. Emin misiniz?"}</div>
            {deleteError&&<p role="alert" style={{color:"#f87171",fontSize:12,marginBottom:12}}>{deleteError}</p>}
            <div style={{display:"flex",gap:10,justifyContent:"center"}}>
              <button onClick={()=>setDelConfirm(null)} style={{background:"#1e293b",border:"1px solid #2d3748",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"9px 22px",fontSize:12,fontFamily:"inherit"}}>İptal</button>
              <button className="btn-hover" onClick={()=>delTx(delConfirm.id)} style={{background:"#7f1d1d",border:"1px solid #ef4444",borderRadius:8,color:"#f87171",cursor:"pointer",padding:"9px 22px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>Evet, Sil</button>
            </div>
          </div>
        </div>
      );
    })()}
  </>);
}

/* ══════════════════════════════════════════════════════════════════════════
   EditModal
══════════════════════════════════════════════════════════════════════════ */
function EditModal({tx,cfg,onSave,onClose}){
  const [fKasa,setFKasa]=useState(tx.kasaId);
  const [fBanka,setFBanka]=useState(tx.bankaId);
  const [fDate,setFDate]=useState(tx.islemTarihi);
  const [fTur,setFTur]=useState(tx.tur);
  const [fTutar,setFTutar]=useState(String(tx.tutar));
  const [fYat,setFYat]=useState(tx.yatacakTarih);
  const I={background:"#0f1117",border:"1px solid #2d3748",borderRadius:8,color:"#e2e8f0",padding:"9px 12px",fontSize:13,fontFamily:"'IBM Plex Mono',monospace",width:"100%"};
  const calc=(d,tur)=>posVadeTarihi(d,cfg.vadeGunleri[tur||fTur]??0);
  const handleSave=()=>{try{const n=POSGuard.money(fTutar);const next={...tx,kasaId:fKasa,bankaId:fBanka,islemTarihi:fDate,tur:fTur,tutar:n,yatacakTarih:fYat};POSGuard.transaction(next,cfg);if(fDate>toS(new Date()))throw Error("İşlem tarihi gelecekte olamaz.");if(cfg.kasalar.find(k=>k.id===fKasa)?.bankaId!==fBanka&&fKasa!==tx.kasaId)throw Error("Kasa seçilen bankaya ait değil.");onSave(next);}catch(e){alert(e.message);}};
  return(
    <div style={{position:"fixed",inset:0,background:"#00000088",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:"#141825",border:"1px solid #3b82f6",borderRadius:14,padding:"24px",width:480,maxWidth:"95vw"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
          <span style={{fontSize:13,fontWeight:700,color:"#f1f5f9"}}>✏️ İşlemi Güncelle</span>
          <button aria-label="Kapat" onClick={onClose} style={{background:"none",border:"none",color:"#a2b1c6",cursor:"pointer",fontSize:18}}><UiIcon kind="close"/></button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}>
          {cfg.bankalar.length>1&&<div style={{gridColumn:"1/-1"}}><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>BANKA</div><select value={fBanka} onChange={e=>{setFBanka(e.target.value);setFKasa(cfg.kasalar.find(k=>k.bankaId===e.target.value&&k.aktif!==false)?.id||"");}} style={{...I}}>{cfg.bankalar.map(b=><option key={b.id} value={b.id}>{b.ad}</option>)}</select></div>}
          <div><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>KASA</div><select value={fKasa} onChange={e=>setFKasa(e.target.value)} style={{...I}}>{cfg.kasalar.filter(k=>(k.bankaId===fBanka&&k.aktif!==false)||(k.id===tx.kasaId&&fBanka===tx.bankaId)).map(k=><option key={k.id} value={k.id}>{k.ad}</option>)}</select></div>
          <div><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>İŞLEM TARİHİ</div><input aria-label="Düzenlenen işlem günü" type="date" value={fDate} onChange={e=>{setFDate(e.target.value);setFYat(calc(e.target.value));}} style={{...I}}/></div>
          <div><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>KART TÜRÜ</div><div style={{display:"flex",gap:6}}>{["KREDİ KARTI","DEBİT KART"].map(t=><button key={t} onClick={()=>{setFTur(t);setFYat(calc(fDate,t));}} style={{flex:1,background:fTur===t?(t==="KREDİ KARTI"?"#1e3a5f":"#14301f"):"#0f1117",border:`1px solid ${fTur===t?(t==="KREDİ KARTI"?"#3b82f6":"#22c55e"):"#2d3748"}`,borderRadius:7,color:fTur===t?(t==="KREDİ KARTI"?"#60a5fa":"#4ade80"):"#a2b1c6",cursor:"pointer",padding:"9px 4px",fontSize:11,fontFamily:"inherit"}}>{t==="KREDİ KARTI"?"KREDİ":"DEBİT"}</button>)}</div></div>
          <div><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>TUTAR (₺)</div><ParaInput value={fTutar} onChange={setFTutar} style={{...I,textAlign:"right"}}/></div>
          <div><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>YATACAK TARİH</div><input aria-label="Düzenlenen yatış günü" type="date" value={fYat} onChange={e=>setFYat(e.target.value)} style={{...I}}/></div>
        </div>
        <div style={{display:"flex",justifyContent:"flex-end",gap:8,marginTop:6}}>
          <button onClick={onClose} style={{background:"#1e293b",border:"1px solid #2d3748",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"9px 20px",fontSize:12,fontFamily:"inherit"}}>İptal</button>
          <button className="btn-hover" onClick={handleSave} style={{background:"#166534",border:"1px solid #22c55e",borderRadius:8,color:"#4ade80",cursor:"pointer",padding:"9px 20px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>✓ Güncelle</button>
        </div>
      </div>
    </div>
  );
}

/* ── Sabitler ── */
const KUPUR_RENK={200:"#f59e0b",100:"#3b82f6",50:"#8b5cf6",20:"#22c55e",10:"#06b6d4",5:"#f97316"};
const DENOMINATIONS=[
  {key:"c200",label:"200 TL",val:200,color:"#f59e0b"},
  {key:"c100",label:"100 TL",val:100,color:"#3b82f6"},
  {key:"c50", label:"50 TL", val:50, color:"#8b5cf6"},
  {key:"c20", label:"20 TL", val:20, color:"#22c55e"},
  {key:"c10", label:"10 TL", val:10, color:"#06b6d4"},
  {key:"c5k", label:"5 TL (Kağıt)", val:5, color:"#f97316"},
  {key:"c5m", label:"5 TL (Madeni)", val:5, color:"#94a3b8"},
];

/* ══════════════════════════════════════════════════════════════════════════
   NakitPlanTab — maaş günü için gereken rezervi hesaplar
══════════════════════════════════════════════════════════════════════════ */
function NakitPlanTab({txs,odemeler,plan,savePlan}){
  const set=(k,v)=>savePlan({...plan,[k]:v});
  const num=v=>parseTR(v);
  const temizle=()=>savePlan({bakiyeTarihi:"",odemeGunu:"",maasTarihi:"",maasTutari:"",bankaBakiye:"",nakitTahmini:"",bugunPosHaric:true,maasGunuPosHaric:true});
  const I={background:"#0f1117",border:"1px solid #2d3748",borderRadius:8,color:"#e2e8f0",padding:"9px 12px",fontSize:13,fontFamily:"'IBM Plex Mono',monospace",width:"100%"};

  const hesap=useMemo(()=>{
    const bt=plan.bakiyeTarihi, og=plan.odemeGunu, mt=plan.maasTarihi;
    if(!bt||!og||!mt||og<bt||mt<og) return null;

    // PENCERE A: bakiye tarihinden ödeme gününe (ödeme günü DAHİL)
    const aBas = plan.bugunPosHaric ? addD(bt,1) : bt;
    const aBit = og;
    // PENCERE B: ödeme günü sonrasından maaş gününe (maaş günü HARİÇ)
    const bBas = addD(og,1);
    const bBit = plan.maasGunuPosHaric ? addD(mt,-1) : mt;

    let posA=0,posB=0; const posGun={};
    txs.forEach(t=>{
      if(t.tahsilEdildi)return;
      const y=t.yatacakTarih;
      posGun[y]=(posGun[y]||0)+t.tutar;
      if(y>=aBas&&y<=aBit) posA+=t.tutar;
      if(y>=bBas&&y<=bBit) posB+=t.tutar;
    });

    let giderA=0,giderB=0; const giderGun={}; const listA=[],listB=[];
    odemeler.forEach(o=>{
      if(o.odendi)return;
      const s=o.sonOdeme;
      if(s>=bt&&s<=og){giderA+=o.tutar;listA.push(o);giderGun[s]=(giderGun[s]||0)+o.tutar;}
      else if(s>=bBas&&s<=mt){giderB+=o.tutar;listB.push(o);giderGun[s]=(giderGun[s]||0)+o.tutar;}
    });

    const maas=num(plan.maasTutari), banka=num(plan.bankaBakiye), nakit=num(plan.nakitTahmini);
    // Ödeme günü eldeki para (firmalara ödeme yapılmadan önce)
    const odemeGunuBakiye = banka + nakit + posA - giderA;
    // Maaş için ödeme gününde ayrılması gereken
    const maasRezerv = Math.max(0, maas + giderB - posB);
    // Firmalara ödenebilecek
    const odenebilir = odemeGunuBakiye - maasRezerv;
    const maasGunuBakiye = odemeGunuBakiye + posB - giderB;

    // Gün gün çizelge
    const gunler=[]; let bakiye=banka; let d=bt; let guard=0;
    while(d<=mt && guard<400){
      let pIn = posGun[d]||0;
      if(d===bt && plan.bugunPosHaric) pIn=0;
      if(d===mt && plan.maasGunuPosHaric) pIn=0;
      const gOut = giderGun[d]||0;
      if(d===bt) bakiye += nakit;           // nakit girişi bakiye tarihinde
      bakiye += pIn - gOut;
      gunler.push({tarih:d,pos:pIn,gider:gOut,bakiye,odemeGunu:d===og,maasGunu:d===mt});
      d=addD(d,1); guard++;
    }
    return{posA,posB,giderA,giderB,listA,listB,maas,banka,nakit,odemeGunuBakiye,maasRezerv,odenebilir,maasGunuBakiye,gunler,aBas,aBit,bBas,bBit};
  },[txs,odemeler,plan]);

  const yeterli = hesap && hesap.odenebilir>=0;

  return(<>
    {/* Giriş formu */}
    <Card title="PLANLAMA BİLGİLERİ" accent="#eab308">
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(168px,1fr))",gap:11,marginBottom:12}}>
        <div>
          <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>BUGÜN (BAKİYE TARİHİ)</div>
          <input type="date" value={plan.bakiyeTarihi} onChange={e=>set("bakiyeTarihi",e.target.value)} style={{...I}}/>
        </div>
        <div>
          <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>FİRMA ÖDEME GÜNÜ</div>
          <input type="date" value={plan.odemeGunu} onChange={e=>set("odemeGunu",e.target.value)} style={{...I,border:"1px solid #22c55e55"}}/>
        </div>
        <div>
          <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>MAAŞ ÖDEME TARİHİ</div>
          <input type="date" value={plan.maasTarihi} onChange={e=>set("maasTarihi",e.target.value)} style={{...I,border:"1px solid #eab30855"}}/>
        </div>
        <div>
          <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>MAAŞ TUTARI (₺)</div>
          <ParaInput value={plan.maasTutari} onChange={v=>set("maasTutari",v)} style={{...I,border:"1px solid #eab30855",textAlign:"right"}}/>
        </div>
        <div>
          <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>BANKADAKİ PARA (₺)</div>
          <ParaInput value={plan.bankaBakiye} onChange={v=>set("bankaBakiye",v)} style={{...I,textAlign:"right"}}/>
        </div>
        <div>
          <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>TAHMİNİ NAKİT GİRİŞİ (₺)</div>
          <ParaInput value={plan.nakitTahmini} onChange={v=>set("nakitTahmini",v)} style={{...I,textAlign:"right"}}/>
        </div>
      </div>
      <div style={{display:"flex",gap:16,flexWrap:"wrap",alignItems:"center"}}>
        <label style={{display:"flex",alignItems:"center",gap:7,cursor:"pointer",fontSize:11,color:plan.bugunPosHaric?"#fbbf24":"#a2b1c6"}}>
          <input type="checkbox" checked={plan.bugunPosHaric} onChange={e=>set("bugunPosHaric",e.target.checked)}/>
          Bugün yatan POS'u sayma <span style={{color:"#94a3b8"}}>(bakiyeye zaten girdiyse)</span>
        </label>
        <label style={{display:"flex",alignItems:"center",gap:7,cursor:"pointer",fontSize:11,color:plan.maasGunuPosHaric?"#fbbf24":"#a2b1c6"}}>
          <input type="checkbox" checked={plan.maasGunuPosHaric} onChange={e=>set("maasGunuPosHaric",e.target.checked)}/>
          Maaş günü yatacak POS'ları sayma <span style={{color:"#94a3b8"}}>(maaş gece ödendiği için)</span>
        </label>
        <button className="btn-hover" onClick={temizle} style={{marginLeft:"auto",background:"#1e293b",border:"1px solid #475569",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"8px 18px",fontSize:11,fontFamily:"inherit",fontWeight:600,letterSpacing:1}}>🔄 TEMİZLE</button>
      </div>
    </Card>

    {!hesap ? (
      <div style={{textAlign:"center",padding:"30px",color:"#94a3b8",fontSize:12,background:"#141825",borderRadius:12,border:"1px dashed #2d3748"}}>
        Tarih sırası: Bugün ≤ Firma ödeme günü ≤ Maaş tarihi olmalı
      </div>
    ) : (<>
      {/* ANA SONUÇ */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:14}}>
        <div style={{background:yeterli?"linear-gradient(135deg,#0f2418,#14301f)":"linear-gradient(135deg,#2d1414,#3d1a1a)",border:`1px solid ${yeterli?"#22c55e":"#ef4444"}`,borderRadius:12,padding:"18px 22px"}}>
          <div style={{fontSize:11,color:yeterli?"#15803d":"#991b1b",letterSpacing:2,textTransform:"uppercase",marginBottom:6}}>
            {yeterli?`${fDSh(plan.odemeGunu)} FİRMALARA ÖDEYEBİLECEĞİM`:"⚠ AÇIK VAR"}
          </div>
          <div style={{fontSize:30,fontWeight:700,color:yeterli?"#4ade80":"#f87171",letterSpacing:-1}}>₺ {fmt(Math.abs(hesap.odenebilir))}</div>
          <div style={{fontSize:11,color:"#78716c",marginTop:5}}>
            {yeterli?"Bu tutara kadar ödeme yapabilirsin":"Maaş için bu kadar eksik kalıyor"}
          </div>
        </div>
        <div style={{background:"linear-gradient(135deg,#2a2410,#3d3418)",border:"1px solid #eab308",borderRadius:12,padding:"18px 22px"}}>
          <div style={{fontSize:11,color:"#a16207",letterSpacing:2,textTransform:"uppercase",marginBottom:6}}>
            MAAŞ İÇİN AYIRMAM GEREKEN
          </div>
          <div style={{fontSize:30,fontWeight:700,color:"#fbbf24",letterSpacing:-1}}>₺ {fmt(hesap.maasRezerv)}</div>
          <div style={{fontSize:11,color:"#78716c",marginTop:5}}>
            {hesap.maasRezerv===0?"Sonraki POS girişleri maaşı karşılıyor":`${fDSh(plan.maasTarihi)} maaşı için`}
          </div>
        </div>
      </div>

      {/* HESAP DÖKÜMÜ */}
      <Card title="HESAP DÖKÜMÜ" accent="#3b82f6">
        <div style={{fontSize:11,color:"#22c55e",letterSpacing:1,marginBottom:6,fontWeight:600}}>① ÖDEME GÜNÜ ELDEKİ PARA</div>
        <div style={{display:"flex",flexDirection:"column",gap:1,fontSize:12,marginBottom:12}}>
          {[
            ["Bankadaki para",hesap.banka,"#e2e8f0",""],
            [`Yatacak POS (${fDSh(hesap.aBas)} → ${fDSh(hesap.aBit)})`,hesap.posA,"#93c5fd","+"],
            ["Tahmini nakit girişi",hesap.nakit,"#93c5fd","+"],
            ["Ödeme gününe kadarki ödemeler",hesap.giderA,"#f87171","−"],
          ].map(([lbl,val,renk,isaret],i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"8px 12px",background:i%2===0?"#0f1117":"transparent",borderRadius:6}}>
              <span style={{color:"#94a3b8"}}>{isaret} {lbl}</span>
              <span style={{color:renk,fontWeight:600}}>₺ {fmt(val)}</span>
            </div>
          ))}
          <div style={{display:"flex",justifyContent:"space-between",padding:"9px 12px",borderTop:"1px solid #2d3748",marginTop:3}}>
            <span style={{color:"#cbd5e1",fontWeight:600}}>= Ödeme günü eldeki para</span>
            <span style={{color:"#f1f5f9",fontWeight:700,fontSize:14}}>₺ {fmt(hesap.odemeGunuBakiye)}</span>
          </div>
        </div>

        <div style={{fontSize:11,color:"#eab308",letterSpacing:1,marginBottom:6,fontWeight:600}}>② MAAŞ İÇİN AYRILACAK</div>
        <div style={{display:"flex",flexDirection:"column",gap:1,fontSize:12,marginBottom:12}}>
          {[
            ["Maaş tutarı",hesap.maas,"#fbbf24","+"],
            ["Maaşa kadarki diğer ödemeler",hesap.giderB,"#f87171","+"],
            [`Maaşa kadar yatacak POS (${fDSh(hesap.bBas)} → ${fDSh(hesap.bBit)})`,hesap.posB,"#93c5fd","−"],
          ].map(([lbl,val,renk,isaret],i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"8px 12px",background:i%2===0?"#0f1117":"transparent",borderRadius:6}}>
              <span style={{color:"#94a3b8"}}>{isaret} {lbl}</span>
              <span style={{color:renk,fontWeight:600}}>₺ {fmt(val)}</span>
            </div>
          ))}
          <div style={{display:"flex",justifyContent:"space-between",padding:"9px 12px",background:"#1a1508",borderRadius:6,marginTop:3}}>
            <span style={{color:"#a16207",fontWeight:600}}>= Maaş için ayrılacak</span>
            <span style={{color:"#fbbf24",fontWeight:700,fontSize:14}}>₺ {fmt(hesap.maasRezerv)}</span>
          </div>
        </div>

        <div style={{display:"flex",justifyContent:"space-between",padding:"12px 14px",background:yeterli?"#0f2418":"#2d1414",borderRadius:8,border:`1px solid ${yeterli?"#22c55e44":"#ef444444"}`}}>
          <span style={{color:yeterli?"#4ade80":"#f87171",fontWeight:700,fontSize:13}}>① − ② = FİRMALARA ÖDENEBİLİR</span>
          <span style={{color:yeterli?"#4ade80":"#f87171",fontWeight:700,fontSize:16}}>₺ {fmt(hesap.odenebilir)}</span>
        </div>

        {(hesap.listA.length>0||hesap.listB.length>0)&&(
          <div style={{marginTop:12,paddingTop:12,borderTop:"1px solid #1e293b"}}>
            <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,marginBottom:7}}>DÜŞÜLEN ÖDEMELER</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
              {[...hesap.listA,...hesap.listB].map(o=>(
                <span key={o.id} style={{fontSize:11,background:"#2d1414",border:"1px solid #ef444433",borderRadius:6,padding:"4px 9px",color:"#fca5a5"}}>
                  {o.ad} · ₺{fmt(o.tutar)} · {fDSh(o.sonOdeme)}
                </span>
              ))}
            </div>
          </div>
        )}
      </Card>

      {/* GÜN GÜN ÇİZELGE */}
      <div style={{background:"#141825",border:"1px solid #1e293b",borderRadius:12,overflow:"hidden"}}>
        <div style={{padding:"11px 16px",borderBottom:"1px solid #1e293b",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <span style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase"}}>GÜN GÜN BAKİYE (hiç ödeme yapılmazsa)</span>
          <span style={{fontSize:11,color:"#a2b1c6"}}>{hesap.gunler.length} gün</span>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"140px 1fr 1fr 1fr",gap:6,padding:"7px 16px",borderBottom:"1px solid #1e293b",fontSize:11,color:"#a2b1c6",letterSpacing:1}}>
          <div>TARİH</div><div style={{textAlign:"right"}}>POS GİRİŞİ</div><div style={{textAlign:"right"}}>ÖDEME</div><div style={{textAlign:"right"}}>BAKİYE</div>
        </div>
        <div style={{maxHeight:340,overflowY:"auto"}}>
          {hesap.gunler.map((g,i)=>{
            const vurgu = g.maasGunu ? "#eab308" : (g.odemeGunu ? "#22c55e" : null);
            return(
              <div key={g.tarih} className="row-hover" style={{display:"grid",gridTemplateColumns:"140px 1fr 1fr 1fr",gap:6,padding:"8px 16px",background:g.maasGunu?"#2a241055":(g.odemeGunu?"#0f241855":(i%2===0?"transparent":"#0d1020")),borderBottom:"1px solid #1e293b1a",borderLeft:`3px solid ${vurgu||"transparent"}`,alignItems:"center",fontSize:12}}>
                <div style={{color:vurgu||"#e2e8f0",fontWeight:vurgu?700:400}}>
                  {fDSh(g.tarih)}
                  {g.odemeGunu&&<span style={{fontSize:9,marginLeft:5}}>ÖDEME</span>}
                  {g.maasGunu&&<span style={{fontSize:9,marginLeft:5}}>MAAŞ</span>}
                </div>
                <div style={{textAlign:"right",color:g.pos>0?"#93c5fd":"#334155"}}>{g.pos>0?"+ ₺"+fmt(g.pos):"—"}</div>
                <div style={{textAlign:"right",color:g.gider>0?"#f87171":"#334155"}}>{g.gider>0?"− ₺"+fmt(g.gider):"—"}</div>
                <div style={{textAlign:"right",fontWeight:600,color:g.bakiye>=0?"#f1f5f9":"#f87171"}}>₺ {fmt(g.bakiye)}</div>
              </div>
            );
          })}
        </div>
      </div>
    </>)}
  </>);
}

/* ══════════════════════════════════════════════════════════════════════════
   AylikOdemeler — aylık ödeme takibi (son ödeme tarihli)
══════════════════════════════════════════════════════════════════════════ */
function AylikOdemeler({odemeler,saveOdemeler}){
  const today=toS(new Date());
  const [ad,setAd]=useState("");
  const [tutar,setTutar]=useState("");
  const [tarih,setTarih]=useState("");
  const [silId,setSilId]=useState(null);
  const [editOdeme,setEditOdeme]=useState(null);
  const [editAd,setEditAd]=useState("");
  const [editTutar,setEditTutar]=useState("");

  const I={background:"#0f1117",border:"1px solid #2d3748",borderRadius:8,color:"#e2e8f0",padding:"9px 12px",fontSize:13,fontFamily:"'IBM Plex Mono',monospace",width:"100%"};

  const ekle=()=>{
    const t=parseTR(tutar);
    if(!ad.trim()||!t||isNaN(t)||!tarih)return;
    saveOdemeler([{id:uid(),ad:ad.trim(),tutar:t,sonOdeme:tarih,odendi:false},...odemeler]);
    setAd("");setTutar("");setTarih("");
  };
  const toggle=id=>saveOdemeler(odemeler.map(o=>o.id===id?{...o,odendi:!o.odendi}:o));
  const sil=id=>{saveOdemeler(odemeler.filter(o=>o.id!==id));setSilId(null);};
  const updateTarih=(id,yeni)=>saveOdemeler(odemeler.map(o=>o.id===id?{...o,sonOdeme:yeni}:o));
  const openEdit=o=>{setEditOdeme(o);setEditAd(o.ad);setEditTutar(String(o.tutar));};
  const saveEdit=()=>{
    const t=parseTR(editTutar);
    if(!editAd.trim()||!t||isNaN(t))return;
    saveOdemeler(odemeler.map(o=>o.id===editOdeme.id?{...o,ad:editAd.trim(),tutar:t}:o));
    setEditOdeme(null);
  };

  // sıralama: ödenmemişler önce, son ödeme tarihine göre
  const sirali=[...odemeler].sort((a,b)=>{
    if(a.odendi!==b.odendi)return a.odendi?1:-1;
    return a.sonOdeme<b.sonOdeme?-1:1;
  });
  const bekleyenToplam=odemeler.filter(o=>!o.odendi).reduce((s,o)=>s+o.tutar,0);
  const bekleyenAdet=odemeler.filter(o=>!o.odendi).length;

  const gunFark=t=>{const d=new Date(t+"T00:00:00");const b=new Date(today+"T00:00:00");return Math.round((d-b)/86400000);};

  return(
    <div style={{marginTop:20,background:"#141825",border:"1px solid #f9731633",borderRadius:12,overflow:"hidden"}}>
      <div style={{padding:"12px 16px",borderBottom:"1px solid #1e293b",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:6,height:6,borderRadius:1,background:"#f97316"}}/>
          <span style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase"}}>AYLIK ÖDEME TAKİBİ</span>
        </div>
        {bekleyenAdet>0&&<span style={{fontSize:12,color:"#fb923c"}}>Bekleyen: <b>₺{fmt(bekleyenToplam)}</b> ({bekleyenAdet})</span>}
      </div>

      <div style={{padding:"16px 18px"}}>
        {/* Ekleme formu */}
        <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"flex-end",marginBottom:16}}>
          <div style={{flex:"2 1 200px"}}>
            <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>ÖDEME ADI</div>
            <input value={ad} placeholder="Kira, elektrik, internet..." onChange={e=>setAd(e.target.value)} onKeyDown={e=>e.key==="Enter"&&ekle()} style={{...I}}/>
          </div>
          <div style={{flex:"1 1 120px"}}>
            <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>TUTAR (₺)</div>
            <ParaInput value={tutar} onChange={setTutar} onEnter={ekle} style={{...I,textAlign:"right"}}/>
          </div>
          <div style={{flex:"1 1 150px"}}>
            <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>SON ÖDEME TARİHİ</div>
            <input type="date" value={tarih} onChange={e=>setTarih(e.target.value)} style={{...I}}/>
          </div>
          <button onClick={ekle} style={{background:"#7c2d12",border:"1px solid #f97316",borderRadius:8,color:"#fb923c",cursor:"pointer",padding:"9px 20px",fontSize:12,fontFamily:"inherit",fontWeight:600,letterSpacing:1}}>+ EKLE</button>
        </div>

        {/* Liste */}
        {odemeler.length===0 ? (
          <div style={{textAlign:"center",padding:"24px",color:"#94a3b8",fontSize:12,background:"#0f1117",borderRadius:10,border:"1px dashed #2d3748"}}>Henüz ödeme eklenmedi</div>
        ) : (
          <div style={{display:"flex",flexDirection:"column",gap:7}}>
            {sirali.map(o=>{
              const gun=gunFark(o.sonOdeme);
              let durum,renk;
              if(o.odendi){durum="✓ Ödendi";renk="#4ade80";}
              else if(gun<0){durum=`${-gun} gün gecikti`;renk="#f87171";}
              else if(gun===0){durum="Bugün son gün!";renk="#fbbf24";}
              else if(gun<=3){durum=`${gun} gün kaldı`;renk="#fbbf24";}
              else{durum=`${gun} gün kaldı`;renk="#a2b1c6";}
              return(
                <div key={o.id} className="row-hover" style={{display:"grid",gridTemplateColumns:"1fr 130px 110px 130px 130px 36px",gap:10,alignItems:"center",background:o.odendi?"#0d1610":"#0f1117",border:`1px solid ${o.odendi?"#22c55e22":(gun<0?"#ef444433":"#1e293b")}`,borderRadius:9,padding:"11px 14px"}}>
                  <div style={{fontSize:13,color:o.odendi?"#86efac":"#e2e8f0",fontWeight:500,textDecoration:o.odendi?"line-through":"none",opacity:o.odendi?0.7:1}}>{o.ad}</div>
                  <div style={{fontSize:14,fontWeight:700,color:o.odendi?"#4ade80":"#f1f5f9",textAlign:"right"}}>₺ {fmt(o.tutar)}</div>
                  <input type="date" value={o.sonOdeme} onChange={e=>updateTarih(o.id,e.target.value)} title="Son ödeme tarihini değiştir" style={{background:"#0f1117",border:"1px solid #2d3748",borderRadius:6,color:"#cbd5e1",padding:"5px 7px",fontSize:11,fontFamily:"'IBM Plex Mono',monospace",cursor:"pointer",textAlign:"center"}}/>
                  <div style={{fontSize:11,color:renk,textAlign:"center",fontWeight:600}}>{durum}</div>
                  <div style={{display:"flex",gap:5,justifyContent:"center"}}>
                    <button aria-label="İşlemi düzenle" onClick={()=>openEdit(o)} title="Ad ve tutarı düzenle" style={{background:"#1e3a5f",border:"1px solid #3b82f644",borderRadius:6,color:"#60a5fa",cursor:"pointer",padding:"4px 8px",fontSize:11,fontFamily:"inherit"}}><UiIcon kind="edit"/></button>
                    {!o.odendi ? (
                      <button onClick={()=>toggle(o.id)} title="Ödendi olarak işaretle" style={{background:"#14301f",border:"1px solid #22c55e44",borderRadius:6,color:"#4ade80",cursor:"pointer",padding:"4px 8px",fontSize:11,fontFamily:"inherit"}}>✓ Öde</button>
                    ) : (
                      <button onClick={()=>toggle(o.id)} title="Ödenmedi olarak işaretle" style={{background:"#1e293b",border:"1px solid #47556944",borderRadius:6,color:"#94a3b8",cursor:"pointer",padding:"4px 8px",fontSize:11,fontFamily:"inherit"}}>↩ Geri</button>
                    )}
                  </div>
                  <div style={{textAlign:"center"}}><button aria-label="Kapat" onClick={()=>setSilId(o.id)} style={{background:"none",border:"none",color:"#94a3b8",cursor:"pointer",fontSize:13,fontFamily:"inherit"}} onMouseEnter={e=>e.target.style.color="#ef4444"} onMouseLeave={e=>e.target.style.color="#94a3b8"}><UiIcon kind="close"/></button></div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Sil onay */}
      {silId&&(
        <div style={{position:"fixed",inset:0,background:"#00000099",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <div style={{background:"#141825",border:"1px solid #ef4444",borderRadius:14,padding:"26px",width:360,maxWidth:"90vw",textAlign:"center"}}>
            <div style={{fontSize:26,marginBottom:10}}>⚠️</div>
            <div style={{fontSize:14,color:"#f1f5f9",fontWeight:600,marginBottom:18}}>Bu ödeme silinsin mi?</div>
            <div style={{display:"flex",gap:10,justifyContent:"center"}}>
              <button onClick={()=>setSilId(null)} style={{background:"#1e293b",border:"1px solid #2d3748",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"9px 22px",fontSize:12,fontFamily:"inherit"}}>İptal</button>
              <button onClick={()=>sil(silId)} style={{background:"#7f1d1d",border:"1px solid #ef4444",borderRadius:8,color:"#f87171",cursor:"pointer",padding:"9px 22px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>Evet, Sil</button>
            </div>
          </div>
        </div>
      )}

      {/* Düzenleme modalı */}
      {editOdeme&&(
        <div style={{position:"fixed",inset:0,background:"#00000099",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={e=>e.target===e.currentTarget&&setEditOdeme(null)}>
          <div style={{background:"#141825",border:"1px solid #3b82f6",borderRadius:14,padding:"24px",width:400,maxWidth:"92vw"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
              <span style={{fontSize:13,fontWeight:700,color:"#f1f5f9"}}>✏️ Ödemeyi Düzenle</span>
              <button aria-label="Kapat" onClick={()=>setEditOdeme(null)} style={{background:"none",border:"none",color:"#a2b1c6",cursor:"pointer",fontSize:18}}><UiIcon kind="close"/></button>
            </div>
            <div style={{marginBottom:10}}>
              <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>ÖDEME ADI</div>
              <input value={editAd} onChange={e=>setEditAd(e.target.value)} onKeyDown={e=>e.key==="Enter"&&saveEdit()} style={{...I}}/>
            </div>
            <div style={{marginBottom:16}}>
              <div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>TUTAR (₺)</div>
              <ParaInput value={editTutar} onChange={setEditTutar} onEnter={saveEdit} style={{...I,textAlign:"right"}}/>
            </div>
            <div style={{display:"flex",justifyContent:"flex-end",gap:8}}>
              <button onClick={()=>setEditOdeme(null)} style={{background:"#1e293b",border:"1px solid #2d3748",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"9px 20px",fontSize:12,fontFamily:"inherit"}}>İptal</button>
              <button className="btn-hover" onClick={saveEdit} style={{background:"#166534",border:"1px solid #22c55e",borderRadius:8,color:"#4ade80",cursor:"pointer",padding:"9px 20px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>✓ Kaydet</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── SB: Ayarlar bölüm kartı (dışarıda tanımlı, focus kaybı olmasın) ── */
function UiIcon({kind="edit"}){const paths={edit:"M4 16 16 4l4 4L8 20H4Z",close:"M6 6l12 12M18 6 6 18",chart:"M4 20V10m6 10V4m6 16v-8m6 8V7",money:"M3 6h18v14H3zM8 6V4h10v2M16 11h5v5h-5z",settings:"M4 6h16M4 12h16M4 18h16M8 3v6m8 0v6m-6 0v6",calendar:"M4 5h16v16H4zM8 3v4m8-4v4M4 10h16",download:"M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4",upload:"M12 16V4m-5 5 5-5 5 5M4 17v4h16v-4",save:"M4 3h14l3 3v15H3V3h1M7 3v6h10V3M7 21v-8h10v8"};return <svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{verticalAlign:"middle",flexShrink:0}}><path d={paths[kind]||paths.edit}/></svg>;}
function SB({label,accent="#a2b1c6",children}){
  return(
    <div style={{background:"#141825",border:`1px solid ${accent}22`,borderRadius:12,padding:"18px 20px",marginBottom:14}}>
      <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase",marginBottom:14,display:"flex",alignItems:"center",gap:8}}><div style={{width:6,height:6,borderRadius:1,background:accent}}/>{label}</div>
      {children}
    </div>
  );
}

/* ── Card: ParaTab dışında tanımlı (focus kaybı olmasın) ── */
function Card({title,children,accent="#3b82f6"}){
  return(
    <div style={{background:"#141825",border:`1px solid ${accent}22`,borderRadius:12,padding:"16px 18px",marginBottom:14}}>
      <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase",marginBottom:14,display:"flex",alignItems:"center",gap:8}}>
        <div style={{width:6,height:6,borderRadius:1,background:accent}}/>
        {title}
      </div>
      {children}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   ParaTab
══════════════════════════════════════════════════════════════════════════ */
function ParaTab({cfg,saveCfg,para,savePara,kasaDurum,saveKD,paraLog,saveParaLog,kasaLog,saveKasaLog}){
  const today=toS(new Date());

  // Kupür inputları için ref — state kullanmıyoruz, her tuşta re-render olmaz
  const inputRefs=useRef({});

  const [islem,setIslem]=useState("giris");
  const [dahil50,setDahil50]=useState(false);
  const [fazlaInput,setFazlaInput]=useState("");
  const [eksikInput,setEksikInput]=useState("");
  const [kdTarih,setKdTarih]=useState(addD(toS(new Date()),-1));
  const [resetConfirm,setResetConfirm]=useState(false);
  const [savedMsg,setSavedMsg]=useState("");

  const showMsg=m=>{setSavedMsg(m);setTimeout(()=>setSavedMsg(""),2200);};

  /* Kasa yapım hesap — esnek kupür listesi (bankaTutar'dan önce olmalı) */
  const ky=cfg.kasaYapim||DEF_CFG.kasaYapim;
  const kasaSayisi=ky.kasaSayisi||14;
  const kupurler=(ky.kupurler||DEF_CFG.kasaYapim.kupurler).slice().sort((a,b)=>b.tutar-a.tutar);
  const paraMevcut=tutar=>{
    if(tutar===200)return para.c200||0;
    if(tutar===100)return para.c100||0;
    if(tutar===50)return para.c50||0;
    if(tutar===20)return para.c20||0;
    if(tutar===10)return para.c10||0;
    if(tutar===5)return (para.c5k||0)+(para.c5m||0);
    return 0;
  };

  /* Bankaya yatacak hesap — kasa yapımı için gerekli 100 TL isteğe bağlı hariç tutulabilir */
  const bankaYedek=cfg.bankaYedek||{aktif:false,adet:null};
  const kupur100=kupurler.find(k=>k.tutar===100);
  const gereken100=(kupur100?.adet||0)*kasaSayisi;
  const istenen100=bankaYedek.adet??gereken100;
  const mevcut100=para.c100||0;
  const fazla100=Math.max(0,mevcut100-istenen100);
  const setBankaYedek=patch=>saveCfg({...cfg,bankaYedek:{...bankaYedek,...patch}});

  const bankaTutar=useMemo(()=>{
    let t=(para.c200||0)*200;
    t += bankaYedek.aktif ? fazla100*100 : mevcut100*100;
    if(dahil50&&(para.c50||0)>100) t+=((para.c50-100)*50);
    return t;
  },[para,dahil50,bankaYedek.aktif,fazla100,mevcut100]);

  /* Uygula butonu — ref'lerden değerleri okur, log'a kaydeder */
  const applyAmounts=()=>{
    const newPara={...para};
    const logKayit={id:uid(),zaman:simdiZaman(),islem:islem,c200:0,c100:0,c50:0,c20:0,c10:0,c5k:0,c5m:0,toplam:0};
    let herhangiVar=false;
    DENOMINATIONS.forEach(({key,val})=>{
      const el=inputRefs.current[key];
      const v=el?parseInt(el.value)||0:0;
      if(v===0)return;
      herhangiVar=true;
      logKayit[key]=v;
      logKayit.toplam+=v*val;
      if(islem==="giris") newPara[key]=(newPara[key]||0)+v;
      else newPara[key]=Math.max(0,(newPara[key]||0)-v);
      if(el) el.value="";
    });
    if(!herhangiVar)return;
    savePara(newPara);
    saveParaLog([logKayit,...paraLog]);
    showMsg(islem==="giris"?"✓ Giriş kaydedildi":"✓ Çıkış kaydedildi");
  };

  /* Kasa durum kaydet — log'a da yazar */
  const applyFazla=()=>{
    const v=parseTR(fazlaInput);
    if(!v||isNaN(v))return;
    const nd={...kasaDurum,fazla:(kasaDurum.fazla||0)+v,tarih:kdTarih};
    saveKD(nd);
    saveKasaLog([{id:uid(),tarih:kdTarih,tur:"fazla",tutar:v},...kasaLog]);
    setFazlaInput("");showMsg("✓ Kasa fazlası eklendi");
  };
  const applyEksik=()=>{
    const v=parseTR(eksikInput);
    if(!v||isNaN(v))return;
    const nd={...kasaDurum,eksik:(kasaDurum.eksik||0)+v,tarih:kdTarih};
    saveKD(nd);
    saveKasaLog([{id:uid(),tarih:kdTarih,tur:"eksik",tutar:v},...kasaLog]);
    setEksikInput("");showMsg("✓ Kasa eksiği eklendi");
  };
  const doReset=()=>{
    saveKD({fazla:0,eksik:0,tarih:kdTarih});
    saveKasaLog([{id:uid(),tarih:kdTarih,tur:"sifirla",tutar:0},...kasaLog]);
    setResetConfirm(false);showMsg("✓ Tutarlar sıfırlandı");
  };

  const net=kasaDurum.fazla-kasaDurum.eksik;

  return(<>
    {savedMsg&&<div className="fi" style={{background:"#14301f",border:"1px solid #22c55e",borderRadius:9,padding:"10px 16px",marginBottom:12,fontSize:12,color:"#4ade80"}}>{savedMsg}</div>}

    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>

      {/* SOL: Para Sayım + Bankaya Yatacak */}
      <div>
        <Card title="PARA SAYIMI" accent="#f59e0b">
          {/* Giriş / Çıkış toggle */}
          <div style={{display:"flex",gap:6,marginBottom:14}}>
            {["giris","cikis"].map(t=>(
              <button key={t} onClick={()=>setIslem(t)} style={{flex:1,background:islem===t?(t==="giris"?"#14301f":"#2d1a1a"):"#0f1117",border:`1px solid ${islem===t?(t==="giris"?"#22c55e":"#ef4444"):"#2d3748"}`,borderRadius:8,color:islem===t?(t==="giris"?"#4ade80":"#f87171"):"#a2b1c6",cursor:"pointer",padding:"9px",fontSize:12,fontFamily:"inherit",fontWeight:600,letterSpacing:1}}>
                {t==="giris"?"⬆ GİRİŞ":"⬇ ÇIKIŞ"}
              </button>
            ))}
          </div>

          {/* Denomination rows */}
          <div style={{display:"grid",gridTemplateColumns:"120px 80px 1fr",gap:"6px 8px",alignItems:"center",marginBottom:14}}>
            <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1}}>KUPÜR</div>
            <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,textAlign:"right"}}>MEVCUT</div>
            <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1}}>ADET GİR</div>
            {DENOMINATIONS.map(({key,label,color})=>(
              <React.Fragment key={key}>
                <div style={{display:"flex",alignItems:"center",gap:6}}>
                  <div style={{width:7,height:7,borderRadius:1,background:color}}/>
                  <span style={{fontSize:12,color:"#e2e8f0"}}>{label}</span>
                </div>
                <div style={{textAlign:"right",fontSize:13,fontWeight:700,color:color}}>{fmtN(para[key]||0)}</div>
                <input type="number" min="0" defaultValue="" placeholder="0"
                  ref={el=>inputRefs.current[key]=el}
                  onKeyDown={e=>e.key==="Enter"&&applyAmounts()}
                  style={{background:"#0f1117",border:"1px solid #2d3748",borderRadius:8,color:"#e2e8f0",padding:"6px 10px",fontSize:12,fontFamily:"'IBM Plex Mono',monospace",width:"100%"}}/>
              </React.Fragment>
            ))}
          </div>

          <button className="btn-hover" onClick={applyAmounts} style={{width:"100%",background:islem==="giris"?"#166534":"#7f1d1d",border:`1px solid ${islem==="giris"?"#22c55e":"#ef4444"}`,borderRadius:9,color:islem==="giris"?"#4ade80":"#f87171",cursor:"pointer",padding:"10px",fontSize:13,fontFamily:"inherit",fontWeight:600,letterSpacing:1}}>
            {islem==="giris"?"⬆ GİRİŞ UYGULA":"⬇ ÇIKIŞ UYGULA"}
          </button>
        </Card>

        {/* Bankaya Yatacak — Para Sayımı'nın altında */}
        <Card title="BANKAYA YATACAK PARA" accent="#3b82f6">
          <div style={{marginBottom:12}}>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:10}}>
              <div style={{background:"#0f1117",border:"1px solid #f59e0b33",borderRadius:8,padding:"10px 12px"}}>
                <div style={{fontSize:11,color:"#a2b1c6",marginBottom:4}}>200 TL × {fmtN(para.c200||0)}</div>
                <div style={{fontSize:15,fontWeight:700,color:"#f59e0b"}}>₺ {fmt((para.c200||0)*200)}</div>
              </div>
              <div style={{background:"#0f1117",border:"1px solid #3b82f633",borderRadius:8,padding:"10px 12px"}}>
                <div style={{fontSize:11,color:"#a2b1c6",marginBottom:4}}>
                  {bankaYedek.aktif ? `100 TL × ${fmtN(fazla100)} (fazla)` : `100 TL × ${fmtN(mevcut100)}`}
                </div>
                <div style={{fontSize:15,fontWeight:700,color:"#3b82f6"}}>₺ {fmt(bankaYedek.aktif?fazla100*100:mevcut100*100)}</div>
              </div>
            </div>

            {/* 50 TL dahil checkbox */}
            <label style={{display:"flex",alignItems:"center",gap:8,cursor:"pointer",background:"#0f1117",border:`1px solid ${dahil50?"#8b5cf6":"#1e293b"}`,borderRadius:8,padding:"10px 12px",marginBottom:10}}>
              <input type="checkbox" checked={dahil50} onChange={e=>setDahil50(e.target.checked)}/>
              <span style={{fontSize:11,color:dahil50?"#c4b5fd":"#a2b1c6"}}>
                100 adet üzeri 50 TL dahil et
                {dahil50&&(para.c50||0)>100&&<span style={{color:"#8b5cf6",marginLeft:6}}>(+{fmtN((para.c50-100))} adet = ₺{fmt((para.c50-100)*50)})</span>}
                {dahil50&&(para.c50||0)<=100&&<span style={{color:"#94a3b8",marginLeft:6}}>(50 TL adedi ≤ 100)</span>}
              </span>
            </label>

            {/* Kasa yapımı için gerekli 100 TL'yi dahil etme */}
            <label style={{display:"flex",alignItems:"center",gap:8,cursor:"pointer",background:"#0f1117",border:`1px solid ${bankaYedek.aktif?"#3b82f6":"#1e293b"}`,borderRadius:8,padding:"10px 12px",marginBottom:bankaYedek.aktif?8:10}}>
              <input type="checkbox" checked={bankaYedek.aktif} onChange={e=>setBankaYedek({aktif:e.target.checked})}/>
              <span style={{fontSize:11,color:bankaYedek.aktif?"#93c5fd":"#a2b1c6"}}>
                Kasa yapımı için gerekli 100 TL'yi dahil etme
              </span>
            </label>
            {bankaYedek.aktif&&(
              <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",background:"#0f1117",border:"1px solid #3b82f633",borderRadius:8,padding:"10px 12px",marginBottom:10}}>
                <span style={{fontSize:11,color:"#a2b1c6"}}>Kasada tutmak istediğim 100 TL adedi:</span>
                <input type="number" min={0} value={istenen100} onChange={e=>setBankaYedek({adet:parseInt(e.target.value)||0})} style={{background:"#141825",border:"1px solid #2d3748",borderRadius:7,color:"#e2e8f0",padding:"6px 10px",fontSize:12,fontFamily:"'IBM Plex Mono',monospace",width:80,textAlign:"center"}}/>
                <span style={{fontSize:11,color:"#94a3b8"}}>(kasa yapımı gereken: {fmtN(gereken100)})</span>
                {bankaYedek.adet!==null&&bankaYedek.adet!==gereken100&&(
                  <button onClick={()=>setBankaYedek({adet:null})} style={{marginLeft:"auto",background:"none",border:"none",color:"#a2b1c6",cursor:"pointer",fontSize:11,fontFamily:"inherit",textDecoration:"underline"}}>Varsayılana dön</button>
                )}
              </div>
            )}

            <div style={{background:"linear-gradient(135deg,#1e3a5f,#1a2a4a)",border:"1px solid #3b82f6",borderRadius:10,padding:"14px 16px",textAlign:"center"}}>
              <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase",marginBottom:6}}>TOPLAM BANKAYA YATACAK</div>
              <div style={{fontSize:26,fontWeight:700,color:"#60a5fa"}}>₺ {fmt(bankaTutar)}</div>
            </div>
          </div>
        </Card>
      </div>

      {/* SAĞ: Kasa Yapımı İçin Gerekli */}
      <div>
        <Card title="KASA YAPIMI İÇİN GEREKLİ" accent="#22c55e">
          <div style={{fontSize:11,color:"#a2b1c6",marginBottom:10}}>{kasaSayisi} kasa × ({kupurler.map(k=>`${k.tutar}TL:${k.adet}`).join(" + ")})</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:5,marginBottom:4}}>
            <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,padding:"4px 0"}}>KUPÜR</div>
            <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,textAlign:"center"}}>GEREKEN</div>
            <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,textAlign:"center"}}>FARK</div>
          </div>
          {kupurler.map(({tutar,adet},i)=>{
            const color=KUPUR_RENK[tutar]||["#8b5cf6","#22c55e","#06b6d4","#f97316","#eab308"][i%5];
            const gereken=(adet||0)*kasaSayisi;
            const mevcut=paraMevcut(tutar);
            const fark=mevcut-gereken;
            return(
              <div key={tutar} style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:5,alignItems:"center",marginBottom:5,padding:"7px 10px",background:"#0f1117",borderRadius:7,border:`1px solid ${color}22`}}>
                <div style={{display:"flex",alignItems:"center",gap:5}}><div style={{width:6,height:6,borderRadius:1,background:color}}/><span style={{fontSize:12,color:"#e2e8f0"}}>{tutar} TL</span></div>
                <div style={{textAlign:"center",fontSize:12,color:"#94a3b8"}}>{fmtN(gereken)} adet</div>
                <div style={{textAlign:"center",fontSize:13,fontWeight:700,color:fark>=0?"#4ade80":"#f87171"}}>
                  {fark>=0?"+":""}{fmtN(fark)}
                </div>
              </div>
            );
          })}
        </Card>

        {/* KASA FAZLASI / EKSİĞİ — sağ sütunda, Kasa Yapımı'nın altında */}
        <Card title="KASA FAZLASI / EKSİĞİ TAKİBİ" accent="#f97316">
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:14}}>
        {/* Fazla */}
        <div style={{background:"#0f1117",border:"1px solid #22c55e33",borderRadius:10,padding:"14px 16px"}}>
          <div style={{fontSize:11,color:"#4ade80",letterSpacing:1,marginBottom:10,fontWeight:700}}>➕ KASA FAZLASI</div>
          <div style={{fontSize:22,fontWeight:700,color:"#4ade80",marginBottom:12}}>₺ {fmt(kasaDurum.fazla||0)}</div>
          <ParaInput value={fazlaInput} onChange={setFazlaInput} placeholder="Tutar girin..." onEnter={applyFazla} style={{background:"#0a0e18",border:"1px solid #22c55e33",borderRadius:8,color:"#e2e8f0",padding:"8px 11px",fontSize:13,fontFamily:"'IBM Plex Mono',monospace",width:"100%",marginBottom:8,textAlign:"right"}}/>
          <button className="btn-hover" onClick={applyFazla} style={{width:"100%",background:"#14301f",border:"1px solid #22c55e",borderRadius:8,color:"#4ade80",cursor:"pointer",padding:"8px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>➕ EKLE</button>
        </div>
        {/* Eksik */}
        <div style={{background:"#0f1117",border:"1px solid #ef444433",borderRadius:10,padding:"14px 16px"}}>
          <div style={{fontSize:11,color:"#f87171",letterSpacing:1,marginBottom:10,fontWeight:700}}>➖ KASA EKSİĞİ</div>
          <div style={{fontSize:22,fontWeight:700,color:"#f87171",marginBottom:12}}>₺ {fmt(kasaDurum.eksik||0)}</div>
          <ParaInput value={eksikInput} onChange={setEksikInput} placeholder="Tutar girin..." onEnter={applyEksik} style={{background:"#0a0e18",border:"1px solid #ef444433",borderRadius:8,color:"#e2e8f0",padding:"8px 11px",fontSize:13,fontFamily:"'IBM Plex Mono',monospace",width:"100%",marginBottom:8,textAlign:"right"}}/>
          <button className="btn-hover" onClick={applyEksik} style={{width:"100%",background:"#2d1a1a",border:"1px solid #ef4444",borderRadius:8,color:"#f87171",cursor:"pointer",padding:"8px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>➖ EKLE</button>
        </div>
      </div>

      {/* Net durum + tarih + sıfırla */}
      <div style={{display:"flex",alignItems:"center",gap:12,flexWrap:"wrap",marginTop:4}}>
        <div style={{background:"#0f1117",border:`1px solid ${net>=0?"#22c55e33":"#ef444433"}`,borderRadius:10,padding:"12px 18px",flex:1,minWidth:180}}>
          <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,textTransform:"uppercase",marginBottom:4}}>NET DURUM</div>
          <div style={{fontSize:20,fontWeight:700,color:net>=0?"#4ade80":"#f87171"}}>{net>0?"✓ Fazla":net===0?"= Sıfır":"✗ Eksik"} &nbsp;₺ {fmt(Math.abs(net))}</div>
        </div>

        {/* Tarih navigasyonu */}
        <div style={{display:"flex",flexDirection:"column",gap:4}}>
          <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,marginBottom:2}}>SON KAYIT TARİHİ</div>
          <div style={{display:"flex",alignItems:"center",gap:6}}>
            <button onClick={()=>setKdTarih(addD(kdTarih,-1))} style={{background:"#0f1117",border:"1px solid #2d3748",borderRadius:7,color:"#94a3b8",cursor:"pointer",padding:"6px 10px",fontSize:13,fontFamily:"inherit"}}>◀</button>
            <div style={{textAlign:"center",minWidth:110}}>
              <div style={{fontSize:13,fontWeight:600,color:"#f1f5f9"}}>{fDSh(kdTarih)}</div>
              {kdTarih===addD(toS(new Date()),-1)&&<div style={{fontSize:9,color:"#a2b1c6"}}>dün</div>}
              {kdTarih===toS(new Date())&&<div style={{fontSize:9,color:"#4ade80"}}>bugün</div>}
            </div>
            <button onClick={()=>setKdTarih(addD(kdTarih,1))} style={{background:"#0f1117",border:"1px solid #2d3748",borderRadius:7,color:"#94a3b8",cursor:"pointer",padding:"6px 10px",fontSize:13,fontFamily:"inherit"}}>▶</button>
            <input type="date" value={kdTarih} onChange={e=>setKdTarih(e.target.value)} style={{background:"#0f1117",border:"1px solid #2d3748",borderRadius:7,color:"#a2b1c6",padding:"5px 8px",fontSize:11,fontFamily:"'IBM Plex Mono',monospace",width:36,opacity:0.7,cursor:"pointer"}} title="Tarih seç"/>
          </div>
          {kasaDurum.tarih&&<div style={{fontSize:11,color:"#94a3b8"}}>Son kaydedilen: {fDSh(kasaDurum.tarih)}</div>}
        </div>

        <button className="btn-hover" onClick={()=>setResetConfirm(true)} style={{background:"#1e293b",border:"1px solid #475569",borderRadius:9,color:"#94a3b8",cursor:"pointer",padding:"10px 18px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>🔄 SIFIRLA</button>
      </div>
    </Card>
      </div>
    </div>

    {/* Reset onay modal */}
    {resetConfirm&&(
      <div style={{position:"fixed",inset:0,background:"#00000099",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}}>
        <div style={{background:"#141825",border:"1px solid #ef4444",borderRadius:14,padding:"28px",width:400,maxWidth:"90vw",textAlign:"center"}}>
          <div style={{fontSize:28,marginBottom:12}}>⚠️</div>
          <div style={{fontSize:15,color:"#f1f5f9",fontWeight:600,marginBottom:8}}>Tutarları Sıfırla</div>
          <div style={{fontSize:12,color:"#94a3b8",marginBottom:20}}>Kasa fazlası ve eksiği sıfırlamak istediğinizden emin misiniz?</div>
          <div style={{display:"flex",gap:10,justifyContent:"center"}}>
            <button onClick={()=>setResetConfirm(false)} style={{background:"#1e293b",border:"1px solid #2d3748",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"9px 24px",fontSize:12,fontFamily:"inherit"}}>İptal</button>
            <button className="btn-hover" onClick={doReset} style={{background:"#7f1d1d",border:"1px solid #ef4444",borderRadius:8,color:"#f87171",cursor:"pointer",padding:"9px 24px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>Evet, Sıfırla</button>
          </div>
        </div>
      </div>
    )}
  </>);
}

/* ══════════════════════════════════════════════════════════════════════════
   KasaSayimiTab — aylık tam kasa sayımı
══════════════════════════════════════════════════════════════════════════ */
const SAYIM_BANKNOT=[["b200","200 TL",200,"#f59e0b"],["b100","100 TL",100,"#3b82f6"],["b50","50 TL",50,"#8b5cf6"],["b20","20 TL",20,"#22c55e"],["b10","10 TL",10,"#06b6d4"],["b5","5 TL (Kağıt)",5,"#f97316"],["b5m","5 TL (Madeni)",5,"#94a3b8"]];
const SAYIM_BOZUK=[["bp1","1 TL",1],["bp05","50 Kr",0.5],["bp025","25 Kr",0.25],["bp01","10 Kr",0.1],["bp005","5 Kr",0.05]];
const SAYIM_YEDEK=[["yk1","1 TL",1],["yk05","50 Kr",0.5],["yk025","25 Kr",0.25],["yk01","10 Kr",0.1],["yk005","5 Kr",0.05]];

function KasaSayimiTab({sayimlar,saveSayimlar}){
  const today=toS(new Date());
  const [tarih,setTarih]=useState(today);
  const [f,setF]=useState({...DEF_SAYIM});
  const [savedMsg,setSavedMsg]=useState("");
  const [silId,setSilId]=useState(null);

  const I={background:"#0f1117",border:"1px solid #2d3748",borderRadius:7,color:"#e2e8f0",padding:"6px 9px",fontSize:12,fontFamily:"'IBM Plex Mono',monospace",width:"100%"};
  const setNum=(k,v)=>setF(p=>({...p,[k]:v}));
  const g=k=>parseTR(f[k]);

  const calc=useMemo(()=>hesaplaSayim(f),[f]);

  // Önceki sayım (tarihe göre en yakın eski)
  const oncekiSayim=useMemo(()=>{
    const eskiler=sayimlar.filter(s=>s.tarih<tarih).sort((a,b)=>a.tarih<b.tarih?1:-1);
    return eskiler[0]||null;
  },[sayimlar,tarih]);
  const oncekiFE=oncekiSayim?hesaplaSayim(oncekiSayim).fazlaEksik:null;
  const fark=oncekiFE!==null?calc.fazlaEksik-oncekiFE:null;

  const kaydet=()=>{
    const kayit={id:uid(),tarih,...f,toplam:calc.toplam,fazlaEksik:calc.fazlaEksik};
    const yeni=[...sayimlar.filter(s=>s.id!==kayit.id),kayit].sort((a,b)=>a.tarih<b.tarih?-1:1);
    saveSayimlar(yeni);
    setSavedMsg("✓ Sayım kaydedildi");setTimeout(()=>setSavedMsg(""),2500);
  };
  const sayimYukle=s=>{
    setTarih(s.tarih);
    const nf={...DEF_SAYIM};SAYIM_KEYS.forEach(k=>{if(k!=="tarih")nf[k]=s[k]??0;});
    nf.kasaBirim=s.kasaBirim??2000;
    nf.avansBirim=s.avansBirim??2000;
    setF(nf);
    window.scrollTo({top:0,behavior:"smooth"});
  };
  const sayimSil=id=>{saveSayimlar(sayimlar.filter(s=>s.id!==id));setSilId(null);};

  return(<>
    {savedMsg&&<div className="fi" style={{background:"#14301f",border:"1px solid #22c55e",borderRadius:9,padding:"10px 16px",marginBottom:12,fontSize:12,color:"#4ade80"}}>{savedMsg}</div>}

    {/* Tarih + sonuç özeti */}
    <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:14,alignItems:"stretch"}}>
      <div style={{background:"#141825",border:"1px solid #1e293b",borderRadius:12,padding:"14px 18px",display:"flex",alignItems:"center",gap:10}}>
        <span style={{fontSize:11,color:"#a2b1c6",letterSpacing:1}}>SAYIM TARİHİ</span>
        <input type="date" value={tarih} onChange={e=>setTarih(e.target.value)} style={{...I,width:150,fontSize:13}}/>
      </div>
      <div style={{flex:1,minWidth:180,background:"linear-gradient(135deg,#141825,#1a2035)",border:"1px solid #2d3a5c",borderRadius:12,padding:"12px 18px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:12}}>
        <div><div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,marginBottom:2}}>SAYIM TOPLAMI</div><div style={{fontSize:22,fontWeight:700,color:"#f1f5f9"}}>₺ {fmt(calc.toplam)}</div></div>
        <div style={{textAlign:"right"}}>
          <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,marginBottom:2}}>KASA FAZLASI/EKSİĞİ</div>
          <div style={{fontSize:20,fontWeight:700,color:calc.fazlaEksik>=0?"#4ade80":"#f87171"}}>{calc.fazlaEksik>=0?"+":""}{fmt(calc.fazlaEksik)}</div>
          {fark!==null&&<div style={{fontSize:11,color:fark>=0?"#4ade80":"#f87171",marginTop:2}}>önceki sayıma göre: {fark>=0?"+":""}{fmt(fark)}</div>}
        </div>
      </div>
      <button className="btn-hover" onClick={kaydet} style={{background:"#166534",border:"1px solid #22c55e",borderRadius:12,color:"#4ade80",cursor:"pointer",padding:"0 28px",fontSize:14,fontFamily:"inherit",fontWeight:700,letterSpacing:1}}>💾 SAYIMI KAYDET</button>
    </div>

    {/* Giriş alanları — 3 sütun */}
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12,marginBottom:14}}>

      {/* Banknotlar */}
      <Card title="BANKNOTLAR (KAĞIT)" accent="#3b82f6">
        <div style={{display:"grid",gridTemplateColumns:"1fr 70px 90px",gap:6,marginBottom:4,fontSize:9,color:"#94a3b8",letterSpacing:1}}>
          <div>KUPÜR</div><div style={{textAlign:"center"}}>ADET</div><div style={{textAlign:"right"}}>TUTAR</div>
        </div>
        {SAYIM_BANKNOT.map(([k,label,birim,renk])=>(
          <div key={k} style={{display:"grid",gridTemplateColumns:"1fr 70px 90px",gap:6,alignItems:"center",padding:"3px 0"}}>
            <div style={{display:"flex",alignItems:"center",gap:6}}><div style={{width:6,height:6,borderRadius:1,background:renk}}/><span style={{fontSize:11,color:"#cbd5e1"}}>{label}</span></div>
            <input type="number" min="0" value={f[k]===0?"":f[k]} placeholder="0" onChange={e=>setNum(k,e.target.value)} style={{...I,textAlign:"center"}}/>
            <div style={{textAlign:"right",fontSize:11,color:renk}}>₺{fmt(g(k)*birim)}</div>
          </div>
        ))}
      </Card>

      {/* Bozuk Para */}
      <Card title="BOZUK PARA (MADENİ)" accent="#f59e0b">
        <div style={{display:"grid",gridTemplateColumns:"1fr 70px 90px",gap:6,marginBottom:4,fontSize:9,color:"#94a3b8",letterSpacing:1}}>
          <div>KUPÜR</div><div style={{textAlign:"center"}}>ADET</div><div style={{textAlign:"right"}}>TUTAR</div>
        </div>
        {SAYIM_BOZUK.map(([k,label,birim])=>(
          <div key={k} style={{display:"grid",gridTemplateColumns:"1fr 70px 90px",gap:6,alignItems:"center",padding:"3px 0"}}>
            <div style={{display:"flex",alignItems:"center",gap:6}}><div style={{width:6,height:6,borderRadius:1,background:"#f59e0b"}}/><span style={{fontSize:11,color:"#cbd5e1"}}>{label}</span></div>
            <input type="number" min="0" value={f[k]===0?"":f[k]} placeholder="0" onChange={e=>setNum(k,e.target.value)} style={{...I,textAlign:"center"}}/>
            <div style={{textAlign:"right",fontSize:11,color:"#f59e0b"}}>₺{fmt(g(k)*birim)}</div>
          </div>
        ))}
        <div style={{height:1,background:"#1e293b",margin:"8px 0"}}/>
        <div style={{display:"grid",gridTemplateColumns:"1fr 90px",gap:6,alignItems:"center"}}>
          <span style={{fontSize:11,color:"#cbd5e1"}}>Bozuk Para Karışık (₺)</span>
          <ParaInput value={f.bozukKarisik===0?"":f.bozukKarisik} onChange={v=>setNum("bozukKarisik",v)} style={{...I,textAlign:"right"}}/>
        </div>
      </Card>

      {/* Diğer kalemler */}
      <Card title="DİĞER KALEMLER" accent="#a855f7">
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div>
            <div style={{fontSize:11,color:"#a2b1c6",marginBottom:3,letterSpacing:.5}}>ALACAK (₺)</div>
            <ParaInput value={f.alacak===0?"":f.alacak} onChange={v=>setNum("alacak",v)} style={{...I,textAlign:"right"}}/>
          </div>
          <div>
            <div style={{fontSize:11,color:"#a2b1c6",marginBottom:3,letterSpacing:.5}}>KASALAR</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 74px 90px",gap:6,alignItems:"center"}}>
              <input type="number" value={f.kasalarAdet===0?"":f.kasalarAdet} placeholder="adet" onChange={e=>setNum("kasalarAdet",e.target.value)} style={{...I}}/>
              <div style={{display:"flex",alignItems:"center",gap:3}}>
                <span style={{fontSize:11,color:"#a2b1c6"}}>×</span>
                <ParaInput value={f.kasaBirim===0?"":f.kasaBirim} onChange={v=>setNum("kasaBirim",v)} placeholder="2000" style={{...I,padding:"6px 8px",fontSize:11,textAlign:"center"}}/>
              </div>
              <div style={{textAlign:"right",fontSize:11,color:"#c084fc"}}>₺{fmt(calc.kasalar)}</div>
            </div>
          </div>
          <div>
            <div style={{fontSize:11,color:"#a2b1c6",marginBottom:3,letterSpacing:.5}}>KASALAR AVANS</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 74px 90px",gap:6,alignItems:"center"}}>
              <input type="number" value={f.avansAdet===0?"":f.avansAdet} placeholder="adet" onChange={e=>setNum("avansAdet",e.target.value)} style={{...I}}/>
              <div style={{display:"flex",alignItems:"center",gap:3}}>
                <span style={{fontSize:11,color:"#a2b1c6"}}>×</span>
                <ParaInput value={f.avansBirim===0?"":f.avansBirim} onChange={v=>setNum("avansBirim",v)} placeholder="2000" style={{...I,padding:"6px 8px",fontSize:11,textAlign:"center"}}/>
              </div>
              <div style={{textAlign:"right",fontSize:11,color:"#c084fc"}}>₺{fmt(calc.avans)}</div>
            </div>
          </div>
          <div>
            <div style={{fontSize:11,color:"#a2b1c6",marginBottom:3,letterSpacing:.5}}>KASA YEDEK SABİT (₺)</div>
            <ParaInput value={f.kasaYedekSabit===0?"":f.kasaYedekSabit} onChange={v=>setNum("kasaYedekSabit",v)} placeholder="1750" style={{...I,textAlign:"right"}}/>
          </div>
          <div style={{height:1,background:"#1e293b",margin:"2px 0"}}/>
          <div>
            <div style={{fontSize:11,color:"#a2b1c6",marginBottom:3,letterSpacing:.5,fontWeight:600,color:"#ef4444"}}>★ MERKEZ KASA (Olması gereken ₺)</div>
            <ParaInput value={f.merkezKasa===0?"":f.merkezKasa} onChange={v=>setNum("merkezKasa",v)} style={{...I,border:"1px solid #ef444455",textAlign:"right"}}/>
          </div>
        </div>
      </Card>
    </div>

    {/* Yedek bozuk para (sabit rezerv) */}
    <Card title="KASA YEDEK BOZUK PARA (Sabit Rezerv)" accent="#14b8a6">
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))",gap:10}}>
        {SAYIM_YEDEK.map(([k,label,birim])=>(
          <div key={k} style={{display:"grid",gridTemplateColumns:"1fr 60px 80px",gap:5,alignItems:"center"}}>
            <span style={{fontSize:11,color:"#cbd5e1"}}>{label}</span>
            <input type="number" value={f[k]===0?"":f[k]} placeholder="0" onChange={e=>setNum(k,e.target.value)} style={{...I,textAlign:"center",fontSize:11,padding:"5px"}}/>
            <span style={{fontSize:11,color:"#2dd4bf",textAlign:"right"}}>₺{fmt(g(k)*birim)}</span>
          </div>
        ))}
      </div>
      <div style={{marginTop:8,fontSize:11,color:"#a2b1c6",textAlign:"right"}}>Yedek bozuk toplam: <span style={{color:"#2dd4bf",fontWeight:600}}>₺{fmt(calc.yedekBozuk)}</span></div>
    </Card>

    {/* Geçmiş sayımlar */}
    <div style={{background:"#141825",border:"1px solid #1e293b",borderRadius:12,overflow:"hidden",marginTop:4}}>
      <div style={{padding:"11px 16px",borderBottom:"1px solid #1e293b",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <span style={{fontSize:11,color:"#a2b1c6",letterSpacing:2,textTransform:"uppercase"}}>GEÇMİŞ SAYIMLAR</span>
        <span style={{fontSize:11,color:"#a2b1c6"}}>{sayimlar.length} sayım</span>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"110px 1fr 1fr 1fr 130px 70px 60px",gap:6,padding:"7px 14px",borderBottom:"1px solid #1e293b",fontSize:11,color:"#a2b1c6",letterSpacing:1}}>
        <div>TARİH</div><div style={{textAlign:"right"}}>TOPLAM</div><div style={{textAlign:"right"}}>MERKEZ KASA</div><div style={{textAlign:"right"}}>FAZLA/EKSİK</div><div style={{textAlign:"right"}}>ÖNCEKİ FARK</div><div style={{textAlign:"center"}}>YÜKLE</div><div style={{textAlign:"center"}}>SİL</div>
      </div>
      <div style={{maxHeight:300,overflowY:"auto"}}>
        {sayimlar.length===0&&<div style={{textAlign:"center",padding:"30px",color:"#94a3b8",fontSize:12}}>Henüz sayım yok</div>}
        {[...sayimlar].sort((a,b)=>a.tarih<b.tarih?1:-1).map((s,i,arr)=>{
          const c=hesaplaSayim(s);
          // önceki (tarihçe sıralı)
          const oncekiList=sayimlar.filter(x=>x.tarih<s.tarih).sort((a,b)=>a.tarih<b.tarih?1:-1);
          const onceki=oncekiList[0];
          const oFark=onceki?c.fazlaEksik-hesaplaSayim(onceki).fazlaEksik:null;
          return(
            <div key={s.id} className="row-hover" style={{display:"grid",gridTemplateColumns:"110px 1fr 1fr 1fr 130px 70px 60px",gap:6,padding:"8px 14px",background:i%2===0?"transparent":"#0d1020",borderBottom:"1px solid #1e293b1a",alignItems:"center",fontSize:12}}>
              <div style={{color:"#e2e8f0"}}>{fDSh(s.tarih)}</div>
              <div style={{textAlign:"right",color:"#f1f5f9",fontWeight:600}}>₺{fmt(c.toplam)}</div>
              <div style={{textAlign:"right",color:"#94a3b8"}}>₺{fmt(s.merkezKasa||0)}</div>
              <div style={{textAlign:"right",fontWeight:700,color:c.fazlaEksik>=0?"#4ade80":"#f87171"}}>{c.fazlaEksik>=0?"+":""}{fmt(c.fazlaEksik)}</div>
              <div style={{textAlign:"right",fontSize:11,color:oFark===null?"#94a3b8":(oFark>=0?"#4ade80":"#f87171")}}>{oFark===null?"—":(oFark>=0?"+":"")+fmt(oFark)}</div>
              <div style={{textAlign:"center"}}><button onClick={()=>sayimYukle(s)} style={{background:"#1e3a5f",border:"1px solid #3b82f633",borderRadius:6,color:"#60a5fa",cursor:"pointer",padding:"3px 9px",fontSize:11,fontFamily:"inherit"}}>↑ Yükle</button></div>
              <div style={{textAlign:"center"}}><button aria-label="Kapat" onClick={()=>setSilId(s.id)} style={{background:"none",border:"none",color:"#94a3b8",cursor:"pointer",fontSize:13,fontFamily:"inherit"}} onMouseEnter={e=>e.target.style.color="#ef4444"} onMouseLeave={e=>e.target.style.color="#94a3b8"}><UiIcon kind="close"/></button></div>
            </div>
          );
        })}
      </div>
    </div>

    {/* Sil onay */}
    {silId&&(
      <div style={{position:"fixed",inset:0,background:"#00000099",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}}>
        <div style={{background:"#141825",border:"1px solid #ef4444",borderRadius:14,padding:"26px",width:380,maxWidth:"90vw",textAlign:"center"}}>
          <div style={{fontSize:26,marginBottom:10}}>⚠️</div>
          <div style={{fontSize:14,color:"#f1f5f9",fontWeight:600,marginBottom:8}}>Sayımı Sil</div>
          <div style={{fontSize:12,color:"#94a3b8",marginBottom:18}}>Bu kasa sayımı kaydı silinsin mi?</div>
          <div style={{display:"flex",gap:10,justifyContent:"center"}}>
            <button onClick={()=>setSilId(null)} style={{background:"#1e293b",border:"1px solid #2d3748",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"9px 22px",fontSize:12,fontFamily:"inherit"}}>İptal</button>
            <button className="btn-hover" onClick={()=>sayimSil(silId)} style={{background:"#7f1d1d",border:"1px solid #ef4444",borderRadius:8,color:"#f87171",cursor:"pointer",padding:"9px 22px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>Evet, Sil</button>
          </div>
        </div>
      </div>
    )}
  </>);
}

/* ══════════════════════════════════════════════════════════════════════════
   AyarlarTab
══════════════════════════════════════════════════════════════════════════ */
function KasaAyarSatiri({k,bankalar,onSave,onDelete}){
 const [editing,setEditing]=useState(false),[draft,setDraft]=useState({...k}),[error,setError]=useState("");
 useEffect(()=>{if(!editing)setDraft({...k});},[k,editing]);
 const I={background:editing?"#0f1117":"#101723",border:"1px solid #2d3748",borderRadius:7,color:editing?"#e2e8f0":"#94a3b8",padding:"7px 9px",fontSize:12,fontFamily:"inherit",width:"100%"};
 const B={background:"#1e3a5f",border:"1px solid #36577c",borderRadius:7,color:"#bfdbfe",padding:"7px 10px",fontSize:11,fontFamily:"inherit",cursor:"pointer"};
 return <div data-kasa-row={k.id} style={{background:"#0f1117",border:"1px solid #28374c",borderRadius:9,padding:12}}>
 <div style={{display:"grid",gridTemplateColumns:"minmax(130px,1fr) 120px minmax(120px,1fr) 150px auto",alignItems:"center",gap:10}}>
 <input aria-label="Kasa adı" disabled={!editing} style={I} value={draft.ad} onChange={e=>setDraft(v=>({...v,ad:e.target.value}))}/>
 <input aria-label="Kasa numarası" disabled={!editing} style={I} value={draft.kod} onChange={e=>setDraft(v=>({...v,kod:e.target.value}))}/>
 <select aria-label="Kasa bankası" disabled={!editing} style={I} value={draft.bankaId} onChange={e=>setDraft(v=>({...v,bankaId:e.target.value}))}>{bankalar.map(b=><option key={b.id} value={b.id}>{b.ad}</option>)}</select>
 <div style={{fontSize:11,color:"#cbd5e1",lineHeight:1.8}}><label><input type="checkbox" disabled={!editing} checked={draft.aktif!==false} onChange={e=>setDraft(v=>({...v,aktif:e.target.checked}))}/> Aktif</label><br/><label><input type="checkbox" disabled={!editing} checked={!!draft.toplamModu} onChange={e=>setDraft(v=>({...v,toplamModu:e.target.checked}))}/> Toplam POS takibi</label></div>
 <div style={{display:"flex",gap:6,flexWrap:"wrap",maxWidth:190}}>{editing?<><button style={B} onClick={()=>{try{onSave(draft);setEditing(false);setError("");}catch(e){setError(e.message);}}}>Kaydet</button><button style={B} onClick={()=>{setDraft({...k});setEditing(false);setError("");}}>Vazgeç</button><button style={{...B,color:"#fca5a5"}} onClick={onDelete}>Sil</button></>:<button aria-label={"Düzenle: "+k.ad} style={B} onClick={()=>setEditing(true)}><UiIcon kind="edit"/> Düzenle</button>}</div>
 </div>{error&&<p role="alert" style={{color:"#fca5a5",fontSize:12,marginTop:8}}>{error}</p>}</div>;
}

function AyarlarTab({cfg,saveCfg,txs,paraLog,kasaLog,sayimlar,onReload}){
  const [dVade,setDVade]=useState({...cfg.vadeGunleri});
  const [dB,setDB]=useState([...cfg.bankalar]);
  const [dK,setDK]=useState([...cfg.kasalar]);
  const [dKY,setDKY]=useState({...cfg.kasaYapim}||{...DEF_CFG.kasaYapim});
  const [newBAd,setNewBAd]=useState("");
  const [newK,setNewK]=useState({ad:"",kod:"",bankaId:cfg.bankalar[0]?.id||""});
  const [ok,setOk]=useState(false);
  const [yedekMsg,setYedekMsg]=useState("");
  const [pendingFile,setPendingFile]=useState(null);
  const fileInputRef=useRef(null);

  const I={background:"#0f1117",border:"1px solid #2d3748",borderRadius:8,color:"#e2e8f0",padding:"9px 12px",fontSize:13,fontFamily:"'IBM Plex Mono',monospace",width:"100%"};
  const addBanka=()=>{if(!newBAd.trim())return;setDB(p=>[...p,{id:uid(),ad:newBAd.trim()}]);setNewBAd("");};
  const delBanka=id=>{if(dK.some(k=>k.bankaId===id)){alert("Önce bu bankaya ait kasaları silin!");return;}setDB(p=>p.filter(b=>b.id!==id));};
  const addKasa=()=>{if(!newK.ad.trim()||!newK.kod.trim())return;setDK(p=>[...p,{id:uid(),...newK}]);setNewK({ad:"",kod:"",bankaId:dB[0]?.id||""});};
  const delKasa=id=>{if(txs.some(t=>t.kasaId===id)){alert("Bu kasanın geçmiş işlemleri var. Silmek yerine pasife alın.");return;}if(confirm("Kasa silinsin mi?"))setDK(p=>p.filter(k=>k.id!==id));};
  const doSave=()=>{try{POSGuard.config({...cfg,vadeGunleri:dVade,bankalar:dB,kasalar:dK});}catch(e){alert(e.message);return;}if(dK.some(k=>!k.ad.trim()||!k.kod.trim())){alert("Kasa adı ve numarası boş bırakılamaz.");return;}if(saveCfg({...cfg,vadeGunleri:dVade,bankalar:dB,kasalar:dK,kasaYapim:dKY})===false)return;setOk(true);setTimeout(()=>setOk(false),2200);};

  const yMsg=m=>{setYedekMsg(m);setTimeout(()=>setYedekMsg(""),3000);};
  const handleFileSelect=e=>{const f=e.target.files[0];if(f)setPendingFile(f);e.target.value="";};
  const confirmRestore=()=>{
    jsonGeriYukle(pendingFile,(success,msg)=>{
      if(success){setPendingFile(null);yMsg("✓ "+msg);setTimeout(()=>onReload(),900);}
      else{setPendingFile(null);alert(msg);}
    });
  };

  return(<>
    <SB label="VADE GÜNLERİ" accent="#3b82f6">
      <div style={{fontSize:11,color:"#94a3b8",marginBottom:12}}>ℹ Değişiklikler yalnızca yeni kayıtlara uygulanır.</div>
      <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
        {["KREDİ KARTI","DEBİT KART"].map(tur=>(
          <div key={tur} style={{background:"#0f1117",border:"1px solid #1e293b",borderRadius:10,padding:"13px 16px",minWidth:180}}>
            <div style={{fontSize:11,color:"#a2b1c6",letterSpacing:1,marginBottom:7}}>{tur==="KREDİ KARTI"?"💳 KREDİ KARTI":"🏧 DEBİT KART"}</div>
            <div style={{display:"flex",alignItems:"center",gap:8}}><input type="number" min={0} max={365} step={1} value={dVade[tur]||0} onChange={e=>setDVade(v=>({...v,[tur]:e.target.value===""?0:Number(e.target.value)}))} style={{...I,width:70,textAlign:"center"}}/><span style={{color:"#a2b1c6",fontSize:12}}>gün</span></div>
          </div>
        ))}
      </div>
    </SB>

    <SB label="KASA YAPIMI VARSAYILANLARI" accent="#22c55e">
      <div style={{fontSize:11,color:"#94a3b8",marginBottom:12}}>Her kasa için gereken kupür adedi ve toplam kasa sayısı. İstediğin kupürü (100, 200 TL dahil) ekleyip çıkarabilirsin.</div>

      <div style={{marginBottom:12}}>
        <div style={{fontSize:11,color:"#a2b1c6",marginBottom:7,letterSpacing:.5}}>KASA SAYISI</div>
        <input type="number" min={0} value={dKY.kasaSayisi??0} onChange={e=>setDKY(v=>({...v,kasaSayisi:parseInt(e.target.value)||0}))} style={{...I,width:140,textAlign:"center"}}/>
      </div>

      <div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:12}}>
        {(dKY.kupurler||[]).slice().sort((a,b)=>b.tutar-a.tutar).map((k,i)=>{
          const renk=KUPUR_RENK[k.tutar]||"#94a3b8";
          return(
            <div key={k.tutar} style={{display:"flex",alignItems:"center",gap:10,background:"#0f1117",border:`1px solid ${renk}33`,borderRadius:9,padding:"9px 14px"}}>
              <div style={{width:8,height:8,borderRadius:2,background:renk,flexShrink:0}}/>
              <span style={{fontSize:13,color:"#e2e8f0",width:70}}>{k.tutar} TL</span>
              <span style={{fontSize:11,color:"#a2b1c6"}}>kasa başına adet:</span>
              <input type="number" min={0} value={k.adet??0} onChange={e=>{
                const yeni=parseInt(e.target.value)||0;
                setDKY(v=>({...v,kupurler:v.kupurler.map(x=>x.tutar===k.tutar?{...x,adet:yeni}:x)}));
              }} style={{...I,width:80,textAlign:"center"}}/>
              <button onClick={()=>setDKY(v=>({...v,kupurler:v.kupurler.filter(x=>x.tutar!==k.tutar)}))} style={{marginLeft:"auto",background:"none",border:"none",color:"#94a3b8",cursor:"pointer",fontSize:12,fontFamily:"inherit"}} onMouseEnter={e=>e.target.style.color="#ef4444"} onMouseLeave={e=>e.target.style.color="#94a3b8"}>✕ Sil</button>
            </div>
          );
        })}
      </div>

      {/* Yeni kupür ekleme */}
      <div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}>
        <span style={{fontSize:11,color:"#a2b1c6"}}>Yeni kupür ekle:</span>
        {[200,100,50,20,10,5].filter(t=>!(dKY.kupurler||[]).some(k=>k.tutar===t)).map(t=>(
          <button key={t} onClick={()=>setDKY(v=>({...v,kupurler:[...(v.kupurler||[]),{tutar:t,adet:0}]}))} style={{background:"#0f1117",border:`1px solid ${KUPUR_RENK[t]}55`,borderRadius:7,color:KUPUR_RENK[t],cursor:"pointer",padding:"6px 13px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>+ {t} TL</button>
        ))}
        {[200,100,50,20,10,5].every(t=>(dKY.kupurler||[]).some(k=>k.tutar===t)) &&
          <span style={{fontSize:11,color:"#94a3b8"}}>Tüm standart kupürler eklendi</span>}
      </div>

      <div style={{fontSize:11,color:"#94a3b8",marginTop:12}}>
        Toplam ihtiyaç ({dKY.kasaSayisi||0} kasa): {(dKY.kupurler||[]).slice().sort((a,b)=>b.tutar-a.tutar).map(k=>`${k.tutar}TL×${(k.adet||0)*(dKY.kasaSayisi||0)}`).join(" · ")}
      </div>
    </SB>

    <SB label="BANKALAR" accent="#ec4899">
      <div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:12}}>
        {dB.map((b,bi)=>(
          <div key={b.id} style={{display:"flex",alignItems:"center",justifyContent:"space-between",background:"#0f1117",border:`1px solid ${BCOLS[bi%BCOLS.length]}33`,borderRadius:8,padding:"9px 14px"}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}><div style={{width:8,height:8,borderRadius:2,background:BCOLS[bi%BCOLS.length]}}/><span style={{fontSize:13,color:"#e2e8f0"}}>{b.ad}</span><span style={{fontSize:11,color:"#94a3b8"}}>({dK.filter(k=>k.bankaId===b.id).length} kasa)</span></div>
            <button onClick={()=>delBanka(b.id)} style={{background:"none",border:"none",color:"#94a3b8",cursor:"pointer",fontSize:12,fontFamily:"inherit"}} onMouseEnter={e=>e.target.style.color="#ef4444"} onMouseLeave={e=>e.target.style.color="#94a3b8"}>✕ Sil</button>
          </div>
        ))}
      </div>
      <div style={{display:"flex",gap:8}}><input placeholder="Yeni banka adı..." value={newBAd} onChange={e=>setNewBAd(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addBanka()} style={{...I,flex:1}}/><button onClick={addBanka} style={{background:"#1e3a5f",border:"1px solid #3b82f6",borderRadius:8,color:"#60a5fa",cursor:"pointer",padding:"9px 16px",fontSize:12,fontFamily:"inherit",whiteSpace:"nowrap"}}>+ Ekle</button></div>
    </SB>

    <SB label="KASALAR / POS TERMİNALLERİ" accent="#f97316">
      <div style={{display:"flex",flexDirection:"column",gap:6,marginBottom:12}}>
        {dK.map(k=><KasaAyarSatiri key={k.id} k={k} bankalar={dB} onSave={next=>{
          const cleaned={...next,ad:next.ad.trim(),kod:next.kod.trim()};
          if(!cleaned.ad||!cleaned.kod)throw Error("Kasa adı ve numarası boş bırakılamaz.");
          if(!cfg.bankalar.some(b=>b.id===cleaned.bankaId))throw Error("Önce bankayı genel Kaydet ile kaydedin.");
          if(dK.some(x=>x.id!==cleaned.id&&x.bankaId===cleaned.bankaId&&x.kod===cleaned.kod))throw Error("Bu bankada aynı kasa numarası zaten var.");
          const exists=cfg.kasalar.some(x=>x.id===cleaned.id);
          if(saveCfg({...cfg,kasalar:exists?cfg.kasalar.map(x=>x.id===cleaned.id?cleaned:x):[...cfg.kasalar,cleaned]})===false)throw Error("Kasa kaydedilemedi.");
          setDK(p=>p.map(x=>x.id===cleaned.id?cleaned:x));
        }} onDelete={()=>delKasa(k.id)}/>)}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 120px 1fr auto",gap:8,alignItems:"end"}}>
        <div><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>KASA ADI</div><input placeholder="KASA 5" value={newK.ad} onChange={e=>setNewK(v=>({...v,ad:e.target.value}))} style={{...I}}/></div>
        <div><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>KOD</div><input placeholder="123456" value={newK.kod} onChange={e=>setNewK(v=>({...v,kod:e.target.value}))} style={{...I}}/></div>
        <div><div style={{fontSize:11,color:"#a2b1c6",marginBottom:5,letterSpacing:1}}>BANKA</div><select value={newK.bankaId} onChange={e=>setNewK(v=>({...v,bankaId:e.target.value}))} style={{...I}}>{dB.map(b=><option key={b.id} value={b.id}>{b.ad}</option>)}</select></div>
        <button onClick={addKasa} style={{background:"#1e3a5f",border:"1px solid #3b82f6",borderRadius:8,color:"#60a5fa",cursor:"pointer",padding:"9px 16px",fontSize:12,fontFamily:"inherit",whiteSpace:"nowrap"}}>+ Ekle</button>
      </div>
    </SB>

    <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:14}}>
      <button className="btn-hover" onClick={doSave} style={{background:"#166534",border:"1px solid #22c55e",borderRadius:10,color:"#4ade80",cursor:"pointer",padding:"11px 28px",fontSize:13,fontFamily:"inherit",fontWeight:600,letterSpacing:1}}>✓ KAYDET</button>
      {ok&&<span className="fi" style={{fontSize:12,color:"#4ade80"}}>✓ Ayarlar kaydedildi</span>}
    </div>

    {/* YEDEKLEME VE DIŞA AKTARMA */}
    <SB label="YEDEKLEME VE DIŞA AKTARMA" accent="#a855f7">
      {yedekMsg&&<div className="fi" style={{background:"#14301f",border:"1px solid #22c55e",borderRadius:8,padding:"9px 14px",marginBottom:12,fontSize:12,color:"#4ade80"}}>{yedekMsg}</div>}

      {/* Tam yedek */}
      <div style={{marginBottom:14}}>
        <div style={{fontSize:11,color:"#94a3b8",marginBottom:8,fontWeight:600}}>💾 TAM YEDEK (Tüm veriler — başka bilgisayara taşımak için)</div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          <button className="btn-hover" onClick={jsonYedekAl} style={{background:"#1e3a5f",border:"1px solid #3b82f6",borderRadius:8,color:"#60a5fa",cursor:"pointer",padding:"10px 18px",fontSize:12,fontFamily:"inherit",fontWeight:600}}><UiIcon kind="download"/> Yedek Dosyası İndir (.json)</button>
          <button className="btn-hover" onClick={()=>fileInputRef.current?.click()} style={{background:"#2d1f3d",border:"1px solid #a855f7",borderRadius:8,color:"#c084fc",cursor:"pointer",padding:"10px 18px",fontSize:12,fontFamily:"inherit",fontWeight:600}}><UiIcon kind="upload"/> Yedekten Geri Yükle</button>
          <input ref={fileInputRef} type="file" accept=".json" onChange={handleFileSelect} style={{display:"none"}}/>
        </div>
        <div style={{fontSize:11,color:"#94a3b8",marginTop:6}}>Yedek dosyası işlemleri, ayarları, para sayımını ve kasa durumunu içerir.</div>
      </div>

      <div style={{height:1,background:"#1e293b",margin:"14px 0"}}/>

      {/* Excel */}
      <div>
        <div style={{fontSize:11,color:"#94a3b8",marginBottom:8,fontWeight:600}}>📊 EXCEL'E AKTAR</div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          <button className="btn-hover" onClick={()=>excelIslemGecmisi(txs,cfg)} style={{background:"#14301f",border:"1px solid #22c55e",borderRadius:8,color:"#4ade80",cursor:"pointer",padding:"10px 16px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>📋 İşlem Geçmişi</button>
          <button className="btn-hover" onClick={()=>excelGunlukRapor(txs,cfg)} style={{background:"#14301f",border:"1px solid #22c55e",borderRadius:8,color:"#4ade80",cursor:"pointer",padding:"10px 16px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>📅 Günlük Yatış Raporu</button>
          <button className="btn-hover" onClick={()=>excelParaLog(paraLog)} style={{background:"#2d2410",border:"1px solid #f59e0b",borderRadius:8,color:"#fbbf24",cursor:"pointer",padding:"10px 16px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>💵 Para Giriş/Çıkış Dökümü</button>
          <button className="btn-hover" onClick={()=>excelKasaLog(kasaLog)} style={{background:"#2d1810",border:"1px solid #f97316",borderRadius:8,color:"#fb923c",cursor:"pointer",padding:"10px 16px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>⚖️ Kasa Fazla/Eksik Dökümü</button>
          <button className="btn-hover" onClick={()=>excelKasaSayimi(sayimlar)} style={{background:"#1a2d2a",border:"1px solid #14b8a6",borderRadius:8,color:"#2dd4bf",cursor:"pointer",padding:"10px 16px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>🧮 Kasa Sayımı Dökümü</button>
        </div>
        <div style={{fontSize:11,color:"#94a3b8",marginTop:6}}>
          {txs.length} işlem · {(paraLog||[]).length} para kaydı · {(kasaLog||[]).length} kasa kaydı · {(sayimlar||[]).length} sayım · Dosyalar "İndirilenler" klasörüne kaydedilir.
        </div>
      </div>
    </SB>

    {/* Geri yükleme onay modalı */}
    {pendingFile&&(
      <div style={{position:"fixed",inset:0,background:"#00000099",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}}>
        <div style={{background:"#141825",border:"1px solid #a855f7",borderRadius:14,padding:"28px",width:430,maxWidth:"90vw",textAlign:"center"}}>
          <div style={{fontSize:28,marginBottom:12}}>⚠️</div>
          <div style={{fontSize:15,color:"#f1f5f9",fontWeight:600,marginBottom:8}}>Yedekten Geri Yükle</div>
          <div style={{fontSize:12,color:"#94a3b8",marginBottom:6}}>Seçilen dosya: <span style={{color:"#c084fc"}}>{pendingFile.name}</span></div>
          <div style={{fontSize:12,color:"#f87171",marginBottom:20}}>Önce dosya doğrulanacak, değişecek alanlar gösterilecek ve güvenlik yedeği istenecek. Devam edilsin mi?</div>
          <div style={{display:"flex",gap:10,justifyContent:"center"}}>
            <button onClick={()=>setPendingFile(null)} style={{background:"#1e293b",border:"1px solid #2d3748",borderRadius:8,color:"#94a3b8",cursor:"pointer",padding:"9px 24px",fontSize:12,fontFamily:"inherit"}}>İptal</button>
            <button className="btn-hover" onClick={confirmRestore} style={{background:"#2d1f3d",border:"1px solid #a855f7",borderRadius:8,color:"#c084fc",cursor:"pointer",padding:"9px 24px",fontSize:12,fontFamily:"inherit",fontWeight:600}}>Evet, Geri Yükle</button>
          </div>
        </div>
      </div>
    )}
  </>);
}

/* ── Boot ── */
let bootError="";
try{POSGuard.recover(localStorage);const raw={};for(const k of POSGuard.KEYS){const text=localStorage.getItem("pos:"+k);if(text!==null)raw[k]=JSON.parse(text);}if(Object.hasOwn(raw,"cfg")||Object.hasOwn(raw,"txs"))POSGuard.validatePackage(raw,{},DEF_CFG);}catch(e){bootError=e.message;}

const root=ReactDOM.createRoot(document.getElementById("root"));
if(!bootError)root.render(React.createElement(App));
else root.render(<div style={{padding:32,color:"#fca5a5"}}><h2>Kayıt güvenliği nedeniyle açılış durduruldu</h2><p>{bootError}</p><p>Mevcut kayıtlar otomatik sıfırlanmadı. Verileri temizlemeyin.</p><button onClick={async()=>{try{const raw={};for(const k of [...POSGuard.KEYS,"restoreSafetyBackup","restoreJournal"])raw[k]=localStorage.getItem("pos:"+k);await saveBackupDocument("POS-HAM-KURTARMA.json",JSON.stringify(raw,null,2));}catch(e){alert(e.message);}}}>Ham kurtarma kopyasını kaydet</button><label> Doğrulanmış tam yedekten kurtar <input type="file" accept=".json" onChange={e=>{const f=e.target.files[0];if(f)jsonGeriYukle(f,(ok,msg)=>{alert(msg);if(ok)window.location.reload();});}}/></label></div>);
window.addEventListener("error",e=>{if(/Kayıt yazılamadı/.test(e.message))alert(e.message);});
