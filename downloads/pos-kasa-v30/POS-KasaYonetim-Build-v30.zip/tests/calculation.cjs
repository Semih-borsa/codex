const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const html=fs.readFileSync(__dirname+'/../pos-app/app-source.jsx','utf8');let script=html.slice(html.indexOf('function parseTR('),html.indexOf('/*',html.indexOf('function parseTR(')));script=script.slice(0,script.indexOf('\n}')+2);
const helper=html.slice(html.indexOf('function posAmount'),html.indexOf('function PosMutabakat'));const ctx=vm.createContext({POSGuard:require('../pos-app/safety.js'),fmt:n=>n.toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2}),Date,Math,Number,String,Error,parseFloat,toS:d=>d.toISOString().slice(0,10)});vm.runInContext(script+'\n'+helper,ctx);
const args={id:'g',kasa:{id:'k',bankaId:'b'},tarih:'2026-01-01',toplam:'10.000,00',vade:'2026-01-22',debitler:[{id:'d1',tarih:'2026-01-02',tutar:'3000'},{id:'d2',tarih:'2026-01-03',tutar:'2000'}]};let checks=0;
const calc=o=>ctx.posMutabakatOlustur({...args,...o});
assert.equal(calc()[0].tutar,5000);checks++;assert.equal(calc()[0].yatacakTarih,'2026-01-22');checks++;assert.equal(calc()[1].yatacakTarih,'2026-01-02');checks++;assert.equal(calc()[1].tahsilEdildi,true);checks++;assert.equal(calc({debitler:[]})[0].tutar,10000);checks++;
assert.equal(calc({toplam:'0,30',debitler:[{id:'d',tarih:'2026-01-02',tutar:'0,10'}]})[0].tutar,0.2);checks++;
assert.equal(calc({toplam:'5000'})[0].tutar,0);checks++;
for(const patch of [{toplam:'4999'},{toplam:'abc'},{toplam:'-1'},{toplam:'1x'},{toplam:'0.001'},{tarih:'2026-02-30'},{vade:'2025-12-01'},{debitler:[{id:'d',tarih:'2025-12-31',tutar:'1'}]},{debitler:[{id:'d',tarih:'2099-01-01',tutar:'1'}]}]){assert.throws(()=>calc(patch));checks++;}
const original=JSON.stringify(args);calc();assert.equal(JSON.stringify(args),original);checks++;console.log(checks+' calculation checks passed');
const babel=require('../pos-app/vendor/babel.min.js');babel.transform(html,{presets:['react']});console.log('JSX compilation passed');
let extra=0;
for(const value of ['3053,50','3053.50','3.053,50',3053.5]){
 assert.equal(ctx.posAmount(value),3053.5);extra++;
 assert.equal(ctx.posTutarGoster(value),'3.053,50');extra++;
 assert.equal(calc({toplam:value,debitler:[]})[0].tutar,3053.5);extra++;
}
assert.equal(ctx.posAmount('3053,5'),3053.5);extra++;
assert.equal(ctx.posTutarGoster(''),'');extra++;
const common={gid:'',txs:[],kasa:args.kasa,tarih:args.tarih,toplam:'3053,50',vade:args.vade,debitler:[{id:'d',tarih:'2026-01-02',tutar:'invalid draft'}],newId:'new'};
const first=ctx.posMutabakatKaydet({...common,mode:'total'});
assert.equal(first.list[0].tutar,3053.5);extra++;
assert.equal(first.list.length,1);extra++;
assert.throws(()=>ctx.posMutabakatKaydet({...common,mode:'debit'}),/Önce/);extra++;
const paid=ctx.posMutabakatKaydet({...common,mode:'debit',gid:first.id,txs:first.txs,toplam:'not saved',tarih:'2099-01-01',vade:'wrong',debitler:[{id:'d',tarih:'2026-01-02',tutar:'1000,25'}]});
assert.equal(paid.list[0].posToplam,3053.5);extra++;
assert.equal(paid.list[0].tutar,2053.25);extra++;
assert.equal(paid.list[1].tutar,1000.25);extra++;
assert.equal(paid.list[0].islemTarihi,args.tarih);extra++;
const changed=ctx.posMutabakatKaydet({...common,mode:'total',gid:paid.id,txs:paid.txs,toplam:'4000',debitler:[]});
assert.equal(changed.list[0].tutar,2999.75);extra++;
assert.equal(changed.list[1].tutar,1000.25);extra++;
assert.equal(changed.txs.length,2);extra++;
const removed=ctx.posMutabakatKaydet({...common,mode:'debit',gid:changed.id,txs:changed.txs,debitler:[]});
assert.equal(removed.list[0].tutar,4000);extra++;
assert.equal(removed.txs.length,1);extra++;
const before=JSON.stringify(paid.txs);
assert.throws(()=>ctx.posMutabakatKaydet({...common,mode:'total',gid:paid.id,txs:paid.txs,toplam:'500'}),/aşamaz/);extra++;
assert.equal(JSON.stringify(paid.txs),before);extra++;
assert.throws(()=>ctx.posMutabakatKaydet({...common,mode:'total',toplam:''}),/Toplam POS tutarını girin/);extra++;
console.log(extra+' additional amount and separate-save checks passed');

let quick=0;
const group={id:'p-kredi',mutabakatId:'p',kasaId:'k',bankaId:'b',islemTarihi:'2026-01-01',yatacakTarih:'2026-01-22',tur:'KREDİ KARTI',posToplam:3053.5,tutar:3053.5};
const qa={txs:[group],kasaId:'k',yatisTarihi:'2026-01-17',tutar:'1000,25',vadeGun:16,id:'d-new'};
assert.equal(ctx.posDebitAdaylari(qa).length,1);quick++;
const q=ctx.posYeniDebitEkle(qa);assert.equal(q.group.tutar,2053.25);quick++;assert.equal(q.debit.islemTarihi,'2026-01-01');quick++;assert.equal(q.debit.yatacakTarih,'2026-01-17');quick++;assert.equal(q.group.yatacakTarih,'2026-01-22');quick++;assert.equal(q.txs.length,2);quick++;
assert.equal(group.tutar,3053.5);quick++;
const q2=ctx.posYeniDebitEkle({...qa,txs:q.txs,id:'d-next',tutar:'53,25'});assert.equal(q2.group.tutar,2000);quick++;assert.equal(q2.txs.filter(t=>t.tur==='DEBİT KART').length,2);quick++;
for(const patch of [{tutar:'4000'},{tutar:'0'},{tutar:'-1'},{yatisTarihi:'2026-02-30'},{yatisTarihi:'2099-01-01'},{kasaId:'unknown'},{vadeGun:15},{yatisTarihi:'2025-12-31',kayitId:'p'}]){assert.throws(()=>ctx.posYeniDebitEkle({...qa,...patch}));quick++;}
assert.throws(()=>ctx.posYeniDebitEkle({...qa,txs:[group,{...group,id:'p2-kredi',mutabakatId:'p2'}]}),/Birden fazla/);quick++;
assert.equal(ctx.posYeniDebitEkle({...qa,txs:[group,{...group,id:'p2-kredi',mutabakatId:'p2'}],kayitId:'p2'}).group.mutabakatId,'p2');quick++;
assert.equal(ctx.posYeniDebitEkle({...qa,yatisTarihi:'2026-01-18',kayitId:'p'}).group.tutar,2053.25);quick++;
assert.throws(()=>ctx.posYeniDebitEkle({...qa,txs:q.txs}),/tekrarlı/);quick++;
assert.equal(ctx.posDebitAdaylari({...qa,vadeGun:0,yatisTarihi:'2026-01-01'}).length,1);quick++;
assert.equal(ctx.posDebitAdaylari({...qa,vadeGun:31,yatisTarihi:'2026-02-01'}).length,1);quick++;
assert.equal(ctx.posDebitAdaylari({...qa,vadeGun:-1}).length,0);quick++;
require('../pos-app/safety.js').validatePackage({txs:q2.txs},{cfg:{bankalar:[{id:'b',ad:'Test'}],kasalar:[{id:'k',ad:'Test',kod:'1',bankaId:'b'}],vadeGunleri:{'KREDİ KARTI':21,'DEBİT KART':16}}});quick++;
console.log(quick+' automatic debit matching and append checks passed');
